function getSpaceCnt(str, tabSize) {
	let spacesCnt = 0;
	for (let i = 0; i < str.length; i++) {
		if (str.charAt(i) === '	') {
			spacesCnt += tabSize;
		} else {
			spacesCnt++;
		}
	}
	return spacesCnt;
}
function getIndentationEditOperations(model, builder, tabSize, tabsToSpaces) {
	if (model.getLineCount() === 1 && model.getLineMaxColumn(1) === 1) {
		return;
	}
	let spaces2 = '';
	for (let i = 0; i < tabSize; i++) {
		spaces2 += ' ';
	}
	const spacesRegExp = new RegExp(spaces2, 'gi');
	for (let lineNumber = 1, lineCount = model.getLineCount(); lineNumber <= lineCount; lineNumber++) {
		let lastIndentationColumn = model.getLineFirstNonWhitespaceColumn(lineNumber);
		if (lastIndentationColumn === 0) {
			lastIndentationColumn = model.getLineMaxColumn(lineNumber);
		}
		if (lastIndentationColumn === 1) {
			continue;
		}
		const originalIndentationRange = new Range(lineNumber, 1, lineNumber, lastIndentationColumn);
		const originalIndentation = model.getValueInRange(originalIndentationRange);
		const newIndentation = tabsToSpaces ? originalIndentation.replace(/\t/gi, spaces2) : originalIndentation.replace(spacesRegExp, '	');
		builder.addEditOperation(originalIndentationRange, newIndentation);
	}
}

function generateIndent(spacesCnt, tabSize, insertSpaces) {
	spacesCnt = spacesCnt < 0 ? 0 : spacesCnt;
	let result = '';
	if (!insertSpaces) {
		const tabsCnt = Math.floor(spacesCnt / tabSize);
		spacesCnt = spacesCnt % tabSize;
		for (let i = 0; i < tabsCnt; i++) {
			result += '	';
		}
	}
	for (let i = 0; i < spacesCnt; i++) {
		result += ' ';
	}
	return result;
}

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class DetectIndentation extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.detectIndentation',
			label: localize('Detect Indentation from Content'),
			alias: 'Detect Indentation from Content',
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const modelService = accessor.get(IModelService);
		const model = editor2.getModel();
		if (!model) {
			return;
		}
		const creationOpts = modelService.getCreationOptions(model.getLanguageId(), model.uri, model.isForSimpleWidget);
		model.detectIndentation(creationOpts.insertSpaces, creationOpts.tabSize);
	}
}
registerEditorAction(DetectIndentation);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class IndentationToTabsCommand {
	constructor(selection, tabSize) {
		this.selection = selection;
		this.tabSize = tabSize;
		this.selectionId = null;
	}
	getEditOperations(model, builder) {
		this.selectionId = builder.trackSelection(this.selection);
		getIndentationEditOperations(model, builder, this.tabSize, false);
	}
	computeCursorState(model, helper) {
		return helper.getTrackedSelection(this.selectionId);
	}
}
class IndentationToTabsAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.indentationToTabs',
			label: localize('Convert Indentation to Tabs'),
			alias: 'Convert Indentation to Tabs',
			precondition: ck_writable,
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const model = editor2.getModel();
		if (!model) {
			return;
		}
		const modelOpts = model.getOptions();
		const selection = editor2.getSelection();
		if (!selection) {
			return;
		}
		const command = new IndentationToTabsCommand(selection, modelOpts.tabSize);
		editor2.pushUndoStop();
		editor2.executeCommands(this.id, [command]);
		editor2.pushUndoStop();
		model.updateOptions({ insertSpaces: false });
	}
}
registerEditorAction(IndentationToTabsAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class AutoIndentOnPasteCommand {
	constructor(edits, initialSelection) {
		this._initialSelection = initialSelection;
		this._edits = [];
		this._selectionId = null;
		for (const edit of edits) {
			if (edit.range && typeof edit.text === 'string') {
				this._edits.push(edit);
			}
		}
	}
	getEditOperations(model, builder) {
		for (const edit of this._edits) {
			builder.addEditOperation(Range.lift(edit.range), edit.text);
		}
		let selectionIsSet = false;
		if (isArray(this._edits) && this._edits.length === 1 && this._initialSelection.isEmpty()) {
			if (
				this._edits[0].range.startColumn === this._initialSelection.endColumn &&
				this._edits[0].range.startLineNumber === this._initialSelection.endLineNumber
			) {
				selectionIsSet = true;
				this._selectionId = builder.trackSelection(this._initialSelection, true);
			} else if (
				this._edits[0].range.endColumn === this._initialSelection.startColumn &&
				this._edits[0].range.endLineNumber === this._initialSelection.startLineNumber
			) {
				selectionIsSet = true;
				this._selectionId = builder.trackSelection(this._initialSelection, false);
			}
		}
		if (!selectionIsSet) {
			this._selectionId = builder.trackSelection(this._initialSelection);
		}
	}
	computeCursorState(model, helper) {
		return helper.getTrackedSelection(this._selectionId);
	}
}
class AutoIndentOnPaste {
	constructor(editor2, _languageConfigurationService) {
		this.editor = editor2;
		this._languageConfigurationService = _languageConfigurationService;
		this.callOnDispose = new DisposableStore();
		this.callOnModel = new DisposableStore();
		this.callOnDispose.add(editor2.onDidChangeConfiguration(() => this.update()));
		this.callOnDispose.add(editor2.onDidChangeModel(() => this.update()));
		this.callOnDispose.add(editor2.onDidChangeModelLanguage(() => this.update()));
	}
	update() {
		this.callOnModel.clear();
		if (
			this.editor.getOption(
				12 // autoIndent
			) < 4 ||
			this.editor.getOption(
				55 // formatOnPaste
			)
		) {
			return;
		}
		if (!this.editor.hasModel()) {
			return;
		}
		this.callOnModel.add(
			this.editor.onDidPaste(({ range: range2 }) => {
				this.trigger(range2);
			})
		);
	}
	trigger(range2) {
		const selections = this.editor.getSelections();
		if (selections === null || selections.length > 1) {
			return;
		}
		const model = this.editor.getModel();
		if (!model) {
			return;
		}
		if (!model.tokenization.isCheapToTokenize(range2.getStartPosition().lineNumber)) {
			return;
		}
		const autoIndent = this.editor.getOption(
			12 // autoIndent
		);
		const { tabSize, indentSize, insertSpaces } = model.getOptions();
		const textEdits = [];
		const indentConverter = {
			shiftIndent: indentation => {
				return ShiftCommand.shiftIndent(indentation, indentation.length + 1, tabSize, indentSize, insertSpaces);
			},
			unshiftIndent: indentation => {
				return ShiftCommand.unshiftIndent(indentation, indentation.length + 1, tabSize, indentSize, insertSpaces);
			}
		};
		let startLineNumber = range2.startLineNumber;
		while (startLineNumber <= range2.endLineNumber) {
			if (this.shouldIgnoreLine(model, startLineNumber)) {
				startLineNumber++;
				continue;
			}
			break;
		}
		if (startLineNumber > range2.endLineNumber) {
			return;
		}
		let firstLineText = model.getLineContent(startLineNumber);
		if (!/\S/.test(firstLineText.substring(0, range2.startColumn - 1))) {
			const indentOfFirstLine = getGoodIndentForLine(
				autoIndent,
				model,
				model.getLanguageId(),
				startLineNumber,
				indentConverter,
				this._languageConfigurationService
			);
			if (indentOfFirstLine !== null) {
				const oldIndentation = getLeadingWhitespace(firstLineText);
				const newSpaceCnt = getSpaceCnt(indentOfFirstLine, tabSize);
				const oldSpaceCnt = getSpaceCnt(oldIndentation, tabSize);
				if (newSpaceCnt !== oldSpaceCnt) {
					const newIndent = generateIndent(newSpaceCnt, tabSize, insertSpaces);
					textEdits.push({
						range: new Range(startLineNumber, 1, startLineNumber, oldIndentation.length + 1),
						text: newIndent
					});
					firstLineText = newIndent + firstLineText.substr(oldIndentation.length);
				} else {
					const indentMetadata = getIndentMetadata(model, startLineNumber, this._languageConfigurationService);
					if (indentMetadata === 0 || indentMetadata === 8) {
						return;
					}
				}
			}
		}
		const firstLineNumber = startLineNumber;
		while (startLineNumber < range2.endLineNumber) {
			if (!/\S/.test(model.getLineContent(startLineNumber + 1))) {
				startLineNumber++;
				continue;
			}
			break;
		}
		if (startLineNumber !== range2.endLineNumber) {
			const virtualModel = {
				tokenization: {
					getLineTokens: lineNumber => {
						return model.tokenization.getLineTokens(lineNumber);
					},
					getLanguageId: () => {
						return model.getLanguageId();
					},
					getLanguageIdAtPosition: (lineNumber, column) => {
						return model.getLanguageIdAtPosition(lineNumber, column);
					}
				},
				getLineContent: lineNumber => {
					if (lineNumber === firstLineNumber) {
						return firstLineText;
					} else {
						return model.getLineContent(lineNumber);
					}
				}
			};
			const indentOfSecondLine = getGoodIndentForLine(
				autoIndent,
				virtualModel,
				model.getLanguageId(),
				startLineNumber + 1,
				indentConverter,
				this._languageConfigurationService
			);
			if (indentOfSecondLine !== null) {
				const newSpaceCntOfSecondLine = getSpaceCnt(indentOfSecondLine, tabSize);
				const oldSpaceCntOfSecondLine = getSpaceCnt(getLeadingWhitespace(model.getLineContent(startLineNumber + 1)), tabSize);
				if (newSpaceCntOfSecondLine !== oldSpaceCntOfSecondLine) {
					const spaceCntOffset = newSpaceCntOfSecondLine - oldSpaceCntOfSecondLine;
					for (let i = startLineNumber + 1; i <= range2.endLineNumber; i++) {
						const lineContent = model.getLineContent(i);
						const originalIndent = getLeadingWhitespace(lineContent);
						const originalSpacesCnt = getSpaceCnt(originalIndent, tabSize);
						const newSpacesCnt = originalSpacesCnt + spaceCntOffset;
						const newIndent = generateIndent(newSpacesCnt, tabSize, insertSpaces);
						if (newIndent !== originalIndent) {
							textEdits.push({
								range: new Range(i, 1, i, originalIndent.length + 1),
								text: newIndent
							});
						}
					}
				}
			}
		}
		if (textEdits.length > 0) {
			this.editor.pushUndoStop();
			const cmd = new AutoIndentOnPasteCommand(textEdits, this.editor.getSelection());
			this.editor.executeCommand('autoIndentOnPaste', cmd);
			this.editor.pushUndoStop();
		}
	}
	shouldIgnoreLine(model, lineNumber) {
		model.tokenization.forceTokenization(lineNumber);
		const nonWhitespaceColumn = model.getLineFirstNonWhitespaceColumn(lineNumber);
		if (nonWhitespaceColumn === 0) {
			return true;
		}
		const tokens = model.tokenization.getLineTokens(lineNumber);
		if (tokens.getCount() > 0) {
			const firstNonWhitespaceTokenIndex = tokens.findTokenIndexAtOffset(nonWhitespaceColumn);
			if (firstNonWhitespaceTokenIndex >= 0 && tokens.getStandardTokenType(firstNonWhitespaceTokenIndex) === 1) {
				return true;
			}
		}
		return false;
	}
	dispose() {
		this.callOnDispose.dispose();
		this.callOnModel.dispose();
	}
}
__decorate([__param(1, ILanguageConfigurationService)], AutoIndentOnPaste);
registerEditorContribution(
	'editor.contrib.autoIndentOnPaste',
	AutoIndentOnPaste,
	2 //BeforeFirstInteraction
);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

function getReindentEditOperations(model, languageConfigurationService, startLineNumber, endLineNumber, inheritedIndent) {
	if (model.getLineCount() === 1 && model.getLineMaxColumn(1) === 1) {
		return [];
	}
	const indentationRules = languageConfigurationService.getLanguageConfiguration(model.getLanguageId()).indentationRules;
	if (!indentationRules) {
		return [];
	}
	endLineNumber = Math.min(endLineNumber, model.getLineCount());
	while (startLineNumber <= endLineNumber) {
		if (!indentationRules.unIndentedLinePattern) {
			break;
		}
		const text2 = model.getLineContent(startLineNumber);
		if (!indentationRules.unIndentedLinePattern.test(text2)) {
			break;
		}
		startLineNumber++;
	}
	if (startLineNumber > endLineNumber - 1) {
		return [];
	}
	const { tabSize, indentSize, insertSpaces } = model.getOptions();
	const shiftIndent = (indentation, count) => {
		count = count || 1;
		return ShiftCommand.shiftIndent(indentation, indentation.length + count, tabSize, indentSize, insertSpaces);
	};
	const unshiftIndent = (indentation, count) => {
		count = count || 1;
		return ShiftCommand.unshiftIndent(indentation, indentation.length + count, tabSize, indentSize, insertSpaces);
	};
	const indentEdits = [];
	let globalIndent;
	const currentLineText = model.getLineContent(startLineNumber);
	let adjustedLineContent = currentLineText;
	if (inheritedIndent !== undefined && inheritedIndent !== null) {
		globalIndent = inheritedIndent;
		const oldIndentation = getLeadingWhitespace(currentLineText);
		adjustedLineContent = globalIndent + currentLineText.substring(oldIndentation.length);
		if (indentationRules.decreaseIndentPattern && indentationRules.decreaseIndentPattern.test(adjustedLineContent)) {
			globalIndent = unshiftIndent(globalIndent);
			adjustedLineContent = globalIndent + currentLineText.substring(oldIndentation.length);
		}
		if (currentLineText !== adjustedLineContent) {
			indentEdits.push(
				EditOperation.replaceMove(
					new EditorSelection(startLineNumber, 1, startLineNumber, oldIndentation.length + 1),
					normalizeIndentation(globalIndent, indentSize, insertSpaces)
				)
			);
		}
	} else {
		globalIndent = getLeadingWhitespace(currentLineText);
	}
	let idealIndentForNextLine = globalIndent;
	if (indentationRules.increaseIndentPattern && indentationRules.increaseIndentPattern.test(adjustedLineContent)) {
		idealIndentForNextLine = shiftIndent(idealIndentForNextLine);
		globalIndent = shiftIndent(globalIndent);
	} else if (indentationRules.indentNextLinePattern && indentationRules.indentNextLinePattern.test(adjustedLineContent)) {
		idealIndentForNextLine = shiftIndent(idealIndentForNextLine);
	}
	startLineNumber++;
	for (let lineNumber = startLineNumber; lineNumber <= endLineNumber; lineNumber++) {
		const text2 = model.getLineContent(lineNumber);
		const oldIndentation = getLeadingWhitespace(text2);
		const adjustedLineContent2 = idealIndentForNextLine + text2.substring(oldIndentation.length);
		if (indentationRules.decreaseIndentPattern && indentationRules.decreaseIndentPattern.test(adjustedLineContent2)) {
			idealIndentForNextLine = unshiftIndent(idealIndentForNextLine);
			globalIndent = unshiftIndent(globalIndent);
		}
		if (oldIndentation !== idealIndentForNextLine) {
			indentEdits.push(
				EditOperation.replaceMove(
					new EditorSelection(lineNumber, 1, lineNumber, oldIndentation.length + 1),
					normalizeIndentation(idealIndentForNextLine, indentSize, insertSpaces)
				)
			);
		}
		if (indentationRules.unIndentedLinePattern && indentationRules.unIndentedLinePattern.test(text2)) {
			continue;
		} else if (indentationRules.increaseIndentPattern && indentationRules.increaseIndentPattern.test(adjustedLineContent2)) {
			globalIndent = shiftIndent(globalIndent);
			idealIndentForNextLine = globalIndent;
		} else if (indentationRules.indentNextLinePattern && indentationRules.indentNextLinePattern.test(adjustedLineContent2)) {
			idealIndentForNextLine = shiftIndent(idealIndentForNextLine);
		} else {
			idealIndentForNextLine = globalIndent;
		}
	}
	return indentEdits;
}

class ReindentLinesAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.reindentlines',
			label: localize('Reindent Lines'),
			alias: 'Reindent Lines',
			precondition: ck_writable,
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const languageConfigurationService = accessor.get(ILanguageConfigurationService);
		const model = editor2.getModel();
		if (!model) {
			return;
		}
		const edits = getReindentEditOperations(model, languageConfigurationService, 1, model.getLineCount());
		if (edits.length > 0) {
			editor2.pushUndoStop();
			editor2.executeEdits(this.id, edits);
			editor2.pushUndoStop();
		}
	}
}
registerEditorAction(ReindentLinesAction);

class ReindentSelectedLinesAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.reindentselectedlines',
			label: localize('Reindent Selected Lines'),
			alias: 'Reindent Selected Lines',
			precondition: ck_writable,
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const languageConfigurationService = accessor.get(ILanguageConfigurationService);
		const model = editor2.getModel();
		if (!model) {
			return;
		}
		const selections = editor2.getSelections();
		if (selections === null) {
			return;
		}
		const edits = [];
		for (const selection of selections) {
			let startLineNumber = selection.startLineNumber;
			let endLineNumber = selection.endLineNumber;
			if (startLineNumber !== endLineNumber && selection.endColumn === 1) {
				endLineNumber--;
			}
			if (startLineNumber === 1) {
				if (startLineNumber === endLineNumber) {
					continue;
				}
			} else {
				startLineNumber--;
			}
			const editOperations = getReindentEditOperations(model, languageConfigurationService, startLineNumber, endLineNumber);
			edits.push(...editOperations);
		}
		if (edits.length > 0) {
			editor2.pushUndoStop();
			editor2.executeEdits(this.id, edits);
			editor2.pushUndoStop();
		}
	}
}
registerEditorAction(ReindentSelectedLinesAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class ChangeIndentationSizeAction extends EditorAction {
	constructor(insertSpaces, displaySizeOnly, opts) {
		super(opts);
		this.insertSpaces = insertSpaces;
		this.displaySizeOnly = displaySizeOnly;
	}
	run(accessor, editor2) {
		//const quickInputService = accessor.get(IQuickInputService);
		const modelService = accessor.get(IModelService);
		const model = editor2.getModel();
		if (!model) {
			return;
		}
		const creationOpts = modelService.getCreationOptions(model.getLanguageId(), model.uri, model.isForSimpleWidget);
		const modelOpts = model.getOptions();
		const picks = [1, 2, 3, 4, 5, 6, 7, 8].map(n => ({
			id: n.toString(),
			label: n.toString(), // add description for tabSize value set in the configuration
			description:
				n === creationOpts.tabSize && n === modelOpts.tabSize
					? localize('Configured Tab Size')
					: n === creationOpts.tabSize
						? localize('Default Tab Size')
						: n === modelOpts.tabSize
							? localize('Current Tab Size')
							: undefined
		}));
		const autoFocusIndex = Math.min(model.getOptions().tabSize - 1, 7);
		setTimeout(() => {
			quickInputService
				.pick(picks, {
					placeHolder: localize('Select Tab Size for Current File'),
					activeItem: picks[autoFocusIndex]
				})
				.then(pick => {
					if (pick) {
						if (model && !model.isDisposed()) {
							const pickedVal = parseInt(pick.label, 10);
							if (this.displaySizeOnly) {
								model.updateOptions({ tabSize: pickedVal });
							} else {
								model.updateOptions({
									tabSize: pickedVal,
									indentSize: pickedVal,
									insertSpaces: this.insertSpaces
								});
							}
						}
					}
				});
		}, 50);
	}
}

class IndentUsingTabs extends ChangeIndentationSizeAction {
	constructor() {
		super(false, false, {
			id: 'editor.action.indentUsingTabs',
			label: localize('Indent Using Tabs'),
			alias: 'Indent Using Tabs',
			metadata: {}
		});
	}
}
registerEditorAction(IndentUsingTabs);

class IndentUsingSpaces extends ChangeIndentationSizeAction {
	constructor() {
		super(true, false, {
			id: 'editor.action.indentUsingSpaces',
			label: localize('Indent Using Spaces'),
			alias: 'Indent Using Spaces',
			metadata: {}
		});
	}
}
registerEditorAction(IndentUsingSpaces);

class ChangeTabDisplaySize extends ChangeIndentationSizeAction {
	constructor() {
		super(true, true, {
			id: 'editor.action.changeTabDisplaySize',
			label: localize('Change Tab Display Size'),
			alias: 'Change Tab Display Size',
			metadata: {}
		});
	}
}
registerEditorAction(ChangeTabDisplaySize);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class IndentationToSpacesCommand {
	constructor(selection, tabSize) {
		this.selection = selection;
		this.tabSize = tabSize;
		this.selectionId = null;
	}
	getEditOperations(model, builder) {
		this.selectionId = builder.trackSelection(this.selection);
		getIndentationEditOperations(model, builder, this.tabSize, true);
	}
	computeCursorState(model, helper) {
		return helper.getTrackedSelection(this.selectionId);
	}
}

class IndentationToSpacesAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.indentationToSpaces',
			label: localize('Convert Indentation to Spaces'),
			alias: 'Convert Indentation to Spaces',
			precondition: ck_writable,
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const model = editor2.getModel();
		if (!model) {
			return;
		}
		const modelOpts = model.getOptions();
		const selection = editor2.getSelection();
		if (!selection) {
			return;
		}
		const command = new IndentationToSpacesCommand(selection, modelOpts.tabSize);
		editor2.pushUndoStop();
		editor2.executeCommands(this.id, [command]);
		editor2.pushUndoStop();
		model.updateOptions({ insertSpaces: true });
	}
}
registerEditorAction(IndentationToSpacesAction);