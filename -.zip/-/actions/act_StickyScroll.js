class ToggleStickyScroll extends Action2 {
	constructor() {
		super({
			id: 'editor.action.toggleStickyScroll',
			title: localize('Toggle Editor Sticky Scroll'),
			metadata: {},
			category: localize('View'),
			toggled: {
				condition: ContextKeyExpr.equals('config.editor.stickyScroll.enabled', true),
				title: localize('Sticky Scroll')
			},
			menu: [
				{
					id: menubarAppearanceMenu_menuId,
					group: '4_editor',
					order: 3
				},
				{ id: stickyScrollContext_menuId } //
			]
		});
	}
	async run(accessor) {
		const e = accessor.get(IConfigurationService);
		return e.updateValue('editor.stickyScroll.enabled', !e.getValue('editor.stickyScroll.enabled'));
	}
}
registerEditorAction2(ToggleStickyScroll);

class FocusStickyScroll extends EditorAction2 {
	constructor() {
		super({
			id: 'editor.action.focusStickyScroll',
			title: localize('Focus on the editor sticky scroll'),
			precondition: ContextKeyExpr.and(ContextKeyExpr.has('config.editor.stickyScroll.enabled'), ck_stickyScroll_visible),
			menu: []
		});
	}
	runEditorCommand(_accessor, editor) {
		StickyScrollController2.get(editor)?.focus();
	}
}
registerEditorAction2(FocusStickyScroll);

class SelectNextStickyScrollLine extends EditorAction2 {
	constructor() {
		super({
			id: 'editor.action.selectNextStickyScrollLine',
			title: localize('Select the next editor sticky scroll line'),
			precondition: ck_stickyScroll_focused.isEqualTo(true),
			keybinding: {
				weight: 100,
				primary: 18 // DownArrow
			}
		});
	}
	runEditorCommand(_accessor, editor) {
		StickyScrollController2.get(editor)?.focusNext();
	}
}
registerEditorAction2(SelectNextStickyScrollLine);

class SelectPreviousStickyScrollLine extends EditorAction2 {
	constructor() {
		super({
			id: 'editor.action.selectPreviousStickyScrollLine',
			title: localize('Select the previous sticky scroll line'),
			precondition: ck_stickyScroll_focused.isEqualTo(true),
			keybinding: {
				weight: 100,
				primary: 16 // UpArrow
			}
		});
	}
	runEditorCommand(_accessor, editor) {
		StickyScrollController2.get(editor)?.focusPrevious();
	}
}
registerEditorAction2(SelectPreviousStickyScrollLine);

class GoToStickyScrollLine extends EditorAction2 {
	constructor() {
		super({
			id: 'editor.action.goToFocusedStickyScrollLine',
			title: localize('Go to the focused sticky scroll line'),
			precondition: ck_stickyScroll_focused.isEqualTo(true),
			keybinding: {
				weight: 100,
				primary: 3 // Enter
			}
		});
	}
	runEditorCommand(_accessor, editor) {
		StickyScrollController2.get(editor)?.goToFocused();
	}
}
registerEditorAction2(GoToStickyScrollLine);

