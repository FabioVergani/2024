
class ToggleTabFocusModeAction extends Action2 {
	constructor() {
		super({
			id: 'editor.action.toggleTabFocusMode',
			title: localize('Toggle Tab Key Moves Focus'),
			keybinding: {
				primary: 2048 | 43,
				mac: {
					primary: 256 | 1024 | 43 //KeyCode.KeyM
				},
				weight: 100 //editorContrib
			},
			metadata: {
				description: localize(
					'Determines whether the tab key moves focus around the workbench or inserts the tab character in the current editor. This is also called tab trapping, tab navigation, or tab focus mode.'
				)
			},
			f1: true
		});
	}
	run() {
		const oldValue = tabFocus.getTabFocusMode();
		const newValue = !oldValue;
		tabFocus.setTabFocusMode(newValue);
		if (newValue) {
			alert(localize('Pressing Tab will now move focus to the next focusable element'));
		} else {
			alert(localize('Pressing Tab will now insert the tab character'));
		}
	}
}
registerEditorAction2(ToggleTabFocusModeAction);