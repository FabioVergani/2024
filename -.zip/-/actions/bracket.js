class JumpToBracketAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.jumpToBracket',
			label: localize('Go to Bracket'),
			alias: 'Go to Bracket',
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 1024 | 93,
				weight: 100 //editorContrib
			}
		});
	}
	run(accessor, editor2) {
		BracketMatchingController.get(editor2)?.jumpToBracket();
	}
}
registerEditorAction(JumpToBracketAction);

class SelectToBracketAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.selectToBracket',
			label: localize('Select to Bracket'),
			alias: 'Select to Bracket',
			metadata: {
				args: [
					{
						name: 'args',
						schema: {
							type: 'object',
							properties: {
								selectBrackets: {
									type: 'boolean',
									default: true
								}
							}
						}
					}
				]
			}
		});
	}
	run(accessor, editor2, args) {
		let selectBrackets = true;
		if (args && args.selectBrackets === false) {
			selectBrackets = false;
		}
		BracketMatchingController.get(editor2)?.selectToBracket(selectBrackets);
	}
}
registerEditorAction(SelectToBracketAction);

class RemoveBracketsAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.removeBrackets',
			label: localize('Remove Brackets'),
			alias: 'Remove Brackets',
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 512 | 1,
				weight: 100 //editorContrib
			}
		});
	}
	run(accessor, editor2) {
		BracketMatchingController.get(editor2)?.removeBrackets(this.id);
	}
}
registerEditorAction(RemoveBracketsAction);