class EditorFontZoomIn extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.fontZoomIn',
			label: localize('Increase Editor Font Size'),
			alias: 'Increase Editor Font Size'
		});
	}
	run(accessor, editor2) {
		editorZoom.setZoomLevel(editorZoom.getZoomLevel() + 1);
	}
}
class EditorFontZoomOut extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.fontZoomOut',
			label: localize('Decrease Editor Font Size'),
			alias: 'Decrease Editor Font Size'
		});
	}
	run(accessor, editor2) {
		editorZoom.setZoomLevel(editorZoom.getZoomLevel() - 1);
	}
}
class EditorFontZoomReset extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.fontZoomReset',
			label: localize('Reset Editor Font Size'),
			alias: 'Reset Editor Font Size'
		});
	}
	run(accessor, editor2) {
		editorZoom.setZoomLevel(0);
	}
}
registerEditorAction(EditorFontZoomIn);
registerEditorAction(EditorFontZoomOut);
registerEditorAction(EditorFontZoomReset);
