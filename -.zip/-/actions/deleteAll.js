class AbstractDeleteAllToBoundaryAction extends EditorAction {
	run(_accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const primaryCursor = editor2.getSelection();
		const rangesToDelete = this._getRangesToDelete(editor2);
		const effectiveRanges = [];
		for (let i = 0, count = rangesToDelete.length - 1; i < count; i++) {
			const range2 = rangesToDelete[i];
			const nextRange = rangesToDelete[i + 1];
			if (Range.intersectRanges(range2, nextRange) === null) {
				effectiveRanges.push(range2);
			} else {
				rangesToDelete[i + 1] = Range.plusRange(range2, nextRange);
			}
		}
		effectiveRanges.push(rangesToDelete[rangesToDelete.length - 1]);
		const endCursorState = this._getEndCursorState(primaryCursor, effectiveRanges);
		const edits = effectiveRanges.map(range2 => {
			return EditOperation.replace(range2, '');
		});
		editor2.pushUndoStop();
		editor2.executeEdits(this.id, edits, endCursorState);
		editor2.pushUndoStop();
	}
}

class DeleteAllLeftAction extends AbstractDeleteAllToBoundaryAction {
	constructor() {
		super({
			id: 'deleteAllLeft',
			label: localize('Delete All Left'),
			alias: 'Delete All Left',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_inputFocus_text,
				primary: 0,
				mac: {
					primary: 2048 | 1 // Backspace
				},
				weight: 100 //editorContrib
			}
		});
	}
	_getEndCursorState(primaryCursor, rangesToDelete) {
		let endPrimaryCursor = null;
		const endCursorState = [];
		let deletedLines = 0;
		rangesToDelete.forEach(range2 => {
			let endCursor;
			if (range2.endColumn === 1 && deletedLines > 0) {
				const newStartLine = range2.startLineNumber - deletedLines;
				endCursor = new EditorSelection(newStartLine, range2.startColumn, newStartLine, range2.startColumn);
			} else {
				endCursor = new EditorSelection(range2.startLineNumber, range2.startColumn, range2.startLineNumber, range2.startColumn);
			}
			deletedLines += range2.endLineNumber - range2.startLineNumber;
			if (range2.intersectRanges(primaryCursor)) {
				endPrimaryCursor = endCursor;
			} else {
				endCursorState.push(endCursor);
			}
		});
		if (endPrimaryCursor) {
			endCursorState.unshift(endPrimaryCursor);
		}
		return endCursorState;
	}
	_getRangesToDelete(editor2) {
		const selections = editor2.getSelections();
		if (selections === null) {
			return [];
		}
		let rangesToDelete = selections;
		const model = editor2.getModel();
		if (model === null) {
			return [];
		}
		rangesToDelete.sort(Range.compareRangesUsingStarts);
		rangesToDelete = rangesToDelete.map(selection => {
			if (selection.isEmpty()) {
				if (selection.startColumn === 1) {
					const deleteFromLine = Math.max(1, selection.startLineNumber - 1);
					const deleteFromColumn = selection.startLineNumber === 1 ? 1 : model.getLineLength(deleteFromLine) + 1;
					return new Range(deleteFromLine, deleteFromColumn, selection.startLineNumber, 1);
				} else {
					return new Range(selection.startLineNumber, 1, selection.startLineNumber, selection.startColumn);
				}
			} else {
				return new Range(selection.startLineNumber, 1, selection.endLineNumber, selection.endColumn);
			}
		});
		return rangesToDelete;
	}
}
registerEditorAction(DeleteAllLeftAction);

class DeleteAllRightAction extends AbstractDeleteAllToBoundaryAction {
	constructor() {
		super({
			id: 'deleteAllRight',
			label: localize('Delete All Right'),
			alias: 'Delete All Right',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_inputFocus_text,
				primary: 0,
				mac: {
					primary: 256 | 41,
					secondary: [
						2048 | 20 // Delete
					]
				},
				weight: 100 //editorContrib
			}
		});
	}
	_getEndCursorState(primaryCursor, rangesToDelete) {
		let endPrimaryCursor = null;
		const endCursorState = [];
		for (let i = 0, len = rangesToDelete.length, offset = 0; i < len; i++) {
			const range2 = rangesToDelete[i];
			const endCursor = new EditorSelection(
				range2.startLineNumber - offset,
				range2.startColumn,
				range2.startLineNumber - offset,
				range2.startColumn
			);
			if (range2.intersectRanges(primaryCursor)) {
				endPrimaryCursor = endCursor;
			} else {
				endCursorState.push(endCursor);
			}
		}
		if (endPrimaryCursor) {
			endCursorState.unshift(endPrimaryCursor);
		}
		return endCursorState;
	}
	_getRangesToDelete(editor2) {
		const model = editor2.getModel();
		if (model === null) {
			return [];
		}
		const selections = editor2.getSelections();
		if (selections === null) {
			return [];
		}
		const rangesToDelete = selections.map(sel => {
			if (sel.isEmpty()) {
				const maxColumn = model.getLineMaxColumn(sel.startLineNumber);
				if (sel.startColumn === maxColumn) {
					return new Range(sel.startLineNumber, sel.startColumn, sel.startLineNumber + 1, 1);
				} else {
					return new Range(sel.startLineNumber, sel.startColumn, sel.startLineNumber, maxColumn);
				}
			}
			return sel;
		});
		rangesToDelete.sort(Range.compareRangesUsingStarts);
		return rangesToDelete;
	}
}
registerEditorAction(DeleteAllRightAction);
