class ToggleHighContrast extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.toggleHighContrast',
			label: localize('Toggle High Contrast Theme'),
			alias: 'Toggle High Contrast Theme'
		});
		this._originalThemeName = null;
	}
	run(accessor) {
		const standaloneThemeService = accessor.get(IStandaloneThemeService);
		const theme = standaloneThemeService.getColorTheme();
		if (isHighContrast(theme.type)) {
			standaloneThemeService.setTheme(this._originalThemeName || (isDark(theme.type) ? themeName_DARK : themeName_LIGHT));
			this._originalThemeName = null;
		} else {
			standaloneThemeService.setTheme(isDark(theme.type) ? themeName_DARK_HC : themeName_LIGHT_HC);
			this._originalThemeName = theme.themeName;
		}
	}
}

registerEditorAction(ToggleHighContrast);