class AbstractSmartSelect extends EditorAction {
	constructor(forward, opts) {
		super(opts);
		this._forward = forward;
	}
	async run(_accessor, editor2) {
		const controller = SmartSelectController.get(editor2);
		if (controller) {
			await controller.run(this._forward);
		}
	}
}

class GrowSelectionAction extends AbstractSmartSelect {
	constructor() {
		super(true, {
			id: 'editor.action.smartSelect.expand',
			label: localize('Expand EditorSelection'),
			alias: 'Expand EditorSelection',
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 1024 | 512 | 17,
				mac: {
					primary: 2048 | 256 | 1024 | 17,
					secondary: [
						256 | 1024 | 17 //KeyCode.RightArrow
					]
				},
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: menubarSelectionMenu_menuId,
				group: '1_basic',
				title: localize('&&Expand EditorSelection'),
				order: 2
			}
		});
	}
}
registerEditorAction(GrowSelectionAction);

class ShrinkSelectionAction extends AbstractSmartSelect {
	constructor() {
		super(false, {
			id: 'editor.action.smartSelect.shrink',
			label: localize('Shrink EditorSelection'),
			alias: 'Shrink EditorSelection',
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 1024 | 512 | 15,
				mac: {
					primary: 2048 | 256 | 1024 | 15,
					secondary: [
						256 | 1024 | 15 //KeyCode.LeftArrow
					]
				},
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: menubarSelectionMenu_menuId,
				group: '1_basic',
				title: localize('&&Shrink EditorSelection'),
				order: 3
			}
		});
	}
}
registerEditorAction(ShrinkSelectionAction);