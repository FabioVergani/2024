class AbstractCaseAction extends EditorAction {
	run(_accessor, editor) {
		const selections = editor.getSelections();
		if (selections) {
			const model = editor.getModel();
			if (model) {
				const wordSeparators2 = editor.getOption(
					131 // wordSeparators
				);
				const textEdits = [];
				for (const selection of selections) {
					if (selection.isEmpty()) {
						const cursor = selection.getStartPosition();
						const word = editor.getConfiguredWordAtPosition(cursor);
						if (!word) {
							continue;
						}
						const wordRange = new Range(cursor.lineNumber, word.startColumn, cursor.lineNumber, word.endColumn);
						const text2 = model.getValueInRange(wordRange);
						textEdits.push(EditOperation.replace(wordRange, this._modifyText(text2, wordSeparators2)));
					} else {
						const text2 = model.getValueInRange(selection);
						textEdits.push(EditOperation.replace(selection, this._modifyText(text2, wordSeparators2)));
					}
				}
				editor.pushUndoStop();
				editor.executeEdits(this.id, textEdits);
				editor.pushUndoStop();
			}
		}
	}
}

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class UpperCaseAction extends AbstractCaseAction {
	constructor() {
		super({
			id: 'editor.action.transformToUppercase',
			label: localize('Transform to Uppercase'),
			alias: 'Transform to Uppercase',
			precondition: ck_writable
		});
	}
	_modifyText(str) {
		return str.toLocaleUpperCase();
	}
}
registerEditorAction(UpperCaseAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class LowerCaseAction extends AbstractCaseAction {
	constructor() {
		super({
			id: 'editor.action.transformToLowercase',
			label: localize('Transform to Lowercase'),
			alias: 'Transform to Lowercase',
			precondition: ck_writable
		});
	}
	_modifyText(str) {
		return str.toLocaleLowerCase();
	}
}
registerEditorAction(LowerCaseAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const titleBoundaryRE = /(^|[^\p{L}\p{N}']|((^|\P{L})'))\p{L}/gmu;
class TitleCaseAction extends AbstractCaseAction {
	constructor() {
		super({
			id: 'editor.action.transformToTitlecase',
			label: localize('Transform to Title Case'),
			alias: 'Transform to Title Case',
			precondition: ck_writable
		});
	}
	_modifyText(str) {
		return str.toLocaleLowerCase().replace(titleBoundaryRE, e => e.toLocaleUpperCase());
	}
}
registerEditorAction(TitleCaseAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const caseBoundaryRE = /(\p{Ll})(\p{Lu})/gmu;
const singleLettersRE = /(\p{Lu}|\p{N})(\p{Lu})(\p{Ll})/gmu;
class SnakeCaseAction extends AbstractCaseAction {
	constructor() {
		super({
			id: 'editor.action.transformToSnakecase',
			label: localize('Transform to Snake Case'),
			alias: 'Transform to Snake Case',
			precondition: ck_writable
		});
	}
	_modifyText(str) {
		return str.replace(caseBoundaryRE, '$1_$2').replace(singleLettersRE, '$1_$2$3').toLocaleLowerCase();
	}
}
registerEditorAction(SnakeCaseAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const camelCaseWordBoundaryRE = /[_\s-]/gm;
class CamelCaseAction extends AbstractCaseAction {
	constructor() {
		super({
			id: 'editor.action.transformToCamelcase',
			label: localize('Transform to Camel Case'),
			alias: 'Transform to Camel Case',
			precondition: ck_writable
		});
	}
	_modifyText(str) {
		const words = str.split(camelCaseWordBoundaryRE);
		const firstWord = words.shift();
		return firstWord + words.map(e => e.substring(0, 1).toLocaleUpperCase() + e.substring(1)).join('');
	}
}
registerEditorAction(CamelCaseAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const pascalCaseWordBoundaryRE = /[_\s-]/gm;
const pascalCaseWordBoundaryToMaintainRE = /(?<=\.)/gm;
class PascalCaseAction extends AbstractCaseAction {
	constructor() {
		super({
			id: 'editor.action.transformToPascalcase',
			label: localize('Transform to Pascal Case'),
			alias: 'Transform to Pascal Case',
			precondition: ck_writable
		});
	}
	_modifyText(str) {
		return str
			.split(pascalCaseWordBoundaryToMaintainRE)
			.map(e => e.split(pascalCaseWordBoundaryRE))
			.flat()
			.map(e => e.substring(0, 1).toLocaleUpperCase() + e.substring(1))
			.join('');
	}
}
registerEditorAction(PascalCaseAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const kebabCaseBoundaryRE = /(\p{Ll})(\p{Lu})/gmu;
const kebabCaseSingleLettersRE = /(\p{Lu}|\p{N})(\p{Lu}\p{Ll})/gmu;
const kebabCaseUnderscoreBoundaryRE = /(\S)(_)(\S)/gm;
class KebabCaseAction extends AbstractCaseAction {
	constructor() {
		super({
			id: 'editor.action.transformToKebabcase',
			label: localize('Transform to Kebab Case'),
			alias: 'Transform to Kebab Case',
			precondition: ck_writable
		});
	}
	_modifyText(str) {
		return str
			.replace(kebabCaseUnderscoreBoundaryRE, '$1-$3')
			.replace(kebabCaseBoundaryRE, '$1-$2')
			.replace(kebabCaseSingleLettersRE, '$1-$2')
			.toLocaleLowerCase();
	}
}
registerEditorAction(KebabCaseAction);