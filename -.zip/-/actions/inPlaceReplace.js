const inPlaceReplaceController_options = ModelDecorationOptions.register({
	description: 'in-place-replace',
	className: 'valueSetReplacement'
});
const inPlaceReplaceController_id = 'editor.contrib.inPlaceReplaceController';
class InPlaceReplaceController {
	static get(editor) {
		return editor.getContribution(inPlaceReplaceController_id);
	}
	constructor(editor2, editorWorkerService) {
		this.editor = editor2;
		this.editorWorkerService = editorWorkerService;
		this.decorations = this.editor.createDecorationsCollection();
	}
	dispose() {}
	run(source, up) {
		this.currentRequest?.cancel();
		const editorSelection = this.editor.getSelection();
		const model = this.editor.getModel();
		if (!model || !editorSelection) {
			return;
		}
		let selection = editorSelection;
		if (selection.startLineNumber !== selection.endLineNumber) {
			return;
		}
		const state = new EditorState(this.editor, 1 | 4 /* CodeEditorStateFlag.Position */);
		const modelURI = model.uri;
		if (!this.editorWorkerService.canNavigateValueSet(modelURI)) {
			return Promise.resolve(undefined);
		}
		this.currentRequest = createCancelablePromise(token => this.editorWorkerService.navigateValueSet(modelURI, selection, up));
		return this.currentRequest
			.then(result => {
				if (!result || !result.range || !result.value || !state.validate(this.editor)) {
					return;
				}
				const editRange = Range.lift(result.range);
				let highlightRange = result.range;
				const diff = result.value.length - (selection.endColumn - selection.startColumn);
				highlightRange = {
					startLineNumber: highlightRange.startLineNumber,
					startColumn: highlightRange.startColumn,
					endLineNumber: highlightRange.endLineNumber,
					endColumn: highlightRange.startColumn + result.value.length
				};
				if (diff > 1) {
					selection = new EditorSelection(
						selection.startLineNumber,
						selection.startColumn,
						selection.endLineNumber,
						selection.endColumn + diff - 1
					);
				}
				const command = new InPlaceReplaceCommand(editRange, selection, result.value);
				this.editor.pushUndoStop();
				this.editor.executeCommand(source, command);
				this.editor.pushUndoStop();
				this.decorations.set([
					{
						range: highlightRange,
						options: inPlaceReplaceController_options
					}
				]);
				this.decorationRemover?.cancel();
				this.decorationRemover = timeout(350);
				this.decorationRemover.then(() => this.decorations.clear()).catch(onUnexpectedError);
			})
			.catch(onUnexpectedError);
	}
}
__decorate([__param(1, IEditorWorkerService)], InPlaceReplaceController);
registerEditorContribution(
	inPlaceReplaceController_id,
	InPlaceReplaceController,
	4 // Lazy
);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class InPlaceReplaceUp extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.inPlaceReplace.up',
			label: localize('Replace with Previous Value'),
			alias: 'Replace with Previous Value',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 1024 | 87,
				weight: 100 //editorContrib
			}
		});
	}
	run(accessor, editor) {
		const controller = InPlaceReplaceController.get(editor);
		if (!controller) {
			return Promise.resolve(undefined);
		}
		return controller.run(this.id, false);
	}
}
registerEditorAction(InPlaceReplaceUp);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class InPlaceReplaceDown extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.inPlaceReplace.down',
			label: localize('Replace with Next Value'),
			alias: 'Replace with Next Value',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 1024 | 89,
				weight: 100 //editorContrib
			}
		});
	}
	run(accessor, editor) {
		const controller = InPlaceReplaceController.get(editor);
		if (!controller) {
			return Promise.resolve(undefined);
		}
		return controller.run(this.id, true);
	}
}
registerEditorAction(InPlaceReplaceDown);
