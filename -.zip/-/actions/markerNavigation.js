class MarkerList {
	constructor(resourceFilter, _markerService, _configService) {
		this._markerService = _markerService;
		this._configService = _configService;
		this._onDidChange = new Emitter();
		this.onDidChange = this._onDidChange.event;
		this._dispoables = new DisposableStore();
		this._markers = [];
		this._nextIdx = -1;
		if (URI.isUri(resourceFilter)) {
			this._resourceFilter = uri => uri.toString() === resourceFilter.toString();
		} else if (resourceFilter) {
			this._resourceFilter = resourceFilter;
		}
		const compareOrder = this._configService.getValue('problems.sortOrder');
		const compareMarker = (a, b) => {
			let res = compare(a.resource.toString(), b.resource.toString());
			if (res === 0) {
				if (compareOrder === 'position') {
					res = Range.compareRangesUsingStarts(a, b) || markerSeverityCompare(a.severity, b.severity);
				} else {
					res = markerSeverityCompare(a.severity, b.severity) || Range.compareRangesUsingStarts(a, b);
				}
			}
			return res;
		};
		const updateMarker = () => {
			this._markers = this._markerService.read({
				resource: URI.isUri(resourceFilter) ? resourceFilter : undefined,
				severities: 8 | 4 | 2
			});
			if (typeof resourceFilter === 'function') {
				this._markers = this._markers.filter(m => this._resourceFilter(m.resource));
			}
			this._markers.sort(compareMarker);
		};
		updateMarker();
		this._dispoables.add(
			_markerService.onMarkerChanged(uris => {
				if (!this._resourceFilter || uris.some(uri => this._resourceFilter(uri))) {
					updateMarker();
					this._nextIdx = -1;
					this._onDidChange.fire();
				}
			})
		);
	}
	dispose() {
		this._dispoables.dispose();
		this._onDidChange.dispose();
	}
	matches(uri) {
		if (!this._resourceFilter && !uri) {
			return true;
		}
		if (!this._resourceFilter || !uri) {
			return false;
		}
		return this._resourceFilter(uri);
	}
	get selected() {
		const marker = this._markers[this._nextIdx];
		if (marker) {
			return {
				marker: marker,
				index: this._nextIdx + 1,
				total: this._markers.length
			};
		}
	}
	_initIdx(model, position, fwd) {
		let found = false;
		let idx = this._markers.findIndex(marker => marker.resource.toString() === model.uri.toString());
		if (idx < 0) {
			idx = binarySearch(this._markers, { resource: model.uri }, (a, b) => compare(a.resource.toString(), b.resource.toString()));
			if (idx < 0) {
				idx = ~idx;
			}
		}
		for (let i = idx; i < this._markers.length; i++) {
			let range2 = Range.lift(this._markers[i]);
			if (range2.isEmpty()) {
				const word = model.getWordAtPosition(range2.getStartPosition());
				if (word) {
					range2 = new Range(range2.startLineNumber, word.startColumn, range2.startLineNumber, word.endColumn);
				}
			}
			if (position && (range2.containsPosition(position) || position.isBeforeOrEqual(range2.getStartPosition()))) {
				this._nextIdx = i;
				found = true;
				break;
			}
			if (this._markers[i].resource.toString() !== model.uri.toString()) {
				break;
			}
		}
		if (!found) {
			this._nextIdx = fwd ? 0 : this._markers.length - 1;
		}
		if (this._nextIdx < 0) {
			this._nextIdx = this._markers.length - 1;
		}
	}
	resetIndex() {
		this._nextIdx = -1;
	}
	move(fwd, model, position) {
		if (this._markers.length === 0) {
			return false;
		}
		const oldIdx = this._nextIdx;
		if (this._nextIdx === -1) {
			this._initIdx(model, position, fwd);
		} else if (fwd) {
			this._nextIdx = (this._nextIdx + 1) % this._markers.length;
		} else if (!fwd) {
			this._nextIdx = (this._nextIdx - 1 + this._markers.length) % this._markers.length;
		}
		if (oldIdx !== this._nextIdx) {
			return true;
		}
		return false;
	}
	find(uri, position) {
		let i = this._markers.findIndex(marker => marker.resource.toString() === uri.toString());
		if (i < 0) {
			return;
		}
		for (; i < this._markers.length; i++) {
			if (Range.containsPosition(this._markers[i], position)) {
				return {
					marker: this._markers[i],
					index: i + 1,
					total: this._markers.length
				};
			}
		}
		return;
	}
}
__decorate([__param(1, IMarkerService), __param(2, IConfigurationService)], MarkerList);
class MarkerNavigationService {
	constructor(_markerService, _configService) {
		this._markerService = _markerService;
		this._configService = _configService;
		this._provider = new LinkedList();
	}
	getMarkerList(resource) {
		for (const provider of this._provider) {
			const result = provider.getMarkerList(resource);
			if (result) {
				return result;
			}
		}
		return new MarkerList(resource, this._markerService, this._configService);
	}
}
__decorate([__param(0, IMarkerService), __param(1, IConfigurationService)], MarkerNavigationService);


registerSingleton(
	IMarkerNavigationService,
	MarkerNavigationService,
	1 //InstantiationType.Delayed
);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class MessageWidget2 {
	constructor(parent, editor2, onRelatedInformation, _openerService, _labelService) {
		this._openerService = _openerService;
		this._labelService = _labelService;
		this._lines = 0;
		this._longestLineLength = 0;
		this._relatedDiagnostics = new WeakMap();
		this._disposables = new DisposableStore();
		this._editor = editor2;
		const domNode = document.createElement('div');
		domNode.className = 'descriptioncontainer';
		this._messageBlock = document.createElement('div');
		this._messageBlock.classList.add('message');
		domNode.appendChild(this._messageBlock);
		this._relatedBlock = document.createElement('div');
		domNode.appendChild(this._relatedBlock);
		this._disposables.add(
			addStandardDisposableListener(this._relatedBlock, 'click', event => {
				event.preventDefault();
				const related = this._relatedDiagnostics.get(event.target);
				if (related) {
					onRelatedInformation(related);
				}
			})
		);
		this._scrollable = new ScrollableElement(domNode, {
			horizontal: 1,
			vertical: 1,
			useShadows: false,
			horizontalScrollbarSize: 6,
			verticalScrollbarSize: 6
		});
		parent.appendChild(this._scrollable.getDomNode());
		this._disposables.add(
			this._scrollable.onScroll(e => {
				domNode.style.left = `-${e.scrollLeft}px`;
				domNode.style.top = `-${e.scrollTop}px`;
			})
		);
		this._disposables.add(this._scrollable);
	}
	dispose() {
		dispose(this._disposables);
	}
	update(marker) {
		const { source, message, relatedInformation, code } = marker;
		let sourceAndCodeLength = (source?.length || 0) + '()'.length;
		if (code) {
			if (typeof code === 'string') {
				sourceAndCodeLength += code.length;
			} else {
				sourceAndCodeLength += code.value.length;
			}
		}
		const lines = splitLines(message);
		this._lines = lines.length;
		this._longestLineLength = 0;
		for (const line of lines) {
			this._longestLineLength = Math.max(line.length + sourceAndCodeLength, this._longestLineLength);
		}
		clearNode(this._messageBlock);
		this._editor.applyFontInfo(this._messageBlock);
		let lastLineElement = this._messageBlock;
		for (const line of lines) {
			lastLineElement = document.createElement('div');
			lastLineElement.innerText = line;
			if (line === '') {
				lastLineElement.style.height = this._messageBlock.style.lineHeight;
			}
			this._messageBlock.appendChild(lastLineElement);
		}
		if (source || code) {
			const detailsElement = document.createElement('span');
			detailsElement.classList.add('details');
			lastLineElement.appendChild(detailsElement);
			if (source) {
				const sourceElement = document.createElement('span');
				sourceElement.innerText = source;
				sourceElement.classList.add('source');
				detailsElement.appendChild(sourceElement);
			}
			if (code) {
				if (typeof code === 'string') {
					const codeElement = document.createElement('span');
					codeElement.innerText = `(${code})`;
					codeElement.classList.add('code');
					detailsElement.appendChild(codeElement);
				} else {
					this._codeLink = $('a.code-link');
					this._codeLink.setAttribute('href', `${code.target.toString()}`);
					this._codeLink.onclick = e => {
						this._openerService.open(code.target, {
							allowCommands: true
						});
						e.preventDefault();
						e.stopPropagation();
					};
					const codeElement = append(this._codeLink, $('span'));
					codeElement.innerText = code.value;
					detailsElement.appendChild(this._codeLink);
				}
			}
		}
		clearNode(this._relatedBlock);
		this._editor.applyFontInfo(this._relatedBlock);
		if (isArrayAndHasLength(relatedInformation)) {
			const relatedInformationNode = this._relatedBlock.appendChild(document.createElement('div'));
			relatedInformationNode.style.paddingTop = `${Math.floor(
				this._editor.getOption(
					67 // lineHeight
				) * 0.66
			)}px`;
			this._lines += 1;
			for (const related of relatedInformation) {
				const container = document.createElement('div');
				const relatedResource = document.createElement('a');
				relatedResource.classList.add('filename');
				relatedResource.innerText = `${this._labelService.getUriBasenameLabel(related.resource)}(${related.startLineNumber}, ${related.startColumn}): `;
				relatedResource.title = this._labelService.getUriLabel(related.resource);
				this._relatedDiagnostics.set(relatedResource, related);
				const relatedMessage = document.createElement('span');
				relatedMessage.innerText = related.message;
				container.appendChild(relatedResource);
				container.appendChild(relatedMessage);
				this._lines += 1;
				relatedInformationNode.appendChild(container);
			}
		}
		const fontInfo = this._editor.getOption(
			50 // fontInfo
		);
		const scrollWidth = Math.ceil(fontInfo.typicalFullwidthCharacterWidth * this._longestLineLength * 0.75);
		const scrollHeight = fontInfo.lineHeight * this._lines;
		this._scrollable.setScrollDimensions({ scrollWidth, scrollHeight });
	}
	layout(height, width2) {
		this._scrollable.getDomNode().style.height = `${height}px`;
		this._scrollable.getDomNode().style.width = `${width2}px`;
		this._scrollable.setScrollDimensions({ width: width2, height });
	}
	getHeightInLines() {
		return Math.min(17, this._lines);
	}
}
class MarkerNavigationWidget extends PeekViewWidget {
	constructor(editor2, _themeService, _openerService, _menuService, instantiationService, _contextKeyService, _labelService) {
		super(
			editor2,
			{
				showArrow: true,
				showFrame: true,
				isAccessible: true,
				frameWidth: 1
			},
			instantiationService
		);
		this._themeService = _themeService;
		this._openerService = _openerService;
		this._menuService = _menuService;
		this._contextKeyService = _contextKeyService;
		this._labelService = _labelService;
		this._callOnDispose = new DisposableStore();
		this._onDidSelectRelatedInformation = new Emitter();
		this.onDidSelectRelatedInformation = this._onDidSelectRelatedInformation.event;
		this._severity = 4;
		this._backgroundColor = colorWhite;
		this._applyTheme(_themeService.getColorTheme());
		this._callOnDispose.add(_themeService.onDidColorThemeChange(this._applyTheme.bind(this)));
		this.create();
	}
	_applyTheme(theme) {
		this._backgroundColor = theme.getColor(colorId_markerNavigation_background);
		let colorId = colorId_narkerNavigationError_background;
		let headerBackground = colorId_narkerNavigationError_headerBackground;
		if (this._severity === 4) {
			colorId = colorId_narkerNavigationWarning_background;
			headerBackground = colorId_narkerNavigationWarning_headerBackground;
		} else if (this._severity === 2) {
			colorId = colorId_markerNavigationInfo_background;
			headerBackground = colorId_markerNavigationInfo_headerBackground;
		}
		const frameColor = theme.getColor(colorId);
		const headerBg = theme.getColor(headerBackground);
		this.style({
			arrowColor: frameColor,
			frameColor,
			headerBackgroundColor: headerBg,
			primaryHeadingColor: theme.getColor(colorId_peekViewTitle_foreground),
			secondaryHeadingColor: theme.getColor(colorId_peekViewTitleDescription_foreground)
		});
	}
	_applyStyles() {
		if (this._parentContainer) {
			this._parentContainer.style.backgroundColor = this._backgroundColor ? this._backgroundColor.toString() : '';
		}
		super._applyStyles();
	}
	dispose() {
		this._callOnDispose.dispose();
		super.dispose();
	}
	_fillHead(container) {
		super._fillHead(container);
		this._disposables.add(this._actionbarWidget.actionRunner.onWillRun(e => this.editor.focus()));
		const actions = [];
		const menu = this._menuService.createMenu(gotoErrorTitle_menuId, this._contextKeyService);
		createAndFillInActionBarActions(menu, undefined, actions);
		this._actionbarWidget.push(actions, {
			label: false,
			icon: true,
			index: 0
		});
		menu.dispose();
	}
	_fillTitleIcon(container) {
		this._icon = append(container, $(''));
	}
	_fillBody(container) {
		this._parentContainer = container;
		container.classList.add('marker-widget');
		this._parentContainer.tabIndex = 0;
		this._parentContainer.setAttribute('role', 'tooltip');
		this._container = document.createElement('div');
		container.appendChild(this._container);
		this._message = new MessageWidget2(
			this._container,
			this.editor,
			related => this._onDidSelectRelatedInformation.fire(related),
			this._openerService,
			this._labelService
		);
		this._disposables.add(this._message);
	}
	show() {
		throw new Error('call showAtMarker');
	}
	showAtMarker(marker, markerIdx, markerCount) {
		this._container.classList.remove('stale');
		this._message.update(marker);
		this._severity = marker.severity;
		this._applyTheme(this._themeService.getColorTheme());
		const range2 = Range.lift(marker);
		const editorPosition = this.editor.getPosition();
		const position = editorPosition && range2.containsPosition(editorPosition) ? editorPosition : range2.getStartPosition();
		super.show(position, this.computeRequiredHeight());
		const model = this.editor.getModel();
		if (model) {
			const detail = markerCount > 1 ? localize(markerIdx, markerCount) : localize(markerIdx, markerCount);
			this.setTitle(basename2(model.uri), detail);
		}
		function _toSeverity(severity) {
			switch (severity) {
				case 8:
					return 3;
				case 4:
					return 2;
				case 2:
					return 1;
				case 1:
					return 0;
			}
		}
		function _severityIconClassName(severity) {
			switch (severity) {
				case 0:
					return 'severity-ignore ' + asThemeIconClassNameString(codicon_info);
				case 1:
					return asThemeIconClassNameString(codicon_info);
				case 2:
					return asThemeIconClassNameString(codicon_warning);
				case 3:
					return asThemeIconClassNameString(codicon_error);
				default:
					return '';
			}
		}
		this._icon.className = `codicon ${_severityIconClassName(_toSeverity(this._severity))}`;
		this.editor.revealPositionNearTop(
			position,
			0 // Smooth
		);
		this.editor.focus();
	}
	updateMarker(marker) {
		this._container.classList.remove('stale');
		this._message.update(marker);
	}
	showStale() {
		this._container.classList.add('stale');
		this._relayout();
	}
	_doLayoutBody(heightInPixel, widthInPixel) {
		super._doLayoutBody(heightInPixel, widthInPixel);
		this._heightInPixel = heightInPixel;
		this._message.layout(heightInPixel, widthInPixel);
		this._container.style.height = `${heightInPixel}px`;
	}
	_onWidth(widthInPixel) {
		this._message.layout(this._heightInPixel, widthInPixel);
	}
	_relayout() {
		super._relayout(this.computeRequiredHeight());
	}
	computeRequiredHeight() {
		return 3 + this._message.getHeightInLines();
	}
}
__decorate(
	[
		__param(1, IThemeService),
		__param(2, IOpenerService),
		__param(3, IMenuService),
		__param(4, IInstantiationService),
		__param(5, IContextKeyService),
		__param(6, ILabelService)
	],
	MarkerNavigationWidget
);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const IMarkerNavigationService = createEditorServiceDecorator('IMarkerNavigationService');

const ck_markersNavigationVisible = new RawContextKey('markersNavigationVisible', false);

const markerController_id = 'editor.contrib.markerController';
class MarkerController {
	static get(editor2) {
		return editor2.getContribution(markerController_id);
	}
	constructor(editor2, _markerNavigationService, _contextKeyService, _editorService, _instantiationService) {
		this._markerNavigationService = _markerNavigationService;
		this._contextKeyService = _contextKeyService;
		this._editorService = _editorService;
		this._instantiationService = _instantiationService;
		this._sessionDispoables = new DisposableStore();
		this._editor = editor2;
		this._widgetVisible = ck_markersNavigationVisible.bindTo(this._contextKeyService);
	}
	dispose() {
		this._cleanUp();
		this._sessionDispoables.dispose();
	}
	_cleanUp() {
		this._widgetVisible.reset();
		this._sessionDispoables.clear();
		this._widget = undefined;
		this._model = undefined;
	}
	_getOrCreateModel(uri) {
		if (this._model && this._model.matches(uri)) {
			return this._model;
		}
		let reusePosition = false;
		if (this._model) {
			reusePosition = true;
			this._cleanUp();
		}
		this._model = this._markerNavigationService.getMarkerList(uri);
		if (reusePosition) {
			this._model.move(true, this._editor.getModel(), this._editor.getPosition());
		}
		this._widget = this._instantiationService.createInstance(MarkerNavigationWidget, this._editor);
		this._widget.onDidClose(() => this.close(), this, this._sessionDispoables);
		this._widgetVisible.set(true);
		this._sessionDispoables.add(this._model);
		this._sessionDispoables.add(this._widget);
		this._sessionDispoables.add(
			this._editor.onDidChangeCursorPosition(e => {
				if (!this._model?.selected || !Range.containsPosition(this._model.selected.marker, e.position)) {
					this._model?.resetIndex();
				}
			})
		);
		this._sessionDispoables.add(
			this._model.onDidChange(() => {
				if (!this._widget || !this._widget.position || !this._model) {
					return;
				}
				const info = this._model.find(this._editor.getModel().uri, this._widget.position);
				if (info) {
					this._widget.updateMarker(info.marker);
				} else {
					this._widget.showStale();
				}
			})
		);
		this._sessionDispoables.add(
			this._widget.onDidSelectRelatedInformation(related => {
				this._editorService.openCodeEditor(
					{
						resource: related.resource,
						options: {
							pinned: true,
							revealIfOpened: true,
							selection: Range.lift(related).collapseToStart()
						}
					},
					this._editor
				);
				this.close(false);
			})
		);
		this._sessionDispoables.add(this._editor.onDidChangeModel(() => this._cleanUp()));
		return this._model;
	}
	close(focusEditor = true) {
		this._cleanUp();
		if (focusEditor) {
			this._editor.focus();
		}
	}
	showAtMarker(marker) {
		if (this._editor.hasModel()) {
			const model = this._getOrCreateModel(this._editor.getModel().uri);
			model.resetIndex();
			model.move(true, this._editor.getModel(), new Position(marker.startLineNumber, marker.startColumn));
			if (model.selected) {
				this._widget.showAtMarker(model.selected.marker, model.selected.index, model.selected.total);
			}
		}
	}
	async nagivate(next, multiFile) {
		if (this._editor.hasModel()) {
			const model = this._getOrCreateModel(multiFile ? undefined : this._editor.getModel().uri);
			model.move(next, this._editor.getModel(), this._editor.getPosition());
			if (!model.selected) {
				return;
			}
			if (model.selected.marker.resource.toString() !== this._editor.getModel().uri.toString()) {
				this._cleanUp();
				const otherEditor = await this._editorService.openCodeEditor(
					{
						resource: model.selected.marker.resource,
						options: {
							pinned: false,
							revealIfOpened: true,
							selectionRevealType: 2,
							selection: model.selected.marker
						}
					},
					this._editor
				);
				if (otherEditor) {
					MarkerController.get(otherEditor)?.close();
					MarkerController.get(otherEditor)?.nagivate(next, multiFile);
				}
			} else {
				this._widget.showAtMarker(model.selected.marker, model.selected.index, model.selected.total);
			}
		}
	}
}
__decorate(
	[
		__param(1, IMarkerNavigationService),
		__param(2, IContextKeyService),
		__param(3, ICodeEditorService),
		__param(4, IInstantiationService)
	],
	MarkerController
);
registerEditorContribution(
	markerController_id,
	MarkerController,
	4 // Lazy
);

class MarkerNavigationAction extends EditorAction {
	constructor(_next, _multiFile, opts) {
		super(opts);
		this._next = _next;
		this._multiFile = _multiFile;
	}
	async run(_accessor, editor) {
		if (editor.hasModel()) {
			MarkerController.get(editor)?.nagivate(this._next, this._multiFile);
		}
	}
}

class NextMarkerAction extends MarkerNavigationAction {
	constructor() {
		const label = localize('Go to Next Problem (Error, Warning, Info)');
		super(true, false, {
			id: 'editor.action.marker.next',
			label: label,
			kbOpts: {
				kbExpr: ck_editorFocus,
				primary: 512 | 66,
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: gotoErrorTitle_menuId,
				title: label,
				icon: iconRegistry.registerIcon('marker-navigation-next', codicon_arrowDown, localize('Icon for goto next marker.')),
				group: 'navigation',
				order: 1
			}
		});
	}
}
registerEditorAction(NextMarkerAction);

class PrevMarkerAction extends MarkerNavigationAction {
	constructor() {
		const label = localize('Go to Previous Problem (Error, Warning, Info)');
		super(false, false, {
			id: 'editor.action.marker.prev',
			label: label,
			alias: 'Go to Previous Problem (Error, Warning, Info)',
			kbOpts: {
				kbExpr: ck_editorFocus,
				primary: 1024 | 512 | 66,
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: gotoErrorTitle_menuId,
				title: label,
				icon: iconRegistry.registerIcon('marker-navigation-previous', codicon_arrowUp, localize('Icon for goto previous marker.')),
				group: 'navigation',
				order: 2
			}
		});
	}
}
registerEditorAction(PrevMarkerAction);

class NextMarkerInFilesAction extends MarkerNavigationAction {
	constructor() {
		super(true, true, {
			id: 'editor.action.marker.nextInFiles',
			label: localize('Go to Next Problem in Files (Error, Warning, Info)'),
			alias: 'Go to Next Problem in Files (Error, Warning, Info)',
			kbOpts: {
				kbExpr: ck_editorFocus,
				primary: 66,
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: menubarGoMenu_menuId,
				title: localize('Next &&Problem'),
				group: '6_problem_nav',
				order: 1
			}
		});
	}
}
registerEditorAction(NextMarkerInFilesAction);

class PrevMarkerInFilesAction extends MarkerNavigationAction {
	constructor() {
		super(false, true, {
			id: 'editor.action.marker.prevInFiles',
			label: localize('Go to Previous Problem in Files (Error, Warning, Info)'),
			alias: 'Go to Previous Problem in Files (Error, Warning, Info)',
			kbOpts: {
				kbExpr: ck_editorFocus,
				primary: 1024 | 66,
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: menubarGoMenu_menuId,
				title: localize('Previous &&Problem'),
				group: '6_problem_nav',
				order: 2
			}
		});
	}
}
registerEditorAction(PrevMarkerInFilesAction);

const closeMarkersNavigationCommand = new (EditorCommand.bindToContribution(MarkerController.get))({
	id: 'closeMarkersNavigation',
	precondition: ck_markersNavigationVisible,
	handler: x => x.close(),
	kbOpts: {
		weight: 150,
		kbExpr: ck_editorFocus,
		primary: 9,
		secondary: [
			1024 | 9 // Escape
		]
	}
});
registerEditorCommand(closeMarkersNavigationCommand);