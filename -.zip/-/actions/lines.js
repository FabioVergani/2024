
class ExpandLineSelectionAction extends EditorAction {
	constructor() {
		super({
			id: 'expandLineSelection',
			label: localize('Expand Line EditorSelection'),
			alias: 'Expand Line EditorSelection',

			kbOpts: {
				weight: 0,
				kbExpr: ck_inputFocus_text,
				primary: 2048 | 42 // KeyL
			}
		});
	}
	run(_accessor, editor2, args) {
		args = args || {};
		if (!editor2.hasModel()) {
			return;
		}
		const viewModel = editor2._getViewModel();
		viewModel.model.pushStackElement();
		viewModel.setCursorStates(args.source, 3, CursorMoveCommands.expandLineSelection(viewModel, viewModel.getCursorStates()));
		viewModel.revealAllCursors(args.source, true);
	}
}
registerEditorAction(ExpandLineSelectionAction);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class MoveLinesCommand {
	constructor(selection, isMovingDown, autoIndent, _languageConfigurationService) {
		this._languageConfigurationService = _languageConfigurationService;
		this._selection = selection;
		this._isMovingDown = isMovingDown;
		this._autoIndent = autoIndent;
		this._selectionId = null;
		this._moveEndLineSelectionShrink = false;
	}
	getEditOperations(model, builder) {
		const modelLineCount = model.getLineCount();
		if (this._isMovingDown && this._selection.endLineNumber === modelLineCount) {
			this._selectionId = builder.trackSelection(this._selection);
			return;
		}
		if (!this._isMovingDown && this._selection.startLineNumber === 1) {
			this._selectionId = builder.trackSelection(this._selection);
			return;
		}
		this._moveEndPositionDown = false;
		let s = this._selection;
		if (s.startLineNumber < s.endLineNumber && s.endColumn === 1) {
			this._moveEndPositionDown = true;
			s = s.setEndPosition(s.endLineNumber - 1, model.getLineMaxColumn(s.endLineNumber - 1));
		}
		const { tabSize, indentSize, insertSpaces } = model.getOptions();
		const indentConverter = this.buildIndentConverter(tabSize, indentSize, insertSpaces);
		const virtualModel = {
			tokenization: {
				getLineTokens: lineNumber => {
					return model.tokenization.getLineTokens(lineNumber);
				},
				getLanguageId: () => {
					return model.getLanguageId();
				},
				getLanguageIdAtPosition: (lineNumber, column) => {
					return model.getLanguageIdAtPosition(lineNumber, column);
				}
			},
			getLineContent: null
		};
		if (s.startLineNumber === s.endLineNumber && model.getLineMaxColumn(s.startLineNumber) === 1) {
			const lineNumber = s.startLineNumber;
			const otherLineNumber = this._isMovingDown ? lineNumber + 1 : lineNumber - 1;
			if (model.getLineMaxColumn(otherLineNumber) === 1) {
				builder.addEditOperation(new Range(1, 1, 1, 1), null);
			} else {
				builder.addEditOperation(new Range(lineNumber, 1, lineNumber, 1), model.getLineContent(otherLineNumber));
				builder.addEditOperation(new Range(otherLineNumber, 1, otherLineNumber, model.getLineMaxColumn(otherLineNumber)), null);
			}
			s = new EditorSelection(otherLineNumber, 1, otherLineNumber, 1);
		} else {
			let movingLineNumber;
			let movingLineText;
			if (this._isMovingDown) {
				movingLineNumber = s.endLineNumber + 1;
				movingLineText = model.getLineContent(movingLineNumber);
				builder.addEditOperation(
					new Range(
						movingLineNumber - 1,
						model.getLineMaxColumn(movingLineNumber - 1),
						movingLineNumber,
						model.getLineMaxColumn(movingLineNumber)
					),
					null
				);
				let insertingText = movingLineText;
				if (this.shouldAutoIndent(model, s)) {
					const movingLineMatchResult = this.matchEnterRule(
						model,
						indentConverter,
						tabSize,
						movingLineNumber,
						s.startLineNumber - 1
					);
					if (movingLineMatchResult !== null) {
						const oldIndentation = getLeadingWhitespace(model.getLineContent(movingLineNumber));
						const newSpaceCnt = movingLineMatchResult + getSpaceCnt(oldIndentation, tabSize);
						const newIndentation = generateIndent(newSpaceCnt, tabSize, insertSpaces);
						insertingText = newIndentation + this.trimStart(movingLineText);
					} else {
						virtualModel.getLineContent = lineNumber => {
							if (lineNumber === s.startLineNumber) {
								return model.getLineContent(movingLineNumber);
							} else {
								return model.getLineContent(lineNumber);
							}
						};
						const indentOfMovingLine = getGoodIndentForLine(
							this._autoIndent,
							virtualModel,
							model.getLanguageIdAtPosition(movingLineNumber, 1),
							s.startLineNumber,
							indentConverter,
							this._languageConfigurationService
						);
						if (indentOfMovingLine !== null) {
							const oldIndentation = getLeadingWhitespace(model.getLineContent(movingLineNumber));
							const newSpaceCnt = getSpaceCnt(indentOfMovingLine, tabSize);
							const oldSpaceCnt = getSpaceCnt(oldIndentation, tabSize);
							if (newSpaceCnt !== oldSpaceCnt) {
								const newIndentation = generateIndent(newSpaceCnt, tabSize, insertSpaces);
								insertingText = newIndentation + this.trimStart(movingLineText);
							}
						}
					}
					builder.addEditOperation(new Range(s.startLineNumber, 1, s.startLineNumber, 1), insertingText + '\n');
					const ret = this.matchEnterRuleMovingDown(
						model,
						indentConverter,
						tabSize,
						s.startLineNumber,
						movingLineNumber,
						insertingText
					);
					if (ret !== null) {
						if (ret !== 0) {
							this.getIndentEditsOfMovingBlock(model, builder, s, tabSize, insertSpaces, ret);
						}
					} else {
						virtualModel.getLineContent = lineNumber => {
							if (lineNumber === s.startLineNumber) {
								return insertingText;
							} else if (lineNumber >= s.startLineNumber + 1 && lineNumber <= s.endLineNumber + 1) {
								return model.getLineContent(lineNumber - 1);
							} else {
								return model.getLineContent(lineNumber);
							}
						};
						const newIndentatOfMovingBlock = getGoodIndentForLine(
							this._autoIndent,
							virtualModel,
							model.getLanguageIdAtPosition(movingLineNumber, 1),
							s.startLineNumber + 1,
							indentConverter,
							this._languageConfigurationService
						);
						if (newIndentatOfMovingBlock !== null) {
							const oldIndentation = getLeadingWhitespace(model.getLineContent(s.startLineNumber));
							const newSpaceCnt = getSpaceCnt(newIndentatOfMovingBlock, tabSize);
							const oldSpaceCnt = getSpaceCnt(oldIndentation, tabSize);
							if (newSpaceCnt !== oldSpaceCnt) {
								const spaceCntOffset = newSpaceCnt - oldSpaceCnt;
								this.getIndentEditsOfMovingBlock(model, builder, s, tabSize, insertSpaces, spaceCntOffset);
							}
						}
					}
				} else {
					builder.addEditOperation(new Range(s.startLineNumber, 1, s.startLineNumber, 1), insertingText + '\n');
				}
			} else {
				movingLineNumber = s.startLineNumber - 1;
				movingLineText = model.getLineContent(movingLineNumber);
				builder.addEditOperation(new Range(movingLineNumber, 1, movingLineNumber + 1, 1), null);
				builder.addEditOperation(
					new Range(
						s.endLineNumber,
						model.getLineMaxColumn(s.endLineNumber),
						s.endLineNumber,
						model.getLineMaxColumn(s.endLineNumber)
					),
					'\n' + movingLineText
				);
				if (this.shouldAutoIndent(model, s)) {
					virtualModel.getLineContent = lineNumber => {
						if (lineNumber === movingLineNumber) {
							return model.getLineContent(s.startLineNumber);
						} else {
							return model.getLineContent(lineNumber);
						}
					};
					const ret = this.matchEnterRule(model, indentConverter, tabSize, s.startLineNumber, s.startLineNumber - 2);
					if (ret !== null) {
						if (ret !== 0) {
							this.getIndentEditsOfMovingBlock(model, builder, s, tabSize, insertSpaces, ret);
						}
					} else {
						const indentOfFirstLine = getGoodIndentForLine(
							this._autoIndent,
							virtualModel,
							model.getLanguageIdAtPosition(s.startLineNumber, 1),
							movingLineNumber,
							indentConverter,
							this._languageConfigurationService
						);
						if (indentOfFirstLine !== null) {
							const oldIndent = getLeadingWhitespace(model.getLineContent(s.startLineNumber));
							const newSpaceCnt = getSpaceCnt(indentOfFirstLine, tabSize);
							const oldSpaceCnt = getSpaceCnt(oldIndent, tabSize);
							if (newSpaceCnt !== oldSpaceCnt) {
								const spaceCntOffset = newSpaceCnt - oldSpaceCnt;
								this.getIndentEditsOfMovingBlock(model, builder, s, tabSize, insertSpaces, spaceCntOffset);
							}
						}
					}
				}
			}
		}
		this._selectionId = builder.trackSelection(s);
	}
	buildIndentConverter(tabSize, indentSize, insertSpaces) {
		return {
			shiftIndent: indentation => {
				return ShiftCommand.shiftIndent(indentation, indentation.length + 1, tabSize, indentSize, insertSpaces);
			},
			unshiftIndent: indentation => {
				return ShiftCommand.unshiftIndent(indentation, indentation.length + 1, tabSize, indentSize, insertSpaces);
			}
		};
	}
	parseEnterResult(model, indentConverter, tabSize, line, enter) {
		if (enter) {
			let enterPrefix = enter.indentation;
			if (enter.indentAction === 0) {
				enterPrefix = enter.indentation + enter.appendText;
			} else if (enter.indentAction === 1) {
				enterPrefix = enter.indentation + enter.appendText;
			} else if (enter.indentAction === 2) {
				enterPrefix = enter.indentation;
			} else if (enter.indentAction === 3) {
				enterPrefix = indentConverter.unshiftIndent(enter.indentation) + enter.appendText;
			}
			const movingLineText = model.getLineContent(line);
			if (this.trimStart(movingLineText).indexOf(this.trimStart(enterPrefix)) >= 0) {
				const oldIndentation = getLeadingWhitespace(model.getLineContent(line));
				let newIndentation = getLeadingWhitespace(enterPrefix);
				const indentMetadataOfMovelingLine = getIndentMetadata(model, line, this._languageConfigurationService);
				if (indentMetadataOfMovelingLine !== null && indentMetadataOfMovelingLine & 2) {
					newIndentation = indentConverter.unshiftIndent(newIndentation);
				}
				const newSpaceCnt = getSpaceCnt(newIndentation, tabSize);
				const oldSpaceCnt = getSpaceCnt(oldIndentation, tabSize);
				return newSpaceCnt - oldSpaceCnt;
			}
		}
		return null;
	}
	matchEnterRuleMovingDown(model, indentConverter, tabSize, line, futureAboveLineNumber, futureAboveLineText) {
		if (lastNonWhitespaceIndex(futureAboveLineText) >= 0) {
			const maxColumn = model.getLineMaxColumn(futureAboveLineNumber);
			const enter = getEnterAction(
				this._autoIndent,
				model,
				new Range(futureAboveLineNumber, maxColumn, futureAboveLineNumber, maxColumn),
				this._languageConfigurationService
			);
			return this.parseEnterResult(model, indentConverter, tabSize, line, enter);
		} else {
			let validPrecedingLine = line - 1;
			while (validPrecedingLine >= 1) {
				const lineContent = model.getLineContent(validPrecedingLine);
				const nonWhitespaceIdx = lastNonWhitespaceIndex(lineContent);
				if (nonWhitespaceIdx >= 0) {
					break;
				}
				validPrecedingLine--;
			}
			if (validPrecedingLine < 1 || line > model.getLineCount()) {
				return null;
			}
			const maxColumn = model.getLineMaxColumn(validPrecedingLine);
			const enter = getEnterAction(
				this._autoIndent,
				model,
				new Range(validPrecedingLine, maxColumn, validPrecedingLine, maxColumn),
				this._languageConfigurationService
			);
			return this.parseEnterResult(model, indentConverter, tabSize, line, enter);
		}
	}
	matchEnterRule(model, indentConverter, tabSize, line, oneLineAbove, previousLineText) {
		let validPrecedingLine = oneLineAbove;
		while (validPrecedingLine >= 1) {
			let lineContent;
			if (validPrecedingLine === oneLineAbove && previousLineText !== undefined) {
				lineContent = previousLineText;
			} else {
				lineContent = model.getLineContent(validPrecedingLine);
			}
			const nonWhitespaceIdx = lastNonWhitespaceIndex(lineContent);
			if (nonWhitespaceIdx >= 0) {
				break;
			}
			validPrecedingLine--;
		}
		if (validPrecedingLine < 1 || line > model.getLineCount()) {
			return null;
		}
		const maxColumn = model.getLineMaxColumn(validPrecedingLine);
		const enter = getEnterAction(
			this._autoIndent,
			model,
			new Range(validPrecedingLine, maxColumn, validPrecedingLine, maxColumn),
			this._languageConfigurationService
		);
		return this.parseEnterResult(model, indentConverter, tabSize, line, enter);
	}
	trimStart(str) {
		return str.replace(/^\s+/, '');
	}
	shouldAutoIndent(model, selection) {
		if (this._autoIndent < 4) {
			return false;
		}
		if (!model.tokenization.isCheapToTokenize(selection.startLineNumber)) {
			return false;
		}
		const languageAtSelectionStart = model.getLanguageIdAtPosition(selection.startLineNumber, 1);
		const languageAtSelectionEnd = model.getLanguageIdAtPosition(selection.endLineNumber, 1);
		if (languageAtSelectionStart !== languageAtSelectionEnd) {
			return false;
		}
		if (this._languageConfigurationService.getLanguageConfiguration(languageAtSelectionStart).indentRulesSupport === null) {
			return false;
		}
		return true;
	}
	getIndentEditsOfMovingBlock(model, builder, s, tabSize, insertSpaces, offset) {
		for (let i = s.startLineNumber; i <= s.endLineNumber; i++) {
			const lineContent = model.getLineContent(i);
			const originalIndent = getLeadingWhitespace(lineContent);
			const originalSpacesCnt = getSpaceCnt(originalIndent, tabSize);
			const newSpacesCnt = originalSpacesCnt + offset;
			const newIndent = generateIndent(newSpacesCnt, tabSize, insertSpaces);
			if (newIndent !== originalIndent) {
				builder.addEditOperation(new Range(i, 1, i, originalIndent.length + 1), newIndent);
				if (i === s.endLineNumber && s.endColumn <= originalIndent.length + 1 && newIndent === '') {
					this._moveEndLineSelectionShrink = true;
				}
			}
		}
	}
	computeCursorState(model, helper) {
		let result = helper.getTrackedSelection(this._selectionId);
		if (this._moveEndPositionDown) {
			result = result.setEndPosition(result.endLineNumber + 1, 1);
		}
		if (this._moveEndLineSelectionShrink && result.startLineNumber < result.endLineNumber) {
			result = result.setEndPosition(result.endLineNumber, 2);
		}
		return result;
	}
}
__decorate([__param(3, ILanguageConfigurationService)], MoveLinesCommand);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

let sortLinesCollator = null;
const getSortData = (model, selection, descending) => {
	const startLineNumber = selection.startLineNumber;
	let endLineNumber = selection.endLineNumber;
	if (selection.endColumn === 1) {
		endLineNumber--;
	}
	if (startLineNumber >= endLineNumber) {
		return null;
	}
	const linesToSort = [];
	for (let lineNumber = startLineNumber; lineNumber <= endLineNumber; lineNumber++) {
		linesToSort.push(model.getLineContent(lineNumber));
	}
	let sorted = linesToSort.slice(0);
	sorted.sort((sortLinesCollator ||= new Intl.Collator()).compare);
	if (descending === true) {
		sorted = sorted.reverse();
	}
	return {
		startLineNumber: startLineNumber,
		endLineNumber: endLineNumber,
		before: linesToSort,
		after: sorted
	};
};
class SortLinesCommand {
	constructor(selection, descending) {
		this.selection = selection;
		this.descending = descending;
		this.selectionId = null;
	}
	getEditOperations(model, builder) {
		const data = getSortData(model, this.selection, this.descending);
		const op = data
			? EditOperation.replace(
					new Range(data.startLineNumber, 1, data.endLineNumber, model.getLineMaxColumn(data.endLineNumber)),
					data.after.join('\n')
				)
			: null;
		if (op) {
			builder.addEditOperation(op.range, op.text);
		}
		this.selectionId = builder.trackSelection(this.selection);
	}
	computeCursorState(model, helper) {
		return helper.getTrackedSelection(this.selectionId);
	}
	static canRun(model, selection, descending) {
		if (model) {
			const data = getSortData(model, selection, descending);
			if (data) {
				for (let i = 0, len = data.before.length; i < len; i++) {
					if (data.before[i] !== data.after[i]) {
						return true;
					}
				}
			}
		}
		return false;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class JoinLinesAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.joinLines',
			label: localize('Join Lines'),
			alias: 'Join Lines',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 0,
				mac: {
					primary: 256 | 40 //KeyJ */
				},
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2) {
		const selections = editor2.getSelections();
		if (selections) {
			let primaryCursor = editor2.getSelection();
			if (primaryCursor) {
				selections.sort(Range.compareRangesUsingStarts);
				const reducedSelections = [];
				const lastSelection = selections.reduce((previousValue, currentValue) => {
					if (previousValue.isEmpty()) {
						if (previousValue.endLineNumber === currentValue.startLineNumber) {
							if (primaryCursor.equalsSelection(previousValue)) {
								primaryCursor = currentValue;
							}
							return currentValue;
						}
						if (currentValue.startLineNumber > previousValue.endLineNumber + 1) {
							reducedSelections.push(previousValue);
							return currentValue;
						} else {
							return new EditorSelection(
								previousValue.startLineNumber,
								previousValue.startColumn,
								currentValue.endLineNumber,
								currentValue.endColumn
							);
						}
					} else {
						if (currentValue.startLineNumber > previousValue.endLineNumber) {
							reducedSelections.push(previousValue);
							return currentValue;
						} else {
							return new EditorSelection(
								previousValue.startLineNumber,
								previousValue.startColumn,
								currentValue.endLineNumber,
								currentValue.endColumn
							);
						}
					}
				});
				reducedSelections.push(lastSelection);
				const model = editor2.getModel();
				if (model) {
					const edits = [];
					const endCursorState = [];
					let endPrimaryCursor = primaryCursor;
					let lineOffset = 0;
					for (let i = 0, len = reducedSelections.length; i < len; i++) {
						const selection = reducedSelections[i];
						const startLineNumber = selection.startLineNumber;
						const startColumn = 1;
						let columnDeltaOffset = 0;
						let endLineNumber, endColumn;
						const selectionEndPositionOffset = model.getLineLength(selection.endLineNumber) - selection.endColumn;
						if (selection.isEmpty() || selection.startLineNumber === selection.endLineNumber) {
							const position = selection.getStartPosition();
							if (position.lineNumber < model.getLineCount()) {
								endLineNumber = startLineNumber + 1;
								endColumn = model.getLineMaxColumn(endLineNumber);
							} else {
								endLineNumber = position.lineNumber;
								endColumn = model.getLineMaxColumn(position.lineNumber);
							}
						} else {
							endLineNumber = selection.endLineNumber;
							endColumn = model.getLineMaxColumn(endLineNumber);
						}
						let trimmedLinesContent = model.getLineContent(startLineNumber);
						for (let i2 = startLineNumber + 1; i2 <= endLineNumber; i2++) {
							const lineText = model.getLineContent(i2);
							const firstNonWhitespaceIdx = model.getLineFirstNonWhitespaceColumn(i2);
							if (firstNonWhitespaceIdx >= 1) {
								let insertSpace = true;
								if (trimmedLinesContent === '') {
									insertSpace = false;
								}
								if (
									insertSpace &&
									(trimmedLinesContent.charAt(trimmedLinesContent.length - 1) === ' ' ||
										trimmedLinesContent.charAt(trimmedLinesContent.length - 1) === '	')
								) {
									insertSpace = false;
									trimmedLinesContent = trimmedLinesContent.replace(/[\s\uFEFF\xA0]+$/g, ' ');
								}
								const lineTextWithoutIndent = lineText.substr(firstNonWhitespaceIdx - 1);
								trimmedLinesContent += (insertSpace ? ' ' : '') + lineTextWithoutIndent;
								if (insertSpace) {
									columnDeltaOffset = lineTextWithoutIndent.length + 1;
								} else {
									columnDeltaOffset = lineTextWithoutIndent.length;
								}
							} else {
								columnDeltaOffset = 0;
							}
						}
						const deleteSelection = new Range(startLineNumber, startColumn, endLineNumber, endColumn);
						if (!deleteSelection.isEmpty()) {
							let resultSelection;
							if (selection.isEmpty()) {
								edits.push(EditOperation.replace(deleteSelection, trimmedLinesContent));
								resultSelection = new EditorSelection(
									deleteSelection.startLineNumber - lineOffset,
									trimmedLinesContent.length - columnDeltaOffset + 1,
									startLineNumber - lineOffset,
									trimmedLinesContent.length - columnDeltaOffset + 1
								);
							} else {
								if (selection.startLineNumber === selection.endLineNumber) {
									edits.push(EditOperation.replace(deleteSelection, trimmedLinesContent));
									resultSelection = new EditorSelection(
										selection.startLineNumber - lineOffset,
										selection.startColumn,
										selection.endLineNumber - lineOffset,
										selection.endColumn
									);
								} else {
									edits.push(EditOperation.replace(deleteSelection, trimmedLinesContent));
									resultSelection = new EditorSelection(
										selection.startLineNumber - lineOffset,
										selection.startColumn,
										selection.startLineNumber - lineOffset,
										trimmedLinesContent.length - selectionEndPositionOffset
									);
								}
							}
							if (Range.intersectRanges(deleteSelection, primaryCursor) !== null) {
								endPrimaryCursor = resultSelection;
							} else {
								endCursorState.push(resultSelection);
							}
						}
						lineOffset += deleteSelection.endLineNumber - deleteSelection.startLineNumber;
					}
					endCursorState.unshift(endPrimaryCursor);
					editor2.pushUndoStop();
					editor2.executeEdits(this.id, edits, endCursorState);
					editor2.pushUndoStop();
				}
			}
		}
	}
}
registerEditorAction(JoinLinesAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class TransposeAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.transpose',
			label: localize('Transpose Characters around the Cursor'),
			alias: 'Transpose Characters around the Cursor',
			precondition: ck_writable
		});
	}
	run(_accessor, editor2) {
		const selections = editor2.getSelections();
		if (selections) {
			const model = editor2.getModel();
			if (model) {
				const commands = [];
				for (let i = 0, len = selections.length; i < len; i++) {
					const selection = selections[i];
					if (!selection.isEmpty()) {
						continue;
					}
					const cursor = selection.getStartPosition();
					const maxColumn = model.getLineMaxColumn(cursor.lineNumber);
					if (cursor.column >= maxColumn) {
						if (cursor.lineNumber === model.getLineCount()) {
							continue;
						}
						const deleteSelection = new Range(cursor.lineNumber, Math.max(1, cursor.column - 1), cursor.lineNumber + 1, 1);
						const chars = model.getValueInRange(deleteSelection).split('').reverse().join('');
						commands.push(
							new ReplaceCommand(
								new EditorSelection(cursor.lineNumber, Math.max(1, cursor.column - 1), cursor.lineNumber + 1, 1),
								chars
							)
						);
					} else {
						const deleteSelection = new Range(
							cursor.lineNumber,
							Math.max(1, cursor.column - 1),
							cursor.lineNumber,
							cursor.column + 1
						);
						const chars = model.getValueInRange(deleteSelection).split('').reverse().join('');
						commands.push(
							new ReplaceCommandThatPreservesSelection(
								deleteSelection,
								chars,
								new EditorSelection(cursor.lineNumber, cursor.column + 1, cursor.lineNumber, cursor.column + 1)
							)
						);
					}
				}
				editor2.pushUndoStop();
				editor2.executeCommands(this.id, commands);
				editor2.pushUndoStop();
			}
		}
	}
}
registerEditorAction(TransposeAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class TrimTrailingWhitespaceCommand {
	constructor(selection, cursors, trimInRegexesAndStrings) {
		this._selection = selection;
		this._cursors = cursors;
		this._selectionId = null;
		this._trimInRegexesAndStrings = trimInRegexesAndStrings;
	}
	getEditOperations(model, builder) {
		const cursors = this._cursors;
		cursors.sort((a, b) => {
			if (a.lineNumber === b.lineNumber) {
				return a.column - b.column;
			}
			return a.lineNumber - b.lineNumber;
		});
		for (let i = cursors.length - 2; i >= 0; i--) {
			if (cursors[i].lineNumber === cursors[i + 1].lineNumber) {
				cursors.splice(i, 1);
			}
		}
		const ops = [];
		let rLen = 0;
		let cursorIndex = 0;
		const cursorLen = cursors.length;
		for (let lineNumber = 1, lineCount = model.getLineCount(); lineNumber <= lineCount; lineNumber++) {
			const lineContent = model.getLineContent(lineNumber);
			const maxLineColumn = lineContent.length + 1;
			let minEditColumn = 0;
			if (cursorIndex < cursorLen && cursors[cursorIndex].lineNumber === lineNumber) {
				minEditColumn = cursors[cursorIndex].column;
				cursorIndex++;
				if (minEditColumn === maxLineColumn) {
					continue;
				}
			}
			if (lineContent.length === 0) {
				continue;
			}
			const lastNonWhitespaceIndex2 = lastNonWhitespaceIndex(lineContent);
			let fromColumn = 0;
			if (lastNonWhitespaceIndex2 === -1) {
				fromColumn = 1;
			} else if (lastNonWhitespaceIndex2 !== lineContent.length - 1) {
				fromColumn = lastNonWhitespaceIndex2 + 2;
			} else {
				continue;
			}
			const trimInRegexesAndStrings = this._trimInRegexesAndStrings;
			if (!trimInRegexesAndStrings) {
				if (!model.tokenization.hasAccurateTokensForLine(lineNumber)) {
					continue;
				}
				const lineTokens = model.tokenization.getLineTokens(lineNumber);
				const fromColumnType = lineTokens.getStandardTokenType(lineTokens.findTokenIndexAtOffset(fromColumn));
				if (fromColumnType === 2 || fromColumnType === 3) {
					continue;
				}
			}
			fromColumn = Math.max(minEditColumn, fromColumn);
			ops[rLen++] = EditOperation.delete(new Range(lineNumber, fromColumn, lineNumber, maxLineColumn));
		}
		for (let i = 0, len = ops.length; i < len; i++) {
			const op = ops[i];
			builder.addEditOperation(op.range, op.text);
		}
		this._selectionId = builder.trackSelection(this._selection);
	}
	computeCursorState(model, helper) {
		return helper.getTrackedSelection(this._selectionId);
	}
}
class TrimTrailingWhitespaceAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.trimTrailingWhitespace',
			label: localize('Trim Trailing Whitespace'),
			alias: 'Trim Trailing Whitespace',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 54 // KeyX
				),
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2, args) {
		let cursors = [];
		if (args.reason === 'auto-save') {
			cursors = (editor2.getSelections() || []).map(s => new Position(s.positionLineNumber, s.positionColumn));
		}
		const selection = editor2.getSelection();
		if (selection) {
			const config = _accessor.get(IConfigurationService);
			const model = editor2.getModel();
			const trimInRegexAndStrings = config.getValue('files.trimTrailingWhitespaceInRegexAndStrings', {
				overrideIdentifier: model?.getLanguageId(),
				resource: model?.uri
			});
			const command = new TrimTrailingWhitespaceCommand(selection, cursors, trimInRegexAndStrings);
			editor2.pushUndoStop();
			editor2.executeCommands(this.id, [command]);
			editor2.pushUndoStop();
		}
	}
}
registerEditorAction(TrimTrailingWhitespaceAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class DeleteLinesAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.deleteLines',
			label: localize('Delete Line'),
			alias: 'Delete Line',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_inputFocus_text,
				primary: 2048 | 1024 | 41,
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2) {
		const model = editor2.getModel();
		if (model) {
			const ops = this._getLinesToRemove(editor2);
			if (model.getLineCount() === 1 && model.getLineMaxColumn(1) === 1) {
				return;
			}
			let linesDeleted = 0;
			const edits = [];
			const cursorState = [];
			for (let i = 0, len = ops.length; i < len; i++) {
				const op = ops[i];
				let startLineNumber = op.startLineNumber;
				let endLineNumber = op.endLineNumber;
				let startColumn = 1;
				let endColumn = model.getLineMaxColumn(endLineNumber);
				if (endLineNumber < model.getLineCount()) {
					endLineNumber += 1;
					endColumn = 1;
				} else if (startLineNumber > 1) {
					startLineNumber -= 1;
					startColumn = model.getLineMaxColumn(startLineNumber);
				}
				edits.push(EditOperation.replace(new EditorSelection(startLineNumber, startColumn, endLineNumber, endColumn), ''));
				cursorState.push(
					new EditorSelection(
						startLineNumber - linesDeleted,
						op.positionColumn,
						startLineNumber - linesDeleted,
						op.positionColumn
					)
				);
				linesDeleted += op.endLineNumber - op.startLineNumber + 1;
			}
			editor2.pushUndoStop();
			editor2.executeEdits(this.id, edits, cursorState);
			editor2.pushUndoStop();
		}
	}
	_getLinesToRemove(editor2) {
		const operations = editor2.getSelections().map(s => {
			let endLineNumber = s.endLineNumber;
			if (s.startLineNumber < s.endLineNumber && s.endColumn === 1) {
				endLineNumber -= 1;
			}
			return {
				startLineNumber: s.startLineNumber,
				selectionStartColumn: s.selectionStartColumn,
				endLineNumber,
				positionColumn: s.positionColumn
			};
		});
		operations.sort((a, b) => {
			if (a.startLineNumber === b.startLineNumber) {
				return a.endLineNumber - b.endLineNumber;
			}
			return a.startLineNumber - b.startLineNumber;
		});
		const mergedOperations = [];
		let previousOperation = operations[0];
		for (let i = 1; i < operations.length; i++) {
			if (previousOperation.endLineNumber + 1 >= operations[i].startLineNumber) {
				previousOperation.endLineNumber = operations[i].endLineNumber;
			} else {
				mergedOperations.push(previousOperation);
				previousOperation = operations[i];
			}
		}
		mergedOperations.push(previousOperation);
		return mergedOperations;
	}
}
registerEditorAction(DeleteLinesAction); //  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
class DeleteDuplicateLinesAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.removeDuplicateLines',
			label: localize('Delete Duplicate Lines'),
			alias: 'Delete Duplicate Lines',
			precondition: ck_writable
		});
	}
	run(_accessor, editor2) {
		const model = editor2.getModel();
		if (model && model.getLineCount() > 1 && model.getLineMaxColumn(1) > 1) {
			const edits = [];
			const endCursorState = [];
			let linesDeleted = 0;
			let updateSelection = true;
			let selections = editor2.getSelections();
			if (selections.length === 1 && selections[0].isEmpty()) {
				selections = [new EditorSelection(1, 1, model.getLineCount(), model.getLineMaxColumn(model.getLineCount()))];
				updateSelection = false;
			}
			for (const selection of selections) {
				const uniqueLines = new Set();
				const lines = [];
				for (let i = selection.startLineNumber; i <= selection.endLineNumber; i++) {
					const line = model.getLineContent(i);
					if (uniqueLines.has(line)) {
						continue;
					}
					lines.push(line);
					uniqueLines.add(line);
				}
				const selectionToReplace = new EditorSelection(
					selection.startLineNumber,
					1,
					selection.endLineNumber,
					model.getLineMaxColumn(selection.endLineNumber)
				);
				const adjustedSelectionStart = selection.startLineNumber - linesDeleted;
				const finalSelection = new EditorSelection(
					adjustedSelectionStart,
					1,
					adjustedSelectionStart + lines.length - 1,
					lines[lines.length - 1].length
				);
				edits.push(EditOperation.replace(selectionToReplace, lines.join('\n')));
				endCursorState.push(finalSelection);
				linesDeleted += selection.endLineNumber - selection.startLineNumber + 1 - lines.length;
			}
			editor2.pushUndoStop();
			editor2.executeEdits(this.id, edits, updateSelection ? endCursorState : undefined);
			editor2.pushUndoStop();
		}
	}
}
registerEditorAction(DeleteDuplicateLinesAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class InsertLineBeforeAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.insertLineBefore',
			label: localize('Insert Line Above'),
			alias: 'Insert Line Above',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 1024 | 3,
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2) {
		const viewModel = editor2._getViewModel();
		if (viewModel) {
			editor2.pushUndoStop();
			editor2.executeCommands(
				this.id,
				TypeOperations.lineInsertBefore(viewModel.cursorConfig, editor2.getModel(), editor2.getSelections())
			);
		}
	}
}
registerEditorAction(InsertLineBeforeAction);
class InsertLineAfterAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.insertLineAfter',
			label: localize('Insert Line Below'),
			alias: 'Insert Line Below',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 3,
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2) {
		const viewModel = editor2._getViewModel();
		if (viewModel) {
			editor2.pushUndoStop();
			editor2.executeCommands(
				this.id,
				TypeOperations.lineInsertAfter(viewModel.cursorConfig, editor2.getModel(), editor2.getSelections())
			);
		}
	}
}
registerEditorAction(InsertLineAfterAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class IndentLinesAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.indentLines',
			label: localize('Indent Line'),
			alias: 'Indent Line',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 94,
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2) {
		const viewModel = editor2._getViewModel();
		if (viewModel) {
			editor2.pushUndoStop();
			editor2.executeCommands(this.id, TypeOperations.indent(viewModel.cursorConfig, editor2.getModel(), editor2.getSelections()));
			editor2.pushUndoStop();
		}
	}
}
registerEditorAction(IndentLinesAction);
class OutdentLinesAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.outdentLines',
			label: localize('Outdent Line'),
			alias: 'Outdent Line',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 92,
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2) {
		commandOutdent.runEditorCommand(_accessor, editor2, null);
	}
}
registerEditorAction(OutdentLinesAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class CopyLinesCommand {
	constructor(selection, isCopyingDown, noop) {
		this._selection = selection;
		this._isCopyingDown = isCopyingDown;
		this._noop = noop || false;
		this._selectionDirection = 0;
		this._selectionId = null;
		this._startLineNumberDelta = 0;
		this._endLineNumberDelta = 0;
	}
	getEditOperations(model, builder) {
		let s = this._selection;
		this._startLineNumberDelta = 0;
		this._endLineNumberDelta = 0;
		if (s.startLineNumber < s.endLineNumber && s.endColumn === 1) {
			this._endLineNumberDelta = 1;
			s = s.setEndPosition(s.endLineNumber - 1, model.getLineMaxColumn(s.endLineNumber - 1));
		}
		const sourceLines = [];
		for (let i = s.startLineNumber; i <= s.endLineNumber; i++) {
			sourceLines.push(model.getLineContent(i));
		}
		const sourceText = sourceLines.join('\n');
		if (sourceText === '') {
			if (this._isCopyingDown) {
				this._startLineNumberDelta++;
				this._endLineNumberDelta++;
			}
		}
		if (this._noop) {
			builder.addEditOperation(
				new Range(s.endLineNumber, model.getLineMaxColumn(s.endLineNumber), s.endLineNumber + 1, 1),
				s.endLineNumber === model.getLineCount() ? '' : '\n'
			);
		} else {
			if (!this._isCopyingDown) {
				builder.addEditOperation(
					new Range(
						s.endLineNumber,
						model.getLineMaxColumn(s.endLineNumber),
						s.endLineNumber,
						model.getLineMaxColumn(s.endLineNumber)
					),
					'\n' + sourceText
				);
			} else {
				builder.addEditOperation(new Range(s.startLineNumber, 1, s.startLineNumber, 1), sourceText + '\n');
			}
		}
		this._selectionId = builder.trackSelection(s);
		this._selectionDirection = this._selection.getDirection();
	}
	computeCursorState(model, helper) {
		let result = helper.getTrackedSelection(this._selectionId);
		if (this._startLineNumberDelta !== 0 || this._endLineNumberDelta !== 0) {
			let startLineNumber = result.startLineNumber;
			let startColumn = result.startColumn;
			let endLineNumber = result.endLineNumber;
			let endColumn = result.endColumn;
			if (this._startLineNumberDelta !== 0) {
				startLineNumber = startLineNumber + this._startLineNumberDelta;
				startColumn = 1;
			}
			if (this._endLineNumberDelta !== 0) {
				endLineNumber = endLineNumber + this._endLineNumberDelta;
				endColumn = 1;
			}
			result = EditorSelection.createWithDirection(startLineNumber, startColumn, endLineNumber, endColumn, this._selectionDirection);
		}
		return result;
	}
}

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class DuplicateSelectionAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.duplicateSelection',
			label: localize('Duplicate EditorSelection'),
			alias: 'Duplicate EditorSelection',
			precondition: ck_writable,
			menuOpts: {
				menuId: menubarSelectionMenu_menuId,
				group: '2_line',
				title: localize('&&Duplicate EditorSelection'),
				order: 5
			}
		});
	}
	run(accessor, editor, args) {
		const model = editor.getModel();
		if (model) {
			const commands = [];
			const selections = editor.getSelections();
			for (const selection of selections) {
				if (selection.isEmpty()) {
					commands.push(new CopyLinesCommand(selection, true));
				} else {
					const insertSelection = new EditorSelection(
						selection.endLineNumber,
						selection.endColumn,
						selection.endLineNumber,
						selection.endColumn
					);
					commands.push(new ReplaceCommandThatSelectsText(insertSelection, model.getValueInRange(selection)));
				}
			}
			editor.pushUndoStop();
			editor.executeCommands(this.id, commands);
			editor.pushUndoStop();
		}
	}
}
registerEditorAction(DuplicateSelectionAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class AbstractSortLinesAction extends EditorAction {
	constructor(descending, opts) {
		super(opts);
		this.descending = descending;
	}
	run(_accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const model = editor2.getModel();
		let selections = editor2.getSelections();
		if (selections.length === 1 && selections[0].isEmpty()) {
			selections = [new EditorSelection(1, 1, model.getLineCount(), model.getLineMaxColumn(model.getLineCount()))];
		}
		for (const selection of selections) {
			if (!SortLinesCommand.canRun(editor2.getModel(), selection, this.descending)) {
				return;
			}
		}
		const commands = [];
		for (let i = 0, len = selections.length; i < len; i++) {
			commands[i] = new SortLinesCommand(selections[i], this.descending);
		}
		editor2.pushUndoStop();
		editor2.executeCommands(this.id, commands);
		editor2.pushUndoStop();
	}
}

class SortLinesAscendingAction extends AbstractSortLinesAction {
	constructor() {
		super(false, {
			id: 'editor.action.sortLinesAscending',
			label: localize('Sort Lines Ascending'),
			alias: 'Sort Lines Ascending',
			precondition: ck_writable
		});
	}
}
registerEditorAction(SortLinesAscendingAction);

class SortLinesDescendingAction extends AbstractSortLinesAction {
	constructor() {
		super(true, {
			id: 'editor.action.sortLinesDescending',
			label: localize('Sort Lines Descending'),
			alias: 'Sort Lines Descending',
			precondition: ck_writable
		});
	}
}
registerEditorAction(SortLinesDescendingAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class AbstractMoveLinesAction extends EditorAction {
	constructor(down, opts) {
		super(opts);
		this.down = down;
	}
	run(accessor, editor2) {
		const languageConfigurationService = accessor.get(ILanguageConfigurationService);
		const commands = [];
		const selections = editor2.getSelections() || [];
		const autoIndent = editor2.getOption(
			12 // autoIndent
		);
		for (const selection of selections) {
			commands.push(new MoveLinesCommand(selection, this.down, autoIndent, languageConfigurationService));
		}
		editor2.pushUndoStop();
		editor2.executeCommands(this.id, commands);
		editor2.pushUndoStop();
	}
}
class MoveLinesUpAction extends AbstractMoveLinesAction {
	constructor() {
		super(false, {
			id: 'editor.action.moveLinesUpAction',
			label: localize('Move Line Up'),
			alias: 'Move Line Up',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 512 | 16,
				linux: { primary: 512 | 16 /* KeyCode.UpArrow */ },
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: menubarSelectionMenu_menuId,
				group: '2_line',
				title: localize('Mo&&ve Line Up'),
				order: 3
			}
		});
	}
}
registerEditorAction(MoveLinesUpAction);
class MoveLinesDownAction extends AbstractMoveLinesAction {
	constructor() {
		super(true, {
			id: 'editor.action.moveLinesDownAction',
			label: localize('Move Line Down'),
			alias: 'Move Line Down',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 512 | 18,
				linux: {
					primary: 512 | 18 // DownArrow
				},
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: menubarSelectionMenu_menuId,
				group: '2_line',
				title: localize('Move &&Line Down'),
				order: 4
			}
		});
	}
}
registerEditorAction(MoveLinesDownAction);


//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -


class AbstractCopyLinesAction extends EditorAction {
	constructor(down, opts) {
		super(opts);
		this.down = down;
	}
	run(_accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const selections = editor2.getSelections().map((selection, index) => ({ selection, index, ignore: false }));
		selections.sort((a, b) => Range.compareRangesUsingStarts(a.selection, b.selection));
		let prev = selections[0];
		for (let i = 1; i < selections.length; i++) {
			const curr = selections[i];
			if (prev.selection.endLineNumber === curr.selection.startLineNumber) {
				if (prev.index < curr.index) {
					curr.ignore = true;
				} else {
					prev.ignore = true;
					prev = curr;
				}
			}
		}
		const commands = [];
		for (const selection of selections) {
			commands.push(new CopyLinesCommand(selection.selection, this.down, selection.ignore));
		}
		editor2.pushUndoStop();
		editor2.executeCommands(this.id, commands);
		editor2.pushUndoStop();
	}
}

class CopyLinesUpAction extends AbstractCopyLinesAction {
	constructor() {
		super(false, {
			id: 'editor.action.copyLinesUpAction',
			label: localize('Copy Line Up'),
			alias: 'Copy Line Up',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 512 | 1024 | 16,
				linux: {
					primary: 2048 | 512 | 1024 | 16 // UpArrow
				},
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: menubarSelectionMenu_menuId,
				group: '2_line',
				title: localize('&&Copy Line Up'),
				order: 1
			}
		});
	}
}
registerEditorAction(CopyLinesUpAction);

class CopyLinesDownAction extends AbstractCopyLinesAction {
	constructor() {
		super(true, {
			id: 'editor.action.copyLinesDownAction',
			label: localize('Copy Line Down'),
			alias: 'Copy Line Down',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 512 | 1024 | 18,
				linux: {
					primary: 2048 | 512 | 1024 | 18 // DownArrow
				},
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: menubarSelectionMenu_menuId,
				group: '2_line',
				title: localize('Co&&py Line Down'),
				order: 2
			}
		});
	}
}
registerEditorAction(CopyLinesDownAction);
//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -



//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
