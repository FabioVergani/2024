const HoverFocusBehavior = {
	NoAutoFocus: 'noAutoFocus',
	FocusIfVisible: 'focusIfVisible',
	AutoFocusImmediately: 'autoFocusImmediately'
};

class ShowOrFocusHoverAction extends EditorAction {
	constructor() {
		super({
			id: SHOW_OR_FOCUS_HOVER_ACTION_ID,
			label: localize('Show or Focus Hover'),
			metadata: {
				description: localize(
					'Show or focus the editor hover which shows documentation, references, and other content for a symbol at the current cursor position.'
				),
				args: [
					{
						name: 'args',
						schema: {
							type: 'object',
							properties: {
								focus: {
									description: 'Controls if and when the hover should take focus upon being triggered by this action.',
									enum: [
										HoverFocusBehavior.NoAutoFocus,
										HoverFocusBehavior.FocusIfVisible,
										HoverFocusBehavior.AutoFocusImmediately
									],
									enumDescriptions: [
										localize('The hover will not automatically take focus.'),
										localize('The hover will take focus only if it is already visible.'),
										localize('The hover will automatically take focus when it appears.')
									],
									default: HoverFocusBehavior.FocusIfVisible
								}
							}
						}
					}
				]
			},
			alias: 'Show or Focus Hover',
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 39 // KeyI
				),
				weight: 100 //editorContrib
			}
		});
	}
	run(accessor, editor2, args) {
		if (!editor2.hasModel()) {
			return;
		}
		const controller = HoverController.get(editor2);
		if (!controller) {
			return;
		}
		const focusArgument = args?.focus;
		let focusOption = HoverFocusBehavior.FocusIfVisible;
		if (Object.values(HoverFocusBehavior).includes(focusArgument)) {
			focusOption = focusArgument;
		} else if (typeof focusArgument === 'boolean' && focusArgument) {
			focusOption = HoverFocusBehavior.AutoFocusImmediately;
		}
		const showContentHover = focus => {
			const position = editor2.getPosition();
			const range2 = new Range(position.lineNumber, position.column, position.lineNumber, position.column);
			controller.showContentHover(range2, 1, 1, focus);
		};
		b;
		if (controller.isHoverVisible) {
			if (focusOption !== HoverFocusBehavior.NoAutoFocus) {
				controller.focus();
			} else {
				showContentHover();
			}
		} else {
			showContentHover(focusOption === HoverFocusBehavior.AutoFocusImmediately);
		}
	}
}
registerEditorAction(ShowOrFocusHoverAction);

class ShowDefinitionPreviewHoverAction extends EditorAction {
	constructor() {
		super({
			id: SHOW_DEFINITION_PREVIEW_HOVER_ACTION_ID,
			label: localize('Show Definition Preview Hover'),
			alias: 'Show Definition Preview Hover',
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const controller = HoverController.get(editor2);
		if (!controller) {
			return;
		}
		const position = editor2.getPosition();
		if (!position) {
			return;
		}
		const range2 = new Range(position.lineNumber, position.column, position.lineNumber, position.column);
		const goto = GotoDefinitionAtPositionEditorContribution.get(editor2);
		if (!goto) {
			return;
		}
		const promise = goto.startFindDefinitionFromCursor(position);
		promise.then(() => {
			controller.showContentHover(range2, 1, 1, true);
		});
	}
}
registerEditorAction(ShowDefinitionPreviewHoverAction);

class ScrollUpHoverAction extends EditorAction {
	constructor() {
		super({
			id: SCROLL_UP_HOVER_ACTION_ID,
			label: localize('Scroll Up Hover'),
			alias: 'Scroll Up Hover',
			precondition: ck_editorHover_focused,
			kbOpts: {
				kbExpr: ck_editorHover_focused,
				primary: 16,
				weight: 100 //editorContrib
			},
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const controller = HoverController.get(editor2);
		if (!controller) {
			return;
		}
		controller.scrollUp();
	}
}
registerEditorAction(ScrollUpHoverAction);

class ScrollDownHoverAction extends EditorAction {
	constructor() {
		super({
			id: SCROLL_DOWN_HOVER_ACTION_ID,
			label: localize('Scroll Down Hover'),
			alias: 'Scroll Down Hover',
			precondition: ck_editorHover_focused,
			kbOpts: {
				kbExpr: ck_editorHover_focused,
				primary: 18,
				weight: 100 //editorContrib
			},
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const controller = HoverController.get(editor2);
		if (!controller) {
			return;
		}
		controller.scrollDown();
	}
}
registerEditorAction(ScrollDownHoverAction);

class ScrollLeftHoverAction extends EditorAction {
	constructor() {
		super({
			id: SCROLL_LEFT_HOVER_ACTION_ID,
			label: localize('Scroll Left Hover'),
			alias: 'Scroll Left Hover',
			precondition: ck_editorHover_focused,
			kbOpts: {
				kbExpr: ck_editorHover_focused,
				primary: 15,
				weight: 100 //editorContrib
			},
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const controller = HoverController.get(editor2);
		if (!controller) {
			return;
		}
		controller.scrollLeft();
	}
}
registerEditorAction(ScrollLeftHoverAction);

class ScrollRightHoverAction extends EditorAction {
	constructor() {
		super({
			id: SCROLL_RIGHT_HOVER_ACTION_ID,
			label: localize('Scroll Right Hover'),
			alias: 'Scroll Right Hover',
			precondition: ck_editorHover_focused,
			kbOpts: {
				kbExpr: ck_editorHover_focused,
				primary: 17,
				weight: 100 //editorContrib
			},
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const controller = HoverController.get(editor2);
		if (!controller) {
			return;
		}
		controller.scrollRight();
	}
}
registerEditorAction(ScrollRightHoverAction);

class PageUpHoverAction extends EditorAction {
	constructor() {
		super({
			id: PAGE_UP_HOVER_ACTION_ID,
			label: localize('Page Up Hover'),
			alias: 'Page Up Hover',
			precondition: ck_editorHover_focused,
			kbOpts: {
				kbExpr: ck_editorHover_focused,
				primary: 11,
				secondary: [
				 512 | 16 // UpArrow
				],
				weight: 100 //editorContrib
			},
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const controller = HoverController.get(editor2);
		if (!controller) {
			return;
		}
		controller.pageUp();
	}
}
registerEditorAction(PageUpHoverAction);

class PageDownHoverAction extends EditorAction {
	constructor() {
		super({
			id: PAGE_DOWN_HOVER_ACTION_ID,
			label: localize('Page Down Hover'),
			alias: 'Page Down Hover',
			precondition: ck_editorHover_focused,
			kbOpts: {
				kbExpr: ck_editorHover_focused,
				primary: 12,
				secondary: [
					512 | 18 // DownArrow
				],
				weight: 100 //editorContrib
			},
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const controller = HoverController.get(editor2);
		if (!controller) {
			return;
		}
		controller.pageDown();
	}
}
registerEditorAction(PageDownHoverAction);

class GoToTopHoverAction extends EditorAction {
	constructor() {
		super({
			id: GO_TO_TOP_HOVER_ACTION_ID,
			label: localize('Go To Top Hover'),
			alias: 'Go To Bottom Hover',
			precondition: ck_editorHover_focused,
			kbOpts: {
				kbExpr: ck_editorHover_focused,
				primary: 14,
				secondary: [
					2048 | 16 // UpArrow
				],
				weight: 100 //editorContrib
			},
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const controller = HoverController.get(editor2);
		if (!controller) {
			return;
		}
		controller.goToTop();
	}
}
registerEditorAction(GoToTopHoverAction);

class GoToBottomHoverAction extends EditorAction {
	constructor() {
		super({
			id: GO_TO_BOTTOM_HOVER_ACTION_ID,
			label: localize('Go To Bottom Hover'),
			alias: 'Go To Bottom Hover',
			precondition: ck_editorHover_focused,
			kbOpts: {
				kbExpr: ck_editorHover_focused,
				primary: 13,
				secondary: [
					2048 | 18 // DownArrow
				],
				weight: 100 //editorContrib
			},
			metadata: {}
		});
	}
	run(accessor, editor2) {
		const controller = HoverController.get(editor2);
		if (!controller) {
			return;
		}
		controller.goToBottom();
	}
}
registerEditorAction(GoToBottomHoverAction);

class IncreaseHoverVerbosityLevel extends EditorAction {
	constructor() {
		super({
			id: INCREASE_HOVER_VERBOSITY_ACTION_ID,
			label: localize('Increase Hover Verbosity Level'),
			alias: 'Increase Hover Verbosity Level',
			precondition: ck_editorHover_focused
		});
	}
	run(accessor, editor2) {
		HoverController.get(editor2)?.updateFocusedMarkdownHoverVerbosityLevel(0);
	}
}
registerEditorAction(IncreaseHoverVerbosityLevel);

class DecreaseHoverVerbosityLevel extends EditorAction {
	constructor() {
		super({
			id: DECREASE_HOVER_VERBOSITY_ACTION_ID,
			label: localize('Decrease Hover Verbosity Level'),
			alias: 'Decrease Hover Verbosity Level',
			precondition: ck_editorHover_focused
		});
	}
	run(accessor, editor2, args) {
		HoverController.get(editor2)?.updateFocusedMarkdownHoverVerbosityLevel(1);
	}
}
registerEditorAction(DecreaseHoverVerbosityLevel);