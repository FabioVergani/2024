function setCollapseStateLevelsDown(foldingModel, doCollapse, levels = Number.MAX_VALUE, lineNumbers) {
	const toToggle = [];
	if (lineNumbers && lineNumbers.length > 0) {
		for (const lineNumber of lineNumbers) {
			const region = foldingModel.getRegionAtLine(lineNumber);
			if (region) {
				if (region.isCollapsed !== doCollapse) {
					toToggle.push(region);
				}
				if (levels > 1) {
					const regionsInside = foldingModel.getRegionsInside(
						region,
						(r, level) => r.isCollapsed !== doCollapse && level < levels
					);
					toToggle.push(...regionsInside);
				}
			}
		}
	} else {
		const regionsInside = foldingModel.getRegionsInside(null, (r, level) => r.isCollapsed !== doCollapse && level < levels);
		toToggle.push(...regionsInside);
	}
	foldingModel.toggleCollapseState(toToggle);
}
function setCollapseStateLevelsUp(foldingModel, doCollapse, levels, lineNumbers) {
	const toToggle = [];
	for (const lineNumber of lineNumbers) {
		const regions = foldingModel.getAllRegionsAtLine(
			lineNumber,
			(region, level) => region.isCollapsed !== doCollapse && level <= levels
		);
		toToggle.push(...regions);
	}
	foldingModel.toggleCollapseState(toToggle);
}
function setCollapseStateForRest(foldingModel, doCollapse, blockedLineNumbers) {
	const filteredRegions = [];
	for (const lineNumber of blockedLineNumbers) {
		const regions = foldingModel.getAllRegionsAtLine(lineNumber, undefined);
		if (regions.length > 0) {
			filteredRegions.push(regions[0]);
		}
	}
	const filter = region =>
		filteredRegions.every(filteredRegion => !filteredRegion.containedBy(region) && !region.containedBy(filteredRegion)) &&
		region.isCollapsed !== doCollapse;
	const toToggle = foldingModel.getRegionsInside(null, filter);
	foldingModel.toggleCollapseState(toToggle);
}
function setCollapseStateForMatchingLines(foldingModel, regExp, doCollapse) {
	const editorModel = foldingModel.textModel;
	const regions = foldingModel.regions;
	const toToggle = [];
	for (let i = regions.length - 1; i >= 0; i--) {
		if (doCollapse !== regions.isCollapsed(i)) {
			const startLineNumber = regions.getStartLineNumber(i);
			if (regExp.test(editorModel.getLineContent(startLineNumber))) {
				toToggle.push(regions.toRegion(i));
			}
		}
	}
	foldingModel.toggleCollapseState(toToggle);
}
function setCollapseStateForType(foldingModel, type, doCollapse) {
	const regions = foldingModel.regions;
	const toToggle = [];
	for (let i = regions.length - 1; i >= 0; i--) {
		if (doCollapse !== regions.isCollapsed(i) && type === regions.getType(i)) {
			toToggle.push(regions.toRegion(i));
		}
	}
	foldingModel.toggleCollapseState(toToggle);
}

class FoldingAction extends EditorAction {
	runEditorCommand(accessor, editor2, args) {
		const languageConfigurationService = accessor.get(ILanguageConfigurationService);
		const foldingController = FoldingController.get(editor2);
		if (!foldingController) {
			return;
		}
		const foldingModelPromise = foldingController.getFoldingModel();
		if (foldingModelPromise) {
			return foldingModelPromise.then(foldingModel => {
				if (foldingModel) {
					this.invoke(foldingController, foldingModel, editor2, args, languageConfigurationService);
					const selection = editor2.getSelection();
					if (selection) {
						foldingController.reveal(selection.getStartPosition());
					}
				}
			});
		}
	}
	getSelectedLines(editor2) {
		const selections = editor2.getSelections();
		return selections ? selections.map(s => s.startLineNumber) : [];
	}
	getLineNumbers(args, editor2) {
		if (args && args.selectionLines) {
			return args.selectionLines.map(l => l + 1);
		}
		return this.getSelectedLines(editor2);
	}
	run(_accessor, _editor) {}
}
function foldingArgumentsConstraint(args) {
	if (!isUndefined(args)) {
		if (!isLiteralObject(args)) {
			return false;
		}
		const foldingArgs = args;
		if (!isUndefined(foldingArgs.levels) && !isNumberTypeAndIsNotNaN(foldingArgs.levels)) {
			return false;
		}
		if (!isUndefined(foldingArgs.direction) && 'string' !== typeof foldingArgs.direction) {
			return false;
		}
		if (
			!isUndefined(foldingArgs.selectionLines) &&
			(!isArray(foldingArgs.selectionLines) || !foldingArgs.selectionLines.every(isNumberTypeAndIsNotNaN))
		) {
			return false;
		}
	}
	return true;
}

class UnfoldAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.unfold',
			label: localize('Unfold'),
			alias: 'Unfold',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 1024 | 94,
				mac: {
					primary: 2048 | 512 | 94 // BracketRight
				},
				weight: 100 //editorContrib
			},
			metadata: {
				description: 'Unfold the content in the editor',
				args: [
					{
						name: 'Unfold editor argument',
						description: `Property-value pairs that can be passed through this argument:
						* 'levels': Number of levels to unfold. If not set, defaults to 1.
						* 'direction': If 'up', unfold given number of levels up otherwise unfolds down.
						* 'selectionLines': Array of the start lines (0-based) of the editor selections to apply the unfold action to. If not set, the active selection(s) will be used.
						`,
						constraint: foldingArgumentsConstraint,
						schema: {
							type: 'object',
							properties: {
								levels: {
									type: 'number',
									default: 1
								},
								direction: {
									type: 'string',
									enum: ['up', 'down'],
									default: 'down'
								},
								selectionLines: {
									type: 'array',
									items: {
										type: 'number'
									}
								}
							}
						}
					}
				]
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2, args) {
		const levels = (args && args.levels) || 1;
		const lineNumbers = this.getLineNumbers(args, editor2);
		if (args && args.direction === 'up') {
			setCollapseStateLevelsUp(foldingModel, false, levels, lineNumbers);
		} else {
			setCollapseStateLevelsDown(foldingModel, false, levels, lineNumbers);
		}
	}
}
registerEditorAction(UnfoldAction);

class UnFoldRecursivelyAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.unfoldRecursively',
			label: localize('Unfold Recursively'),
			alias: 'Unfold Recursively',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 94 // BracketRight
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2, _args) {
		setCollapseStateLevelsDown(foldingModel, false, Number.MAX_VALUE, this.getSelectedLines(editor2));
	}
}
registerEditorAction(UnFoldRecursivelyAction);

class FoldAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.fold',
			label: localize('Fold'),
			alias: 'Fold',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 1024 | 92,
				mac: {
					primary: 2048 | 512 | 92 // BracketLeft
				},
				weight: 100 //editorContrib
			},
			metadata: {
				description: 'Fold the content in the editor',
				args: [
					{
						name: 'Fold editor argument',
						description: `Property-value pairs that can be passed through this argument:
							* 'levels': Number of levels to fold.
							* 'direction': If 'up', folds given number of levels up otherwise folds down.
							* 'selectionLines': Array of the start lines (0-based) of the editor selections to apply the fold action to. If not set, the active selection(s) will be used.
							If no levels or direction is set, folds the region at the locations or if already collapsed, the first uncollapsed parent instead.
						`,
						constraint: foldingArgumentsConstraint,
						schema: {
							type: 'object',
							properties: {
								levels: { type: 'number' },
								direction: {
									type: 'string',
									enum: ['up', 'down']
								},
								selectionLines: {
									type: 'array',
									items: { type: 'number' }
								}
							}
						}
					}
				]
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2, args) {
		const lineNumbers = this.getLineNumbers(args, editor2);
		const levels = args && args.levels;
		const direction = args && args.direction;
		if (typeof levels !== 'number' && typeof direction !== 'string') {
			function _setCollapseStateUp(foldingModel, doCollapse, lineNumbers) {
				const toToggle = [];
				for (const lineNumber of lineNumbers) {
					const regions = foldingModel.getAllRegionsAtLine(lineNumber, region => region.isCollapsed !== doCollapse);
					if (regions.length > 0) {
						toToggle.push(regions[0]);
					}
				}
				foldingModel.toggleCollapseState(toToggle);
			}
			_setCollapseStateUp(foldingModel, true, lineNumbers);
		} else {
			if (direction === 'up') {
				setCollapseStateLevelsUp(foldingModel, true, levels || 1, lineNumbers);
			} else {
				setCollapseStateLevelsDown(foldingModel, true, levels || 1, lineNumbers);
			}
		}
	}
}
registerEditorAction(FoldAction);

class ToggleFoldAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.toggleFold',
			label: localize('Toggle Fold'),
			alias: 'Toggle Fold',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 42 // KeyL
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2) {
		const selectedLines = this.getSelectedLines(editor2);
		toggleCollapseState(foldingModel, 1, selectedLines);
	}
}
registerEditorAction(ToggleFoldAction);

class FoldRecursivelyAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.foldRecursively',
			label: localize('Fold Recursively'),
			alias: 'Fold Recursively',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 92 // BracketLeft
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2) {
		const selectedLines = this.getSelectedLines(editor2);
		setCollapseStateLevelsDown(foldingModel, true, Number.MAX_VALUE, selectedLines);
	}
}
registerEditorAction(FoldRecursivelyAction);

class FoldAllBlockCommentsAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.foldAllBlockComments',
			label: localize('Fold All Block Comments'),
			alias: 'Fold All Block Comments',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 90 // Slash
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2, args, languageConfigurationService) {
		if (foldingModel.regions.hasTypes()) {
			setCollapseStateForType(foldingModel, foldingRangeComment.value, true);
		} else {
			const editorModel = editor2.getModel();
			if (!editorModel) {
				return;
			}
			const comments = languageConfigurationService.getLanguageConfiguration(editorModel.getLanguageId()).comments;
			if (comments && comments.blockCommentStartToken) {
				const regExp = new RegExp('^\\s*' + escapeRegexChars(comments.blockCommentStartToken));
				setCollapseStateForMatchingLines(foldingModel, regExp, true);
			}
		}
	}
}
registerEditorAction(FoldAllBlockCommentsAction);

class FoldAllRegionsAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.foldAllMarkerRegions',
			label: localize('Fold All Regions'),
			alias: 'Fold All Regions',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 29 // Digit8
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2, args, languageConfigurationService) {
		if (foldingModel.regions.hasTypes()) {
			setCollapseStateForType(foldingModel, foldingRangeRegion.value, true);
		} else {
			const editorModel = editor2.getModel();
			if (!editorModel) {
				return;
			}
			const foldingRules = languageConfigurationService.getLanguageConfiguration(editorModel.getLanguageId()).foldingRules;
			if (foldingRules && foldingRules.markers && foldingRules.markers.start) {
				const regExp = new RegExp(foldingRules.markers.start);
				setCollapseStateForMatchingLines(foldingModel, regExp, true);
			}
		}
	}
}
registerEditorAction(FoldAllRegionsAction);

class UnfoldAllRegionsAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.unfoldAllMarkerRegions',
			label: localize('Unfold All Regions'),
			alias: 'Unfold All Regions',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 30 // Digit9
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2, args, languageConfigurationService) {
		if (foldingModel.regions.hasTypes()) {
			setCollapseStateForType(foldingModel, foldingRangeRegion.value, false);
		} else {
			const editorModel = editor2.getModel();
			if (!editorModel) {
				return;
			}
			const foldingRules = languageConfigurationService.getLanguageConfiguration(editorModel.getLanguageId()).foldingRules;
			if (foldingRules && foldingRules.markers && foldingRules.markers.start) {
				const regExp = new RegExp(foldingRules.markers.start);
				setCollapseStateForMatchingLines(foldingModel, regExp, false);
			}
		}
	}
}
registerEditorAction(UnfoldAllRegionsAction);

class FoldAllExceptAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.foldAllExcept',
			label: localize('Fold All Except Selected'),
			alias: 'Fold All Except Selected',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 88 // Minus
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2) {
		const selectedLines = this.getSelectedLines(editor2);
		setCollapseStateForRest(foldingModel, true, selectedLines);
	}
}
registerEditorAction(FoldAllExceptAction);

class UnfoldAllExceptAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.unfoldAllExcept',
			label: localize('Unfold All Except Selected'),
			alias: 'Unfold All Except Selected',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 86 // Equal
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2) {
		const selectedLines = this.getSelectedLines(editor2);
		setCollapseStateForRest(foldingModel, false, selectedLines);
	}
}
registerEditorAction(UnfoldAllExceptAction);

class FoldAllAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.foldAll',
			label: localize('Fold All'),
			alias: 'Fold All',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 21 // Digit0
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, _editor) {
		setCollapseStateLevelsDown(foldingModel, true);
	}
}
registerEditorAction(FoldAllAction);

class UnfoldAllAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.unfoldAll',
			label: localize('Unfold All'),
			alias: 'Unfold All',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 40 // KeyJ
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, _editor) {
		setCollapseStateLevelsDown(foldingModel, false);
	}
}
registerEditorAction(UnfoldAllAction);

class GotoParentFoldAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.gotoParentFold',
			label: localize('Go to Parent Fold'),
			alias: 'Go to Parent Fold',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2) {
		const selectedLines = this.getSelectedLines(editor2);
		if (selectedLines.length > 0) {
			function _getParentFoldLine(lineNumber, foldingModel) {
				let startLineNumber = null;
				const foldingRegion = foldingModel.getRegionAtLine(lineNumber);
				if (foldingRegion !== null) {
					startLineNumber = foldingRegion.startLineNumber;
					if (lineNumber === startLineNumber) {
						const parentFoldingIdx = foldingRegion.parentIndex;
						if (parentFoldingIdx !== -1) {
							startLineNumber = foldingModel.regions.getStartLineNumber(parentFoldingIdx);
						} else {
							startLineNumber = null;
						}
					}
				}
				return startLineNumber;
			}
			const startLineNumber = _getParentFoldLine(selectedLines[0], foldingModel);
			if (startLineNumber !== null) {
				editor2.setSelection({
					startLineNumber,
					startColumn: 1,
					endLineNumber: startLineNumber,
					endColumn: 1
				});
			}
		}
	}
}
registerEditorAction(GotoParentFoldAction);

class GotoPreviousFoldAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.gotoPreviousFold',
			label: localize('Go to Previous Folding Range'),
			alias: 'Go to Previous Folding Range',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2) {
		const selectedLines = this.getSelectedLines(editor2);
		if (selectedLines.length > 0) {
			function _getPreviousFoldLine(lineNumber, foldingModel) {
				let foldingRegion = foldingModel.getRegionAtLine(lineNumber);
				if (foldingRegion !== null && foldingRegion.startLineNumber === lineNumber) {
					if (lineNumber !== foldingRegion.startLineNumber) {
						return foldingRegion.startLineNumber;
					} else {
						const expectedParentIndex = foldingRegion.parentIndex;
						let minLineNumber = 0;
						if (expectedParentIndex !== -1) {
							minLineNumber = foldingModel.regions.getStartLineNumber(foldingRegion.parentIndex);
						}
						while (foldingRegion !== null) {
							if (foldingRegion.regionIndex > 0) {
								foldingRegion = foldingModel.regions.toRegion(foldingRegion.regionIndex - 1);
								if (foldingRegion.startLineNumber <= minLineNumber) {
									return null;
								} else if (foldingRegion.parentIndex === expectedParentIndex) {
									return foldingRegion.startLineNumber;
								}
							} else {
								return null;
							}
						}
					}
				} else {
					if (foldingModel.regions.length > 0) {
						foldingRegion = foldingModel.regions.toRegion(foldingModel.regions.length - 1);
						while (foldingRegion !== null) {
							if (foldingRegion.startLineNumber < lineNumber) {
								return foldingRegion.startLineNumber;
							}
							if (foldingRegion.regionIndex > 0) {
								foldingRegion = foldingModel.regions.toRegion(foldingRegion.regionIndex - 1);
							} else {
								foldingRegion = null;
							}
						}
					}
				}
				return null;
			}
			const startLineNumber = _getPreviousFoldLine(selectedLines[0], foldingModel);
			if (startLineNumber !== null) {
				editor2.setSelection({
					startLineNumber,
					startColumn: 1,
					endLineNumber: startLineNumber,
					endColumn: 1
				});
			}
		}
	}
}
registerEditorAction(GotoPreviousFoldAction);

class GotoNextFoldAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.gotoNextFold',
			label: localize('Go to Next Folding Range'),
			alias: 'Go to Next Folding Range',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2) {
		const selectedLines = this.getSelectedLines(editor2);
		if (selectedLines.length > 0) {
			function _getNextFoldLine(lineNumber, foldingModel) {
				let foldingRegion = foldingModel.getRegionAtLine(lineNumber);
				if (foldingRegion !== null && foldingRegion.startLineNumber === lineNumber) {
					const expectedParentIndex = foldingRegion.parentIndex;
					let maxLineNumber = 0;
					if (expectedParentIndex !== -1) {
						maxLineNumber = foldingModel.regions.getEndLineNumber(foldingRegion.parentIndex);
					} else if (foldingModel.regions.length === 0) {
						return null;
					} else {
						maxLineNumber = foldingModel.regions.getEndLineNumber(foldingModel.regions.length - 1);
					}
					while (foldingRegion !== null) {
						if (foldingRegion.regionIndex < foldingModel.regions.length) {
							foldingRegion = foldingModel.regions.toRegion(foldingRegion.regionIndex + 1);
							if (foldingRegion.startLineNumber >= maxLineNumber) {
								return null;
							} else if (foldingRegion.parentIndex === expectedParentIndex) {
								return foldingRegion.startLineNumber;
							}
						} else {
							return null;
						}
					}
				} else {
					if (foldingModel.regions.length > 0) {
						foldingRegion = foldingModel.regions.toRegion(0);
						while (foldingRegion !== null) {
							if (foldingRegion.startLineNumber > lineNumber) {
								return foldingRegion.startLineNumber;
							}
							if (foldingRegion.regionIndex < foldingModel.regions.length) {
								foldingRegion = foldingModel.regions.toRegion(foldingRegion.regionIndex + 1);
							} else {
								foldingRegion = null;
							}
						}
					}
				}
				return null;
			}
			const startLineNumber = _getNextFoldLine(selectedLines[0], foldingModel);
			if (startLineNumber !== null) {
				editor2.setSelection({
					startLineNumber,
					startColumn: 1,
					endLineNumber: startLineNumber,
					endColumn: 1
				});
			}
		}
	}
}
registerEditorAction(GotoNextFoldAction);

class FoldRangeFromSelectionAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.createFoldingRangeFromSelection',
			label: localize('Create Folding Range from EditorSelection'),
			alias: 'Create Folding Range from EditorSelection',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 87 // Comma
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(_foldingController, foldingModel, editor2) {
		const collapseRanges = [];
		const selections = editor2.getSelections();
		if (selections) {
			for (const selection of selections) {
				let endLineNumber = selection.endLineNumber;
				if (selection.endColumn === 1) {
					--endLineNumber;
				}
				if (endLineNumber > selection.startLineNumber) {
					collapseRanges.push({
						startLineNumber: selection.startLineNumber,
						endLineNumber,
						type: undefined,
						isCollapsed: true,
						source: 1 // FoldSource.userDefined
					});
					editor2.setSelection({
						startLineNumber: selection.startLineNumber,
						startColumn: 1,
						endLineNumber: selection.startLineNumber,
						endColumn: 1
					});
				}
			}
			if (collapseRanges.length > 0) {
				collapseRanges.sort((a, b) => {
					return a.startLineNumber - b.startLineNumber;
				});
				const newRanges = FoldingRegions.sanitizeAndMerge(foldingModel.regions, collapseRanges, editor2.getModel()?.getLineCount());
				foldingModel.updatePost(FoldingRegions.fromFoldRanges(newRanges));
			}
		}
	}
}
registerEditorAction(FoldRangeFromSelectionAction);

class RemoveFoldRangeFromSelectionAction extends FoldingAction {
	constructor() {
		super({
			id: 'editor.removeManualFoldingRanges',
			label: localize('Remove Manual Folding Ranges'),
			alias: 'Remove Manual Folding Ranges',
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 89 // Period
				),
				weight: 100 //editorContrib
			}
		});
	}
	invoke(foldingController, foldingModel, editor2) {
		const selections = editor2.getSelections();
		if (selections) {
			const ranges = [];
			for (const selection of selections) {
				const { startLineNumber, endLineNumber } = selection;
				ranges.push(endLineNumber >= startLineNumber ? { startLineNumber, endLineNumber } : { endLineNumber, startLineNumber });
			}
			foldingModel.removeManualRanges(ranges);
			foldingController.triggerFoldingModelChanged();
		}
	}
}
registerEditorAction(RemoveFoldRangeFromSelectionAction);

class FoldLevelAction extends FoldingAction {
	getFoldingLevel() {
		return parseInt(
			this.id.substr(
				17 // PREFIX (editor.foldLevel) length
			)
		);
	}
	invoke(_foldingController, foldingModel, editor2) {
		function _setCollapseStateAtLevel(foldingModel, foldLevel, doCollapse, blockedLineNumbers) {
			const filter = (region, level) =>
				level === foldLevel && region.isCollapsed !== doCollapse && !blockedLineNumbers.some(line => region.containsLine(line));
			const toToggle = foldingModel.getRegionsInside(null, filter);
			foldingModel.toggleCollapseState(toToggle);
		}
		_setCollapseStateAtLevel(foldingModel, this.getFoldingLevel(), true, this.getSelectedLines(editor2));
	}
}
for (let i = 1; i <= 7; i++) {
	registerInstantiatedEditorAction(
		new FoldLevelAction({
			id: `editor.foldLevel ${i}`,
			label: localize(i),
			alias: `Fold Level ${i}`,
			precondition: ck_foldingEnabled,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(2048 | 41, 2048 | (21 + i)),
				weight: 100 //editorContrib
			}
		})
	);
}

commandsRegistry.registerCommand('_executeFoldingRangeProvider', async function (accessor, ...args) {
	const [resource] = args;
	if (!(resource instanceof URI)) {
		throw illegalArgument();
	}
	const languageFeaturesService = accessor.get(ILanguageFeaturesService);
	const model = accessor.get(IModelService).getModel(resource);
	if (!model) {
		throw illegalArgument();
	}
	const configurationService = accessor.get(IConfigurationService);
	if (!configurationService.getValue('editor.folding', { resource })) {
		return [];
	}
	const languageConfigurationService = accessor.get(ILanguageConfigurationService);
	const strategy = configurationService.getValue('editor.foldingStrategy', { resource });
	const foldingLimitReporter = {
		get limit() {
			return configurationService.getValue('editor.foldingMaximumRegions', { resource });
		},
		update: (computed, limited) => {}
	};
	const indentRangeProvider = new IndentRangeProvider(model, languageConfigurationService, foldingLimitReporter);
	let rangeProvider = indentRangeProvider;
	if (strategy !== 'indentation') {
		const providers = FoldingController.getFoldingRangeProviders(languageFeaturesService, model);
		if (providers.length) {
			rangeProvider = new SyntaxRangeProvider(model, providers, dummyArrowFn, foldingLimitReporter, indentRangeProvider);
		}
	}
	const ranges = await rangeProvider.compute(cancellationToken_none);
	const result = [];
	try {
		if (ranges) {
			for (let i = 0; i < ranges.length; i++) {
				const rangeType = ranges.getType(i);
				let kind;
				switch (rangeType) {
					case 'comment':
						kind = foldingRangeComment;
						break;
					case 'imports':
						kind = foldingRangeImports;
						break;
					case 'region':
						kind = foldingRangeRegion;
						break;
					default:
						kind = rangeType ? { value: rangeType } : undefined;
				}

				result.push({
					start: ranges.getStartLineNumber(i),
					end: ranges.getEndLineNumber(i),
					kind: kind
				});
			}
		}
		return result;
	} finally {
		rangeProvider.dispose();
	}
});