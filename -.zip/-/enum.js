

const TypeNavigationMode = {
    Automatic: 0,
    Trigger: 1,
    '0': 'Automatic',
    '1': 'Trigger'
};

const TypeNavigationControllerState = {
    Idle: 0,
    Typing: 1,
    '0': 'Idle',
    '1': 'Typing'
}

const ObjectTreeElementCollapseState = {
	Expanded: 0,
	Collapsed: 1,
	PreserveOrExpanded: 2,
	PreserveOrCollapsed: 3,
	0: 'Expanded',
	1: 'Collapsed',
	2: 'PreserveOrExpanded',
	3: 'PreserveOrCollapsed'
};

const TreeMouseEventTarget = {
	Unknown: 0,
	Twistie: 1,
	Element: 2,
	Filter: 3,
	0: 'Unknown',
	1: 'Twistie',
	2: 'Element',
	3: 'Filter'
};














function toFoldingRangeKind2(kind) {
	switch (kind) {
		case 'comment':
			return foldingRangeComment;
		case 'imports':
			return foldingRangeImports;
		case 'region':
			return foldingRangeRegion;
	}
	return;
}

	const FoldingRangeKind2 = {};
	{
		FoldingRangeKind2['Comment'] = 'comment';
		FoldingRangeKind2['Imports'] = 'imports';
		FoldingRangeKind2['Region'] = 'region';
	}


	const TreeFindMode = {
		0: 'Highlight',
		1: 'Filter',
		Highlight: 0,
		Filter: 1
	};




// node_modules/monaco-editor/esm/vs/platform/files/common/files.js
const FileKind = {
	FILE: 0,
	0: 'FILE',
	FOLDER: 1,
	1: 'FOLDER',
	ROOT_FOLDER: 2,
	2: 'ROOT_FOLDER'
};







	const InsertTextFormat = {
		PlainText: 1,
		Snippet: 2
	};


	const DiagnosticSeverity = {
		Error: 1,
		Warning: 2,
		Information: 3,
		Hint: 4
	};



const TriggerAction = {
	NO_ACTION: 0,
	CLOSE_PICKER: 1,
	REFRESH_PICKER: 2,
	REMOVE_ITEM: 3,
	0: 'NO_ACTION',
	1: 'CLOSE_PICKER',
	2: 'REFRESH_PICKER',
	3: 'REMOVE_ITEM'
};

/*

Hint: 1,
Info: 2,
Warning: 4,
Error: 8,

	function fromSeverity(severity) {
		switch (severity) {
			case 3:
				return 8;
			case 2:
				return 4;
			case 1:
				return 2;
			case 0:
				return 1;
		}
	}

	function toSeverity(severity) {
		switch (severity) {
			case 8:
				return 3;
			case 4:
				return 2;
			case 2:
				return 1;
			case 1:
				return 0;
		}
	}


	const QuickInputListFocus = {
		First: 1,
		1: 'First',
		Second: 2,
		2: 'Second',
		Last: 3,
		3: 'Last',
		Next: 4,
		4: 'Next',
		Previous: 5,
		5: 'Previous',
		NextPage: 6,
		6: 'NextPage',
		PreviousPage: 7,
		7: 'PreviousPage',
		NextSeparator: 8,
		8: 'NextSeparator',
		PreviousSeparator: 9,
		9: 'PreviousSeparator'
	};

	const QuickPickSeparatorFocusReason = {
		NONE: 0,
		0: 'NONE',
		MOUSE_HOVER: 1,
		1: 'MOUSE_HOVER',
		ACTIVE_ITEM: 2,
		2: 'ACTIVE_ITEM'
	};

	const ColorScheme = {
		DARK: 'dark',
		LIGHT: 'light',
		HIGH_CONTRAST_DARK: 'hcDark',
		HIGH_CONTRAST_LIGHT: 'hcLight'
	};
*/


const VersionIdChangeReason = {
	Undo: 0,
	0: 'Undo',
	Redo: 1,
	1: 'Redo',
	AcceptWord: 2,
	2: 'AcceptWord',
	Other: 3,
	3: 'Other'
};




const MarkerTag = {
	Unnecessary: 1,
	Deprecated: 2,
	1: 'Unnecessary',
	2: 'Deprecated'
};



const DocumentPasteTriggerKind = {
	Automatic: 0,
	PasteAs: 1,
	0: 'Automatic',
	1: 'PasteAs'
};



const EditorType = {
	ICodeEditor: 1//'vs.editor.ICodeEditor', //1
	IDiffEditor: 2//'vs.editor.IDiffEditor', //2
};
const ShowLightbulbIconMode = {
	Off: 'off',
	OnCode: 'onCode',
	On: 'on'
};

const TextEditorCursorStyle = {
	Line: 1,
	Block: 2,
	Underline: 3,
	LineThin: 4,
	BlockOutline: 5,
	UnderlineThin: 6,
	1: 'Line',
	2: 'Block',
	3: 'Underline',
	4: 'LineThin',
	5: 'BlockOutline',
	6: 'UnderlineThin'
};

const PositionAffinity = {
	Left: 0,
	Right: 1,
	None: 2,
	LeftOfInjectedText: 3,
	RightOfInjectedText: 4,
	0: 'Left',
	1: 'Right',
	2: 'None',
	3: 'LeftOfInjectedText',
	4: 'RightOfInjectedText'
};


const InjectedTextCursorStops = {
	Both: 0,
	Right: 1,
	Left: 2,
	None: 3,
	0: 'Both',
	1: 'Right',
	2: 'Left',
	3: 'None'
};

const WrappingIndent = {
	None: 0,
	Same: 1,
	Indent: 2,
	DeepIndent: 3,
	0: 'None',
	1: 'Same',
	2: 'Indent',
	3: 'DeepIndent'
};
const TrackedRangeStickiness = {
	AlwaysGrowsWhenTypingAtEdges: 0,
	NeverGrowsWhenTypingAtEdges: 1,
	GrowsOnlyWhenTypingBefore: 2,
	GrowsOnlyWhenTypingAfter: 3,
	0: 'AlwaysGrowsWhenTypingAtEdges',
	1: 'NeverGrowsWhenTypingAtEdges',
	2: 'GrowsOnlyWhenTypingBefore',
	3: 'GrowsOnlyWhenTypingAfter'
};

const TextEditorCursorBlinkingStyle = {
	Hidden: 0,
	Blink: 1,
	Smooth: 2,
	Phase: 3,
	Expand: 4,
	Solid: 5,
	0: 'Hidden',
	1: 'Blink',
	2: 'Smooth',
	3: 'Phase',
	4: 'Expand',
	5: 'Solid'
};

const ScrollType = {
	Smooth: 0,
	Immediate: 1,
	0: 'Smooth',
	1: 'Immediate'
};

const ScrollbarVisibility = {
	Auto: 1,
	Hidden: 2,
	Visible: 3,
	1: 'Auto',
	2: 'Hidden',
	3: 'Visible'
};

const RenderMinimap = {
	None: 0,
	Text: 1,
	Blocks: 2,
	0: 'None',
	1: 'Text',
	2: 'Blocks'
};

const RenderLineNumbersType = {
	Off: 0,
	On: 1,
	Relative: 2,
	Interval: 3,
	Custom: 4,
	0: 'Off',
	1: 'On',
	2: 'Relative',
	3: 'Interval',
	4: 'Custom'
};


const GlyphMarginLane = {
	Left: 1,
	Center: 2,
	Right: 3,
	1: 'Left',
	2: 'Center',
	3: 'Right'
};



const OverlayWidgetPositionPreference = {
	TOP_RIGHT_CORNER: 0,
	BOTTOM_RIGHT_CORNER: 1,
	TOP_CENTER: 2,
	0: 'TOP_RIGHT_CORNER',
	1: 'BOTTOM_RIGHT_CORNER',
	2: 'TOP_CENTER'
};

const MouseTargetType = {
	UNKNOWN: 0,
	TEXTAREA: 1,
	GUTTER_GLYPH_MARGIN: 2,
	GUTTER_LINE_NUMBERS: 3,
	GUTTER_LINE_DECORATIONS: 4,
	GUTTER_VIEW_ZONE: 5,
	CONTENT_TEXT: 6,
	CONTENT_EMPTY: 7,
	CONTENT_VIEW_ZONE: 8,
	CONTENT_WIDGET: 9,
	OVERVIEW_RULER: 10,
	SCROLLBAR: 11,
	OVERLAY_WIDGET: 12,
	OUTSIDE_EDITOR: 13,
	0: 'UNKNOWN',
	1: 'TEXTAREA',
	2: 'GUTTER_GLYPH_MARGIN',
	3: 'GUTTER_LINE_NUMBERS',
	4: 'GUTTER_LINE_DECORATIONS',
	5: 'GUTTER_VIEW_ZONE',
	6: 'CONTENT_TEXT',
	7: 'CONTENT_EMPTY',
	8: 'CONTENT_VIEW_ZONE',
	9: 'CONTENT_WIDGET',
	10: 'OVERVIEW_RULER',
	11: 'SCROLLBAR',
	12: 'OVERLAY_WIDGET',
	13: 'OUTSIDE_EDITOR'
};


const MinimapSectionHeaderStyle = {
	Normal: 1,
	Underlined: 2,
	1: 'Normal',
	2: 'Underlined'
};

const MinimapPosition = {
	Inline: 1,
	Gutter: 2,
	1: 'Inline',
	2: 'Gutter'
};


const EndOfLineSequence = {
	LF: 0,
	CRLF: 1,
	0: 'LF',
	1: 'CRLF'
};

const EndOfLinePreference = {
	TextDefined: 0,
	LF: 1,
	CRLF: 2,
	0: 'TextDefined',
	1: 'LF',
	2: 'CRLF'
};


const EditorOption = {
	acceptSuggestionOnCommitCharacter: 0,
	acceptSuggestionOnEnter: 1,
	accessibilitySupport: 2,
	accessibilityPageSize: 3,
	ariaLabel: 4,
	ariaRequired: 5,
	autoClosingBrackets: 6,
	autoClosingComments: 7,
	screenReaderAnnounceInlineSuggestion: 8,
	autoClosingDelete: 9,
	autoClosingOvertype: 10,
	autoClosingQuotes: 11,
	autoIndent: 12,
	0: 'acceptSuggestionOnCommitCharacter',
	1: 'acceptSuggestionOnEnter',
	2: 'accessibilitySupport',
	3: 'accessibilityPageSize',
	4: 'ariaLabel',
	5: 'ariaRequired',
	6: 'autoClosingBrackets',
	7: 'autoClosingComments',
	8: 'screenReaderAnnounceInlineSuggestion',
	9: 'autoClosingDelete',
	10: 'autoClosingOvertype',
	11: 'autoClosingQuotes',
	12: 'autoIndent',
	automaticLayout: 13,
	autoSurround: 14,
	bracketPairColorization: 15,
	guides: 16,
	codeLens: 17,
	codeLensFontFamily: 18,
	codeLensFontSize: 19,
	colorDecorators: 20,
	colorDecoratorsLimit: 21,
	columnSelection: 22,
	comments: 23,
	contextmenu: 24,
	copyWithSyntaxHighlighting: 25,
	cursorBlinking: 26,
	cursorSmoothCaretAnimation: 27,
	cursorStyle: 28,
	cursorSurroundingLines: 29,
	cursorSurroundingLinesStyle: 30,
	cursorWidth: 31,
	13: 'automaticLayout',
	14: 'autoSurround',
	15: 'bracketPairColorization',
	16: 'guides',
	17: 'codeLens',
	18: 'codeLensFontFamily',
	19: 'codeLensFontSize',
	20: 'colorDecorators',
	21: 'colorDecoratorsLimit',
	22: 'columnSelection',
	23: 'comments',
	24: 'contextmenu',
	25: 'copyWithSyntaxHighlighting',
	26: 'cursorBlinking',
	27: 'cursorSmoothCaretAnimation',
	28: 'cursorStyle',
	29: 'cursorSurroundingLines',
	30: 'cursorSurroundingLinesStyle',
	31: 'cursorWidth',

	disableLayerHinting: 32,
	disableMonospaceOptimizations: 33,
	domReadOnly: 34,
	dragAndDrop: 35,
	dropIntoEditor: 36,
	emptySelectionClipboard: 37,
	experimentalWhitespaceRendering: 38,
	extraEditorClassName: 39,
	fastScrollSensitivity: 40,
	find: 41,
	fixedOverflowWidgets: 42,
	folding: 43,
	foldingStrategy: 44,
	foldingHighlight: 45,
	foldingImportsByDefault: 46,
	foldingMaximumRegions: 47,
	unfoldOnClickAfterEndOfLine: 48,
	fontFamily: 49,
	fontInfo: 50,
	32: 'disableLayerHinting',
	33: 'disableMonospaceOptimizations',
	34: 'domReadOnly',
	35: 'dragAndDrop',
	36: 'dropIntoEditor',
	37: 'emptySelectionClipboard',
	38: 'experimentalWhitespaceRendering',
	39: 'extraEditorClassName',
	40: 'fastScrollSensitivity',
	41: 'find',
	42: 'fixedOverflowWidgets',
	43: 'folding',
	44: 'foldingStrategy',
	45: 'foldingHighlight',
	46: 'foldingImportsByDefault',
	47: 'foldingMaximumRegions',
	48: 'unfoldOnClickAfterEndOfLine',
	49: 'fontFamily',
	50: 'fontInfo',
	fontLigatures: 51,
	fontSize: 52,
	fontWeight: 53,
	fontVariations: 54,
	formatOnPaste: 55,
	formatOnType: 56,
	glyphMargin: 57,
	gotoLocation: 58,
	hideCursorInOverviewRuler: 59,
	hover: 60,
	inDiffEditor: 61,
	inlineSuggest: 62,
	inlineEdit: 63,
	letterSpacing: 64,
	lightbulb: 65,
	lineDecorationsWidth: 66,
	lineHeight: 67,
	lineNumbers: 68,
	lineNumbersMinChars: 69,
	linkedEditing: 70,
	links: 71,
	51: 'fontLigatures',
	52: 'fontSize',
	53: 'fontWeight',
	54: 'fontVariations',
	55: 'formatOnPaste',
	56: 'formatOnType',
	57: 'glyphMargin',
	58: 'gotoLocation',
	59: 'hideCursorInOverviewRuler',
	60: 'hover',
	61: 'inDiffEditor',
	62: 'inlineSuggest',
	63: 'inlineEdit',
	64: 'letterSpacing',
	65: 'lightbulb',
	66: 'lineDecorationsWidth',
	67: 'lineHeight',
	68: 'lineNumbers',
	69: 'lineNumbersMinChars',
	70: 'linkedEditing',
	71: 'links',
	matchBrackets: 72,
	minimap: 73,
	mouseStyle: 74,
	mouseWheelScrollSensitivity: 75,
	mouseWheelZoom: 76,
	multiCursorMergeOverlapping: 77,
	multiCursorModifier: 78,
	multiCursorPaste: 79,
	multiCursorLimit: 80,
	occurrencesHighlight: 81,
	overviewRulerBorder: 82,
	overviewRulerLanes: 83,
	padding: 84,
	pasteAs: 85,
	parameterHints: 86,
	peekWidgetDefaultFocus: 87,
	definitionLinkOpensInPeek: 88,
	quickSuggestions: 89,
	quickSuggestionsDelay: 90,
	readOnly: 91,
	72: 'matchBrackets',
	73: 'minimap',
	74: 'mouseStyle',
	75: 'mouseWheelScrollSensitivity',
	76: 'mouseWheelZoom',
	77: 'multiCursorMergeOverlapping',
	78: 'multiCursorModifier',
	79: 'multiCursorPaste',
	80: 'multiCursorLimit',
	81: 'occurrencesHighlight',
	82: 'overviewRulerBorder',
	83: 'overviewRulerLanes',
	84: 'padding',
	85: 'pasteAs',
	86: 'parameterHints',
	87: 'peekWidgetDefaultFocus',
	88: 'definitionLinkOpensInPeek',
	89: 'quickSuggestions',
	90: 'quickSuggestionsDelay',
	91: 'readOnly',
	readOnlyMessage: 92,
	renameOnType: 93,
	renderControlCharacters: 94,
	renderFinalNewline: 95,
	renderLineHighlight: 96,
	renderLineHighlightOnlyWhenFocus: 97,
	renderValidationDecorations: 98,
	renderWhitespace: 99,
	revealHorizontalRightPadding: 100,
	roundedSelection: 101,
	rulers: 102,
	scrollbar: 103,
	scrollBeyondLastColumn: 104,
	scrollBeyondLastLine: 105,
	scrollPredominantAxis: 106,
	selectionClipboard: 107,
	selectionHighlight: 108,
	selectOnLineNumbers: 109,
	showFoldingControls: 110,
	showUnused: 111,
	snippetSuggestions: 112,
	smartSelect: 113,
	smoothScrolling: 114,
	stickyScroll: 115,
	stickyTabStops: 116,
	92: 'readOnlyMessage',
	93: 'renameOnType',
	94: 'renderControlCharacters',
	95: 'renderFinalNewline',
	96: 'renderLineHighlight',
	97: 'renderLineHighlightOnlyWhenFocus',
	98: 'renderValidationDecorations',
	99: 'renderWhitespace',
	100: 'revealHorizontalRightPadding',
	101: 'roundedSelection',
	102: 'rulers',
	103: 'scrollbar',
	104: 'scrollBeyondLastColumn',
	105: 'scrollBeyondLastLine',
	106: 'scrollPredominantAxis',
	107: 'selectionClipboard',
	108: 'selectionHighlight',
	109: 'selectOnLineNumbers',
	110: 'showFoldingControls',
	111: 'showUnused',
	112: 'snippetSuggestions',
	113: 'smartSelect',
	114: 'smoothScrolling',
	115: 'stickyScroll',
	116: 'stickyTabStops',
	stopRenderingLineAfter: 117,
	suggest: 118,
	suggestFontSize: 119,
	suggestLineHeight: 120,
	suggestOnTriggerCharacters: 121,
	suggestSelection: 122,
	tabCompletion: 123,
	tabIndex: 124,
	unicodeHighlighting: 125,
	unusualLineTerminators: 126,
	useShadowDOM: 127,
	useTabStops: 128,
	wordBreak: 129,
	wordSegmenterLocales: 130,
	wordSeparators: 131,
	wordWrap: 132,
	wordWrapBreakAfterCharacters: 133,
	wordWrapBreakBeforeCharacters: 134,
	wordWrapColumn: 135,
	wordWrapOverride1: 136,
	wordWrapOverride2: 137,
	wrappingIndent: 138,
	wrappingStrategy: 139,
	showDeprecated: 140,
	inlayHints: 141,
	editorClassName: 142,
	pixelRatio: 143,
	tabFocusMode: 144,
	layoutInfo: 145,
	wrappingInfo: 146,
	defaultColorDecorators: 147,
	colorDecoratorsActivatedOn: 148,
	inlineCompletionsAccessibilityVerbose: 149,
	117: 'stopRenderingLineAfter',
	118: 'suggest',
	119: 'suggestFontSize',
	120: 'suggestLineHeight',
	121: 'suggestOnTriggerCharacters',
	122: 'suggestSelection',
	123: 'tabCompletion',
	124: 'tabIndex',
	125: 'unicodeHighlighting',
	126: 'unusualLineTerminators',
	127: 'useShadowDOM',
	128: 'useTabStops',
	129: 'wordBreak',
	130: 'wordSegmenterLocales',
	131: 'wordSeparators',
	132: 'wordWrap',
	133: 'wordWrapBreakAfterCharacters',
	134: 'wordWrapBreakBeforeCharacters',
	135: 'wordWrapColumn',
	136: 'wordWrapOverride1',
	137: 'wordWrapOverride2',
	138: 'wrappingIndent',
	139: 'wrappingStrategy',
	140: 'showDeprecated',
	141: 'inlayHints',
	142: 'editorClassName',
	143: 'pixelRatio',
	144: 'tabFocusMode',
	145: 'layoutInfo',
	146: 'wrappingInfo',
	147: 'defaultColorDecorators',
	148: 'colorDecoratorsActivatedOn',
	149: 'inlineCompletionsAccessibilityVerbose'
};


const EditorAutoIndentStrategy = {
	None: 0,
	Keep: 1,
	Brackets: 2,
	Advanced: 3,
	Full: 4,
	0: 'None',
	1: 'Keep',
	2: 'Brackets',
	3: 'Advanced',
	4: 'Full'
};

const DefaultEndOfLine = {
	LF: 1,
	CRLF: 2,
	1: 'LF',
	2: 'CRLF'
};
const CursorChangeReason = {
	NotSet: 0,
	ContentFlush: 1,
	RecoverFromMarkers: 2,
	Explicit: 3,
	Paste: 4,
	Undo: 5,
	Redo: 6,
	0: 'NotSet',
	1: 'ContentFlush',
	2: 'RecoverFromMarkers',
	3: 'Explicit',
	4: 'Paste',
	5: 'Undo',
	6: 'Redo'
};

const ContentWidgetPositionPreference = {
	EXACT: 0,
	ABOVE: 1,
	BELOW: 2,
	0: 'EXACT',
	1: 'ABOVE',
	2: 'BELOW'
};
const AccessibilitySupport = {
	Unknown: 0,
	Disabled: 1,
	Enabled: 2,
	0: 'Unknown',
	1: 'Disabled',
	2: 'Enabled'
};

const PartialAcceptTriggerKind = {
	Word: 0,
	Line: 1,
	Suggest: 2,
	0: 'Word',
	1: 'Line',
	2: 'Suggest'
};


const HoverVerbosityAction = {
	Increase: 0,
	Decrease: 1,
	0: 'Increase',
	1: 'Decrease'
};

const NewSymbolNameTriggerKind = {
	Invoke: 0,
	Automatic: 1,
	0: 'Invoke',
	1: 'Automatic'
};

const NewSymbolNameTag = {
	AIGenerated: 1,
	1: 'AIGenerated'
};

const CodeActionTriggerType = {
	Invoke: 1,
	Auto: 2,
	1: 'Invoke',
	2: 'Auto'
};


const InlineEditTriggerKind = {
	Invoke: 0,
	Automatic: 1,
	0: 'Invoke',
	1: 'Automatic'
};


const InlineCompletionTriggerKind = {
	Automatic: 0,
	Explicit: 1,
	0: 'Automatic',
	1: 'Explicit'
};

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


const InlayHintKind = {
	Type: 1,
	Parameter: 2,
	1: 'Type',
	2: 'Parameter'
};

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

const SignatureHelpTriggerKind = {
	Invoke: 1,
	TriggerCharacter: 2,
	ContentChange: 3,
	1: 'Invoke',
	2: 'TriggerCharacter',
	3: 'ContentChange'
};




// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

const CompletionTriggerKind = {
	Invoke: 0,
	TriggerCharacter: 1,
	TriggerForIncompleteCompletions: 2,
	0: 'Invoke',
	1: 'TriggerCharacter',
	2: 'TriggerForIncompleteCompletions'
};

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

const IndentAction = {
	None: 0,
	Indent: 1,
	IndentOutdent: 2,
	Outdent: 3,
	0: 'None',
	1: 'Indent',
	2: 'IndentOutdent',
	3: 'Outdent'
};




// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

const SymbolTag = {
	Deprecated: 1,
	1: 'Deprecated'
};


	const SymbolTag2 = {
		Deprecated: 1
	};


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

const SymbolKind = {
	File: 0,
	Module: 1,
	Namespace: 2,
	Package: 3,
	Class: 4,
	Method: 5,
	Property: 6,
	Field: 7,
	Constructor: 8,
	Enum: 9,
	Interface: 10,
	Function: 11,
	Variable: 12,
	Constant: 13,
	String: 14,
	Number: 15,
	Boolean: 16,
	Array: 17,
	Object: 18,
	Key: 19,
	Null: 20,
	EnumMember: 21,
	Struct: 22,
	Event: 23,
	Operator: 24,
	TypeParameter: 25,
	0: 'File',
	1: 'Module',
	2: 'Namespace',
	3: 'Package',
	4: 'Class',
	5: 'Method',
	6: 'Property',
	7: 'Field',
	8: 'Constructor',
	9: 'Enum',
	10: 'Interface',
	11: 'Function',
	12: 'Variable',
	13: 'Constant',
	14: 'String',
	15: 'Number',
	16: 'Boolean',
	17: 'Array',
	18: 'Object',
	19: 'Key',
	20: 'Null',
	21: 'EnumMember',
	22: 'Struct',
	23: 'Event',
	24: 'Operator',
	25: 'TypeParameter'
};
const SymbolKind2 = {
	File: 1,
	Module: 2,
	Namespace: 3,
	Package: 4,
	Class: 5,
	Method: 6,
	Property: 7,
	Field: 8,
	Constructor: 9,
	Enum: 10,
	Interface: 11,
	Function: 12,
	Variable: 13,
	Constant: 14,
	String: 15,
	Number: 16,
	Boolean: 17,
	Array: 18,
	Object: 19,
	Key: 20,
	Null: 21,
	EnumMember: 22,
	Struct: 23,
	Event: 24,
	Operator: 25,
	TypeParameter: 26
};


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

const CompletionItemInsertTextRule = {
	None: 0,
	KeepWhitespace: 1,
	InsertAsSnippet: 4,
	0: 'None',
	1: 'KeepWhitespace',
	4: 'InsertAsSnippet'
};

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


const CompletionItemKind = {
	Method: 0,
	Function: 1,
	Constructor: 2,
	Field: 3,
	Variable: 4,
	Class: 5,
	Struct: 6,
	Interface: 7,
	Module: 8,
	Property: 9,
	Event: 10,
	Operator: 11,
	Unit: 12,
	Value: 13,
	Constant: 14,
	Enum: 15,
	EnumMember: 16,
	Keyword: 17,
	Text: 18,
	Color: 19,
	File: 20,
	Reference: 21,
	Customcolor: 22,
	Folder: 23,
	TypeParameter: 24,
	User: 25,
	Issue: 26,
	Snippet: 27,
	0: 'Method',
	1: 'Function',
	2: 'Constructor',
	3: 'Field',
	4: 'Variable',
	5: 'Class',
	6: 'Struct',
	7: 'Interface',
	8: 'Module',
	9: 'Property',
	10: 'Event',
	11: 'Operator',
	12: 'Unit',
	13: 'Value',
	14: 'Constant',
	15: 'Enum',
	16: 'EnumMember',
	17: 'Keyword',
	18: 'Text',
	19: 'Color',
	20: 'File',
	21: 'Reference',
	22: 'Customcolor',
	23: 'Folder',
	24: 'TypeParameter',
	25: 'User',
	26: 'Issue',
	27: 'Snippet'
};
const CompletionItemKind2 = {
	Text: 1,
	Method: 2,
	Function: 3,
	Constructor: 4,
	Field: 5,
	Variable: 6,
	Class: 7,
	Interface: 8,
	Module: 9,
	Property: 10,
	Unit: 11,
	Value: 12,
	Enum: 13,
	Keyword: 14,
	Snippet: 15,
	Color: 16,
	File: 17,
	Reference: 18,
	Folder: 19,
	EnumMember: 20,
	Constant: 21,
	Struct: 22,
	Event: 23,
	Operator: 24,
	TypeParameter: 25
};


const CompletionItemTag = {
	Deprecated: 1,
	1: 'Deprecated'
};
const CompletionItemTag2 = {
	Deprecated: 1
};



// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

const DocumentHighlightKind = {
	Text: 0,
	Read: 1,
	Write: 2,
	0: 'Text',
	1: 'Read',
	2: 'Write'
};

const DocumentHighlightKind3 = {
	Text: 1,
	Read: 2,
	Write: 3
};


