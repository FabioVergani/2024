const editorDefault_wordSeparators = [
	'`',
	'~',
	'!',
	'@',
	'#',
	'$',
	'%',
	'^',
	'&',
	'*',
	'(',
	')',
	'-',
	'=',
	'+',
	'[',
	'{',
	']',
	'}',
	'\\',
	'|',
	';',
	':',
	"'",
	'"',
	',',
	'.',
	'<',
	'>',
	'/',
	'?'
];

// prettier-ignore
const editorDefault_wordSeparatorsRE = new RegExp(
	`(-?\\d*\\.\\d\\w*)|([^${
		editorDefault_wordSeparators.map(e => `\\${e}`).join('')
	}\\s]+)`,
	'g'
);
