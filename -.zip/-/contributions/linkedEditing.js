const ck_linkedEditingInputVisible = new RawContextKey('LinkedEditingInputVisible', false);

function getLinkedEditingRanges(providers, model, position, token) {
	const orderedByScore = providers.ordered(model);
	return first(
		orderedByScore.map(provider => async () => {
			try {
				return await provider.provideLinkedEditingRanges(model, position, token);
			} catch (e) {
				onUnexpectedExternalError(e);
				return;
			}
		}),
		result => !!result && isArrayAndHasLength(result?.ranges)
	);
}

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const linkedEditingContribution_id = 'editor.contrib.linkedEditing';

const opts_linkedEditing = ModelDecorationOptions.register({
	description: 'linked-editing',
	className: 'linked-editing-decoration',
	stickiness: 0
});

class LinkedEditingContribution extends Disposable {
	static get(editor2) {
		return editor2.getContribution(linkedEditingContribution_id);
	}
	constructor(editor2, contextKeyService, languageFeaturesService, languageConfigurationService, languageFeatureDebounceService) {
		super();
		this.languageConfigurationService = languageConfigurationService;
		this._syncRangesToken = 0;
		this._localToDispose = this._register(new DisposableStore());
		this._editor = editor2;
		this._providers = languageFeaturesService.linkedEditingRangeProvider;
		this._enabled = false;
		this._visibleContextKey = ck_linkedEditingInputVisible.bindTo(contextKeyService);
		this._debounceInformation = languageFeatureDebounceService.for(this._providers, 'Linked Editing', { max: 200 });
		this._currentDecorations = this._editor.createDecorationsCollection();
		this._languageWordPattern = null;
		this._currentWordPattern = null;
		this._ignoreChangeEvent = false;
		this._localToDispose = this._register(new DisposableStore());
		this._rangeUpdateTriggerPromise = null;
		this._rangeSyncTriggerPromise = null;
		this._currentRequestCts = null;
		this._currentRequestPosition = null;
		this._currentRequestModelVersion = null;
		this._register(this._editor.onDidChangeModel(() => this.reinitialize(true)));
		this._register(
			this._editor.onDidChangeConfiguration(e => {
				if (
					e.hasChanged(
						70 // linkedEditing
					) ||
					e.hasChanged(
						93 // renameOnType
					)
				) {
					this.reinitialize(false);
				}
			})
		);
		this._register(this._providers.onDidChange(() => this.reinitialize(false)));
		this._register(this._editor.onDidChangeModelLanguage(() => this.reinitialize(true)));
		this.reinitialize(true);
	}
	reinitialize(forceRefresh) {
		const model = this._editor.getModel();
		const isEnabled =
			model !== null &&
			(this._editor.getOption(
				70 // linkedEditing
			) ||
				this._editor.getOption(
					93 // renameOnType
				)) &&
			this._providers.has(model);
		if (isEnabled === this._enabled && !forceRefresh) {
			return;
		}
		this._enabled = isEnabled;
		this.clearRanges();
		this._localToDispose.clear();
		if (!isEnabled || model === null) {
			return;
		}
		this._localToDispose.add(
			editorEventRunAndSubscribe(model.onDidChangeLanguageConfiguration, () => {
				this._languageWordPattern = this.languageConfigurationService
					.getLanguageConfiguration(model.getLanguageId())
					.getWordDefinition();
			})
		);
		const rangeUpdateScheduler = new Delayer(this._debounceInformation.get(model));
		const triggerRangeUpdate = () => {
			this._rangeUpdateTriggerPromise = rangeUpdateScheduler.trigger(
				() => this.updateRanges(),
				this._debounceDuration ?? this._debounceInformation.get(model)
			);
		};
		const rangeSyncScheduler = new Delayer(0);
		const triggerRangeSync = token => {
			this._rangeSyncTriggerPromise = rangeSyncScheduler.trigger(() => this._syncRanges(token));
		};
		this._localToDispose.add(
			this._editor.onDidChangeCursorPosition(() => {
				triggerRangeUpdate();
			})
		);
		this._localToDispose.add(
			this._editor.onDidChangeModelContent(e => {
				if (!this._ignoreChangeEvent) {
					if (this._currentDecorations.length > 0) {
						const referenceRange = this._currentDecorations.getRange(0);
						if (referenceRange && e.changes.every(c => referenceRange.intersectRanges(c.range))) {
							triggerRangeSync(this._syncRangesToken);
							return;
						}
					}
				}
				triggerRangeUpdate();
			})
		);
		this._localToDispose.add({
			dispose: () => {
				rangeUpdateScheduler.dispose();
				rangeSyncScheduler.dispose();
			}
		});
		this.updateRanges();
	}
	_syncRanges(token) {
		if (!this._editor.hasModel() || token !== this._syncRangesToken || this._currentDecorations.length === 0) {
			return;
		}
		const model = this._editor.getModel();
		const referenceRange = this._currentDecorations.getRange(0);
		if (!referenceRange || referenceRange.startLineNumber !== referenceRange.endLineNumber) {
			return this.clearRanges();
		}
		const referenceValue = model.getValueInRange(referenceRange);
		if (this._currentWordPattern) {
			const match2 = referenceValue.match(this._currentWordPattern);
			const matchLength = match2 ? match2[0].length : 0;
			if (matchLength !== referenceValue.length) {
				return this.clearRanges();
			}
		}
		const edits = [];
		for (let i = 1, len = this._currentDecorations.length; i < len; i++) {
			const mirrorRange = this._currentDecorations.getRange(i);
			if (!mirrorRange) {
				continue;
			}
			if (mirrorRange.startLineNumber !== mirrorRange.endLineNumber) {
				edits.push({
					range: mirrorRange,
					text: referenceValue
				});
			} else {
				let oldValue = model.getValueInRange(mirrorRange);
				let newValue = referenceValue;
				let rangeStartColumn = mirrorRange.startColumn;
				let rangeEndColumn = mirrorRange.endColumn;
				const commonPrefixLength2 = commonPrefixLength(oldValue, newValue);
				rangeStartColumn += commonPrefixLength2;
				oldValue = oldValue.substr(commonPrefixLength2);
				newValue = newValue.substr(commonPrefixLength2);
				const commonSuffixLength2 = commonSuffixLength(oldValue, newValue);
				rangeEndColumn -= commonSuffixLength2;
				oldValue = oldValue.substr(0, oldValue.length - commonSuffixLength2);
				newValue = newValue.substr(0, newValue.length - commonSuffixLength2);
				if (rangeStartColumn !== rangeEndColumn || newValue.length !== 0) {
					edits.push({
						range: new Range(mirrorRange.startLineNumber, rangeStartColumn, mirrorRange.endLineNumber, rangeEndColumn),
						text: newValue
					});
				}
			}
		}
		if (edits.length === 0) {
			return;
		}
		try {
			this._editor.popUndoStop();
			this._ignoreChangeEvent = true;
			const prevEditOperationType = this._editor._getViewModel().getPrevEditOperationType();
			this._editor.executeEdits('linkedEditing', edits);
			this._editor._getViewModel().setPrevEditOperationType(prevEditOperationType);
		} finally {
			this._ignoreChangeEvent = false;
		}
	}
	dispose() {
		this.clearRanges();
		super.dispose();
	}
	clearRanges() {
		this._visibleContextKey.set(false);
		this._currentDecorations.clear();
		if (this._currentRequestCts) {
			this._currentRequestCts.cancel();
			this._currentRequestCts = null;
			this._currentRequestPosition = null;
		}
	}
	async updateRanges(force = false) {
		if (!this._editor.hasModel()) {
			this.clearRanges();
			return;
		}
		const position = this._editor.getPosition();
		if ((!this._enabled && !force) || this._editor.getSelections().length > 1) {
			this.clearRanges();
			return;
		}
		const model = this._editor.getModel();
		const modelVersionId = model.getVersionId();
		if (this._currentRequestPosition && this._currentRequestModelVersion === modelVersionId) {
			if (position.equals(this._currentRequestPosition)) {
				return;
			}
			if (this._currentDecorations.length > 0) {
				const range2 = this._currentDecorations.getRange(0);
				if (range2 && range2.containsPosition(position)) {
					return;
				}
			}
		}
		this.clearRanges();
		this._currentRequestPosition = position;
		this._currentRequestModelVersion = modelVersionId;
		const currentRequestCts = (this._currentRequestCts = new CancellationTokenSource());
		try {
			const sw = new StopWatch(false);
			const response = await getLinkedEditingRanges(this._providers, model, position, currentRequestCts.token);
			this._debounceInformation.update(model, sw.elapsed());
			if (currentRequestCts !== this._currentRequestCts) {
				return;
			}
			this._currentRequestCts = null;
			if (modelVersionId !== model.getVersionId()) {
				return;
			}
			let ranges = [];
			if (response?.ranges) {
				ranges = response.ranges;
			}
			this._currentWordPattern = response?.wordPattern || this._languageWordPattern;
			let foundReferenceRange = false;
			for (let i = 0, len = ranges.length; i < len; i++) {
				if (Range.containsPosition(ranges[i], position)) {
					foundReferenceRange = true;
					if (i !== 0) {
						const referenceRange = ranges[i];
						ranges.splice(i, 1);
						ranges.unshift(referenceRange);
					}
					break;
				}
			}
			if (!foundReferenceRange) {
				this.clearRanges();
				return;
			}
			const decorations = ranges.map(range2 => ({
				range: range2,
				options: opts_linkedEditing
			}));
			this._visibleContextKey.set(true);
			this._currentDecorations.set(decorations);
			this._syncRangesToken++;
		} catch (err) {
			if (!isCancellationError(err)) {
				onUnexpectedError(err);
			}
			if (this._currentRequestCts === currentRequestCts || !this._currentRequestCts) {
				this.clearRanges();
			}
		}
	}
}
registerEditorContribution(
	linkedEditingContribution_id,
	LinkedEditingContribution,
	1 // AfterFirstRender
);
__decorate(
	[
		__param(1, IContextKeyService),
		__param(2, ILanguageFeaturesService),
		__param(3, ILanguageConfigurationService),
		__param(4, ILanguageFeatureDebounceService)
		//...
	],
	LinkedEditingContribution
);

const LinkedEditingCommand = EditorCommand.bindToContribution(LinkedEditingContribution.get);
registerEditorCommand(
	new LinkedEditingCommand({
		id: 'cancelLinkedEditingInput',
		precondition: ck_linkedEditingInputVisible,
		handler: x => x.clearRanges(),
		kbOpts: {
			kbExpr: ck_editorFocus_text,
			weight: 100 + 99,
			primary: 9,
			secondary: [
				1024 | 9 // Escape
			]
		}
	})
);

registerModelAndPositionCommand('_executeLinkedEditingProvider', (_accessor, model, position) => {
	const { linkedEditingRangeProvider } = _accessor.get(ILanguageFeaturesService);
	return getLinkedEditingRanges(linkedEditingRangeProvider, model, position, cancellationToken_none);
});

class LinkedEditingAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.linkedEditing',
			label: localize('Start Linked Editing'),
			alias: 'Start Linked Editing',
			precondition: ContextKeyExpr.and(ck_writable, ck_editorHasProvider_rename),
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 1024 | 60,
				weight: 100 //editorContrib
			}
		});
	}
	runCommand(accessor, args) {
		const editorService = accessor.get(ICodeEditorService);
		const [uri, pos] = (isArray(args) && args) || [undefined, undefined];
		if (URI.isUri(uri) && Position.isIPosition(pos)) {
			return editorService.openCodeEditor({ resource: uri }, editorService.getActiveCodeEditor()).then(editor2 => {
				if (!editor2) {
					return;
				}
				editor2.setPosition(pos);
				editor2.invokeWithinContext(accessor2 => {
					return this.run(accessor2, editor2);
				});
			}, onUnexpectedError);
		}
		return super.runCommand(accessor, args);
	}
	run(_accessor, editor2) {
		const controller = LinkedEditingContribution.get(editor2);
		if (controller) {
			return Promise.resolve(controller.updateRanges(true));
		}
		return Promise.resolve();
	}
}
registerEditorAction(LinkedEditingAction);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

function _getLinks(providers, model, token) {
	const lists = [];
	const promises = providers
		.ordered(model)
		.reverse()
		.map((provider, i) => {
			return Promise.resolve(provider.provideLinks(model, token)).then(result => {
				if (result) {
					lists[i] = [result, provider];
				}
			}, onUnexpectedExternalError);
		});
	return Promise.all(promises).then(() => {
		const result = new LinksList(lists.filter(e => !!e));
		if (!token.isCancellationRequested) {
			return result;
		}
		result.dispose();
		return new LinksList([]);
	});
}

class Link {
	constructor(link, provider) {
		this._link = link;
		this._provider = provider;
	}
	toJSON() {
		return { range: this.range, url: this.url, tooltip: this.tooltip };
	}
	get range() {
		return this._link.range;
	}
	get url() {
		return this._link.url;
	}
	get tooltip() {
		return this._link.tooltip;
	}
	async resolve(token) {
		if (this._link.url) {
			return this._link.url;
		}
		if (typeof this._provider.resolveLink === 'function') {
			return Promise.resolve(this._provider.resolveLink(this._link, token)).then(value => {
				this._link = value || this._link;
				if (this._link.url) {
					return this.resolve(token);
				}
				return Promise.reject(new Error('missing'));
			});
		}
		return Promise.reject(new Error('missing'));
	}
}

class LinksList {
	constructor(tuples) {
		this._disposables = new DisposableStore();
		let links = [];
		for (const [list, provider] of tuples) {
			const newLinks = list.links.map(link => new Link(link, provider));
			links = LinksList._union(links, newLinks);
			if (isDisposable(list)) {
				this._disposables.add(list);
			}
		}
		this.links = links;
	}
	dispose() {
		this._disposables.dispose();
		this.links.length = 0;
	}
	static _union(oldLinks, newLinks) {
		const result = [];
		let oldIndex;
		let oldLen;
		let newIndex;
		let newLen;
		for (oldIndex = 0, newIndex = 0, oldLen = oldLinks.length, newLen = newLinks.length; oldIndex < oldLen && newIndex < newLen; ) {
			const oldLink = oldLinks[oldIndex];
			const newLink = newLinks[newIndex];
			if (Range.areIntersectingOrTouching(oldLink.range, newLink.range)) {
				oldIndex++;
				continue;
			}
			const comparisonResult = Range.compareRangesUsingStarts(oldLink.range, newLink.range);
			if (comparisonResult < 0) {
				result.push(oldLink);
				oldIndex++;
			} else {
				result.push(newLink);
				newIndex++;
			}
		}
		for (; oldIndex < oldLen; oldIndex++) {
			result.push(oldLinks[oldIndex]);
		}
		for (; newIndex < newLen; newIndex++) {
			result.push(newLinks[newIndex]);
		}
		return result;
	}
}

commandsRegistry.registerCommand('_executeLinkProvider', async (accessor, uri, resolveCount) => {
	if (uri instanceof URI) {
		if (typeof resolveCount !== 'number') {
			resolveCount = 0;
		}
		const { linkProvider } = accessor.get(ILanguageFeaturesService);
		const model = accessor.get(IModelService).getModel(uri);
		if (!model) {
			return [];
		}
		const list = await _getLinks(linkProvider, model, cancellationToken_none);
		if (!list) {
			return [];
		}
		for (let i = 0; i < Math.min(resolveCount, list.links.length); i++) {
			await list.links[i].resolve(cancellationToken_none);
		}
		const result = list.links.slice(0);
		list.dispose();
		return result;
	}
});

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const optDetectedLink = ModelDecorationOptions.register({
	description: 'detected-link',
	stickiness: 1,
	collapseOnReplaceEdit: true,
	inlineClassName: 'detected-link'
});

const optDetectedActiveLink = ModelDecorationOptions.register({
	description: 'detected-link-active',
	stickiness: 1,
	collapseOnReplaceEdit: true,
	inlineClassName: 'detected-link-active'
});

class LinkOccurrence {
	static decoration(link, useMetaKey) {
		return {
			range: link.range,
			options: LinkOccurrence._getOptions(link, useMetaKey, false)
		};
	}
	static _getOptions(link, useMetaKey, isActive) {
		const options2 = {
			...(isActive ? optDetectedActiveLink : optDetectedLink)
		};
		const executeCmd = link.url && /^command:/i.test(link.url.toString());
		const label = link.tooltip ? link.tooltip : executeCmd ? localize('Execute command') : localize('Follow link');
		const kb = useMetaKey
			? isMacintosh
				? localize('cmd + click')
				: localize('ctrl + click')
			: isMacintosh
				? localize('option + click')
				: localize('alt + click');
		let msg;
		if (link.url) {
			let nativeLabel = '';
			if (/^command:/i.test(link.url.toString())) {
				const match2 = link.url.toString().match(/^command:([^?#]+)/);
				if (match2) {
					const commandId = match2[1];
					nativeLabel = localize(commandId);
				}
			}
			msg = new MarkdownString('', true)
				.appendLink(link.url.toString(true).replace(/ /g, '%20'), label, nativeLabel)
				.appendMarkdown(` (${kb})`);
		} else {
			msg = new MarkdownString().appendText(`${label} (${kb})`);
		}
		options2.hoverMessage = msg;
		return options2;
	}
	constructor(link, decorationId) {
		this.link = link;
		this.decorationId = decorationId;
	}
	activate(changeAccessor, useMetaKey) {
		changeAccessor.changeDecorationOptions(this.decorationId, LinkOccurrence._getOptions(this.link, useMetaKey, true));
	}
	deactivate(changeAccessor, useMetaKey) {
		changeAccessor.changeDecorationOptions(this.decorationId, LinkOccurrence._getOptions(this.link, useMetaKey, false));
	}
}

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
const linkDetector_id = 'editor.linkDetector';
class LinkDetector extends Disposable {
	static get(editor) {
		return editor.getContribution(linkDetector_id);
	}
	constructor(editor2, openerService, notificationService, languageFeaturesService, languageFeatureDebounceService) {
		super();
		this.editor = editor2;
		this.openerService = openerService;
		this.notificationService = notificationService;
		this.languageFeaturesService = languageFeaturesService;
		this.providers = this.languageFeaturesService.linkProvider;
		this.debounceInformation = languageFeatureDebounceService.for(this.providers, 'Links', { min: 1e3, max: 4e3 });
		this.computeLinks = this._register(new RunOnceScheduler(() => this.computeLinksNow(), 1e3));
		this.computePromise = null;
		this.activeLinksList = null;
		this.currentOccurrences = {};
		this.activeLinkDecorationId = null;
		const clickLinkGesture = this._register(new ClickLinkGesture(editor2));
		this._register(
			clickLinkGesture.onMouseMoveOrRelevantKeyDown(([mouseEvent, keyboardEvent]) => {
				this._onEditorMouseMove(mouseEvent, keyboardEvent);
			})
		);
		this._register(
			clickLinkGesture.onExecute(e => {
				this.onEditorMouseUp(e);
			})
		);
		this._register(
			clickLinkGesture.onCancel(e => {
				this.cleanUpActiveLinkDecoration();
			})
		);
		this._register(
			editor2.onDidChangeConfiguration(e => {
				if (
					!e.hasChanged(
						71 // links
					)
				) {
					return;
				}
				this.updateDecorations([]);
				this.stop();
				this.computeLinks.schedule(0);
			})
		);
		this._register(
			editor2.onDidChangeModelContent(e => {
				if (!this.editor.hasModel()) {
					return;
				}
				this.computeLinks.schedule(this.debounceInformation.get(this.editor.getModel()));
			})
		);
		this._register(
			editor2.onDidChangeModel(e => {
				this.currentOccurrences = {};
				this.activeLinkDecorationId = null;
				this.stop();
				this.computeLinks.schedule(0);
			})
		);
		this._register(
			editor2.onDidChangeModelLanguage(e => {
				this.stop();
				this.computeLinks.schedule(0);
			})
		);
		this._register(
			this.providers.onDidChange(e => {
				this.stop();
				this.computeLinks.schedule(0);
			})
		);
		this.computeLinks.schedule(0);
	}
	async computeLinksNow() {
		if (
			!this.editor.hasModel() ||
			!this.editor.getOption(
				71 // links
			)
		) {
			return;
		}
		const model = this.editor.getModel();
		if (model.isTooLargeForSyncing()) {
			return;
		}
		if (!this.providers.has(model)) {
			return;
		}
		if (this.activeLinksList) {
			this.activeLinksList.dispose();
			this.activeLinksList = null;
		}
		this.computePromise = createCancelablePromise(token => _getLinks(this.providers, model, token));
		try {
			const sw = new StopWatch(false);
			this.activeLinksList = await this.computePromise;
			this.debounceInformation.update(model, sw.elapsed());
			if (model.isDisposed()) {
				return;
			}
			this.updateDecorations(this.activeLinksList.links);
		} catch (err) {
			onUnexpectedError(err);
		} finally {
			this.computePromise = null;
		}
	}
	updateDecorations(links) {
		const useMetaKey =
			this.editor.getOption(
				78 // multiCursorModifier
			) === 'altKey';
		const oldDecorations = [];
		const keys = Object.keys(this.currentOccurrences);
		for (const decorationId of keys) {
			const occurence = this.currentOccurrences[decorationId];
			oldDecorations.push(occurence.decorationId);
		}
		const newDecorations = [];
		if (links) {
			for (const link of links) {
				newDecorations.push(LinkOccurrence.decoration(link, useMetaKey));
			}
		}
		this.editor.changeDecorations(changeAccessor => {
			const decorations = changeAccessor.deltaDecorations(oldDecorations, newDecorations);
			this.currentOccurrences = {};
			this.activeLinkDecorationId = null;
			for (let i = 0, len = decorations.length; i < len; i++) {
				const occurence = new LinkOccurrence(links[i], decorations[i]);
				this.currentOccurrences[occurence.decorationId] = occurence;
			}
		});
	}
	_onEditorMouseMove(mouseEvent, withKey) {
		const useMetaKey =
			this.editor.getOption(
				78 // multiCursorModifier
			) === 'altKey';
		if (this.isEnabled(mouseEvent, withKey)) {
			this.cleanUpActiveLinkDecoration();
			const occurrence = this.getLinkOccurrence(mouseEvent.target.position);
			if (occurrence) {
				this.editor.changeDecorations(changeAccessor => {
					occurrence.activate(changeAccessor, useMetaKey);
					this.activeLinkDecorationId = occurrence.decorationId;
				});
			}
		} else {
			this.cleanUpActiveLinkDecoration();
		}
	}
	cleanUpActiveLinkDecoration() {
		const useMetaKey =
			this.editor.getOption(
				78 // multiCursorModifier
			) === 'altKey';
		if (this.activeLinkDecorationId) {
			const occurrence = this.currentOccurrences[this.activeLinkDecorationId];
			if (occurrence) {
				this.editor.changeDecorations(changeAccessor => {
					occurrence.deactivate(changeAccessor, useMetaKey);
				});
			}
			this.activeLinkDecorationId = null;
		}
	}
	onEditorMouseUp(mouseEvent) {
		if (!this.isEnabled(mouseEvent)) {
			return;
		}
		const occurrence = this.getLinkOccurrence(mouseEvent.target.position);
		if (!occurrence) {
			return;
		}
		this.openLinkOccurrence(occurrence, mouseEvent.hasSideBySideModifier, true /* from user gesture */);
	}
	openLinkOccurrence(occurrence, openToSide, fromUserGesture = false) {
		if (!this.openerService) {
			return;
		}
		const { link } = occurrence;
		link.resolve(cancellationToken_none).then(
			uri => {
				if (typeof uri === 'string' && this.editor.hasModel()) {
					const modelUri = this.editor.getModel().uri;
					if (modelUri.scheme === Schemas.file && uri.startsWith(`${Schemas.file}:`)) {
						const parsedUri = URI.parse(uri);
						if (parsedUri.scheme === Schemas.file) {
							const fsPath = originalFSPath(parsedUri);
							let relativePath2 = null;
							if (fsPath.startsWith('/./') || fsPath.startsWith('\\.\\')) {
								relativePath2 = `.${fsPath.substr(1)}`;
							} else if (fsPath.startsWith('//./') || fsPath.startsWith('\\\\.\\')) {
								relativePath2 = `.${fsPath.substr(2)}`;
							}
							if (relativePath2) {
								uri = joinPath(modelUri, relativePath2);
							}
						}
					}
				}
				return this.openerService.open(uri, {
					openToSide,
					fromUserGesture,
					allowContributedOpeners: true,
					allowCommands: true,
					fromWorkspace: true
				});
			},
			err => {
				const messageOrError = err instanceof Error ? err.message : err;
				if (messageOrError === 'invalid') {
					this.notificationService.warn(localize(link.url.toString()));
				} else if (messageOrError === 'missing') {
					this.notificationService.warn(localize('Failed to open this link because its target is missing.'));
				} else {
					onUnexpectedError(err);
				}
			}
		);
	}
	getLinkOccurrence(position) {
		if (!this.editor.hasModel() || !position) {
			return null;
		}
		const decorations = this.editor.getModel().getDecorationsInRange(
			{
				startLineNumber: position.lineNumber,
				startColumn: position.column,
				endLineNumber: position.lineNumber,
				endColumn: position.column
			},
			0,
			true
		);
		for (const decoration3 of decorations) {
			const currentOccurrence = this.currentOccurrences[decoration3.id];
			if (currentOccurrence) {
				return currentOccurrence;
			}
		}
		return null;
	}
	isEnabled(mouseEvent, withKey) {
		return Boolean(mouseEvent.target.type === 6 && (mouseEvent.hasTriggerModifier || (withKey && withKey.keyCodeIsTriggerKey)));
	}
	stop() {
		this.computeLinks.cancel();
		if (this.activeLinksList) {
			this.activeLinksList?.dispose();
			this.activeLinksList = null;
		}
		if (this.computePromise) {
			this.computePromise.cancel();
			this.computePromise = null;
		}
	}
	dispose() {
		super.dispose();
		this.stop();
	}
}
__decorate(
	[
		__param(1, IOpenerService),
		__param(2, INotificationService),
		__param(3, ILanguageFeaturesService),
		__param(4, ILanguageFeatureDebounceService)
		//...
	],
	LinkDetector
);
registerEditorContribution(
	linkDetector_id,
	LinkDetector,
	1 //AfterFirstRender
);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class OpenLinkAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.openLink',
			label: localize('Open Link'),
			alias: 'Open Link'
		});
	}
	run(accessor, editor2) {
		const linkDetector = LinkDetector.get(editor2);
		if (!linkDetector) {
			return;
		}
		if (!editor2.hasModel()) {
			return;
		}
		const selections = editor2.getSelections();
		for (const sel of selections) {
			const link = linkDetector.getLinkOccurrence(sel.getEndPosition());
			if (link) {
				linkDetector.openLinkOccurrence(link, false);
			}
		}
	}
}
registerEditorAction(OpenLinkAction);