class LongLinesHelper extends Disposable {
	constructor(_editor) {
		super();
		this._editor = _editor;
		this._register(
			this._editor.onMouseDown(e => {
				const stopRenderingLineAfter = this._editor.getOption(117);
				if (stopRenderingLineAfter >= 0 && e.target.type === 6 && e.target.position.column >= stopRenderingLineAfter) {
					this._editor.updateOptions({
						stopRenderingLineAfter: -1
					});
				}
			})
		);
	}
}
registerEditorContribution(
	'editor.contrib.longLinesHelper',
	LongLinesHelper,
	2 // BeforeFirstInteraction
);