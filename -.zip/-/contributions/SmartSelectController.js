class SelectionRanges {
	constructor(index, ranges) {
		this.index = index;
		this.ranges = ranges;
	}
	mov(fwd) {
		const index = this.index + (fwd ? 1 : -1);
		if (index < 0 || index >= this.ranges.length) {
			return this;
		}
		const res = new SelectionRanges(index, this.ranges);
		if (res.ranges[index].equalsRange(this.ranges[this.index])) {
			return res.mov(fwd);
		}
		return res;
	}
}

class SmartSelectController {
	static get(editor2) {
		return editor2.getContribution(SmartSelectController.ID);
	}
	constructor(_editor, _languageFeaturesService) {
		this._editor = _editor;
		this._languageFeaturesService = _languageFeaturesService;
		this._ignoreSelection = false;
	}
	dispose() {
		this._selectionListener?.dispose();
	}
	async run(forward) {
		if (!this._editor.hasModel()) {
			return;
		}
		const selections = this._editor.getSelections();
		const model = this._editor.getModel();
		if (!this._state) {
			await provideSelectionRanges(
				this._languageFeaturesService.selectionRangeProvider,
				model,
				selections.map(s => s.getPosition()),
				this._editor.getOption(
					113 // smartSelect
				),
				cancellationToken_none
			).then(ranges => {
				if (!isArrayAndHasLength(ranges) || ranges.length !== selections.length) {
					return;
				}
				if (!this._editor.hasModel() || !equals(this._editor.getSelections(), selections, (a, b) => a.equalsSelection(b))) {
					return;
				}
				for (let i = 0; i < ranges.length; i++) {
					ranges[i] = ranges[i].filter(range2 => {
						return (
							range2.containsPosition(selections[i].getStartPosition()) &&
							range2.containsPosition(selections[i].getEndPosition())
						);
					});
					ranges[i].unshift(selections[i]);
				}
				this._state = ranges.map(ranges2 => new SelectionRanges(0, ranges2));
				this._selectionListener?.dispose();
				this._selectionListener = this._editor.onDidChangeCursorPosition(() => {
					if (!this._ignoreSelection) {
						this._selectionListener?.dispose();
						this._state = undefined;
					}
				});
			});
		}
		if (!this._state) {
			return;
		}
		this._state = this._state.map(state => state.mov(forward));
		const newSelections = this._state.map(state =>
			EditorSelection.fromPositions(state.ranges[state.index].getStartPosition(), state.ranges[state.index].getEndPosition())
		);
		this._ignoreSelection = true;
		try {
			this._editor.setSelections(newSelections);
		} finally {
			this._ignoreSelection = false;
		}
	}
}
SmartSelectController.ID = 'editor.contrib.smartSelectController';
__decorate([__param(1, ILanguageFeaturesService)], SmartSelectController);
registerEditorContribution(
	SmartSelectController.ID,
	SmartSelectController,
	4 // Lazy
);