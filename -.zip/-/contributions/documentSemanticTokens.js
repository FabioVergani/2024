

const reverseEndianness = arr => {
	for (let i = 0, len = arr.length; i < len; i += 4) {
		const b0 = arr[i + 0];
		const b1 = arr[i + 1];
		const b2 = arr[i + 2];
		arr[i] = arr[i + 3];
		arr[i + 1] = b2;
		arr[i + 2] = b1;
		arr[i + 3] = b0;
	}
};

const toLittleEndianBuffer = arr => {
	const uint8Arr = new Uint8Array(arr.buffer, arr.byteOffset, arr.length * 4);
	if (!isLittleEndian()) {
		reverseEndianness(uint8Arr);
	}
	return VSBuffer.wrap(uint8Arr);
};




const encodeSemanticTokensDto = semanticTokens => {
	const dest = new Uint32Array(encodeSemanticTokensDtoSize(semanticTokens));
	let offset = 0;
	dest[offset++] = semanticTokens.id;
	if (semanticTokens.type === 'full') {
		dest[offset++] = 1;
		dest[offset++] = semanticTokens.data.length;
		dest.set(semanticTokens.data, offset);
		offset += semanticTokens.data.length;
	} else {
		dest[offset++] = 2;
		dest[offset++] = semanticTokens.deltas.length;
		for (const delta of semanticTokens.deltas) {
			dest[offset++] = delta.start;
			dest[offset++] = delta.deleteCount;
			if (delta.data) {
				dest[offset++] = delta.data.length;
				dest.set(delta.data, offset);
				offset += delta.data.length;
			} else {
				dest[offset++] = 0;
			}
		}
	}
	return toLittleEndianBuffer(dest);
};

const encodeSemanticTokensDtoSize = semanticTokens => {
	let result = 0;
	result += 1 + 1;
	if (semanticTokens.type === 'full') {
		result += 1 + semanticTokens.data.length;
	} else {
		result += 1;
		result += (1 + 1 + 1) * semanticTokens.deltas.length;
		for (const delta of semanticTokens.deltas) {
			if (delta.data) {
				result += delta.data.length;
			}
		}
	}
	return result;
};

const isSemanticTokens = v => {
	return v && !!v.data;
};

const isSemanticTokensEdits = v => {
	return v && isArray(v.edits);
};

async function getDocumentSemanticTokens(registry, model, lastProvider, lastResultId, token) {
	const groups = registry.orderedGroups(model);

	const providers = groups.length > 0 ? groups[0] : [];
	const results = await Promise.all(
		providers.map(async provider => {
			let result;
			let error = null;
			try {
				result = await provider.provideDocumentSemanticTokens(model, provider === lastProvider ? lastResultId : null, token);
			} catch (err) {
				error = err;
				result = null;
			}
			if (!result || (!isSemanticTokens(result) && !isSemanticTokensEdits(result))) {
				result = null;
			}
			return {
				provider: provider,
				tokens: result,
				error: error
			};
		})
	);
	for (const result of results) {
		if (result.error) {
			throw result.error;
		}
		if (result.tokens) {
			return result;
		}
	}
	if (results.length > 0) {
		return results[0];
	}
	return null;
}

const _getDocumentSemanticTokensProviderHighestGroup = (registry, model) => {
	const result = registry.orderedGroups(model);
	return result.length > 0 ? result[0] : null;
};

class DocumentRangeSemanticTokensResult {
	constructor(provider, tokens) {
		this.provider = provider;
		this.tokens = tokens;
	}
}

const hasDocumentRangeSemanticTokensProvider = (providers, model) => {
	return providers.has(model);
};

const getDocumentRangeSemanticTokensProviders = (providers, model) => {
	const groups = providers.orderedGroups(model);
	return groups.length > 0 ? groups[0] : [];
};

async function getDocumentRangeSemanticTokens(registry, model, range2, token) {
	const providers = getDocumentRangeSemanticTokensProviders(registry, model);
	const results = await Promise.all(
		providers.map(async provider => {
			let result;
			try {
				result = await provider.provideDocumentRangeSemanticTokens(model, range2, token);
			} catch (err) {
				onUnexpectedExternalError(err);
				result = null;
			}
			if (!result || !isSemanticTokens(result)) {
				result = null;
			}
			return new DocumentRangeSemanticTokensResult(provider, result);
		})
	);
	for (const result of results) {
		if (result.tokens) {
			return result;
		}
	}
	if (results.length > 0) {
		return results[0];
	}
	return null;
}

commandsRegistry.registerCommand('_provideDocumentSemanticTokensLegend', async (accessor, uri) => {
	if (uri instanceof URI) {
		const model = accessor.get(IModelService).getModel(uri);
		if (model) {
			const { documentSemanticTokensProvider } = accessor.get(ILanguageFeaturesService);
			const providers = _getDocumentSemanticTokensProviderHighestGroup(documentSemanticTokensProvider, model);
			if (!providers) {
				return accessor.get(ICommandService).executeCommand('_provideDocumentRangeSemanticTokensLegend', uri);
			}
			return providers[0].getLegend();
		}
	}
});

commandsRegistry.registerCommand('_provideDocumentSemanticTokens', async (accessor, uri) => {
	if (uri instanceof URI) {
		const model = accessor.get(IModelService).getModel(uri);
		if (model) {
			const { documentSemanticTokensProvider } = accessor.get(ILanguageFeaturesService);
			if (!documentSemanticTokensProvider.has(model)) {
				return accessor.get(ICommandService).executeCommand('_provideDocumentRangeSemanticTokens', uri, model.getFullModelRange());
			}
			const r = await getDocumentSemanticTokens(documentSemanticTokensProvider, model, null, null, cancellationToken_none);
			if (!r) {
				return;
			}
			const { provider, tokens } = r;
			if (!tokens || !isSemanticTokens(tokens)) {
				return;
			}
			const buff = encodeSemanticTokensDto({
				id: 0,
				type: 'full',
				data: tokens.data
			});
			if (tokens.resultId) {
				provider.releaseDocumentSemanticTokens(tokens.resultId);
			}
			return buff;
		}
	}
});

commandsRegistry.registerCommand('_provideDocumentRangeSemanticTokensLegend', async (accessor, uri, range2) => {
	if (uri instanceof URI) {
	}
	const model = accessor.get(IModelService).getModel(uri);
	if (model) {
		const { documentRangeSemanticTokensProvider } = accessor.get(ILanguageFeaturesService);
		const providers = getDocumentRangeSemanticTokensProviders(documentRangeSemanticTokensProvider, model);
		if (providers.length === 0) {
			return;
		}
		if (providers.length === 1) {
			return providers[0].getLegend();
		}
		if (!range2 || !Range.isIRange(range2)) {
			console.warn(
				`provideDocumentRangeSemanticTokensLegend might be out-of-sync with provideDocumentRangeSemanticTokens unless a range argument is passed in`
			);
			return providers[0].getLegend();
		}
		const result = await getDocumentRangeSemanticTokens(
			documentRangeSemanticTokensProvider,
			model,
			Range.lift(range2),
			cancellationToken_none
		);
		if (!result) {
			return;
		}
		return result.provider.getLegend();
	}
});

commandsRegistry.registerCommand('_provideDocumentRangeSemanticTokens', async (accessor, uri, range2) => {
	if (uri instanceof URI && Range.isIRange(range2)) {
		const model = accessor.get(IModelService).getModel(uri);
		if (model) {
			const { documentRangeSemanticTokensProvider } = accessor.get(ILanguageFeaturesService);
			const result = await getDocumentRangeSemanticTokens(
				documentRangeSemanticTokensProvider,
				model,
				Range.lift(range2),
				cancellationToken_none
			);
			if (!result || !result.tokens) {
				return;
			}
			return encodeSemanticTokensDto({
				id: 0,
				type: 'full',
				data: result.tokens.data
			});
		}
	}
});

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const SEMANTIC_HIGHLIGHTING_SETTING_ID = 'editor.semanticHighlighting';

const isSemanticColoringEnabled = (model, themeService, configurationService) => {
	const setting = configurationService.getValue(SEMANTIC_HIGHLIGHTING_SETTING_ID, {
		overrideIdentifier: model.getLanguageId(),
		resource: model.uri
	})?.enabled;
	if (typeof setting === 'boolean') {
		return setting;
	}
	return themeService.getColorTheme().semanticHighlighting;
};


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



class DocumentSemanticTokensFeature extends Disposable {
	constructor(
		semanticTokensStylingService,
		modelService,
		themeService,
		configurationService,
		languageFeatureDebounceService,
		languageFeaturesService
	) {
		super();
		this._watchers = Object.create(null);
		const register4 = model => {
			this._watchers[model.uri.toString()] = new ModelSemanticColoring(
				model,
				semanticTokensStylingService,
				themeService,
				languageFeatureDebounceService,
				languageFeaturesService
			);
		};
		const deregister = (model, modelSemanticColoring) => {
			modelSemanticColoring.dispose();
			delete this._watchers[model.uri.toString()];
		};
		const handleSettingOrThemeChange = () => {
			for (const model of modelService.getModels()) {
				const curr = this._watchers[model.uri.toString()];
				if (isSemanticColoringEnabled(model, themeService, configurationService)) {
					if (!curr) {
						register4(model);
					}
				} else {
					if (curr) {
						deregister(model, curr);
					}
				}
			}
		};
		modelService.getModels().forEach(model => {
			if (isSemanticColoringEnabled(model, themeService, configurationService)) {
				register4(model);
			}
		});
		this._register(
			modelService.onModelAdded(model => {
				if (isSemanticColoringEnabled(model, themeService, configurationService)) {
					register4(model);
				}
			})
		);
		this._register(
			modelService.onModelRemoved(model => {
				const curr = this._watchers[model.uri.toString()];
				if (curr) {
					deregister(model, curr);
				}
			})
		);
		this._register(
			configurationService.onDidChangeConfiguration(e => {
				if (e.affectsConfiguration(SEMANTIC_HIGHLIGHTING_SETTING_ID)) {
					handleSettingOrThemeChange();
				}
			})
		);
		this._register(themeService.onDidColorThemeChange(handleSettingOrThemeChange));
	}
	dispose() {
		for (const watcher of Object.values(this._watchers)) {
			watcher.dispose();
		}
		super.dispose();
	}
}
__decorate(
	[
		__param(0, ISemanticTokensStylingService),
		__param(1, IModelService),
		__param(2, IThemeService),
		__param(3, IConfigurationService),
		__param(4, ILanguageFeatureDebounceService),
		__param(5, ILanguageFeaturesService)
	],
	DocumentSemanticTokensFeature
);
registerEditorFeature(DocumentSemanticTokensFeature);


class SemanticTokensResponse {
	constructor(provider, resultId, data) {
		this.provider = provider;
		this.resultId = resultId;
		this.data = data;
	}
	dispose() {
		this.provider.releaseDocumentSemanticTokens(this.resultId);
	}
}

class ModelSemanticColoring extends Disposable {
	constructor(model, _semanticTokensStylingService, themeService, languageFeatureDebounceService, languageFeaturesService) {
		super();
		this._semanticTokensStylingService = _semanticTokensStylingService;
		this._isDisposed = false;
		this._model = model;
		this._provider = languageFeaturesService.documentSemanticTokensProvider;
		this._debounceInformation = languageFeatureDebounceService.for(this._provider, 'DocumentSemanticTokens', {
			min: ModelSemanticColoring.REQUEST_MIN_DELAY,
			max: ModelSemanticColoring.REQUEST_MAX_DELAY
		});
		this._fetchDocumentSemanticTokens = this._register(
			new RunOnceScheduler(() => this._fetchDocumentSemanticTokensNow(), ModelSemanticColoring.REQUEST_MIN_DELAY)
		);
		this._currentDocumentResponse = null;
		this._currentDocumentRequestCancellationTokenSource = null;
		this._documentProvidersChangeListeners = [];
		this._providersChangedDuringRequest = false;
		this._register(
			this._model.onDidChangeContent(() => {
				if (!this._fetchDocumentSemanticTokens.isScheduled()) {
					this._fetchDocumentSemanticTokens.schedule(this._debounceInformation.get(this._model));
				}
			})
		);
		this._register(
			this._model.onDidChangeAttached(() => {
				if (!this._fetchDocumentSemanticTokens.isScheduled()) {
					this._fetchDocumentSemanticTokens.schedule(this._debounceInformation.get(this._model));
				}
			})
		);
		this._register(
			this._model.onDidChangeLanguage(() => {
				if (this._currentDocumentResponse) {
					this._currentDocumentResponse.dispose();
					this._currentDocumentResponse = null;
				}
				if (this._currentDocumentRequestCancellationTokenSource) {
					this._currentDocumentRequestCancellationTokenSource.cancel();
					this._currentDocumentRequestCancellationTokenSource = null;
				}
				this._setDocumentSemanticTokens(null, null, null, []);
				this._fetchDocumentSemanticTokens.schedule(0);
			})
		);
		const bindDocumentChangeListeners = () => {
			dispose(this._documentProvidersChangeListeners);
			this._documentProvidersChangeListeners = [];
			for (const provider of this._provider.all(model)) {
				if (typeof provider.onDidChange === 'function') {
					this._documentProvidersChangeListeners.push(
						provider.onDidChange(() => {
							if (this._currentDocumentRequestCancellationTokenSource) {
								this._providersChangedDuringRequest = true;
								return;
							}
							this._fetchDocumentSemanticTokens.schedule(0);
						})
					);
				}
			}
		};
		bindDocumentChangeListeners();
		this._register(
			this._provider.onDidChange(() => {
				bindDocumentChangeListeners();
				this._fetchDocumentSemanticTokens.schedule(this._debounceInformation.get(this._model));
			})
		);
		this._register(
			themeService.onDidColorThemeChange(_ => {
				this._setDocumentSemanticTokens(null, null, null, []);
				this._fetchDocumentSemanticTokens.schedule(this._debounceInformation.get(this._model));
			})
		);
		this._fetchDocumentSemanticTokens.schedule(0);
	}
	dispose() {
		if (this._currentDocumentResponse) {
			this._currentDocumentResponse.dispose();
			this._currentDocumentResponse = null;
		}
		if (this._currentDocumentRequestCancellationTokenSource) {
			this._currentDocumentRequestCancellationTokenSource.cancel();
			this._currentDocumentRequestCancellationTokenSource = null;
		}
		dispose(this._documentProvidersChangeListeners);
		this._documentProvidersChangeListeners = [];
		this._setDocumentSemanticTokens(null, null, null, []);
		this._isDisposed = true;
		super.dispose();
	}
	_fetchDocumentSemanticTokensNow() {
		if (this._currentDocumentRequestCancellationTokenSource) {
			return;
		}
		if (!this._provider.has(this._model)) {
			if (this._currentDocumentResponse) {
				this._model.tokenization.setSemanticTokens(null, false);
			}
			return;
		}
		if (!this._model.isAttachedToEditor()) {
			return;
		}
		const cancellationTokenSource = new CancellationTokenSource();
		const lastProvider = this._currentDocumentResponse ? this._currentDocumentResponse.provider : null;
		const lastResultId = this._currentDocumentResponse ? this._currentDocumentResponse.resultId || null : null;
		const request = getDocumentSemanticTokens(this._provider, this._model, lastProvider, lastResultId, cancellationTokenSource.token);
		this._currentDocumentRequestCancellationTokenSource = cancellationTokenSource;
		this._providersChangedDuringRequest = false;
		const pendingChanges = [];
		const contentChangeListener = this._model.onDidChangeContent(e => {
			pendingChanges.push(e);
		});
		const sw = new StopWatch(false);
		request.then(
			res => {
				this._debounceInformation.update(this._model, sw.elapsed());
				this._currentDocumentRequestCancellationTokenSource = null;
				contentChangeListener.dispose();
				if (!res) {
					this._setDocumentSemanticTokens(null, null, null, pendingChanges);
				} else {
					const { provider, tokens } = res;
					const styling = this._semanticTokensStylingService.getStyling(provider);
					this._setDocumentSemanticTokens(provider, tokens || null, styling, pendingChanges);
				}
			},
			err => {
				const isExpectedError =
					err && (isCancellationError(err) || (typeof err.message === 'string' && err.message.indexOf('busy') !== -1));
				if (!isExpectedError) {
					onUnexpectedError(err);
				}
				this._currentDocumentRequestCancellationTokenSource = null;
				contentChangeListener.dispose();
				if (pendingChanges.length > 0 || this._providersChangedDuringRequest) {
					if (!this._fetchDocumentSemanticTokens.isScheduled()) {
						this._fetchDocumentSemanticTokens.schedule(this._debounceInformation.get(this._model));
					}
				}
			}
		);
	}
	static _copy(src, srcOffset, dest, destOffset, length) {
		length = Math.min(length, dest.length - destOffset, src.length - srcOffset);
		for (let i = 0; i < length; i++) {
			dest[destOffset + i] = src[srcOffset + i];
		}
	}
	_setDocumentSemanticTokens(provider, tokens, styling, pendingChanges) {
		const currentResponse = this._currentDocumentResponse;
		const rescheduleIfNeeded = () => {
			if ((pendingChanges.length > 0 || this._providersChangedDuringRequest) && !this._fetchDocumentSemanticTokens.isScheduled()) {
				this._fetchDocumentSemanticTokens.schedule(this._debounceInformation.get(this._model));
			}
		};
		if (this._currentDocumentResponse) {
			this._currentDocumentResponse.dispose();
			this._currentDocumentResponse = null;
		}
		if (this._isDisposed) {
			if (provider && tokens) {
				provider.releaseDocumentSemanticTokens(tokens.resultId);
			}
			return;
		}
		if (!provider || !styling) {
			this._model.tokenization.setSemanticTokens(null, false);
			return;
		}
		if (!tokens) {
			this._model.tokenization.setSemanticTokens(null, true);
			rescheduleIfNeeded();
			return;
		}
		if (isSemanticTokensEdits(tokens)) {
			if (!currentResponse) {
				this._model.tokenization.setSemanticTokens(null, true);
				return;
			}
			if (tokens.edits.length === 0) {
				tokens = {
					resultId: tokens.resultId,
					data: currentResponse.data
				};
			} else {
				let deltaLength = 0;
				for (const edit of tokens.edits) {
					deltaLength += (edit.data ? edit.data.length : 0) - edit.deleteCount;
				}
				const srcData = currentResponse.data;
				const destData = new Uint32Array(srcData.length + deltaLength);
				let srcLastStart = srcData.length;
				let destLastStart = destData.length;
				for (let i = tokens.edits.length - 1; i >= 0; i--) {
					const edit = tokens.edits[i];
					if (edit.start > srcData.length) {
						styling.warnInvalidEditStart(currentResponse.resultId, tokens.resultId, i, edit.start, srcData.length);
						this._model.tokenization.setSemanticTokens(null, true);
						return;
					}
					const copyCount = srcLastStart - (edit.start + edit.deleteCount);
					if (copyCount > 0) {
						ModelSemanticColoring._copy(srcData, srcLastStart - copyCount, destData, destLastStart - copyCount, copyCount);
						destLastStart -= copyCount;
					}
					if (edit.data) {
						ModelSemanticColoring._copy(edit.data, 0, destData, destLastStart - edit.data.length, edit.data.length);
						destLastStart -= edit.data.length;
					}
					srcLastStart = edit.start;
				}
				if (srcLastStart > 0) {
					ModelSemanticColoring._copy(srcData, 0, destData, 0, srcLastStart);
				}
				tokens = {
					resultId: tokens.resultId,
					data: destData
				};
			}
		}
		if (isSemanticTokens(tokens)) {
			this._currentDocumentResponse = new SemanticTokensResponse(provider, tokens.resultId, tokens.data);
			const result = toMultilineTokens2(tokens, styling, this._model.getLanguageId());
			if (pendingChanges.length > 0) {
				for (const change of pendingChanges) {
					for (const area of result) {
						for (const singleChange of change.changes) {
							area.applyEdit(singleChange.range, singleChange.text);
						}
					}
				}
			}
			this._model.tokenization.setSemanticTokens(result, true);
		} else {
			this._model.tokenization.setSemanticTokens(null, true);
		}
		rescheduleIfNeeded();
	}
}
ModelSemanticColoring.REQUEST_MIN_DELAY = 300;
ModelSemanticColoring.REQUEST_MAX_DELAY = 2e3;
__decorate(
	[
		__param(1, ISemanticTokensStylingService),
		__param(2, IThemeService),
		__param(3, ILanguageFeatureDebounceService),
		__param(4, ILanguageFeaturesService)
	],
	ModelSemanticColoring
);



class ViewportSemanticTokensContribution extends Disposable {
	constructor(
		editor2,
		_semanticTokensStylingService,
		_themeService,
		_configurationService,
		languageFeatureDebounceService,
		languageFeaturesService
	) {
		super();
		this._semanticTokensStylingService = _semanticTokensStylingService;
		this._themeService = _themeService;
		this._configurationService = _configurationService;
		this._editor = editor2;
		this._provider = languageFeaturesService.documentRangeSemanticTokensProvider;
		this._debounceInformation = languageFeatureDebounceService.for(this._provider, 'DocumentRangeSemanticTokens', {
			min: 100,
			max: 500
		});
		this._tokenizeViewport = this._register(new RunOnceScheduler(() => this._tokenizeViewportNow(), 100));
		this._outstandingRequests = [];
		const scheduleTokenizeViewport = () => {
			if (this._editor.hasModel()) {
				this._tokenizeViewport.schedule(this._debounceInformation.get(this._editor.getModel()));
			}
		};
		this._register(
			this._editor.onDidScrollChange(() => {
				scheduleTokenizeViewport();
			})
		);
		this._register(
			this._editor.onDidChangeModel(() => {
				this._cancelAll();
				scheduleTokenizeViewport();
			})
		);
		this._register(
			this._editor.onDidChangeModelContent(() => {
				this._cancelAll();
				scheduleTokenizeViewport();
			})
		);
		this._register(
			this._provider.onDidChange(() => {
				this._cancelAll();
				scheduleTokenizeViewport();
			})
		);
		this._register(
			this._configurationService.onDidChangeConfiguration(e => {
				if (e.affectsConfiguration(SEMANTIC_HIGHLIGHTING_SETTING_ID)) {
					this._cancelAll();
					scheduleTokenizeViewport();
				}
			})
		);
		this._register(
			this._themeService.onDidColorThemeChange(() => {
				this._cancelAll();
				scheduleTokenizeViewport();
			})
		);
		scheduleTokenizeViewport();
	}
	_cancelAll() {
		for (const request of this._outstandingRequests) {
			request.cancel();
		}
		this._outstandingRequests = [];
	}
	_removeOutstandingRequest(req) {
		for (let i = 0, len = this._outstandingRequests.length; i < len; i++) {
			if (this._outstandingRequests[i] === req) {
				this._outstandingRequests.splice(i, 1);
				return;
			}
		}
	}
	_tokenizeViewportNow() {
		if (!this._editor.hasModel()) {
			return;
		}
		const model = this._editor.getModel();
		if (model.tokenization.hasCompleteSemanticTokens()) {
			return;
		}
		if (!isSemanticColoringEnabled(model, this._themeService, this._configurationService)) {
			if (model.tokenization.hasSomeSemanticTokens()) {
				model.tokenization.setSemanticTokens(null, false);
			}
			return;
		}
		if (!hasDocumentRangeSemanticTokensProvider(this._provider, model)) {
			if (model.tokenization.hasSomeSemanticTokens()) {
				model.tokenization.setSemanticTokens(null, false);
			}
			return;
		}
		const visibleRanges = this._editor.getVisibleRangesPlusViewportAboveBelow();
		this._outstandingRequests = this._outstandingRequests.concat(visibleRanges.map(range2 => this._requestRange(model, range2)));
	}
	_requestRange(model, range2) {
		const requestVersionId = model.getVersionId();
		const request = createCancelablePromise(token =>
			Promise.resolve(getDocumentRangeSemanticTokens(this._provider, model, range2, token))
		);
		const sw = new StopWatch(false);
		request
			.then(r => {
				this._debounceInformation.update(model, sw.elapsed());
				if (!r || !r.tokens || model.isDisposed() || model.getVersionId() !== requestVersionId) {
					return;
				}
				const { provider, tokens: result } = r;
				const styling = this._semanticTokensStylingService.getStyling(provider);
				model.tokenization.setPartialSemanticTokens(range2, toMultilineTokens2(result, styling, model.getLanguageId()));
			})
			.then(
				() => this._removeOutstandingRequest(request),
				() => this._removeOutstandingRequest(request)
			);
		return request;
	}
}
ViewportSemanticTokensContribution.ID = 'editor.contrib.viewportSemanticTokens';
__decorate(
	[
		__param(1, ISemanticTokensStylingService),
		__param(2, IThemeService),
		__param(3, IConfigurationService),
		__param(4, ILanguageFeatureDebounceService),
		__param(5, ILanguageFeaturesService)
	],
	ViewportSemanticTokensContribution
);
registerEditorContribution(
	ViewportSemanticTokensContribution.ID,
	ViewportSemanticTokensContribution,
	1 //Instantiation.AfterFirstRender
);