function announceCursorChange(previousCursorState, cursorState) {
	const e = cursorState.filter(cs => !previousCursorState.find(pcs => pcs.equals(cs)));
	if (e.length >= 1) {
		const cursorPositions = e.map(cs => `line ${cs.viewState.position.lineNumber} column ${cs.viewState.position.column}`).join(', ');
		const msg = e.length === 1 ? localize(cursorPositions) : localize(cursorPositions);

	}
}

class InsertCursorAbove extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.insertCursorAbove',
			label: localize('Add Cursor Above'),
			alias: 'Add Cursor Above',

			kbOpts: {
				kbExpr: ctxKeys_editorFocus_text,
				primary: 2048 | 512 | 16,
				linux: {
					primary: 1024 | 512 | 16,
					secondary: [
						2048 | 1024 | 16 //KeyCode.UpArrow
					]
				},
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: MenuId.MenubarSelectionMenu,
				group: '3_multi',
				title: localize('&&Add Cursor Above'),
				order: 2
			}
		});
	}
	run(accessor, editor2, args) {
		if (!editor2.hasModel()) {
			return;
		}
		let useLogicalLine = true;
		if (args && args.logicalLine === false) {
			useLogicalLine = false;
		}
		const viewModel = editor2._getViewModel();
		if (viewModel.cursorConfig.readOnly) {
			return;
		}
		viewModel.model.pushStackElement();
		const previousCursorState = viewModel.getCursorStates();
		viewModel.setCursorStates(args.source, 3, CursorMoveCommands.addCursorUp(viewModel, previousCursorState, useLogicalLine));
		viewModel.revealTopMostCursor(args.source);
		announceCursorChange(previousCursorState, viewModel.getCursorStates());
	}
}

class InsertCursorBelow extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.insertCursorBelow',
			label: localize('Add Cursor Below'),
			alias: 'Add Cursor Below',

			kbOpts: {
				kbExpr: ctxKeys_editorFocus_text,
				primary: 2048 | 512 | 18,
				linux: {
					primary: 1024 | 512 | 18,
					secondary: [
						2048 | 1024 | 18
						// DownArrow
					]
				},
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: MenuId.MenubarSelectionMenu,
				group: '3_multi',
				title: localize('A&&dd Cursor Below'),
				order: 3
			}
		});
	}
	run(accessor, editor2, args) {
		if (!editor2.hasModel()) {
			return;
		}
		let useLogicalLine = true;
		if (args && args.logicalLine === false) {
			useLogicalLine = false;
		}
		const viewModel = editor2._getViewModel();
		if (viewModel.cursorConfig.readOnly) {
			return;
		}
		viewModel.model.pushStackElement();
		const previousCursorState = viewModel.getCursorStates();
		viewModel.setCursorStates(args.source, 3, CursorMoveCommands.addCursorDown(viewModel, previousCursorState, useLogicalLine));
		viewModel.revealBottomMostCursor(args.source);
		announceCursorChange(previousCursorState, viewModel.getCursorStates());
	}
}

class InsertCursorAtEndOfEachLineSelected extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.insertCursorAtEndOfEachLineSelected',
			label: localize('Add Cursors to Line Ends'),
			alias: 'Add Cursors to Line Ends',

			kbOpts: {
				kbExpr: ctxKeys_editorFocus_text,
				primary: 1024 | 512 | 39,
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: MenuId.MenubarSelectionMenu,
				group: '3_multi',
				title: localize('Add C&&ursors to Line Ends'),
				order: 4
			}
		});
	}
	getCursorsForSelection(selection, model, result) {
		if (selection.isEmpty()) {
			return;
		}
		for (let i = selection.startLineNumber; i < selection.endLineNumber; i++) {
			const currentLineMaxColumn = model.getLineMaxColumn(i);
			result.push(new EditorSelection(i, currentLineMaxColumn, i, currentLineMaxColumn));
		}
		if (selection.endColumn > 1) {
			result.push(new EditorSelection(selection.endLineNumber, selection.endColumn, selection.endLineNumber, selection.endColumn));
		}
	}
	run(accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const model = editor2.getModel();
		const selections = editor2.getSelections();
		const viewModel = editor2._getViewModel();
		const previousCursorState = viewModel.getCursorStates();
		const newSelections = [];
		selections.forEach(sel => this.getCursorsForSelection(sel, model, newSelections));
		if (newSelections.length > 0) {
			editor2.setSelections(newSelections);
		}
		announceCursorChange(previousCursorState, viewModel.getCursorStates());
	}
}

class InsertCursorAtEndOfLineSelected extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.addCursorsToBottom',
			label: localize('Add Cursors To Bottom'),
			alias: 'Add Cursors To Bottom'
		});
	}
	run(accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const selections = editor2.getSelections();
		const lineCount = editor2.getModel().getLineCount();
		const newSelections = [];
		for (let i = selections[0].startLineNumber; i <= lineCount; i++) {
			newSelections.push(new EditorSelection(i, selections[0].startColumn, i, selections[0].endColumn));
		}
		const viewModel = editor2._getViewModel();
		const previousCursorState = viewModel.getCursorStates();
		if (newSelections.length > 0) {
			editor2.setSelections(newSelections);
		}
		announceCursorChange(previousCursorState, viewModel.getCursorStates());
	}
}

class InsertCursorAtTopOfLineSelected extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.addCursorsToTop',
			label: localize('Add Cursors To Top'),
			alias: 'Add Cursors To Top'
		});
	}
	run(accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const selections = editor2.getSelections();
		const newSelections = [];
		for (let i = selections[0].startLineNumber; i >= 1; i--) {
			newSelections.push(new EditorSelection(i, selections[0].startColumn, i, selections[0].endColumn));
		}
		const viewModel = editor2._getViewModel();
		const previousCursorState = viewModel.getCursorStates();
		if (newSelections.length > 0) {
			editor2.setSelections(newSelections);
		}
		announceCursorChange(previousCursorState, viewModel.getCursorStates());
	}
}

class MultiCursorSessionResult {
	constructor(selections, revealRange, revealScrollType) {
		this.selections = selections;
		this.revealRange = revealRange;
		this.revealScrollType = revealScrollType;
	}
}

class MultiCursorSession {
	static create(editor2, findController) {
		if (!editor2.hasModel()) {
			return null;
		}
		const findState = findController.getState();
		if (!editor2.hasTextFocus() && findState.isRevealed && findState.searchString.length > 0) {
			return new MultiCursorSession(
				editor2,
				findController,
				false,
				findState.searchString,
				findState.wholeWord,
				findState.matchCase,
				null
			);
		}
		let isDisconnectedFromFindController = false;
		let wholeWord;
		let matchCase;
		const selections = editor2.getSelections();
		if (selections.length === 1 && selections[0].isEmpty()) {
			isDisconnectedFromFindController = true;
			wholeWord = true;
			matchCase = true;
		} else {
			wholeWord = findState.wholeWord;
			matchCase = findState.matchCase;
		}
		const s = editor2.getSelection();
		let searchText;
		let currentMatch = null;
		if (s.isEmpty()) {
			const word = editor2.getConfiguredWordAtPosition(s.getStartPosition());
			if (!word) {
				return null;
			}
			searchText = word.word;
			currentMatch = new EditorSelection(s.startLineNumber, word.startColumn, s.startLineNumber, word.endColumn);
		} else {
			searchText = editor2.getModel().getValueInRange(s).replace(/\r\n/g, '\n');
		}
		return new MultiCursorSession(
			editor2,
			findController,
			isDisconnectedFromFindController,
			searchText,
			wholeWord,
			matchCase,
			currentMatch
		);
	}
	constructor(_editor, findController, isDisconnectedFromFindController, searchText, wholeWord, matchCase, currentMatch) {
		this._editor = _editor;
		this.findController = findController;
		this.isDisconnectedFromFindController = isDisconnectedFromFindController;
		this.searchText = searchText;
		this.wholeWord = wholeWord;
		this.matchCase = matchCase;
		this.currentMatch = currentMatch;
	}
	addSelectionToNextFindMatch() {
		if (!this._editor.hasModel()) {
			return null;
		}
		const nextMatch = this._getNextMatch();
		if (!nextMatch) {
			return null;
		}
		const allSelections = this._editor.getSelections();
		return new MultiCursorSessionResult(
			allSelections.concat(nextMatch),
			nextMatch,
			0
			// Smooth
		);
	}
	moveSelectionToNextFindMatch() {
		if (!this._editor.hasModel()) {
			return null;
		}
		const nextMatch = this._getNextMatch();
		if (!nextMatch) {
			return null;
		}
		const allSelections = this._editor.getSelections();
		return new MultiCursorSessionResult(
			allSelections.slice(0, allSelections.length - 1).concat(nextMatch),
			nextMatch,
			0
			// Smooth
		);
	}
	_getNextMatch() {
		if (!this._editor.hasModel()) {
			return null;
		}
		if (this.currentMatch) {
			const result = this.currentMatch;
			this.currentMatch = null;
			return result;
		}
		this.findController.highlightFindOptions();
		const allSelections = this._editor.getSelections();
		const lastAddedSelection = allSelections[allSelections.length - 1];
		const nextMatch = this._editor.getModel().findNextMatch(
			this.searchText,
			lastAddedSelection.getEndPosition(),
			false,
			this.matchCase,
			this.wholeWord
				? this._editor.getOption(
						131
						// wordSeparators
					)
				: null,
			false
		);
		if (!nextMatch) {
			return null;
		}
		return new EditorSelection(
			nextMatch.range.startLineNumber,
			nextMatch.range.startColumn,
			nextMatch.range.endLineNumber,
			nextMatch.range.endColumn
		);
	}
	addSelectionToPreviousFindMatch() {
		if (!this._editor.hasModel()) {
			return null;
		}
		const previousMatch = this._getPreviousMatch();
		if (!previousMatch) {
			return null;
		}
		const allSelections = this._editor.getSelections();
		return new MultiCursorSessionResult(
			allSelections.concat(previousMatch),
			previousMatch,
			0
			// Smooth
		);
	}
	moveSelectionToPreviousFindMatch() {
		if (!this._editor.hasModel()) {
			return null;
		}
		const previousMatch = this._getPreviousMatch();
		if (!previousMatch) {
			return null;
		}
		const allSelections = this._editor.getSelections();
		return new MultiCursorSessionResult(
			allSelections.slice(0, allSelections.length - 1).concat(previousMatch),
			previousMatch,
			0
			// Smooth
		);
	}
	_getPreviousMatch() {
		if (!this._editor.hasModel()) {
			return null;
		}
		if (this.currentMatch) {
			const result = this.currentMatch;
			this.currentMatch = null;
			return result;
		}
		this.findController.highlightFindOptions();
		const allSelections = this._editor.getSelections();
		const lastAddedSelection = allSelections[allSelections.length - 1];
		const previousMatch = this._editor.getModel().findPreviousMatch(
			this.searchText,
			lastAddedSelection.getStartPosition(),
			false,
			this.matchCase,
			this.wholeWord
				? this._editor.getOption(
						131
						// wordSeparators
					)
				: null,
			false
		);
		if (!previousMatch) {
			return null;
		}
		return new EditorSelection(
			previousMatch.range.startLineNumber,
			previousMatch.range.startColumn,
			previousMatch.range.endLineNumber,
			previousMatch.range.endColumn
		);
	}
	selectAll(searchScope) {
		if (!this._editor.hasModel()) {
			return [];
		}
		this.findController.highlightFindOptions();
		const editorModel = this._editor.getModel();
		if (searchScope) {
			return editorModel.findMatches(
				this.searchText,
				searchScope,
				false,
				this.matchCase,
				this.wholeWord
					? this._editor.getOption(
							131
							// wordSeparators
						)
					: null,
				false,
				1073741824 // Constants.MAX_SAFE_SMALL_INTEGER
			);
		}
		return editorModel.findMatches(
			this.searchText,
			true,
			false,
			this.matchCase,
			this.wholeWord
				? this._editor.getOption(
						131
						// wordSeparators
					)
				: null,
			false,
			1073741824 //Constants.MAX_SAFE_SMALL_INTEGER
		);
	}
}

class MultiCursorSelectionController extends Disposable {
	static get(editor2) {
		return editor2.getContribution(MultiCursorSelectionController.ID);
	}
	constructor(editor2) {
		super();
		this._sessionDispose = this._register(new DisposableStore());
		this._editor = editor2;
		this._ignoreSelectionChange = false;
		this._session = null;
	}
	dispose() {
		this._endSession();
		super.dispose();
	}
	_beginSessionIfNeeded(findController) {
		if (!this._session) {
			const session = MultiCursorSession.create(this._editor, findController);
			if (!session) {
				return;
			}
			this._session = session;
			const newState = { searchString: this._session.searchText };
			if (this._session.isDisconnectedFromFindController) {
				newState.wholeWordOverride = 1;
				newState.matchCaseOverride = 1;
				newState.isRegexOverride = 2;
			}
			findController.getState().change(newState, false);
			this._sessionDispose.add(
				this._editor.onDidChangeCursorSelection(() => {
					if (this._ignoreSelectionChange) {
						return;
					}
					this._endSession();
				})
			);
			this._sessionDispose.add(
				this._editor.onDidBlurEditorText(() => {
					this._endSession();
				})
			);
			this._sessionDispose.add(
				findController.getState().onFindReplaceStateChange(e => {
					if (e.matchCase || e.wholeWord) {
						this._endSession();
					}
				})
			);
		}
	}
	_endSession() {
		this._sessionDispose.clear();
		if (this._session && this._session.isDisconnectedFromFindController) {
			const newState = {
				wholeWordOverride: 0,
				matchCaseOverride: 0,
				isRegexOverride: 0
			};
			this._session.findController.getState().change(newState, false);
		}
		this._session = null;
	}
	_setSelections(selections) {
		this._ignoreSelectionChange = true;
		this._editor.setSelections(selections);
		this._ignoreSelectionChange = false;
	}
	_expandEmptyToWord(model, selection) {
		if (!selection.isEmpty()) {
			return selection;
		}
		const word = this._editor.getConfiguredWordAtPosition(selection.getStartPosition());
		if (!word) {
			return selection;
		}
		return new EditorSelection(selection.startLineNumber, word.startColumn, selection.startLineNumber, word.endColumn);
	}
	_applySessionResult(result) {
		if (!result) {
			return;
		}
		this._setSelections(result.selections);
		if (result.revealRange) {
			this._editor.revealRangeInCenterIfOutsideViewport(result.revealRange, result.revealScrollType);
		}
	}
	getSession() {
		return this._session;
	}
	addSelectionToNextFindMatch(findController) {
		if (!this._editor.hasModel()) {
			return;
		}
		if (!this._session) {
			const allSelections = this._editor.getSelections();
			if (allSelections.length > 1) {
				const findState = findController.getState();
				const matchCase = findState.matchCase;
				const selectionsContainSameText = modelRangesContainSameText(this._editor.getModel(), allSelections, matchCase);
				if (!selectionsContainSameText) {
					const model = this._editor.getModel();
					const resultingSelections = [];
					for (let i = 0, len = allSelections.length; i < len; i++) {
						resultingSelections[i] = this._expandEmptyToWord(model, allSelections[i]);
					}
					this._editor.setSelections(resultingSelections);
					return;
				}
			}
		}
		this._beginSessionIfNeeded(findController);
		if (this._session) {
			this._applySessionResult(this._session.addSelectionToNextFindMatch());
		}
	}
	addSelectionToPreviousFindMatch(findController) {
		this._beginSessionIfNeeded(findController);
		if (this._session) {
			this._applySessionResult(this._session.addSelectionToPreviousFindMatch());
		}
	}
	moveSelectionToNextFindMatch(findController) {
		this._beginSessionIfNeeded(findController);
		if (this._session) {
			this._applySessionResult(this._session.moveSelectionToNextFindMatch());
		}
	}
	moveSelectionToPreviousFindMatch(findController) {
		this._beginSessionIfNeeded(findController);
		if (this._session) {
			this._applySessionResult(this._session.moveSelectionToPreviousFindMatch());
		}
	}
	selectAll(findController) {
		if (!this._editor.hasModel()) {
			return;
		}
		let matches = null;
		const findState = findController.getState();
		if (findState.isRevealed && findState.searchString.length > 0 && findState.isRegex) {
			const editorModel = this._editor.getModel();
			if (findState.searchScope) {
				matches = editorModel.findMatches(
					findState.searchString,
					findState.searchScope,
					findState.isRegex,
					findState.matchCase,
					findState.wholeWord
						? this._editor.getOption(
								131
								// wordSeparators
							)
						: null,
					false,
					1073741824 //Constants.MAX_SAFE_SMALL_INTEGER
				);
			} else {
				matches = editorModel.findMatches(
					findState.searchString,
					true,
					findState.isRegex,
					findState.matchCase,
					findState.wholeWord
						? this._editor.getOption(
								131
								// wordSeparators
							)
						: null,
					false,
					1073741824 //Constants.MAX_SAFE_SMALL_INTEGER
				);
			}
		} else {
			this._beginSessionIfNeeded(findController);
			if (!this._session) {
				return;
			}
			matches = this._session.selectAll(findState.searchScope);
		}
		if (matches.length > 0) {
			const editorSelection = this._editor.getSelection();
			for (let i = 0, len = matches.length; i < len; i++) {
				const match2 = matches[i];
				const intersection2 = match2.range.intersectRanges(editorSelection);
				if (intersection2) {
					matches[i] = matches[0];
					matches[0] = match2;
					break;
				}
			}
			this._setSelections(
				matches.map(
					m => new EditorSelection(m.range.startLineNumber, m.range.startColumn, m.range.endLineNumber, m.range.endColumn)
				)
			);
		}
	}
}
MultiCursorSelectionController.ID = 'editor.contrib.multiCursorController';

class MultiCursorSelectionControllerAction extends EditorAction {
	run(accessor, editor2) {
		const multiCursorController = MultiCursorSelectionController.get(editor2);
		if (!multiCursorController) {
			return;
		}
		const viewModel = editor2._getViewModel();
		if (viewModel) {
			const previousCursorState = viewModel.getCursorStates();
			const findController = CommonFindController.get(editor2);
			if (findController) {
				this._run(multiCursorController, findController);
			} else {
				const newFindController = accessor.get(IInstantiationService).createInstance(CommonFindController, editor2);
				this._run(multiCursorController, newFindController);
				newFindController.dispose();
			}
			announceCursorChange(previousCursorState, viewModel.getCursorStates());
		}
	}
}

class AddSelectionToNextFindMatchAction extends MultiCursorSelectionControllerAction {
	constructor() {
		super({
			id: 'editor.action.addSelectionToNextFindMatch',
			label: localize('Add EditorSelection To Next Find Match'),
			alias: 'Add EditorSelection To Next Find Match',

			kbOpts: {
				kbExpr: ctxKeys_editorFocus,
				primary: 2048 | 34,
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: MenuId.MenubarSelectionMenu,
				group: '3_multi',
				title: localize('Add &&Next Occurrence'),
				order: 5
			}
		});
	}
	_run(multiCursorController, findController) {
		multiCursorController.addSelectionToNextFindMatch(findController);
	}
}

class AddSelectionToPreviousFindMatchAction extends MultiCursorSelectionControllerAction {
	constructor() {
		super({
			id: 'editor.action.addSelectionToPreviousFindMatch',
			label: localize('Add EditorSelection To Previous Find Match'),
			alias: 'Add EditorSelection To Previous Find Match',

			menuOpts: {
				menuId: MenuId.MenubarSelectionMenu,
				group: '3_multi',
				title: localize('Add P&&revious Occurrence'),
				order: 6
			}
		});
	}
	_run(multiCursorController, findController) {
		multiCursorController.addSelectionToPreviousFindMatch(findController);
	}
}

class MoveSelectionToNextFindMatchAction extends MultiCursorSelectionControllerAction {
	constructor() {
		super({
			id: 'editor.action.moveSelectionToNextFindMatch',
			label: localize('Move Last EditorSelection To Next Find Match'),
			alias: 'Move Last EditorSelection To Next Find Match',

			kbOpts: {
				kbExpr: ctxKeys_editorFocus,
				primary: KeyChord(
					2048 | 41,
					2048 | 34 //KeyCode.KeyD
				),
				weight: 100 //editorContrib
			}
		});
	}
	_run(multiCursorController, findController) {
		multiCursorController.moveSelectionToNextFindMatch(findController);
	}
}

class MoveSelectionToPreviousFindMatchAction extends MultiCursorSelectionControllerAction {
	constructor() {
		super({
			id: 'editor.action.moveSelectionToPreviousFindMatch',
			label: localize('Move Last EditorSelection To Previous Find Match'),
			alias: 'Move Last EditorSelection To Previous Find Match'
		});
	}
	_run(multiCursorController, findController) {
		multiCursorController.moveSelectionToPreviousFindMatch(findController);
	}
}

class SelectHighlightsAction extends MultiCursorSelectionControllerAction {
	constructor() {
		super({
			id: 'editor.action.selectHighlights',
			label: localize('Select All Occurrences of Find Match'),
			alias: 'Select All Occurrences of Find Match',

			kbOpts: {
				kbExpr: ctxKeys_editorFocus,
				primary: 2048 | 1024 | 42,
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: MenuId.MenubarSelectionMenu,
				group: '3_multi',
				title: localize('Select All &&Occurrences'),
				order: 7
			}
		});
	}
	_run(multiCursorController, findController) {
		multiCursorController.selectAll(findController);
	}
}

class CompatChangeAll extends MultiCursorSelectionControllerAction {
	constructor() {
		super({
			id: 'editor.action.changeAll',
			label: localize('Change All Occurrences'),
			alias: 'Change All Occurrences',
			precondition: ContextKeyExpr.and(ctxKeys_writable, ctxKeys_editorFocus_text),
			kbOpts: {
				kbExpr: ctxKeys_editorFocus_text,
				primary: 2048 | 60,
				weight: 100 //editorContrib
			},
			contextMenuOpts: {
				group: '1_modification',
				order: 1.2
			}
		});
	}
	_run(multiCursorController, findController) {
		multiCursorController.selectAll(findController);
	}
}

class SelectionHighlighterState {
	constructor(_model, _searchText, _matchCase, _wordSeparators, prevState) {
		this._model = _model;
		this._searchText = _searchText;
		this._matchCase = _matchCase;
		this._wordSeparators = _wordSeparators;
		this._modelVersionId = this._model.getVersionId();
		this._cachedFindMatches = null;
		if (
			prevState &&
			this._model === prevState._model &&
			this._searchText === prevState._searchText &&
			this._matchCase === prevState._matchCase &&
			this._wordSeparators === prevState._wordSeparators &&
			this._modelVersionId === prevState._modelVersionId
		) {
			this._cachedFindMatches = prevState._cachedFindMatches;
		}
	}
	findMatches() {
		if (this._cachedFindMatches === null) {
			this._cachedFindMatches = this._model
				.findMatches(this._searchText, true, false, this._matchCase, this._wordSeparators, false)
				.map(m => m.range);
			this._cachedFindMatches.sort(Range.compareRangesUsingStarts);
		}
		return this._cachedFindMatches;
	}
}

class SelectionHighlighter extends Disposable {
	constructor(editor2, _languageFeaturesService) {
		super();
		this._languageFeaturesService = _languageFeaturesService;
		this.editor = editor2;
		this._isEnabled = editor2.getOption(
			108
			// selectionHighlight
		);
		this._decorations = editor2.createDecorationsCollection();
		this.updateSoon = this._register(new RunOnceScheduler(() => this._update(), 300));
		this.state = null;
		this._register(
			editor2.onDidChangeConfiguration(() => {
				this._isEnabled = editor2.getOption(
					108
					// selectionHighlight
				);
			})
		);
		this._register(
			editor2.onDidChangeCursorSelection(e => {
				if (!this._isEnabled) {
					return;
				}
				if (e.selection.isEmpty()) {
					if (e.reason === 3) {
						if (this.state) {
							this._setState(null);
						}
						this.updateSoon.schedule();
					} else {
						this._setState(null);
					}
				} else {
					this._update();
				}
			})
		);
		this._register(
			editor2.onDidChangeModel(() => {
				this._setState(null);
			})
		);
		this._register(
			editor2.onDidChangeModelContent(() => {
				if (this._isEnabled) {
					this.updateSoon.schedule();
				}
			})
		);
		const findController = CommonFindController.get(editor2);
		if (findController) {
			this._register(
				findController.getState().onFindReplaceStateChange(() => {
					this._update();
				})
			);
		}
		this.updateSoon.schedule();
	}
	_update() {
		this._setState(SelectionHighlighter._createState(this.state, this._isEnabled, this.editor));
	}
	static _createState(oldState, isEnabled, editor2) {
		if (!isEnabled) {
			return null;
		}
		if (!editor2.hasModel()) {
			return null;
		}
		const s = editor2.getSelection();
		if (s.startLineNumber !== s.endLineNumber) {
			return null;
		}
		const multiCursorController = MultiCursorSelectionController.get(editor2);
		if (!multiCursorController) {
			return null;
		}
		const findController = CommonFindController.get(editor2);
		if (!findController) {
			return null;
		}
		let r = multiCursorController.getSession(findController);
		if (!r) {
			const allSelections = editor2.getSelections();
			if (allSelections.length > 1) {
				const findState2 = findController.getState();
				const matchCase = findState2.matchCase;
				const selectionsContainSameText = modelRangesContainSameText(editor2.getModel(), allSelections, matchCase);
				if (!selectionsContainSameText) {
					return null;
				}
			}
			r = MultiCursorSession.create(editor2, findController);
		}
		if (!r) {
			return null;
		}
		if (r.currentMatch) {
			return null;
		}
		if (/^[ \t]+$/.test(r.searchText)) {
			return null;
		}
		if (r.searchText.length > 200) {
			return null;
		}
		const findState = findController.getState();
		const caseSensitive = findState.matchCase;
		if (findState.isRevealed) {
			let findStateSearchString = findState.searchString;
			if (!caseSensitive) {
				findStateSearchString = findStateSearchString.toLowerCase();
			}
			let mySearchString = r.searchText;
			if (!caseSensitive) {
				mySearchString = mySearchString.toLowerCase();
			}
			if (
				findStateSearchString === mySearchString &&
				r.matchCase === findState.matchCase &&
				r.wholeWord === findState.wholeWord &&
				!findState.isRegex
			) {
				return null;
			}
		}
		return new SelectionHighlighterState(
			editor2.getModel(),
			r.searchText,
			r.matchCase,
			r.wholeWord
				? editor2.getOption(
						131
						// wordSeparators
					)
				: null,
			oldState
		);
	}
	_setState(newState) {
		this.state = newState;
		if (!this.state) {
			this._decorations.clear();
			return;
		}
		if (!this.editor.hasModel()) {
			return;
		}
		const model = this.editor.getModel();
		if (model.isTooLargeForTokenization()) {
			return;
		}
		const allMatches = this.state.findMatches();
		const selections = this.editor.getSelections();
		selections.sort(Range.compareRangesUsingStarts);
		const matches = [];
		for (let i = 0, j = 0, len = allMatches.length, lenJ = selections.length; i < len; ) {
			const match2 = allMatches[i];
			if (j >= lenJ) {
				matches.push(match2);
				i++;
			} else {
				const cmp3 = Range.compareRangesUsingStarts(match2, selections[j]);
				if (cmp3 < 0) {
					if (selections[j].isEmpty() || !Range.areIntersecting(match2, selections[j])) {
						matches.push(match2);
					}
					i++;
				} else if (cmp3 > 0) {
					j++;
				} else {
					i++;
					j++;
				}
			}
		}
		const occurrenceHighlighting =
			this.editor.getOption(
				81
				// occurrencesHighlight
			) !== 'off';
		const hasSemanticHighlights = this._languageFeaturesService.documentHighlightProvider.has(model) && occurrenceHighlighting;
		const decorations = matches.map(r => {
			return {
				range: r,
				options: getSelectionHighlightDecorationOptions(hasSemanticHighlights)
			};
		});
		this._decorations.set(decorations);
	}
	dispose() {
		this._setState(null);
		super.dispose();
	}
}
SelectionHighlighter.ID = 'editor.contrib.selectionHighlighter';
__decorate([__param(1, ILanguageFeaturesService)], SelectionHighlighter);

function modelRangesContainSameText(model, ranges, matchCase) {
	const toLowerCase = !matchCase;

	const text1 = model.getValueInRange(ranges[0]);

	const selectedText = toLowerCase ? text1.toLowerCase() : text1;

	for (let i = 1, len = ranges.length; i < len; ++i) {
		const range = ranges[i];
		if (range.isEmpty()) {
			return false;
		}

		const text2 = model.getValueInRange(ranges);
		const thisSelectedText = toLowerCase ? text2.toLowerCase() : text2;

		if (selectedText !== thisSelectedText) {
			return false;
		}
	}
	return true;
}

class FocusNextCursor extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.focusNextCursor',
			label: localize('Focus Next Cursor'),
			metadata: {
				args: []
			},
			alias: 'Focus Next Cursor'
		});
	}
	run(accessor, editor2, args) {
		if (!editor2.hasModel()) {
			return;
		}
		const viewModel = editor2._getViewModel();
		if (viewModel.cursorConfig.readOnly) {
			return;
		}
		viewModel.model.pushStackElement();
		const previousCursorState = Array.from(viewModel.getCursorStates());
		const firstCursor = previousCursorState.shift();
		if (!firstCursor) {
			return;
		}
		previousCursorState.push(firstCursor);
		viewModel.setCursorStates(args.source, 3, previousCursorState);
		viewModel.revealPrimaryCursor(args.source, true);
		announceCursorChange(previousCursorState, viewModel.getCursorStates());
	}
}
class FocusPreviousCursor extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.focusPreviousCursor',
			label: localize('Focus Previous Cursor'),
			metadata: {
				args: []
			},
			alias: 'Focus Previous Cursor'
		});
	}
	run(accessor, editor2, args) {
		if (!editor2.hasModel()) {
			return;
		}
		const viewModel = editor2._getViewModel();
		if (viewModel.cursorConfig.readOnly) {
			return;
		}
		viewModel.model.pushStackElement();
		const previousCursorState = Array.from(viewModel.getCursorStates());
		const firstCursor = previousCursorState.pop();
		if (!firstCursor) {
			return;
		}
		previousCursorState.unshift(firstCursor);
		viewModel.setCursorStates(args.source, 3, previousCursorState);
		viewModel.revealPrimaryCursor(args.source, true);
		announceCursorChange(previousCursorState, viewModel.getCursorStates());
	}
}
registerEditorContribution(
	MultiCursorSelectionController.ID,
	MultiCursorSelectionController,
	4 //Instantiation.Lazy
);
registerEditorContribution(
	SelectionHighlighter.ID,
	SelectionHighlighter,
	1 //Instantiation.AfterFirstRender
);
registerEditorAction(InsertCursorAbove);
registerEditorAction(InsertCursorBelow);
registerEditorAction(InsertCursorAtEndOfEachLineSelected);
registerEditorAction(AddSelectionToNextFindMatchAction);
registerEditorAction(AddSelectionToPreviousFindMatchAction);
registerEditorAction(MoveSelectionToNextFindMatchAction);
registerEditorAction(MoveSelectionToPreviousFindMatchAction);
registerEditorAction(SelectHighlightsAction);
registerEditorAction(CompatChangeAll);
registerEditorAction(InsertCursorAtEndOfLineSelected);
registerEditorAction(InsertCursorAtTopOfLineSelected);
registerEditorAction(FocusNextCursor);
registerEditorAction(FocusPreviousCursor);