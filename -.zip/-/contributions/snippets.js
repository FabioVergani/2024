const CommandCtor = EditorCommand.bindToContribution(SnippetController2.get);
registerEditorCommand(
	new CommandCtor({
		id: 'jumpToNextSnippetPlaceholder',
		precondition: ContextKeyExpr.and(ck_inSnippetMode, ck_hasNextTabstop),
		handler: ctrl => ctrl.next(),
		kbOpts: {
			weight: 100 + 30,
			kbExpr: ck_inputFocus_text,
			primary: 2 // Tab
		}
	})
);
registerEditorCommand(
	new CommandCtor({
		id: 'jumpToPrevSnippetPlaceholder',
		precondition: ContextKeyExpr.and(ck_inSnippetMode, ck_hasPrevTabstop),
		handler: ctrl => ctrl.prev(),
		kbOpts: {
			weight: 100 + 30,
			kbExpr: ck_inputFocus_text,
			primary: 1024 | 2 // Tab
		}
	})
);
registerEditorCommand(
	new CommandCtor({
		id: 'leaveSnippet',
		precondition: ck_inSnippetMode,
		handler: ctrl => ctrl.cancel(true),
		kbOpts: {
			weight: 100 + 30,
			kbExpr: ck_inputFocus_text,
			primary: 9,
			secondary: [
				1024 | 9 // Escape
			]
		}
	})
);

commandsRegistry.registerCommand('_executeCompletionItemProvider', async (accessor, uri, position, triggerCharacter, maxItemsToResolve) => {
	if (
		(typeof triggerCharacter === 'string' || !triggerCharacter) &&
		(typeof maxItemsToResolve === 'number' || !maxItemsToResolve) &&
		URI.isUri(uri) &&
		Position.isIPosition(position)
	) {
		const { completionProvider } = accessor.get(ILanguageFeaturesService);
		const ref = await accessor.get(ITextModelService).createModelReference(uri);
		try {
			const result = { incomplete: false, suggestions: [] };
			const resolving = [];
			const actualPosition = ref.object.textEditorModel.validatePosition(position);
			const completions = await provideSuggestionItems(completionProvider, ref.object.textEditorModel, actualPosition, undefined, {
				triggerCharacter: triggerCharacter !== null && triggerCharacter !== undefined ? triggerCharacter : undefined,
				triggerKind: triggerCharacter
					? 1 //TriggerCharacter
					: 0 //Invoke
			});
			for (const item of completions.items) {
				if (resolving.length < (maxItemsToResolve !== null && maxItemsToResolve !== undefined ? maxItemsToResolve : 0)) {
					resolving.push(item.resolve(cancellationToken_none));
				}
				result.incomplete = result.incomplete || item.container.incomplete;
				result.suggestions.push(item.completion);
			}
			try {
				await Promise.all(resolving);
				return result;
			} finally {
				setTimeout(() => completions.disposable.dispose(), 100);
			}
		} finally {
			ref.dispose();
		}
	}
});