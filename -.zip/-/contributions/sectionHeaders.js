class SectionHeaderDetector extends Disposable {
	constructor(editor2, languageConfigurationService, editorWorkerService) {
		super();
		this.editor = editor2;
		this.languageConfigurationService = languageConfigurationService;
		this.editorWorkerService = editorWorkerService;
		this.decorations = this.editor.createDecorationsCollection();
		this.options = this.createOptions(
			editor2.getOption(
				73
				// minimap
			)
		);
		this.computePromise = null;
		this.currentOccurrences = {};
		this._register(
			editor2.onDidChangeModel(() => {
				this.currentOccurrences = {};
				this.options = this.createOptions(
					editor2.getOption(
						73
						// minimap
					)
				);
				this.stop();
				this.computeSectionHeaders.schedule(0);
			})
		);
		this._register(
			editor2.onDidChangeModelLanguage(() => {
				this.currentOccurrences = {};
				this.options = this.createOptions(
					editor2.getOption(
						73
						// minimap
					)
				);
				this.stop();
				this.computeSectionHeaders.schedule(0);
			})
		);
		this._register(
			languageConfigurationService.onDidChange(e => {
				const editorLanguageId = this.editor.getModel()?.getLanguageId();
				if (editorLanguageId && e.affects(editorLanguageId)) {
					this.currentOccurrences = {};
					this.options = this.createOptions(
						editor2.getOption(
							73
							// minimap
						)
					);
					this.stop();
					this.computeSectionHeaders.schedule(0);
				}
			})
		);
		this._register(
			editor2.onDidChangeConfiguration(e => {
				if (
					this.options &&
					!e.hasChanged(
						73
						// minimap
					)
				) {
					return;
				}
				this.options = this.createOptions(
					editor2.getOption(
						73
						// minimap
					)
				);
				this.updateDecorations([]);
				this.stop();
				this.computeSectionHeaders.schedule(0);
			})
		);
		this._register(
			this.editor.onDidChangeModelContent(() => {
				this.computeSectionHeaders.schedule();
			})
		);
		this._register(
			editor2.onDidChangeModelTokens(() => {
				if (!this.computeSectionHeaders.isScheduled()) {
					this.computeSectionHeaders.schedule(1e3);
				}
			})
		);
		this.computeSectionHeaders = this._register(
			new RunOnceScheduler(() => {
				this.findSectionHeaders();
			}, 250)
		);
		this.computeSectionHeaders.schedule(0);
	}
	createOptions(minimap) {
		if (!minimap || !this.editor.hasModel()) {
			return;
		}
		const languageId = this.editor.getModel().getLanguageId();
		if (!languageId) {
			return;
		}
		const commentsConfiguration = this.languageConfigurationService.getLanguageConfiguration(languageId).comments;
		const foldingRules = this.languageConfigurationService.getLanguageConfiguration(languageId).foldingRules;
		if (!commentsConfiguration && !foldingRules?.markers) {
			return;
		}
		return {
			foldingRules,
			findMarkSectionHeaders: minimap.showMarkSectionHeaders,
			findRegionSectionHeaders: minimap.showRegionSectionHeaders
		};
	}
	findSectionHeaders() {
		if (!this.editor.hasModel() || (!this.options?.findMarkSectionHeaders && !this.options?.findRegionSectionHeaders)) {
			return;
		}
		const model = this.editor.getModel();
		if (model.isDisposed() || model.isTooLargeForSyncing()) {
			return;
		}
		const modelVersionId = model.getVersionId();
		this.editorWorkerService.findSectionHeaders(model.uri, this.options).then(sectionHeaders => {
			if (model.isDisposed() || model.getVersionId() !== modelVersionId) {
				return;
			}
			this.updateDecorations(sectionHeaders);
		});
	}
	updateDecorations(sectionHeaders) {
		const model = this.editor.getModel();
		if (model) {
			sectionHeaders = sectionHeaders.filter(sectionHeader => {
				if (!sectionHeader.shouldBeInComments) {
					return true;
				}
				const validRange = model.validateRange(sectionHeader.range);
				const tokens = model.tokenization.getLineTokens(validRange.startLineNumber);
				const idx = tokens.findTokenIndexAtOffset(validRange.startColumn - 1);
				const tokenType = tokens.getStandardTokenType(idx);
				const languageId = tokens.getLanguageId(idx);
				return languageId === model.getLanguageId() && tokenType === 1;
			});
		}
		const oldDecorations = Object.values(this.currentOccurrences).map(occurrence => occurrence.decorationId);
		const newDecorations = sectionHeaders.map(sectionHeader => decoration2(sectionHeader));
		this.editor.changeDecorations(changeAccessor => {
			const decorations = changeAccessor.deltaDecorations(oldDecorations, newDecorations);
			this.currentOccurrences = {};
			for (let i = 0, len = decorations.length; i < len; i++) {
				const occurrence = { sectionHeader: sectionHeaders[i], decorationId: decorations[i] };
				this.currentOccurrences[occurrence.decorationId] = occurrence;
			}
		});
	}
	stop() {
		this.computeSectionHeaders.cancel();
		if (this.computePromise) {
			this.computePromise.cancel();
			this.computePromise = null;
		}
	}
	dispose() {
		super.dispose();
		this.stop();
		this.decorations.clear();
	}
}
SectionHeaderDetector.ID = 'editor.sectionHeaderDetector';
__decorate([__param(1, ILanguageConfigurationService), __param(2, IEditorWorkerService)], SectionHeaderDetector);

const decoration2 = sectionHeader => {
	return {
		range: sectionHeader.range,
		options: ModelDecorationOptions.createDynamic({
			description: 'section-header',
			stickiness: 3,
			collapseOnReplaceEdit: true,
			minimap: {
				color: undefined,
				position: 1,
				sectionHeaderStyle: sectionHeader.hasSeparatorLine ? 2 : 1,
				sectionHeaderText: sectionHeader.text
			}
		})
	};
};

registerEditorContribution(
	SectionHeaderDetector.ID,
	SectionHeaderDetector,
	1
	/* EditorContributionInstantiation.AfterFirstRender */
);
