class GotoDefinitionAtPositionEditorContribution {
	constructor(editor2, textModelResolverService, languageService, languageFeaturesService) {
		this.textModelResolverService = textModelResolverService;
		this.languageService = languageService;
		this.languageFeaturesService = languageFeaturesService;
		this.toUnhook = new DisposableStore();
		this.toUnhookForKeyboard = new DisposableStore();
		this.currentWordAtPosition = null;
		this.previousPromise = null;
		this.editor = editor2;
		this.linkDecorations = this.editor.createDecorationsCollection();
		const linkGesture = new ClickLinkGesture(editor2);
		this.toUnhook.add(linkGesture);
		this.toUnhook.add(
			linkGesture.onMouseMoveOrRelevantKeyDown(([mouseEvent, keyboardEvent]) => {
				this.startFindDefinitionFromMouse(
					mouseEvent,
					keyboardEvent !== null && keyboardEvent !== undefined ? keyboardEvent : undefined
				);
			})
		);
		this.toUnhook.add(
			linkGesture.onExecute(mouseEvent => {
				if (this.isEnabled(mouseEvent)) {
					this.gotoDefinition(mouseEvent.target.position, mouseEvent.hasSideBySideModifier)
						.catch(error => {
							onUnexpectedError(error);
						})
						.finally(() => {
							this.removeLinkDecorations();
						});
				}
			})
		);
		this.toUnhook.add(
			linkGesture.onCancel(() => {
				this.removeLinkDecorations();
				this.currentWordAtPosition = null;
			})
		);
	}
	static get(editor2) {
		return editor2.getContribution(GotoDefinitionAtPositionEditorContribution.ID);
	}
	async startFindDefinitionFromCursor(position) {
		await this.startFindDefinition(position);
		this.toUnhookForKeyboard.add(
			this.editor.onDidChangeCursorPosition(() => {
				this.currentWordAtPosition = null;
				this.removeLinkDecorations();
				this.toUnhookForKeyboard.clear();
			})
		);
		this.toUnhookForKeyboard.add(
			this.editor.onKeyDown(e => {
				if (e) {
					this.currentWordAtPosition = null;
					this.removeLinkDecorations();
					this.toUnhookForKeyboard.clear();
				}
			})
		);
	}
	startFindDefinitionFromMouse(mouseEvent, withKey) {
		if (mouseEvent.target.type === 9 && this.linkDecorations.length > 0) {
			return;
		}
		if (!this.editor.hasModel() || !this.isEnabled(mouseEvent, withKey)) {
			this.currentWordAtPosition = null;
			this.removeLinkDecorations();
			return;
		}
		const position = mouseEvent.target.position;
		this.startFindDefinition(position);
	}
	async startFindDefinition(position) {
		this.toUnhookForKeyboard.clear();
		const word = position ? this.editor.getModel()?.getWordAtPosition(position) : null;
		if (!word) {
			this.currentWordAtPosition = null;
			this.removeLinkDecorations();
			return;
		}
		if (
			this.currentWordAtPosition &&
			this.currentWordAtPosition.startColumn === word.startColumn &&
			this.currentWordAtPosition.endColumn === word.endColumn &&
			this.currentWordAtPosition.word === word.word
		) {
			return;
		}
		this.currentWordAtPosition = word;
		const state = new EditorState(
			this.editor,
			4 | 1 | 2 | 8
			/* CodeEditorStateFlag.Scroll */
		);
		if (this.previousPromise) {
			this.previousPromise.cancel();
			this.previousPromise = null;
		}
		this.previousPromise = createCancelablePromise(token => this.findDefinition(position, token));
		let results;
		try {
			results = await this.previousPromise;
		} catch (error) {
			onUnexpectedError(error);
			return;
		}
		if (!results || !results.length || !state.validate(this.editor)) {
			this.removeLinkDecorations();
			return;
		}
		const linkRange = results[0].originSelectionRange
			? Range.lift(results[0].originSelectionRange)
			: new Range(position.lineNumber, word.startColumn, position.lineNumber, word.endColumn);
		if (results.length > 1) {
			let combinedRange = linkRange;
			for (const { originSelectionRange } of results) {
				if (originSelectionRange) {
					combinedRange = Range.plusRange(combinedRange, originSelectionRange);
				}
			}
			this.addDecoration(combinedRange, new MarkdownString().appendText(localize(results.length)));
		} else {
			const result = results[0];
			if (!result.uri) {
				return;
			}
			this.textModelResolverService.createModelReference(result.uri).then(ref => {
				if (!ref.object || !ref.object.textEditorModel) {
					ref.dispose();
					return;
				}
				const {
					object: { textEditorModel }
				} = ref;
				const { startLineNumber } = result.range;
				if (startLineNumber < 1 || startLineNumber > textEditorModel.getLineCount()) {
					ref.dispose();
					return;
				}
				const previewValue = this.getPreviewValue(textEditorModel, startLineNumber, result);
				const languageId = this.languageService.guessLanguageIdByFilepathOrFirstLine(textEditorModel.uri);
				this.addDecoration(
					linkRange,
					previewValue ? new MarkdownString().appendCodeblock(languageId ? languageId : '', previewValue) : undefined
				);
				ref.dispose();
			});
		}
	}
	getPreviewValue(textEditorModel, startLineNumber, result) {
		let rangeToUse = result.range;
		const numberOfLinesInRange = rangeToUse.endLineNumber - rangeToUse.startLineNumber;
		if (numberOfLinesInRange >= GotoDefinitionAtPositionEditorContribution.MAX_SOURCE_PREVIEW_LINES) {
			rangeToUse = this.getPreviewRangeBasedOnIndentation(textEditorModel, startLineNumber);
		}
		const previewValue = this.stripIndentationFromPreviewRange(textEditorModel, startLineNumber, rangeToUse);
		return previewValue;
	}
	stripIndentationFromPreviewRange(textEditorModel, startLineNumber, previewRange) {
		const startIndent = textEditorModel.getLineFirstNonWhitespaceColumn(startLineNumber);
		let minIndent = startIndent;
		for (let endLineNumber = startLineNumber + 1; endLineNumber < previewRange.endLineNumber; endLineNumber++) {
			const endIndent = textEditorModel.getLineFirstNonWhitespaceColumn(endLineNumber);
			minIndent = Math.min(minIndent, endIndent);
		}
		const previewValue = textEditorModel
			.getValueInRange(previewRange)
			.replace(new RegExp(`^\\s{${minIndent - 1}}`, 'gm'), '')
			.trim();
		return previewValue;
	}
	getPreviewRangeBasedOnIndentation(textEditorModel, startLineNumber) {
		const startIndent = textEditorModel.getLineFirstNonWhitespaceColumn(startLineNumber);
		const maxLineNumber = Math.min(
			textEditorModel.getLineCount(),
			startLineNumber + GotoDefinitionAtPositionEditorContribution.MAX_SOURCE_PREVIEW_LINES
		);
		let endLineNumber = startLineNumber + 1;
		for (; endLineNumber < maxLineNumber; endLineNumber++) {
			const endIndent = textEditorModel.getLineFirstNonWhitespaceColumn(endLineNumber);
			if (startIndent === endIndent) {
				break;
			}
		}
		return new Range(startLineNumber, 1, endLineNumber + 1, 1);
	}
	addDecoration(range2, hoverMessage) {
		const newDecorations = {
			range: range2,
			options: {
				description: 'goto-definition-link',
				inlineClassName: 'goto-definition-link',
				hoverMessage
			}
		};
		this.linkDecorations.set([newDecorations]);
	}
	removeLinkDecorations() {
		this.linkDecorations.clear();
	}
	isEnabled(mouseEvent, withKey) {
		return (
			this.editor.hasModel() &&
			mouseEvent.isLeftClick &&
			mouseEvent.isNoneOrSingleMouseDown &&
			mouseEvent.target.type === 6 &&
			!(mouseEvent.target.detail.injectedText?.options instanceof ModelDecorationInjectedTextOptions) &&
			(mouseEvent.hasTriggerModifier || (withKey ? withKey.keyCodeIsTriggerKey : false)) &&
			this.languageFeaturesService.definitionProvider.has(this.editor.getModel())
		);
	}
	findDefinition(position, token) {
		const model = this.editor.getModel();
		if (!model) {
			return Promise.resolve(null);
		}
		return getDefinitionsAtPosition(this.languageFeaturesService.definitionProvider, model, position, token);
	}
	gotoDefinition(position, openToSide) {
		this.editor.setPosition(position);
		return this.editor.invokeWithinContext(accessor => {
			const canPeek =
				!openToSide &&
				this.editor.getOption(
					88
					// definitionLinkOpensInPeek
				) &&
				!this.isInPeekEditor(accessor);
			const action = new DefinitionAction(
				{ openToSide, openInPeek: canPeek, muteMessage: true },
				{ title: { value: '', original: '' }, id: '' }
			);
			return action.run(accessor);
		});
	}
	isInPeekEditor(accessor) {
		const contextKeyService = accessor.get(IContextKeyService);
		return ctxKeys_inPeekEditor.getValue(contextKeyService);
	}
	dispose() {
		this.toUnhook.dispose();
		this.toUnhookForKeyboard.dispose();
	}
}
GotoDefinitionAtPositionEditorContribution.ID = 'editor.contrib.gotodefinitionatposition';
GotoDefinitionAtPositionEditorContribution.MAX_SOURCE_PREVIEW_LINES = 8;

__decorate(
	[__param(1, ITextModelService), __param(2, ILanguageService), __param(3, ILanguageFeaturesService)],
	GotoDefinitionAtPositionEditorContribution
);

registerEditorContribution(
	GotoDefinitionAtPositionEditorContribution.ID,
	GotoDefinitionAtPositionEditorContribution,
	2
	/* EditorContributionInstantiation.BeforeFirstInteraction */
);


//class LanguagesRegistry extends Disposable {
	guessLanguageIdByFilepathOrFirstLine(resource, firstLine) {
		if (!resource && !firstLine) {
			return [];
		}
		function getAssociationByFirstline(firstLine) {
			if (startsWithUTF8BOM(firstLine)) {
				firstLine = firstLine.substr(1);
			}
			if (firstLine.length > 0) {
				for (let i = registeredAssociations.length - 1; i >= 0; i--) {
					const association = registeredAssociations[i];
					if (!association.firstline) {
						continue;
					}
					const matches = firstLine.match(association.firstline);
					if (matches && matches.length > 0) {
						return association;
					}
				}
			}
			return;
		}

		const _getAssociations = (resource, firstLine) => {
			let path;
			if (resource) {
				switch (resource.scheme) {
					case Schemas.file:
						path = resource.fsPath;
						break;
					case Schemas.data: {
						const metadata = DataUri.parseMetaData(resource);
						path = metadata.get(DataUri.META_DATA_LABEL);
						break;
					}
					case Schemas.vscodeNotebookCell:
						path = undefined;
						break;
					default:
						path = resource.path;
				}
			}
			if (!path) {
				return [{ id: 'unknown', mime: 'application/unknown' }];
			}
			path = path.toLowerCase();
			const filename = basename(path);
			const configuredLanguage = getAssociationByPath(path, filename, userRegisteredAssociations);
			if (configuredLanguage) {
				return [configuredLanguage, { id: PLAINTEXT_LANGUAGE_ID, mime: 'text/plain' }];
			}
			const registeredLanguage = getAssociationByPath(path, filename, nonUserRegisteredAssociations);
			if (registeredLanguage) {
				return [registeredLanguage, { id: PLAINTEXT_LANGUAGE_ID, mime: 'text/plain' }];
			}
			if (firstLine) {
				const firstlineLanguage = getAssociationByFirstline(firstLine);
				if (firstlineLanguage) {
					return [firstlineLanguage, { id: PLAINTEXT_LANGUAGE_ID, mime: 'text/plain' }];
				}
			}
			return [{ id: 'unknown', mime: 'application/unknown' }];
		};
		return _getAssociations(resource, firstLine).map(e => e.id);
	}

	guessLanguageIdByFilepathOrFirstLine(resource, firstLine) {
		const languageIds = this._registry.guessLanguageIdByFilepathOrFirstLine(resource, firstLine);
		return firstSlotOrFallbackValue(languageIds, null);
	}


		createByFilepathOrFirstLine(resource, firstLine) {
		return new LanguageSelection(this.onDidChange, () => {
			const languageId = this.guessLanguageIdByFilepathOrFirstLine(resource, firstLine);
			return this._createAndGetLanguageIdentifier(languageId);
		});
	}




function detectLanguageId(modelService, languageService, resource) {
	if (!resource) {
		return null;
	}
	let languageId = null;
	if (resource.scheme === Schemas.data) {
		const metadata = DataUri.parseMetaData(resource);
		const mime = metadata.get(DataUri.META_DATA_MIME);
		if (mime) {
			languageId = languageService.getLanguageIdByMimeType(mime);
		}
	} else {
		const model = modelService.getModel(resource);
		if (model) {
			languageId = model.getLanguageId();
		}
	}
	if (languageId && languageId !== PLAINTEXT_LANGUAGE_ID) {
		return languageId;
	}
	return languageService.guessLanguageIdByFilepathOrFirstLine(resource);
}
			const detectedLanguageId = detectLanguageId(modelService, languageService, resource);
			if (detectedLanguageId) {
				classes.push(`${cssEscape(detectedLanguageId)}-lang-file-icon`);
			}