var CodeDataTransfers = {
	EDITORS: 'CodeEditors',
	FILES: 'CodeFiles'
};

class DragAndDropContributionRegistry {}

var Extensions10 = {
	DragAndDropContribution: 'workbench.contributions.dragAndDrop'
};
registry.add(Extensions10.DragAndDropContribution, new DragAndDropContributionRegistry());



		const isDropIntoEnabled = () => {
			return (
				!this._configuration.options.get(
					91 // readOnly
				) &&
				this._configuration.options.get(
					36 // dropIntoEditor
				).enabled
			);
		};

class DragAndDropObserver extends Disposable {
	constructor(element, callbacks) {
		super();
		this.element = element;
		this.callbacks = callbacks;
		this.counter = 0;
		this.dragStartTime = 0;
		this.registerListeners();
	}
	registerListeners() {
		if (this.callbacks.onDragStart) {
			this._register(
				addDisposableListener(this.element, EventType.DRAG_START, e => {
					this.callbacks.onDragStart?.call(this.callbacks, e);
				})
			);
		}
		if (this.callbacks.onDrag) {
			this._register(
				addDisposableListener(this.element, EventType.DRAG, e => {
					this.callbacks.onDrag?.call(this.callbacks, e);
				})
			);
		}
		this._register(
			addDisposableListener(this.element, EventType.DRAG_ENTER, e => {
				this.counter++;
				this.dragStartTime = e.timeStamp;
				this.callbacks.onDragEnter?.call(this.callbacks, e);
			})
		);
		this._register(
			addDisposableListener(this.element, EventType.DRAG_OVER, e => {
				e.preventDefault();
				this.callbacks.onDragOver?.call(this.callbacks, e, e.timeStamp - this.dragStartTime);
			})
		);
		this._register(
			addDisposableListener(this.element, EventType.DRAG_LEAVE, e => {
				this.counter--;
				if (this.counter === 0) {
					this.dragStartTime = 0;
					this.callbacks.onDragLeave?.call(this.callbacks, e);
				}
			})
		);
		this._register(
			addDisposableListener(this.element, EventType.DRAG_END, e => {
				this.counter = 0;
				this.dragStartTime = 0;
				this.callbacks.onDragEnd?.call(this.callbacks, e);
			})
		);
		this._register(
			addDisposableListener(this.element, EventType.DROP, e => {
				this.counter = 0;
				this.dragStartTime = 0;
				this.callbacks.onDrop?.call(this.callbacks, e);
			})
		);
	}
}

		this._register(
			new DragAndDropObserver(this._domElement, {
				onDragOver: e => {
					if (!isDropIntoEnabled()) {
						return;
					}
					const target = this.getTargetAtClientPoint(e.clientX, e.clientY);
					if (target?.position) {
						this.showDropIndicatorAt(target.position);
					}
				},
				onDrop: async e => {
					if (!isDropIntoEnabled()) {
						return;
					}
					this.removeDropIndicator();
					if (!e.dataTransfer) {
						return;
					}
					const target = this.getTargetAtClientPoint(e.clientX, e.clientY);
					if (target?.position) {
						this._onDropIntoEditor.fire({
							position: target.position,
							event: e
						});
					}
				},
				onDragLeave: () => {
					this.removeDropIndicator();
				},
				onDragEnd: () => {
					this.removeDropIndicator();
				}
			})
		);







//CodeEditorWidget

CodeEditorWidget.dropIntoEditorDecorationOptions = ModelDecorationOptions.register({
	description: 'workbench-dnd-target',
	className: 'dnd-target'
});



showDropIndicatorAt(position) {
		const newDecorations = [
			{
				range: new Range(position.lineNumber, position.column, position.lineNumber, position.column),
				options: CodeEditorWidget.dropIntoEditorDecorationOptions
			}
		];
		this._dropIntoEditorDecorations.set(newDecorations);
		this.revealPosition(
			position,
			1 //Immediate
		);
	}
		removeDropIndicator() {
		this._dropIntoEditorDecorations.clear();
	}









class ListViewDragAndDrop {
	constructor(list, dnd) {
		this.list = list;
		this.dnd = dnd;
	}
	getDragElements(element) {
		const selection = this.list.getSelectedElements();
		const elements = selection.indexOf(element) > -1 ? selection : [element];
		return elements;
	}
	getDragURI(element) {
		return this.dnd.getDragURI(element);
	}
	getDragLabel(elements, originalEvent) {
		if (this.dnd.getDragLabel) {
			return this.dnd.getDragLabel(elements, originalEvent);
		}
		return;
	}
	onDragStart(data, originalEvent) {
		this.dnd.onDragStart?.call(this.dnd, data, originalEvent);
	}
	onDragOver(data, targetElement, targetIndex, targetSector, originalEvent) {
		return this.dnd.onDragOver(data, targetElement, targetIndex, targetSector, originalEvent);
	}
	onDragLeave(data, targetElement, targetIndex, originalEvent) {
		this.dnd.onDragLeave?.call(this.dnd, data, targetElement, targetIndex, originalEvent);
	}
	onDragEnd(originalEvent) {
		this.dnd.onDragEnd?.call(this.dnd, originalEvent);
	}
	drop(data, targetElement, targetIndex, targetSector, originalEvent) {
		this.dnd.drop(data, targetElement, targetIndex, targetSector, originalEvent);
	}
	dispose() {
		this.dnd.dispose();
	}
}







	const StaticDND = {
	CurrentDragAndDropData: undefined
};

	class ElementsDragAndDropData {
	constructor(elements) {
		this.elements = elements;
	}
	update() {}
	getData() {
		return this.elements;
	}
}


	class ExternalElementsDragAndDropData {
	constructor(elements) {
		this.elements = elements;
	}
	update() {}
	getData() {
		return this.elements;
	}
}

class NativeDragAndDropData {
	constructor() {
		this.types = [];
		this.files = [];
	}
	update(dataTransfer) {
		if (dataTransfer.types) {
			this.types.splice(0, this.types.length, ...dataTransfer.types);
		}
		if (dataTransfer.files) {
			this.files.splice(0, this.files.length);
			for (let i = 0; i < dataTransfer.files.length; i++) {
				const file = dataTransfer.files.item(i);
				if (file && (file.size || file.type)) {
					this.files.push(file);
				}
			}
		}
	}
	getData() {
		return {
			types: this.types,
			files: this.files
		};
	}
}

//ListView

	toDragEvent(browserEvent) {
		const index = this.getItemIndexFromEventTarget(browserEvent.target || null);
		const item = typeof index === 'undefined' ? undefined : this.items[index];
		const element = item && item.element;
		const sector = this.getTargetSector(browserEvent, index);
		return { browserEvent, index, element, sector };
	}
	onDragStart(element, uri, event) {
		if (event.dataTransfer) {
			const elements = this.dnd.getDragElements(element);
			event.dataTransfer.effectAllowed = 'copyMove';
			event.dataTransfer.setData('text/plain', uri);
			if (event.dataTransfer.setDragImage) {
				let label;
				if (this.dnd.getDragLabel) {
					label = this.dnd.getDragLabel(elements, event);
				}
				if (typeof label === 'undefined') {
					label = String(elements.length);
				}
				const dragImage = createDomElement('.monaco-drag-image');
				dragImage.textContent = label;
				const getDragImageContainer = e => {
					while (e && !e.classList.contains('monaco-workbench')) {
						e = e.parentElement;
					}
					return e || this.domNode.ownerDocument;
				};
				const container = getDragImageContainer(this.domNode);
				container.appendChild(dragImage);
				event.dataTransfer.setDragImage(dragImage, -10, -10);
				setTimeout(() => container.removeChild(dragImage), 0);
			}
			this.domNode.classList.add('dragging');
			this.currentDragData = new ElementsDragAndDropData(elements);
			StaticDND.CurrentDragAndDropData = new ExternalElementsDragAndDropData(elements);
			this.dnd.onDragStart?.call(this.dnd, this.currentDragData, event);
		}
	}
	onDragOver(event) {
		event.browserEvent.preventDefault();
		this.onDragLeaveTimeout.dispose();
		if (StaticDND.CurrentDragAndDropData && StaticDND.CurrentDragAndDropData.getData() === 'vscode-ui') {
			return false;
		}
		this.setupDragAndDropScrollTopAnimation(event.browserEvent);
		if (!event.browserEvent.dataTransfer) {
			return false;
		}
		if (!this.currentDragData) {
			if (StaticDND.CurrentDragAndDropData) {
				this.currentDragData = StaticDND.CurrentDragAndDropData;
			} else {
				if (!event.browserEvent.dataTransfer.types) {
					return false;
				}
				this.currentDragData = new NativeDragAndDropData();
			}
		}
		const result = this.dnd.onDragOver(this.currentDragData, event.element, event.index, event.sector, event.browserEvent);
		this.canDrop = typeof result === 'boolean' ? result : result.accept;
		if (!this.canDrop) {
			this.currentDragFeedback = undefined;
			this.currentDragFeedbackDisposable.dispose();
			return false;
		}
		event.browserEvent.dataTransfer.dropEffect = typeof result !== 'boolean' && result.effect?.type === 0 ? 'copy' : 'move';
		let feedback;
		if (typeof result !== 'boolean' && result.feedback) {
			feedback = result.feedback;
		} else {
			if (typeof event.index === 'undefined') {
				feedback = [-1];
			} else {
				feedback = [event.index];
			}
		}
		feedback = distinct(feedback)
			.filter(i => i >= -1 && i < this.length)
			.sort((a, b) => a - b);
		feedback = feedback[0] === -1 ? [-1] : feedback;
		let dragOverEffectPosition = typeof result !== 'boolean' && result.effect && result.effect.position ? result.effect.position : 'drop-target';

		function _equalsDragFeedback(a, b) {
			return isArray(a) && isArray(b) ? equals(a, b) : a === b;
		}

		if (_equalsDragFeedback(this.currentDragFeedback, feedback) && this.currentDragFeedbackPosition === dragOverEffectPosition) {
			return true;
		}
		this.currentDragFeedback = feedback;
		this.currentDragFeedbackPosition = dragOverEffectPosition;
		this.currentDragFeedbackDisposable.dispose();
		if (feedback[0] === -1) {
			this.domNode.classList.add(dragOverEffectPosition);
			this.rowsContainer.classList.add(dragOverEffectPosition);
			this.currentDragFeedbackDisposable = toDisposable(() => {
				this.domNode.classList.remove(dragOverEffectPosition);
				this.rowsContainer.classList.remove(dragOverEffectPosition);
			});
		} else {
			if (feedback.length > 1 && dragOverEffectPosition !== 'drop-target') {
				throw new Error("Can't use multiple feedbacks with position different than 'over'");
			}
			if (dragOverEffectPosition === 'drop-target-after') {
				if (feedback[0] < this.length - 1) {
					feedback[0] += 1;
					dragOverEffectPosition = 'drop-target-before';
				}
			}
			for (const index of feedback) {
				const item = this.items[index];
				item.dropTarget = true;
				item.row?.domNode.classList.add(dragOverEffectPosition);
			}
			this.currentDragFeedbackDisposable = toDisposable(() => {
				for (const index of feedback) {
					const item = this.items[index];
					item.dropTarget = false;
					item.row?.domNode.classList.remove(dragOverEffectPosition);
				}
			});
		}
		return true;
	}
	onDragLeave(event) {
		this.onDragLeaveTimeout.dispose();
		this.onDragLeaveTimeout = disposableTimeout(() => this.clearDragOverFeedback(), 100, this.disposables);
		if (this.currentDragData) {
			this.dnd.onDragLeave?.call(this.dnd, this.currentDragData, event.element, event.index, event.browserEvent);
		}
	}
	onDrop(event) {
		if (!this.canDrop) {
			return;
		}
		const dragData = this.currentDragData;
		this.teardownDragAndDropScrollTopAnimation();
		this.clearDragOverFeedback();
		this.domNode.classList.remove('dragging');
		this.currentDragData = undefined;
		StaticDND.CurrentDragAndDropData = undefined;
		if (!dragData || !event.browserEvent.dataTransfer) {
			return;
		}
		event.browserEvent.preventDefault();
		dragData.update(event.browserEvent.dataTransfer);
		this.dnd.drop(dragData, event.element, event.index, event.sector, event.browserEvent);
	}
	onDragEnd(event) {
		this.canDrop = false;
		this.teardownDragAndDropScrollTopAnimation();
		this.clearDragOverFeedback();
		this.domNode.classList.remove('dragging');
		this.currentDragData = undefined;
		StaticDND.CurrentDragAndDropData = undefined;
		this.dnd.onDragEnd?.call(this.dnd, event);
	}
	clearDragOverFeedback() {
		this.currentDragFeedback = undefined;
		this.currentDragFeedbackPosition = undefined;
		this.currentDragFeedbackDisposable.dispose();
		this.currentDragFeedbackDisposable = disposableNone;
	}
	// DND scroll top animation
	setupDragAndDropScrollTopAnimation(event) {
		if (!this.dragOverAnimationDisposable) {
			const viewTop = getTopLeftOffset(this.domNode).top;
			this.dragOverAnimationDisposable = animate(getWindow(this.domNode), this.animateDragAndDropScrollTop.bind(this, viewTop));
		}
		this.dragOverAnimationStopDisposable.dispose();
		this.dragOverAnimationStopDisposable = disposableTimeout(
			() => {
				if (this.dragOverAnimationDisposable) {
					this.dragOverAnimationDisposable.dispose();
					this.dragOverAnimationDisposable = undefined;
				}
			},
			1e3,
			this.disposables
		);
		this.dragOverMouseY = event.pageY;
	}
	animateDragAndDropScrollTop(viewTop) {
		if (this.dragOverMouseY === undefined) {
			return;
		}
		const diff = this.dragOverMouseY - viewTop;
		const upperLimit = this.renderHeight - 35;
		if (diff < 35) {
			this.scrollTop += Math.max(-14, Math.floor(0.3 * (diff - 35)));
		} else if (diff > upperLimit) {
			this.scrollTop += Math.min(14, Math.floor(0.3 * (diff - upperLimit)));
		}
	}
	teardownDragAndDropScrollTopAnimation() {
		this.dragOverAnimationStopDisposable.dispose();
		if (this.dragOverAnimationDisposable) {
			this.dragOverAnimationDisposable.dispose();
			this.dragOverAnimationDisposable = undefined;
		}
	}


	//insertItemInDOM
		const uri = this.dnd.getDragURI(item.element);
		item.dragStartDisposable.dispose();
		item.row.domNode.draggable = !!uri;
		if (uri) {
			item.dragStartDisposable = addDisposableListener(item.row.domNode, 'dragstart', event => this.onDragStart(item.element, uri, event));
		}





