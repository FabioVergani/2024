// ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -






// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -







// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


	static createSortPermutation(arr, compareFn) {
		const sortIndices = Array.from(arr.keys()).sort((index1, index2) => compareFn(arr[index1], arr[index2]));
		return new Permutation(sortIndices);
	}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const toSymbolKind = e => {
	switch (e) {
		case 1: //file
			return 0;
		case 2: //Module
			return 1;
		case 3: //Namespace
			return 2;
		case 4: //Package
			return 3;
		case 5: //Class
			return 4;
		case 6: //Method
			return 5;
		case 7: //Property
			return 6;
		case 8: //Field:
			return 7;
		case 9: //Constructor
			return 8;
		case 10: //Enum
			return 9;
		case 11: //Interface
			return 10;
		case 12: //Function
			return 11;
		case 13: //Variable
			return 12;
		case 14: //Constant
			return 13;
		case 15: //String
			return 14;
		case 16: //Number
			return 15;
		case 17: //Boolean
			return 16;
		case 18: //Array
			return 17;
	}
	return 11; //Interface
};

const toDocumentHighlightKind = e => {
	switch (e) {
		case 3:
			return 2; // Write
		case 2:
			return 1; // Read
		case 1:
		default:
			return 0; // Text
	}
};


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



const regexChars2RE = /[\-\\\{\}\+\?\|\^\$\.\,\[\]\(\)\#\s]/g;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


const suggestFilteredTypesMapping = {
	method: 'showMethods',
	function: 'showFunctions',
	constructor: 'showConstructors',
	deprecated: 'showDeprecated',
	field: 'showFields',
	variable: 'showVariables',
	class: 'showClasses',
	struct: 'showStructs',
	interface: 'showInterfaces',
	module: 'showModules',
	property: 'showProperties',
	event: 'showEvents',
	operator: 'showOperators',
	unit: 'showUnits',
	value: 'showValues',
	constant: 'showConstants',
	enum: 'showEnums',
	enumMember: 'showEnumMembers',
	keyword: 'showKeywords',
	text: 'showWords',
	color: 'showColors',
	file: 'showFiles',
	folder: 'showFolders',
	typeParameter: 'showTypeParameters',
	snippet: 'showSnippets'
};



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




const colorId_editorLightBulb_foreground = 'editorLightBulb.foreground';

class EditorLightbulb extends BaseEditorOption {
	constructor() {
		const defaults = {
			enabled: 'on'
		};
		super(65, 'lightbulb', defaults, {
			'editor.lightbulb.enabled': {
				type: 'string',
				tags: ['experimental'],
				enum: [
					'off', //Disable the code action menu.
					'onCode', //Show the code action menu when the cursor is on lines with code.
					'on' //Show the code action menu when the cursor is on lines with code or on empty lines.
				],
				default: defaults.enabled
			}
		});
	}
	validate(e) {
		return e && 'object' === typeof e
			? {
					enabled: stringSet(e.enabled, this.defaultValue.enabled, ['off', 'onCode', 'on'])
				}
			: this.defaultValue;
	}
}

lightbulb: registerEditorOption(new EditorLightbulb()),



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



class PathIterator {
	constructor(_splitOnBackslash = true, _caseSensitive = true) {
		this._splitOnBackslash = _splitOnBackslash;
		this._caseSensitive = _caseSensitive;
	}
	reset(key) {
		this._from = 0;
		this._to = 0;
		this._value = key;
		this._valueLen = key.length;
		for (let pos = key.length - 1; pos >= 0; pos--, this._valueLen--) {
			const ch = this._value.charCodeAt(pos);
			if (!(ch === 47 || (this._splitOnBackslash && ch === 92))) {
				break;
			}
		}
		return this.next();
	}
	hasNext() {
		return this._to < this._valueLen;
	}
	next() {
		this._from = this._to;
		let justSeps = true;
		for (; this._to < this._valueLen; this._to++) {
			const ch = this._value.charCodeAt(this._to);
			if (ch === 47 || (this._splitOnBackslash && ch === 92)) {
				if (justSeps) {
					this._from++;
				} else {
					break;
				}
			} else {
				justSeps = false;
			}
		}
		return this;
	}
	cmp(a) {
		return this._caseSensitive ? compareSubstring(a, this._value, 0, a.length, this._from, this._to) : compareSubstringIgnoreCase(a, this._value, 0, a.length, this._from, this._to);
	}
	value() {
		return this._value.substring(this._from, this._to);
	}
}


class UriIterator {
	constructor(_ignorePathCasing, _ignoreQueryAndFragment) {
		this._ignorePathCasing = _ignorePathCasing;
		this._ignoreQueryAndFragment = _ignoreQueryAndFragment;
		this._states = [];
		this._stateIdx = 0;
	}
	reset(key) {
		this._value = key;
		this._states = [];
		if (this._value.scheme) {
			this._states.push(
				1 //UriIteratorState.Scheme
			);
		}
		if (this._value.authority) {
			this._states.push(
				2 //UriIteratorState.Authority
			);
		}
		if (this._value.path) {
			this._pathIterator = new PathIterator(false, !this._ignorePathCasing(key));
			this._pathIterator.reset(key.path);
			if (this._pathIterator.value()) {
				this._states.push(
					3 //UriIteratorState.Path
				);
			}
		}
		if (!this._ignoreQueryAndFragment(key)) {
			if (this._value.query) {
				this._states.push(
					4 //UriIteratorState.Query
				);
			}
			if (this._value.fragment) {
				this._states.push(
					5 //UriIteratorState.Fragment
				);
			}
		}
		this._stateIdx = 0;
		return this;
	}
	next() {
		if (this._states[this._stateIdx] === 3 && this._pathIterator.hasNext()) {
			this._pathIterator.next();
		} else {
			this._stateIdx += 1;
		}
		return this;
	}
	hasNext() {
		return (this._states[this._stateIdx] === 3 && this._pathIterator.hasNext()) || this._stateIdx < this._states.length - 1;
	}
	cmp(a) {
		if (this._states[this._stateIdx] === 1) {
			return compareIgnoreCase(a, this._value.scheme);
		} else if (this._states[this._stateIdx] === 2) {
			return compareIgnoreCase(a, this._value.authority);
		} else if (this._states[this._stateIdx] === 3) {
			return this._pathIterator.cmp(a);
		} else if (this._states[this._stateIdx] === 4) {
			return compare(a, this._value.query);
		} else if (this._states[this._stateIdx] === 5) {
			return compare(a, this._value.fragment);
		}
		throw new Error();
	}
	value() {
		if (this._states[this._stateIdx] === 1) {
			return this._value.scheme;
		} else if (this._states[this._stateIdx] === 2) {
			return this._value.authority;
		} else if (this._states[this._stateIdx] === 3) {
			return this._pathIterator.value();
		} else if (this._states[this._stateIdx] === 4) {
			return this._value.query;
		} else if (this._states[this._stateIdx] === 5) {
			return this._value.fragment;
		}
		throw new Error();
	}
}
//TernarySearchTree
	static forUris(ignorePathCasing = () => false, ignoreQueryAndFragment = () => false) {
		return new TernarySearchTree(new UriIterator(ignorePathCasing, ignoreQueryAndFragment));
	}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function toMultilineTokens2(tokens, styling, languageId) {
	const srcData = tokens.data;
	const tokenCount = (tokens.data.length / 5) | 0;
	const tokensPerArea = Math.max(
		Math.ceil(
			tokenCount / 1024 //SemanticColoringConstants.DesiredMaxAreas
		),
		400 //DesiredTokensPerArea
	);
	const result = [];
	let tokenIndex = 0;
	let lastLineNumber = 1;
	let lastStartCharacter = 0;
	while (tokenIndex < tokenCount) {
		const tokenStartIndex = tokenIndex;
		let tokenEndIndex = Math.min(tokenStartIndex + tokensPerArea, tokenCount);
		if (tokenEndIndex < tokenCount) {
			let smallTokenEndIndex = tokenEndIndex;
			while (smallTokenEndIndex - 1 > tokenStartIndex && srcData[5 * smallTokenEndIndex] === 0) {
				smallTokenEndIndex--;
			}
			if (smallTokenEndIndex - 1 === tokenStartIndex) {
				let bigTokenEndIndex = tokenEndIndex;
				while (bigTokenEndIndex + 1 < tokenCount && srcData[5 * bigTokenEndIndex] === 0) {
					bigTokenEndIndex++;
				}
				tokenEndIndex = bigTokenEndIndex;
			} else {
				tokenEndIndex = smallTokenEndIndex;
			}
		}
		let destData = new Uint32Array((tokenEndIndex - tokenStartIndex) * 4);
		let destOffset = 0;
		let areaLine = 0;
		let prevLineNumber = 0;
		let prevEndCharacter = 0;
		while (tokenIndex < tokenEndIndex) {
			const srcOffset = 5 * tokenIndex;
			const deltaLine = srcData[srcOffset];
			const deltaCharacter = srcData[srcOffset + 1];
			const lineNumber = (lastLineNumber + deltaLine) | 0;
			const startCharacter = deltaLine === 0 ? (lastStartCharacter + deltaCharacter) | 0 : deltaCharacter;
			const length = srcData[srcOffset + 2];
			const endCharacter = (startCharacter + length) | 0;
			const tokenTypeIndex = srcData[srcOffset + 3];
			const tokenModifierSet = srcData[srcOffset + 4];
			if (endCharacter <= startCharacter) {
				styling.warnInvalidLengthSemanticTokens(lineNumber, startCharacter + 1);
			} else if (prevLineNumber === lineNumber && prevEndCharacter > startCharacter) {
				styling.warnOverlappingSemanticTokens(lineNumber, startCharacter + 1);
			} else {
				const metadata = styling.getMetadata(tokenTypeIndex, tokenModifierSet, languageId);
				if (metadata !== 2147483647) {
					if (areaLine === 0) {
						areaLine = lineNumber;
					}
					destData[destOffset] = lineNumber - areaLine;
					destData[destOffset + 1] = startCharacter;
					destData[destOffset + 2] = endCharacter;
					destData[destOffset + 3] = metadata;
					destOffset += 4;
					prevLineNumber = lineNumber;
					prevEndCharacter = endCharacter;
				}
			}
			lastLineNumber = lineNumber;
			lastStartCharacter = startCharacter;
			tokenIndex++;
		}
		if (destOffset !== destData.length) {
			destData = destData.subarray(0, destOffset);
		}
		const tokens2 = SparseMultilineTokens.create(areaLine, destData);
		result.push(tokens2);
	}
	return result;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


function createElement(options2) {
	const tagName = options2.inline ? 'span' : 'div';
	const element = document.createElement(tagName);
	if (options2.className) {
		element.className = options2.className;
	}
	return element;
}



function _renderFormattedText(element, treeNode, actionHandler, renderCodeSegments) {
	let child;
	if (treeNode.type === 2) {
		child = document.createTextNode(treeNode.content || '');
	} else if (treeNode.type === 3) {
		child = document.createElement('b');
	} else if (treeNode.type === 4) {
		child = document.createElement('i');
	} else if (treeNode.type === 7 && renderCodeSegments) {
		child = document.createElement('code');
	} else if (treeNode.type === 5 && actionHandler) {
		const a = document.createElement('a');
		actionHandler.disposables.add(
			addStandardDisposableListener(a, 'click', event => {
				actionHandler.callback(String(treeNode.index), event);
			})
		);
		child = a;
	} else if (treeNode.type === 8) {
		child = document.createElement('br');
	} else if (treeNode.type === 1) {
		child = element;
	}
	if (child && element !== child) {
		element.appendChild(child);
	}
	if (child && isArray(treeNode.children)) {
		treeNode.children.forEach(nodeChild => {
			_renderFormattedText(child, nodeChild, actionHandler, renderCodeSegments);
		});
	}
}

class StringStream {
	constructor(source) {
		this.source = source;
		this.index = 0;
	}
	eos() {
		return this.index >= this.source.length;
	}
	next() {
		const next = this.peek();
		this.advance();
		return next;
	}
	peek() {
		return this.source[this.index];
	}
	advance() {
		this.index++;
	}
}

function formatTagType(char, supportCodeSegments) {
	switch (char) {
		case '*':
			return 3;
		case '_':
			return 4;
		case '[':
			return 5;
		case ']':
			return 6;
		case '`':
			return supportCodeSegments ? 7 : 0;
		default:
			return 0;
	}
}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function extractSelection(uri) {
	let selection = undefined;
	const match2 = /^L?(\d+)(?:,(\d+))?(-L?(\d+)(?:,(\d+))?)?/.exec(uri.fragment);
	if (match2) {
		selection = {
			startLineNumber: parseInt(match2[1]),
			startColumn: match2[2] ? parseInt(match2[2]) : 1,
			endLineNumber: match2[4] ? parseInt(match2[4]) : undefined,
			endColumn: match2[4] ? (match2[5] ? parseInt(match2[5]) : 1) : undefined
		};
		uri = uri.with({ fragment: '' });
	}
	return { selection, uri };
}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function renderText(text2, options2 = {}) {
	const element = createElement(options2);
	element.textContent = text2;
	return element;
}

function renderFormattedText(formattedText, options2 = {}) {
	const element = createElement(options2);


		function _parseFormattedText(content, parseCodeSegments) {
			const root = {
				type: 1,
				children: []
			};
			let actionViewItemIndex = 0;
			let current = root;
			const stack = [];
			const stream = new StringStream(content);
			while (!stream.eos()) {
				let next = stream.next();
				const isEscapedFormatType = next === '\\' && formatTagType(stream.peek(), parseCodeSegments) !== 0;
				if (isEscapedFormatType) {
					next = stream.next();
				}

				function _isFormatTag(char, supportCodeSegments) {
			return formatTagType(char, supportCodeSegments) !== 0;
		}

				if (!isEscapedFormatType && _isFormatTag(next, parseCodeSegments) && next === stream.peek()) {
					stream.advance();
					if (current.type === 2) {
						current = stack.pop();
					}
					const type = formatTagType(next, parseCodeSegments);
					if (current.type === type || (current.type === 5 && type === 6)) {
						current = stack.pop();
					} else {
						const newCurrent = {
							type,
							children: []
						};
						if (type === 5) {
							newCurrent.index = actionViewItemIndex;
							actionViewItemIndex++;
						}
						current.children.push(newCurrent);
						stack.push(current);
						current = newCurrent;
					}
				} else if (next === '\n') {
					if (current.type === 2) {
						current = stack.pop();
					}
					current.children.push({
						type: 8 //FormatType.NewLine
					});
				} else {
					if (current.type !== 2) {
						const textCurrent = {
							type: 2,
							content: next
						};
						current.children.push(textCurrent);
						stack.push(current);
						current = textCurrent;
					} else {
						current.content += next;
					}
				}
			}
			if (current.type === 2) {
				current = stack.pop();
			}
			if (stack.length) {
			}
			return root;
		}

	_renderFormattedText(element, _parseFormattedText(formattedText, !!options2.renderCodeSegments), options2.actionHandler, options2.renderCodeSegments);
	return element;
}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function matchesWords(word, target, contiguous = false) {
	if (!target || target.length === 0) {
		return null;
	}
	let result = null;
	let targetIndex = 0;
	word = word.toLowerCase();
	target = target.toLowerCase();
	while (targetIndex < target.length) {
		result = _matchesWords(word, target, 0, targetIndex, contiguous);
		if (result !== null) {
			break;
		}
		targetIndex = nextWord(target, targetIndex + 1);
	}
	return result;
}

function matchesFuzzy(word, wordToMatchAgainst, enableSeparateSubstringMatching = false) {
	if (typeof word !== 'string' || typeof wordToMatchAgainst !== 'string') {
		return null;
	}
	let regexp = fuzzyRegExpCache.get(word);
	if (!regexp) {
		regexp = new RegExp(word.replace(regexChars2RE, escapeReplacement).replace(wildcard2RE, '.*'), 'i');
		fuzzyRegExpCache.set(word, regexp);
	}
	const match2 = regexp.exec(wordToMatchAgainst);
	if (match2) {
		return [{ start: match2.index, end: match2.index + match2[0].length }];
	}
	return enableSeparateSubstringMatching ? fuzzySeparateFilter(word, wordToMatchAgainst) : fuzzyContiguousFilter(word, wordToMatchAgainst);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



function printTable(table, pattern, patternLen, word, wordLen) {
	function pad(s, n, pad2 = ' ') {
		while (s.length < n) {
			s = pad2 + s;
		}
		return s;
	}
	let ret = ` |   |${word
		.split('')
		.map(c => pad(c, 3))
		.join('|')}
`;
	for (let i = 0; i <= patternLen; i++) {
		if (i === 0) {
			ret += ' |';
		} else {
			ret += `${pattern[i - 1]}|`;
		}
		ret +=
			table[i]
				.slice(0, wordLen + 1)
				.map(n => pad(n.toString(), 3))
				.join('|') + '\n';
	}
	return ret;
}

function printTables(pattern, patternStart, word, wordStart) {
	pattern = pattern.substr(patternStart);
	word = word.substr(wordStart);
	console.log(printTable(_table, pattern, pattern.length, word, word.length));
	console.log(printTable(_arrows, pattern, pattern.length, word, word.length));
	console.log(printTable(_diag, pattern, pattern.length, word, word.length));
}



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const escapeIconsRegex = new RegExp(`(\\\\)?${iconsRegex.source}`, 'g');


const _parseIcons_RE = new RegExp(`\\$\\(${exp_editorIconChars}+\\)`, 'g');

function escapeIcons(text2) {
	return text2.replace(escapeIconsRegex, (match2, escaped) => (escaped ? match2 : `\\${match2}`));
}

function parseLabelWithIcons(input) {
	_parseIcons_RE.lastIndex = 0;
	let text2 = '';
	const iconOffsets = [];
	let iconsOffset = 0;
	while (true) {
		const pos = _parseIcons_RE.lastIndex;
		const match2 = _parseIcons_RE.exec(input);
		const chars = input.substring(pos, match2?.index);
		if (chars.length > 0) {
			text2 += chars;
			for (let i = 0; i < chars.length; i++) {
				iconOffsets.push(iconsOffset);
			}
		}
		if (!match2) {
			break;
		}
		iconsOffset += match2[0].length;
	}
	return { text: text2, iconOffsets };
}

function matchesFuzzyIconAware(query, target, enableSeparateSubstringMatching = false) {
	const { text: text2, iconOffsets } = target;
	if (!iconOffsets || iconOffsets.length === 0) {
		return matchesFuzzy(query, text2, enableSeparateSubstringMatching);
	}
	const wordToMatchAgainstWithoutIconsTrimmed = trimsTrailingOccurrencesFromStart(text2, ' ');
	const leadingWhitespaceOffset = text2.length - wordToMatchAgainstWithoutIconsTrimmed.length;
	const matches = matchesFuzzy(query, wordToMatchAgainstWithoutIconsTrimmed, enableSeparateSubstringMatching);
	if (matches) {
		for (const match2 of matches) {
			const iconOffset = iconOffsets[match2.start + leadingWhitespaceOffset] + leadingWhitespaceOffset;
			match2.start += iconOffset;
			match2.end += iconOffset;
		}
	}
	return matches;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


function renderText(text2, options2 = {}) {
	const element = createElement(options2);
	element.textContent = text2;
	return element;
}



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



function or(...filter) {
	return function (word, wordToMatchAgainst) {
		for (let i = 0, len = filter.length; i < len; i++) {
			const match2 = filter[i](word, wordToMatchAgainst);
			if (match2) {
				return match2;
			}
		}
		return null;
	};
}


function matchesContiguousSubString(word, wordToMatchAgainst) {
	const index = wordToMatchAgainst.toLowerCase().indexOf(word.toLowerCase());
	if (index === -1) {
		return null;
	}
	return [{ start: index, end: index + word.length }];
}



function matchesSubString(word, wordToMatchAgainst) {
	return _matchesSubString(word.toLowerCase(), wordToMatchAgainst.toLowerCase(), 0, 0);
}

function analyzeCamelCaseWord(word) {
	let upper = 0,
		lower = 0,
		alpha = 0,
		numeric = 0,
		code = 0;
	for (let i = 0; i < word.length; i++) {
		code = word.charCodeAt(i);
		if (isUpper(code)) {
			upper++;
		}
		if (isLower(code)) {
			lower++;
		}
		if (isAlphanumeric(code)) {
			alpha++;
		}
		if (isNumber2(code)) {
			numeric++;
		}
	}
	const upperPercent = upper / word.length;
	const lowerPercent = lower / word.length;
	const alphaPercent = alpha / word.length;
	const numericPercent = numeric / word.length;
	return { upperPercent, lowerPercent, alphaPercent, numericPercent };
}
function isUpperCaseWord(analysis) {
	const { upperPercent, lowerPercent } = analysis;
	return lowerPercent === 0 && upperPercent > 0.6;
}
function isCamelCaseWord(analysis) {
	const { upperPercent, lowerPercent, alphaPercent, numericPercent } = analysis;
	return lowerPercent > 0.2 && upperPercent < 0.8 && alphaPercent > 0.6 && numericPercent < 0.2;
}
function isCamelCasePattern(word) {
	let upper = 0,
		lower = 0,
		code = 0,
		whitespace = 0;
	for (let i = 0; i < word.length; i++) {
		code = word.charCodeAt(i);
		if (isUpper(code)) {
			upper++;
		}
		if (isLower(code)) {
			lower++;
		}
		if (isWhitespace(code)) {
			whitespace++;
		}
	}
	if ((upper === 0 || lower === 0) && whitespace === 0) {
		return word.length <= 30;
	} else {
		return upper <= 5;
	}
}

function matchesCamelCase(word, camelCaseWord) {
	if (!camelCaseWord) {
		return null;
	}
	camelCaseWord = camelCaseWord.trim();
	if (camelCaseWord.length === 0) {
		return null;
	}
	if (!isCamelCasePattern(word)) {
		return null;
	}
	if (camelCaseWord.length > 60) {
		camelCaseWord = camelCaseWord.substring(0, 60);
	}
	const analysis = analyzeCamelCaseWord(camelCaseWord);
	if (!isCamelCaseWord(analysis)) {
		if (!isUpperCaseWord(analysis)) {
			return null;
		}
		camelCaseWord = camelCaseWord.toLowerCase();
	}
	let result = null;
	let i = 0;
	word = word.toLowerCase();
	while (i < camelCaseWord.length && (result = _matchesCamelCase(word, camelCaseWord, 0, i)) === null) {
		i = nextAnchor(camelCaseWord, i + 1);
	}
	return result;
}

function matchesWords(word, target, contiguous = false) {
	if (!target || target.length === 0) {
		return null;
	}
	let result = null;
	let targetIndex = 0;
	word = word.toLowerCase();
	target = target.toLowerCase();
	while (targetIndex < target.length) {
		result = _matchesWords(word, target, 0, targetIndex, contiguous);
		if (result !== null) {
			break;
		}
		targetIndex = nextWord(target, targetIndex + 1);
	}
	return result;
}
const fuzzySeparateFilter = or(matchesPrefix, matchesCamelCase, matchesSubString);
const fuzzyContiguousFilter = or(matchesPrefix, matchesCamelCase, matchesContiguousSubString);


function matchesFuzzy(word, wordToMatchAgainst, enableSeparateSubstringMatching = false) {
	if (typeof word !== 'string' || typeof wordToMatchAgainst !== 'string') {
		return null;
	}
	let regexp = fuzzyRegExpCache.get(word);
	if (!regexp) {
		regexp = new RegExp(word.replace(regexChars2RE, escapeReplacement).replace(wildcard2RE, '.*'), 'i');
		fuzzyRegExpCache.set(word, regexp);
	}
	const match2 = regexp.exec(wordToMatchAgainst);
	if (match2) {
		return [{ start: match2.index, end: match2.index + match2[0].length }];
	}
	return enableSeparateSubstringMatching
		? fuzzySeparateFilter(word, wordToMatchAgainst)
		: fuzzyContiguousFilter(word, wordToMatchAgainst);
}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


function printTable(table, pattern, patternLen, word, wordLen) {
	function pad(s, n, pad2 = ' ') {
		while (s.length < n) {
			s = pad2 + s;
		}
		return s;
	}
	let ret = ` |   |${word
		.split('')
		.map(c => pad(c, 3))
		.join('|')}
`;
	for (let i = 0; i <= patternLen; i++) {
		if (i === 0) {
			ret += ' |';
		} else {
			ret += `${pattern[i - 1]}|`;
		}
		ret +=
			table[i]
				.slice(0, wordLen + 1)
				.map(n => pad(n.toString(), 3))
				.join('|') + '\n';
	}
	return ret;
}

function printTables(pattern, patternStart, word, wordStart) {
	pattern = pattern.substr(patternStart);
	word = word.substr(wordStart);
	console.log(printTable(_table, pattern, pattern.length, word, word.length));
	console.log(printTable(_arrows, pattern, pattern.length, word, word.length));
	console.log(printTable(_diag, pattern, pattern.length, word, word.length));
}



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -





function __parse2(src, opt, callback) {
	if (typeof src === 'undefined' || src === null) {
		throw new Error('marked(): input parameter is undefined or null');
	}
	if (typeof src !== 'string') {
		throw new Error('marked(): input parameter is of type ' + toString.call(src) + ', string expected');
	}
	if (typeof opt === 'function') {
		callback = opt;
		opt = null;
	}
	opt = _merge({}, editorDefaults, opt || {});
	if (callback) {
		var highlight = opt.highlight;
		var tokens;
		try {
			tokens = Lexer.lex(src, opt);
		} catch (e) {
			return callback(e);
		}
		var done = function done2(err) {
			var out;
			if (!err) {
				try {
					if (opt.walkTokens) {
						walkTokens(tokens, opt.walkTokens);
					}
					out = Parser3.parse(tokens, opt);
				} catch (e) {
					err = e;
				}
			}
			opt.highlight = highlight;
			return err ? callback(err) : callback(null, out);
		};
		if (!highlight || highlight.length < 3) {
			return done();
		}
		delete opt.highlight;
		if (!tokens.length) return done();
		var pending = 0;
		walkTokens(tokens, function (token) {
			if (token.type === 'code') {
				pending++;
				setTimeout(function () {
					highlight(token.text, token.lang, function (err, code) {
						if (err) {
							return done(err);
						}
						if (code != null && code !== token.text) {
							token.text = code;
							token.escaped = true;
						}
						pending--;
						if (pending === 0) {
							done();
						}
					});
				}, 0);
			}
		});
		if (pending === 0) {
			done();
		}
		return;
	}
	function onError(e) {
		e.message += '\nPlease report this to https://github.com/markedjs/marked.';
		if (opt.silent) {
			return '<p>An error occurred:</p><pre>' + _escape(e.message + '', true) + '</pre>';
		}
		throw e;
	}
	try {
		var _tokens = Lexer.lex(src, opt);
		if (opt.walkTokens) {
			if (opt.async) {
				return Promise.all(walkTokens(_tokens, opt.walkTokens))
					.then(function () {
						return Parser3.parse(_tokens, opt);
					})
					['catch'](onError);
			}
			walkTokens(_tokens, opt.walkTokens);
		}
		return Parser3.parse(_tokens, opt);
	} catch (e) {
		onError(e);
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
function parseInline(src, opt) {
	if (typeof src === 'undefined' || src === null) {
		throw new Error('marked.parseInline(): input parameter is undefined or null');
	}
	if (typeof src !== 'string') {
		throw new Error('marked.parseInline(): input parameter is of type ' + toString.call(src) + ', string expected');
	}
	opt = _merge({}, editorDefaults, opt || {});
	_checkSanitizeDeprecation(opt);
	try {
		var tokens = Lexer.lexInline(src, opt);
		if (opt.walkTokens) {
			walkTokens(tokens, opt.walkTokens);
		}
		return Parser3.parseInline(tokens, opt);
	} catch (e) {
		e.message += '\nPlease report this to https://github.com/markedjs/marked.';
		if (opt.silent) {
			return '<p>An error occurred:</p><pre>' + _escape(e.message + '', true) + '</pre>';
		}
		throw e;
	}
}
const lexer = Lexer.lex;


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
const setOptions = opt => {
	_merge(editorDefaults, opt);
	changeDefaults(editorDefaults);
	return parse2;
};
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class EditOperation {
	static insert(position, text2) {
		return {
			range: new Range(position.lineNumber, position.column, position.lineNumber, position.column),
			text: text2,
			forceMoveMarkers: true
		};
	}
	static delete(range2) {
		return {
			range: range2,
			text: null
		};
	}


}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


function printWhenExplanation(when) {
	if (!when) {
		return `no when condition`;
	}
	return `${when.serialize()}`;
}

function printSourceExplanation(kb) {
	return kb.extensionId
		? kb.isBuiltinExtension
			? `built-in extension ${kb.extensionId}`
			: `user extension ${kb.extensionId}`
		: kb.isDefault
			? `built-in`
			: `user`;
}


const HIGH_FREQ_COMMANDS = /^(cursor|delete|undo|redo|tab|editor\.action\.clipboard)/;



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



function isListElementDescendantOfClass(e, className) {
	if (e.classList.contains(className)) {
		return true;
	}
	if (e.classList.contains('monaco-list')) {
		return false;
	}
	if (!e.parentElement) {
		return false;
	}
	return isListElementDescendantOfClass(e.parentElement, className);
}

function isMonacoEditor(e) {
	return isListElementDescendantOfClass(e, 'monaco-editor');
}
function isMonacoCustomToggle(e) {
	return isListElementDescendantOfClass(e, 'monaco-custom-toggle');
}

function isActionItem(e) {
	return isListElementDescendantOfClass(e, 'action-item');
}
function isStickyScrollElement(e) {
	return isListElementDescendantOfClass(e, 'monaco-tree-sticky-row');
}
function isStickyScrollContainer(e) {
	return e.classList.contains('monaco-tree-sticky-container');
}




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const unthemedButtonStyles = {
	buttonBackground: '#0E639C',
	buttonHoverBackground: '#006BB3',
	buttonSeparator: colorWhite.toString(),
	buttonForeground: colorWhite.toString(),
	buttonBorder: undefined,
	buttonSecondaryBackground: undefined,
	buttonSecondaryForeground: undefined,
	buttonSecondaryHoverBackground: undefined
};

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




function appendRemoveOnDispose(parent, child) {
	parent.appendChild(child);
	return toDisposable(() => {
		parent.removeChild(child);
	});
}


function animatedObservable(targetWindow, base, store) {
	let targetVal = base.get();
	let startVal = targetVal;
	let curVal = targetVal;
	const result = observableValue('animatedValue', targetVal);
	let animationStartMs = -1;
	const durationMs = 300;
	let animationFrame = undefined;
	store.add(
		autorunHandleChanges(
			{
				createEmptyChangeSummary: () => ({ animate: false }),
				handleChange: (ctx, s) => {
					if (ctx.didChange(base)) {
						s.animate = s.animate || ctx.change;
					}
					return true;
				}
			},
			(reader, s) => {
				if (animationFrame !== undefined) {
					targetWindow.cancelAnimationFrame(animationFrame);
					animationFrame = undefined;
				}
				startVal = curVal;
				targetVal = base.read(reader);
				animationStartMs = Date.now() - (s.animate ? 0 : durationMs);
				update();
			}
		)
	);
	function update() {
		const passedMs = Date.now() - animationStartMs;
		function _easeOutExpo(t, b, c, d) {
			return t === d ? b + c : c * (-Math.pow(2, (-10 * t) / d) + 1) + b;
		}

		curVal = Math.floor(_easeOutExpo(passedMs, startVal, targetVal - startVal, durationMs));
		if (passedMs < durationMs) {
			animationFrame = targetWindow.requestAnimationFrame(update);
		} else {
			curVal = targetVal;
		}
		result.set(curVal, undefined);
	}
	return result;
}


function translatePosition(posInOriginal, mappings) {
	const mapping = findLast(mappings, m => m.original.startLineNumber <= posInOriginal.lineNumber);
	if (!mapping) {
		return Range.fromPositions(posInOriginal);
	}
	if (mapping.original.endLineNumberExclusive <= posInOriginal.lineNumber) {
		const newLineNumber = posInOriginal.lineNumber - mapping.original.endLineNumberExclusive + mapping.modified.endLineNumberExclusive;
		return Range.fromPositions(new Position(newLineNumber, posInOriginal.column));
	}
	if (!mapping.innerChanges) {
		return Range.fromPositions(new Position(mapping.modified.startLineNumber, 1));
	}
	const innerMapping = findLast(mapping.innerChanges, m => m.originalRange.getStartPosition().isBeforeOrEqual(posInOriginal));
	if (!innerMapping) {
		const newLineNumber = posInOriginal.lineNumber - mapping.original.startLineNumber + mapping.modified.startLineNumber;
		return Range.fromPositions(new Position(newLineNumber, posInOriginal.column));
	}
	if (innerMapping.originalRange.containsPosition(posInOriginal)) {
		return innerMapping.modifiedRange;
	} else {
		function _lengthBetweenPositions(position1, position2) {
			if (position1.lineNumber === position2.lineNumber) {
				return new TextLength(0, position2.column - position1.column);
			} else {
				return new TextLength(position2.lineNumber - position1.lineNumber, position2.column - 1);
			}
		}
		const l = _lengthBetweenPositions(innerMapping.originalRange.getEndPosition(), posInOriginal);
		return Range.fromPositions(l.addToPosition(innerMapping.modifiedRange.getEndPosition()));
	}
}

function bindContextKey(key, service, computeValue) {
	const boundKey = key.bindTo(service);
	return autorunOpts({ debugName: () => `Set Context Key "${key.key}"` }, reader => {
		boundKey.set(computeValue(reader));
	});
}


class ObservableElementSizeObserver extends Disposable {
	get width() {
		return this._width;
	}
	get height() {
		return this._height;
	}
	constructor(element, dimension) {
		super();
		this.elementSizeObserver = this._register(new ElementSizeObserver(element, dimension));
		this._width = observableValue(this, this.elementSizeObserver.getWidth());
		this._height = observableValue(this, this.elementSizeObserver.getHeight());
		this._register(
			this.elementSizeObserver.onDidChange(e =>
				transaction(tx => {
					this._width.set(this.elementSizeObserver.getWidth(), tx);
					this._height.set(this.elementSizeObserver.getHeight(), tx);
				})
			)
		);
	}
	observe(dimension) {
		this.elementSizeObserver.observe(dimension);
	}
	setAutomaticLayout(automaticLayout) {
		if (automaticLayout) {
			this.elementSizeObserver.startObserving();
		} else {
			this.elementSizeObserver.stopObserving();
		}
	}
}



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



class DisposableCancellationTokenSource extends CancellationTokenSource {
	dispose() {
		super.dispose(true);
	}
}



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


const registerSignatureHelpProvider = (languageSelector, provider) => {
	return getService_LanguageFeatures().signatureHelpProvider.register(languageSelector, provider);
};

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -






const isBoolean = e => true === e || false === e;

const isObjectLiteral = e => e !== null && 'object' === typeof e;

const isObjectString = e => '[object String]' === toString.call(e);
const isObjectNumber = e => '[object Number]' === toString.call(e);
const isObjectFunction = e => '[object Function]' === toString.call(e);

const uinteger_MAX = 2147483647;



const isInteger = e => isObjectNumber(e) && -2147483648 <= e && e <= uinteger_MAX;
const isUinteger = e => isObjectNumber(e) && 0 <= e && e <= uinteger_MAX;



const isNumberInRange = (e, min, max) => isObjectNumber(e) && min <= e && e <= max;



const isTypedArrayCheck = (e, check) => isArray(e) && e.every(check);


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




const createPosition0 = (line, character) => {
	return {
		line: Number.MAX_VALUE === line ? uinteger_MAX : line,
		character: Number.MAX_VALUE === character ? uinteger_MAX : character
	};
};


const isValidPosition0 = e => isObjectLiteral(e) && isUinteger(e.line) && isUinteger(e.character);


const createRange0 = (one, two, three, four) => {
	if (isUinteger(one) && isUinteger(two) && isUinteger(three) && isUinteger(four)) {
		return {
			start: createPosition0(one, two),
			end: createPosition0(three, four)
		};
	} else if (isValidPosition0(one) && isValidPosition0(two)) {
		return { start: one, end: two };
	} else {
		throw new Error({ one, two, three, four });
	}
};

const isValidRange0 = e => isObjectLiteral(e) && isValidPosition(e.start) && isValidPosition(e.end);





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class CssDocumentLinkAdapter {
	constructor(_worker) {
		this._worker = _worker;
	}
	provideLinks(model, token) {
		const resource = model.uri;
		return this._worker(resource)
			.then(worker2 => worker2.findDocumentLinks(resource.toString()))
			.then(items => {
				if (!items) {
					return;
				}
				return {
					links: items.map(item => ({
						range: toRange(item.range),
						url: item.target
					}))
				};
			});
	}
}



class CssDocumentRangeFormattingEditProvider {
	constructor(_worker) {
		this._worker = _worker;
		this.canFormatMultipleRanges = false;
	}
	provideDocumentRangeFormattingEdits(model, range2, options2, token) {
		const resource = model.uri;
		return this._worker(resource).then(worker2 => {
			return worker2
				.format(resource.toString(), fromRange0(range2), { tabSize: options2.tabSize, insertSpaces: options2.insertSpaces })
				.then(edits => {
					if (!edits || edits.length === 0) {
						return;
					}
					return edits.map(toTextEdit);
				});
		});
	}
}












// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

var KnownSnippetVariableNames = freeze({
	CURRENT_YEAR: true,
	CURRENT_YEAR_SHORT: true,
	CURRENT_MONTH: true,
	CURRENT_DATE: true,
	CURRENT_HOUR: true,
	CURRENT_MINUTE: true,
	CURRENT_SECOND: true,
	CURRENT_DAY_NAME: true,
	CURRENT_DAY_NAME_SHORT: true,
	CURRENT_MONTH_NAME: true,
	CURRENT_MONTH_NAME_SHORT: true,
	CURRENT_SECONDS_UNIX: true,
	CURRENT_TIMEZONE_OFFSET: true,
	SELECTION: true,
	CLIPBOARD: true,
	TM_SELECTED_TEXT: true,
	TM_CURRENT_LINE: true,
	TM_CURRENT_WORD: true,
	TM_LINE_INDEX: true,
	TM_LINE_NUMBER: true,
	TM_FILENAME: true,
	TM_FILENAME_BASE: true,
	TM_DIRECTORY: true,
	TM_FILEPATH: true,
	CURSOR_INDEX: true,
	// 0-offset
	CURSOR_NUMBER: true,
	// 1-offset
	RELATIVE_FILEPATH: true,
	BLOCK_COMMENT_START: true,
	BLOCK_COMMENT_END: true,
	LINE_COMMENT: true,
	WORKSPACE_NAME: true,
	WORKSPACE_FOLDER: true,
	RANDOM: true,
	RANDOM_HEX: true,
	UUID: true
});

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


class LineContext {
	constructor(leadingLineContent, characterCountDelta) {
		this.leadingLineContent = leadingLineContent;
		this.characterCountDelta = characterCountDelta;
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


class BackwardsCompatibleRegExp {
	constructor(_pattern, _flags) {
		this._pattern = _pattern;
		this._flags = _flags;
		this._actual = null;
		this._evaluated = false;
	}
	get() {
		if (!this._evaluated) {
			this._evaluated = true;
			try {
				this._actual = new RegExp(this._pattern, this._flags);
			} catch (err) {}
		}
		return this._actual;
	}
	isSupported() {
		return this.get() !== null;
	}
}

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

var _SELECTION_HIGHLIGHT_OPTIONS = ModelDecorationOptions.register({
	description: 'selection-highlight-overview',
	stickiness: 1,
	className: 'selectionHighlight',
	overviewRuler: {
		color: { id: colorId_overviewRuler_selectionHighlight_foreground },
		position: OverviewRulerLane2.Center
	},
	minimap: {
		color: { id: colorId_minimap_highlight_selectionOccurrence },
		position: 1
		// Inline
	}
});
var _SELECTION_HIGHLIGHT_OPTIONS_NO_OVERVIEW = ModelDecorationOptions.register({
	description: 'selection-highlight',
	stickiness: 1,
	className: 'selectionHighlight'
});

function getSelectionHighlightDecorationOptions(hasSemanticHighlights) {
	return hasSemanticHighlights ? _SELECTION_HIGHLIGHT_OPTIONS_NO_OVERVIEW : _SELECTION_HIGHLIGHT_OPTIONS;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

async function formatDocumentRangesWithSelectedProvider(accessor, editorOrModel, rangeOrRanges, mode, progress, token, userGesture) {
	const instaService = accessor.get(IInstantiationService);
	const { documentRangeFormattingEditProvider: documentRangeFormattingEditProviderRegistry } = accessor.get(ILanguageFeaturesService);
	const model = isCodeEditor(editorOrModel) ? editorOrModel.getModel() : editorOrModel;
	const provider = documentRangeFormattingEditProviderRegistry.ordered(model);
	const selected = await FormattingConflicts.select(
		provider,
		model,
		mode,
		2
		/* FormattingKind.EditorSelection */
	);
	if (selected) {
		progress.report(selected);
		await instaService.invokeFunction(formatDocumentRangesWithProvider, selected, editorOrModel, rangeOrRanges, token, userGesture);
	}
}

async function formatDocumentRangesWithProvider(accessor, provider, editorOrModel, rangeOrRanges, token, userGesture) {
	const workerService = accessor.get(IEditorWorkerService);

	let model;
	let cts;
	if (isCodeEditor(editorOrModel)) {
		model = editorOrModel.getModel();
		cts = new EditorStateCancellationTokenSource(editorOrModel, 1 | 4, undefined, token);
	} else {
		model = editorOrModel;
		cts = new TextModelCancellationTokenSource(editorOrModel, token);
	}
	const ranges = [];
	let len = 0;
	for (const range2 of asArray(rangeOrRanges).sort(Range.compareRangesUsingStarts)) {
		if (len > 0 && Range.areIntersectingOrTouching(ranges[len - 1], range2)) {
			ranges[len - 1] = Range.fromPositions(ranges[len - 1].getStartPosition(), range2.getEndPosition());
		} else {
			len = ranges.push(range2);
		}
	}
	const computeEdits = async range2 => {
		return (await provider.provideDocumentRangeFormattingEdits(model, range2, model.getFormattingOptions(), cts.token)) || [];
	};
	const hasIntersectingEdit = (a, b) => {
		if (!a.length || !b.length) {
			return false;
		}
		const mergedA = a.reduce((acc, val) => {
			return Range.plusRange(acc, val.range);
		}, a[0].range);
		if (
			!b.some(x => {
				return Range.intersectRanges(mergedA, x.range);
			})
		) {
			return false;
		}
		for (const edit of a) {
			for (const otherEdit of b) {
				if (Range.intersectRanges(edit.range, otherEdit.range)) {
					return true;
				}
			}
		}
		return false;
	};
	const allEdits = [];
	const rawEditsList = [];
	try {
		if (typeof provider.provideDocumentRangesFormattingEdits === 'function') {
			const result =
				(await provider.provideDocumentRangesFormattingEdits(model, ranges, model.getFormattingOptions(), cts.token)) || [];

			rawEditsList.push(result);
		} else {
			for (const range2 of ranges) {
				if (cts.token.isCancellationRequested) {
					return true;
				}
				rawEditsList.push(await computeEdits(range2));
			}
			for (let i = 0; i < ranges.length; ++i) {
				for (let j = i + 1; j < ranges.length; ++j) {
					if (cts.token.isCancellationRequested) {
						return true;
					}
					if (hasIntersectingEdit(rawEditsList[i], rawEditsList[j])) {
						const mergedRange = Range.plusRange(ranges[i], ranges[j]);
						const edits = await computeEdits(mergedRange);
						ranges.splice(j, 1);
						ranges.splice(i, 1);
						ranges.push(mergedRange);
						rawEditsList.splice(j, 1);
						rawEditsList.splice(i, 1);
						rawEditsList.push(edits);
						i = 0;
						j = 0;
					}
				}
			}
		}
		for (const rawEdits of rawEditsList) {
			if (cts.token.isCancellationRequested) {
				return true;
			}
			const minimalEdits = await workerService.computeMoreMinimalEdits(model.uri, rawEdits);
			if (minimalEdits) {
				allEdits.push(...minimalEdits);
			}
		}
	} finally {
		cts.dispose();
	}
	if (allEdits.length === 0) {
		return false;
	}
	if (isCodeEditor(editorOrModel)) {
		FormattingEdit.execute(editorOrModel, allEdits, true);
		editorOrModel.revealPositionInCenterIfOutsideViewport(
			editorOrModel.getPosition(),
			1
			// Immediate
		);
	} else {
		const [{ range: range2 }] = allEdits;
		const initialSelection = new EditorSelection(range2.startLineNumber, range2.startColumn, range2.endLineNumber, range2.endColumn);
		model.pushEditOperations(
			[initialSelection],
			allEdits.map(edit => {
				return {
					text: edit.text,
					range: Range.lift(edit.range),
					forceMoveMarkers: true
				};
			}),
			undoEdits => {
				for (const { range: range3 } of undoEdits) {
					if (Range.areIntersectingOrTouching(range3, initialSelection)) {
						return [new EditorSelection(range3.startLineNumber, range3.startColumn, range3.endLineNumber, range3.endColumn)];
					}
				}
				return null;
			}
		);
	}

	return true;
}


async function formatDocumentWithSelectedProvider(accessor, editorOrModel, mode, progress, token, userGesture) {
	const instaService = accessor.get(IInstantiationService);
	const languageFeaturesService = accessor.get(ILanguageFeaturesService);
	const model = isCodeEditor(editorOrModel) ? editorOrModel.getModel() : editorOrModel;
	const provider = getRealAndSyntheticDocumentFormattersOrdered(
		languageFeaturesService.documentFormattingEditProvider,
		languageFeaturesService.documentRangeFormattingEditProvider,
		model
	);
	const selected = await FormattingConflicts.select(
		provider,
		model,
		mode,
		1
		/* FormattingKind.File */
	);
	if (selected) {
		progress.report(selected);
		await instaService.invokeFunction(formatDocumentWithProvider, selected, editorOrModel, mode, token, userGesture);
	}
}

async function formatDocumentWithProvider(accessor, provider, editorOrModel, mode, token, userGesture) {
	const workerService = accessor.get(IEditorWorkerService);

	let model;
	let cts;
	if (isCodeEditor(editorOrModel)) {
		model = editorOrModel.getModel();
		cts = new EditorStateCancellationTokenSource(editorOrModel, 1 | 4, undefined, token);
	} else {
		model = editorOrModel;
		cts = new TextModelCancellationTokenSource(editorOrModel, token);
	}
	let edits;
	try {
		const rawEdits = await provider.provideDocumentFormattingEdits(model, model.getFormattingOptions(), cts.token);
		edits = await workerService.computeMoreMinimalEdits(model.uri, rawEdits);
		if (cts.token.isCancellationRequested) {
			return true;
		}
	} finally {
		cts.dispose();
	}
	if (!edits || edits.length === 0) {
		return false;
	}
	if (isCodeEditor(editorOrModel)) {
		FormattingEdit.execute(
			editorOrModel,
			edits,
			mode !== 2
			/* FormattingMode.Silent */
		);
		if (mode !== 2) {
			editorOrModel.revealPositionInCenterIfOutsideViewport(
				editorOrModel.getPosition(),
				1
				// Immediate
			);
		}
	} else {
		const [{ range: range2 }] = edits;
		const initialSelection = new EditorSelection(range2.startLineNumber, range2.startColumn, range2.endLineNumber, range2.endColumn);
		model.pushEditOperations(
			[initialSelection],
			edits.map(edit => {
				return {
					text: edit.text,
					range: Range.lift(edit.range),
					forceMoveMarkers: true
				};
			}),
			undoEdits => {
				for (const { range: range3 } of undoEdits) {
					if (Range.areIntersectingOrTouching(range3, initialSelection)) {
						return [new EditorSelection(range3.startLineNumber, range3.startColumn, range3.endLineNumber, range3.endColumn)];
					}
				}
				return null;
			}
		);
	}

	return true;
}



function getCodeEditor(e) {
	if (isCodeEditor(e)) {
		return e;
	}

	if (
		e?.onDidChangeActiveEditor &&
		isCodeEditor(e.activeCodeEditor)
	) {
		return e.activeCodeEditor;
	}
	return null;
}


function getRealAndSyntheticDocumentFormattersOrdered(documentFormattingEditProvider, documentRangeFormattingEditProvider, model) {
	const result = [];
	const seen = new ExtensionIdentifierSet();
	const docFormatter = documentFormattingEditProvider.ordered(model);
	for (const formatter of docFormatter) {
		result.push(formatter);
		if (formatter.extensionId) {
			seen.add(formatter.extensionId);
		}
	}
	const rangeFormatter = documentRangeFormattingEditProvider.ordered(model);
	for (const formatter of rangeFormatter) {
		if (formatter.extensionId) {
			if (seen.has(formatter.extensionId)) {
				continue;
			}
			seen.add(formatter.extensionId);
		}
		result.push({
			displayName: formatter.displayName,
			extensionId: formatter.extensionId,
			provideDocumentFormattingEdits(model2, options2, token) {
				return formatter.provideDocumentRangeFormattingEdits(model2, model2.getFullModelRange(), options2, token);
			}
		});
	}
	return result;
}





async function getDocumentRangeFormattingEditsUntilResult(workerService, languageFeaturesService, model, range2, options2, token) {
	const providers = languageFeaturesService.documentRangeFormattingEditProvider.ordered(model);
	for (const provider of providers) {
		const rawEdits = await Promise.resolve(provider.provideDocumentRangeFormattingEdits(model, range2, options2, token)).catch(
			onUnexpectedExternalError
		);
		if (isArrayAndHasLength(rawEdits)) {
			return await workerService.computeMoreMinimalEdits(model.uri, rawEdits);
		}
	}
	return;
}

async function getDocumentFormattingEditsUntilResult(workerService, languageFeaturesService, model, options2, token) {
	const providers = getRealAndSyntheticDocumentFormattersOrdered(
		languageFeaturesService.documentFormattingEditProvider,
		languageFeaturesService.documentRangeFormattingEditProvider,
		model
	);
	for (const provider of providers) {
		const rawEdits = await Promise.resolve(provider.provideDocumentFormattingEdits(model, options2, token)).catch(
			onUnexpectedExternalError
		);
		if (isArrayAndHasLength(rawEdits)) {
			return await workerService.computeMoreMinimalEdits(model.uri, rawEdits);
		}
	}
	return;
}

function getOnTypeFormattingEdits(workerService, languageFeaturesService, model, position, ch, options2, token) {
	const providers = languageFeaturesService.onTypeFormattingEditProvider.ordered(model);
	if (providers.length === 0) {
		return Promise.resolve(undefined);
	}
	if (providers[0].autoFormatTriggerCharacters.indexOf(ch) < 0) {
		return Promise.resolve(undefined);
	}
	return Promise.resolve(providers[0].provideOnTypeFormattingEdits(model, position, ch, options2, token))
		.catch(onUnexpectedExternalError)
		.then(edits => {
			return workerService.computeMoreMinimalEdits(model.uri, edits);
		});
}

class FormattingConflicts {
	static setFormatterSelector(selector) {
		const remove = FormattingConflicts._selectors.unshift(selector);
		return { dispose: remove };
	}
	static async select(formatter, document2, mode, kind) {
		if (formatter.length === 0) {
			return;
		}
		const selector = iterableFirst(FormattingConflicts._selectors);
		if (selector) {
			return await selector(formatter, document2, mode, kind);
		}
		return;
	}
}
FormattingConflicts._selectors = new LinkedList();

commandsRegistry.registerCommand('_executeFormatRangeProvider', async (accessor, resource, range, options) => {
	if (URI.isUri(resource) && Range.isIRange(range)) {
		const resolverService = accessor.get(ITextModelService);
		const workerService = accessor.get(IEditorWorkerService);
		const languageFeaturesService = accessor.get(ILanguageFeaturesService);
		const reference = await resolverService.createModelReference(resource);
		try {
			return getDocumentRangeFormattingEditsUntilResult(
				workerService,
				languageFeaturesService,
				reference.object.textEditorModel,
				Range.lift(range),
				options,
				cancellationToken_none
			);
		} finally {
			reference.dispose();
		}
	} else {
		console.error();
	}
});

commandsRegistry.registerCommand('_executeFormatDocumentProvider', async (accessor, resource, options) => {
	if (URI.isUri(resource)) {
		const resolverService = accessor.get(ITextModelService);
		const workerService = accessor.get(IEditorWorkerService);
		const languageFeaturesService = accessor.get(ILanguageFeaturesService);
		const reference = await resolverService.createModelReference(resource);
		try {
			return getDocumentFormattingEditsUntilResult(
				workerService,
				languageFeaturesService,
				reference.object.textEditorModel,
				options,
				cancellationToken_none
			);
		} finally {
			reference.dispose();
		}
	}
});

commandsRegistry.registerCommand('_executeFormatOnTypeProvider', async (accessor, resource, position, ch, options) => {
	if ('string' === typeof ch && URI.isUri(resource) && Position.isIPosition(position)) {
		const resolverService = accessor.get(ITextModelService);
		const workerService = accessor.get(IEditorWorkerService);
		const languageFeaturesService = accessor.get(ILanguageFeaturesService);
		const reference = await resolverService.createModelReference(resource);
		try {
			return getOnTypeFormattingEdits(
				workerService,
				languageFeaturesService,
				reference.object.textEditorModel,
				Position.lift(position),
				ch,
				options,
				cancellationToken_none
			);
		} finally {
			reference.dispose();
		}
	}
});

const extensionIdentifierToKey = e => 'string' === typeof e ? e.toLowerCase() : e._lower;

class ExtensionIdentifierSet {
	constructor(iterable) {
		this._set = new Set();
		if (iterable) {
			for (const e of iterable) {
				this.add(e);
			}
		}
	}
	add(id) {
		this._set.add(extensionIdentifierToKey(id));
	}
	has(id) {
		return this._set.has(extensionIdentifierToKey(id));
	}
}
FormattingConflicts.setFormatterSelector((formatter, document2, mode) => Promise.resolve(formatter[0]));

class FormattingEdit {
	static _handleEolEdits(editor2, edits) {
		let newEol = undefined;
		const singleEdits = [];
		for (const edit of edits) {
			if (typeof edit.eol === 'number') {
				newEol = edit.eol;
			}
			if (edit.range && typeof edit.text === 'string') {
				singleEdits.push(edit);
			}
		}
		if (typeof newEol === 'number') {
			if (editor2.hasModel()) {
				editor2.getModel().pushEOL(newEol);
			}
		}
		return singleEdits;
	}
	static _isFullModelReplaceEdit(editor2, edit) {
		if (!editor2.hasModel()) {
			return false;
		}
		const model = editor2.getModel();
		const editRange = model.validateRange(edit.range);
		const fullModelRange = model.getFullModelRange();
		return fullModelRange.equalsRange(editRange);
	}
	static execute(editor2, _edits, addUndoStops) {
		if (addUndoStops) {
			editor2.pushUndoStop();
		}
		const scrollState = StableEditorScrollState.capture(editor2);
		const edits = FormattingEdit._handleEolEdits(editor2, _edits);
		if (edits.length === 1 && FormattingEdit._isFullModelReplaceEdit(editor2, edits[0])) {
			editor2.executeEdits(
				'formatEditsCommand',
				edits.map(edit => EditOperation.replace(Range.lift(edit.range), edit.text))
			);
		} else {
			editor2.executeEdits(
				'formatEditsCommand',
				edits.map(edit => EditOperation.replaceMove(Range.lift(edit.range), edit.text))
			);
		}
		if (addUndoStops) {
			editor2.pushUndoStop();
		}
		scrollState.restoreRelativeVerticalPositionOfCursor(editor2);
	}
}


// node_modules/monaco-editor/esm/vs/platform/opener/browser/link.js
class Link2 extends Disposable {
	get enabled() {
		return this._enabled;
	}
	set enabled(enabled) {
		if (enabled) {
			this.el.tabIndex = 0;
			this.el.style.pointerEvents = 'auto';
			this.el.style.opacity = '1';
			this.el.style.cursor = 'pointer';
			this._enabled = false;
		} else {
			this.el.tabIndex = -1;
			this.el.style.pointerEvents = 'none';
			this.el.style.opacity = '0.4';
			this.el.style.cursor = 'default';
			this._enabled = true;
		}
		this._enabled = enabled;
	}
	constructor(container, _link, options, _hoverService, openerService) {
		super();
		this._link = _link;
		this._hoverService = _hoverService;
		this._enabled = true;
		this.el = append(
			container,
			$(
				'a.monaco-link',
				{
					tabIndex: _link.tabIndex ?? 0,
					href: _link.href
				},
				_link.label
			)
		);
		this.hoverDelegate = options?.hoverDelegate ?? getDefaultHoverDelegate('mouse');
		this.setTooltip(_link.title);
		this.el.setAttribute('role', 'button');
		const onClickEmitter = this._register(new DomEmitter(this.el, 'click'));
		const onKeyPress = this._register(new DomEmitter(this.el, 'keypress'));
		const onEnterPress = editorEventChain(onKeyPress.event, o =>
			o
				.map(e => new StandardKeyboardEvent(e))
				.filter(
					e => e.keyCode === 3 // Enter
				)
		);
		const onTap = this._register(new DomEmitter(this.el, GestureType.Tap)).event;
		this._register(Gesture.addTarget(this.el));

		const onOpen = editorEventAny(onClickEmitter.event, onEnterPress, onTap);
		this._register(
			onOpen(e => {
				if (this.enabled) {
					EventHelper.stop(e, true);
					if (options?.opener) {
						options.opener(this._link.href);
					} else {
						openerService.open(this._link.href, { allowCommands: true });
					}
				}
			})
		);
		this.enabled = true;
	}
	setTooltip(title) {
		if (this.hoverDelegate.showNativeHover) {
			this.el.title = title !== null && title !== undefined ? title : '';
		} else if (!this.hover && title) {
			this.hover = this._register(this._hoverService.setupUpdatableHover(this.hoverDelegate, this.el, title));
		} else if (this.hover) {
			this.hover.update(title);
		}
	}
}
__decorate([__param(3, IHoverService), __param(4, IOpenerService)], Link2);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class Stacktrace {
	static create() {
		return new Stacktrace(new Error().stack || '');
	}
	constructor(value) {
		this.value = value;
	}
	print() {
		console.warn(this.value.split('\n').slice(2).join('\n'));
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const _globalLeakWarningThreshold = -1;

class LeakageMonitor {
	constructor(threshold, name = Math.random().toString(18).slice(2, 5)) {
		this.threshold = threshold;
		this.name = name;
		this._warnCountdown = 0;
	}
	dispose() {
		this._stacks?.clear();
	}
	check(stack, listenerCount) {
		const threshold = this.threshold;
		if (threshold <= 0 || listenerCount < threshold) {
			return;
		}
		if (!this._stacks) {
			this._stacks = new Map();
		}
		const count = this._stacks.get(stack.value) || 0;
		this._stacks.set(stack.value, count + 1);
		this._warnCountdown -= 1;
		if (this._warnCountdown <= 0) {
			this._warnCountdown = threshold * 0.5;
			let topStack;
			let topCount = 0;
			for (const [stack2, count2] of this._stacks) {
				if (!topStack || topCount < count2) {
					topStack = stack2;
					topCount = count2;
				}
			}
			console.warn(
				`[${this.name}] potential listener LEAK detected, having ${listenerCount} listeners already. MOST frequent listener (${topCount}):`
			);
			console.warn(topStack);
		}
		return () => {
			const count2 = this._stacks.get(stack.value) || 0;
			this._stacks.set(stack.value, count2 - 1);
		};
	}
}




		this._leakageMon =
			_globalLeakWarningThreshold > 0 || this._options?.leakWarningThreshold
				? new LeakageMonitor(this._options?.leakWarningThreshold ?? _globalLeakWarningThreshold)
				: undefined;


			if (this._leakageMon && this._size >= Math.ceil(this._leakageMon.threshold * 0.2)) {
				contained.stack = Stacktrace.create();
				removeMonitor = this._leakageMon.check(contained.stack, this._size + 1);
			}

		if (this._leakageMon && this._size > this._leakageMon.threshold * 3) {
				console.warn(`[${this._leakageMon.name}] REFUSES to accept new listeners because it exceeded its threshold by far`);
				return disposableNone;
			}
this._leakageMon?.dispose();



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class EventProfiling {
	static _lastId = -1;
	constructor(name) {
		this.listenerCount = 0;
		this.invocationCount = 0;
		this.elapsedOverall = 0;
		this.durations = [];
		this.name = `${name}_${++EventProfiling._lastId}`;
	}
	start(listenerCount) {
		this._stopWatch = new StopWatch();
		this.listenerCount = listenerCount;
	}
	stop() {
		if (this._stopWatch) {
			const elapsed = this._stopWatch.elapsed();
			this.durations.push(elapsed);
			this.elapsedOverall += elapsed;
			this.invocationCount += 1;
			this._stopWatch = undefined;
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

	class EmitterObserver {
		constructor(_observable, store) {
			this._observable = _observable;
			this._counter = 0;
			this._hasChanged = false;
			const options2 = {
				onWillAddFirstListener: () => {
					_observable.addObserver(this);
				},
				onDidRemoveLastListener: () => {
					_observable.removeObserver(this);
				}
			};

			this.emitter = new Emitter(options2);
			if (store) {
				store.add(this.emitter);
			}
		}
		beginUpdate(_observable) {
			this._counter++;
		}
		handlePossibleChange(_observable) {}
		handleChange(_observable, _change) {
			this._hasChanged = true;
		}
		endUpdate(_observable) {
			this._counter--;
			if (this._counter === 0) {
				this._observable.reportChanges();
				if (this._hasChanged) {
					this._hasChanged = false;
					this.emitter.fire(this._observable.get());
				}
			}
		}
	}
	function fromObservable(obs, store) {
		const observer = new EmitterObserver(obs, store);
		return observer.emitter.event;
	}
	EditorEvent.fromObservable = fromObservable;


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


	function fromPromise(promise) {
		const result = new Emitter();
		promise
			.then(
				res => {
					result.fire(res);
				},
				() => {
					result.fire(undefined);
				}
			)
			.finally(() => {
				result.dispose();
			});
		return result.event;
	}
	EditorEvent.fromPromise = fromPromise;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


	function fromDOMEventEmitter(emitter, eventName, map2 = id => id) {
		const fn = (...args) => result.fire(map2(...args));
		const onFirstListenerAdd = () => emitter.addEventListener(eventName, fn);
		const onLastListenerRemove = () => emitter.removeEventListener(eventName, fn);
		const result = new Emitter({
			onWillAddFirstListener: onFirstListenerAdd,
			onDidRemoveLastListener: onLastListenerRemove
		});
		return result.event;
	}
	EditorEvent.fromDOMEventEmitter = fromDOMEventEmitter;

	function fromNodeEventEmitter(emitter, eventName, map2 = id => id) {
		const fn = (...args) => result.fire(map2(...args));
		const onFirstListenerAdd = () => emitter.on(eventName, fn);
		const onLastListenerRemove = () => emitter.removeListener(eventName, fn);
		const result = new Emitter({
			onWillAddFirstListener: onFirstListenerAdd,
			onDidRemoveLastListener: onLastListenerRemove
		});
		return result.event;
	}
	EditorEvent.fromNodeEventEmitter = fromNodeEventEmitter;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

	function buffer(event, flushAfterTimeout = false, _buffer = [], disposable) {
		let buffer2 = _buffer.slice();
		let listener = event(e => {
			if (buffer2) {
				buffer2.push(e);
			} else {
				emitter.fire(e);
			}
		});
		if (disposable) {
			disposable.add(listener);
		}
		const flush = () => {
			buffer2?.forEach(e => emitter.fire(e));
			buffer2 = null;
		};
		const emitter = new Emitter({
			onWillAddFirstListener() {
				if (!listener) {
					listener = event(e => emitter.fire(e));
					if (disposable) {
						disposable.add(listener);
					}
				}
			},
			onDidAddFirstListener() {
				if (buffer2) {
					if (flushAfterTimeout) {
						setTimeout(flush);
					} else {
						flush();
					}
				}
			},
			onDidRemoveLastListener() {
				if (listener) {
					listener.dispose();
				}
				listener = null;
			}
		});
		if (disposable) {
			disposable.add(emitter);
		}
		return emitter.event;
	}
	EditorEvent.buffer = buffer;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

	function split(event, isT, disposable) {
		return [editorEventFilter(event, isT, disposable), editorEventFilter(event, e => !isT(e), disposable)];
	}
	EditorEvent.split = split;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

	function accumulate(event, delay = 0, disposable) {
		return editorEventDebounce(
			event,
			(last, e) => {
				if (!last) {
					return [e];
				}
				last.push(e);
				return last;
			},
			delay,
			undefined,
			true,
			undefined,
			disposable
		);
	}
	EditorEvent.accumulate = accumulate;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


	function defer(event, disposable) {
		return debounce(event, () => undefined, 0, undefined, true, undefined, disposable);
	}
	EditorEvent.defer = defer;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const CancellationToken = {
	isCancellationToken: thing => {
		if (thing === cancellationToken_none || thing === cancellationToken_cancelled) {
			return true;
		}
		if (thing instanceof MutableToken) {
			return true;
		}
		if (!thing || typeof thing !== 'object') {
			return false;
		}
		return typeof thing.isCancellationRequested === 'boolean' && typeof thing.onCancellationRequested === 'function';
	},


};


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class KeyMod {
	static chord(firstPart, secondPart) {
		return KeyChord(firstPart, secondPart);
	}
}

KeyMod.CtrlCmd = 2048;
KeyMod.Shift = 1024;
KeyMod.Alt = 512;
KeyMod.WinCtrl = 256;


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const syncing = themeIconModify(Codicon.sync, 'spin');
const spinningLoading = themeIconModify(Codicon.loading, 'spin');



const IconContribution = {};
{
	function getDefinition(contribution, registry) {
		let definition = contribution.defaults;
		while (isThemeIcon(definition)) {
			const c = iconRegistry.getIcon(definition.id);
			if (!c) {
				return;
			}
			definition = c.defaults;
		}
		return definition;
	}
	IconContribution.getDefinition = getDefinition;
}

const IconFontDefinition = {};
{
	function toJSONObject(iconFont) {
		return {
			weight: iconFont.weight,
			style: iconFont.style,
			src: iconFont.src.map(s => ({ format: s.format, location: s.location.toString() }))
		};
	}
	IconFontDefinition.toJSONObject = toJSONObject;
	function fromJSONObject(json) {
		const stringOrUndef = s => ('string' === typeof s ? s : undefined);
		if (json && isArray(json.src) && json.src.every(s => 'string' === typeof s.format && 'string' === typeof s.location)) {
			return {
				weight: stringOrUndef(json.weight),
				style: stringOrUndef(json.style),
				src: json.src.map(s => ({ format: s.format, location: URI.parse(s.location) }))
			};
		}
		return;
	}
	IconFontDefinition.fromJSONObject = fromJSONObject;
}



const Sizing = {};
{
	Sizing.Distribute = { type: 'distribute' };
	function Split(index) {
		return { type: 'split', index };
	}
	Sizing.Split = Split;
	function Auto(index) {
		return { type: 'auto', index };
	}
	Sizing.Auto = Auto;
	function Invisible(cachedVisibleSize) {
		return { type: 'invisible', cachedVisibleSize };
	}
	Sizing.Invisible = Invisible;
}


const RenderIndentGuides2 = {
    None: 'none',
    OnHover: 'onHover',
    Always: 'always'
};
	const TreeFindMode2 = {
		Highlight: 0,
		0: 'Highlight',
		Filter: 1,
		1: 'Filter'
	};
const TreeFindMatchType2 = {
    Fuzzy: 0,
    0: 'Fuzzy',
    Contiguous: 1,
    1: 'Contiguous'
};













