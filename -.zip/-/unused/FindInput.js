


class CaseSensitiveToggle extends Toggle {
	constructor(opts) {
		super({
			icon: codicon_caseSensitive,
			title: localize('Match Case') + opts.appendTitle,
			isChecked: opts.isChecked,
			hoverDelegate: opts.hoverDelegate ?? getDefaultHoverDelegate('element'),
			inputActiveOptionBorder: opts.inputActiveOptionBorder,
			inputActiveOptionForeground: opts.inputActiveOptionForeground,
			inputActiveOptionBackground: opts.inputActiveOptionBackground
		});
	}
}


class WholeWordsToggle extends Toggle {
	constructor(opts) {
		super({
			icon: codicon_wholeWord,
			title: localize('Match Whole Word') + opts.appendTitle,
			isChecked: opts.isChecked,
			hoverDelegate: opts.hoverDelegate ?? getDefaultHoverDelegate('element'),
			inputActiveOptionBorder: opts.inputActiveOptionBorder,
			inputActiveOptionForeground: opts.inputActiveOptionForeground,
			inputActiveOptionBackground: opts.inputActiveOptionBackground
		});
	}
}


class RegexToggle extends Toggle {
	constructor(opts) {
		super({
			icon: codicon_regex,
			title: localize('Use Regular Expression') + opts.appendTitle,
			isChecked: opts.isChecked,
			hoverDelegate: opts.hoverDelegate ?? getDefaultHoverDelegate('element'),
			inputActiveOptionBorder: opts.inputActiveOptionBorder,
			inputActiveOptionForeground: opts.inputActiveOptionForeground,
			inputActiveOptionBackground: opts.inputActiveOptionBackground
		});
	}
}


class ArrayNavigator {
	constructor(items, start = 0, end = items.length, index = start - 1) {
		this.items = items;
		this.start = start;
		this.end = end;
		this.index = index;
	}
	current() {
		if (this.index === this.start - 1 || this.index === this.end) {
			return null;
		}
		return this.items[this.index];
	}
	next() {
		this.index = Math.min(this.index + 1, this.end);
		return this.current();
	}
	previous() {
		this.index = Math.max(this.index - 1, this.start - 1);
		return this.current();
	}
	first() {
		this.index = this.start;
		return this.current();
	}
	last() {
		this.index = this.end - 1;
		return this.current();
	}
}




class HistoryNavigator {
	constructor(history = [], limit = 10) {
		this._initialize(history);
		this._limit = limit;
		this._onChange();
	}
	getHistory() {
		return this._elements;
	}
	add(t) {
		this._history.delete(t);
		this._history.add(t);
		this._onChange();
	}
	next() {
		return this._navigator.next();
	}
	previous() {
		if (this._currentPosition() !== 0) {
			return this._navigator.previous();
		}
		return null;
	}
	current() {
		return this._navigator.current();
	}
	first() {
		return this._navigator.first();
	}
	last() {
		return this._navigator.last();
	}
	isLast() {
		return this._currentPosition() >= this._elements.length - 1;
	}
	isNowhere() {
		return this._navigator.current() === null;
	}
	has(t) {
		return this._history.has(t);
	}
	_onChange() {
		this._reduceToLimit();
		const elements = this._elements;
		this._navigator = new ArrayNavigator(elements, 0, elements.length, elements.length);
	}
	_reduceToLimit() {
		const data = this._elements;
		if (data.length > this._limit) {
			this._initialize(data.slice(data.length - this._limit));
		}
	}
	_currentPosition() {
		const currentElement = this._navigator.current();
		if (!currentElement) {
			return -1;
		}
		return this._elements.indexOf(currentElement);
	}
	_initialize(history) {
		this._history = new Set();
		for (const entry of history) {
			this._history.add(entry);
		}
	}
	get _elements() {
		const elements = [];
		this._history.forEach(e => elements.push(e));
		return elements;
	}
}


class InputBox extends Widget {
	constructor(container, contextViewProvider, options2) {
		super();
		this.state = 'idle';
		this.maxHeight = Number.POSITIVE_INFINITY;
		this._onDidChange = this._register(new Emitter());
		this.onDidChange = this._onDidChange.event;
		this._onDidHeightChange = this._register(new Emitter());
		this.onDidHeightChange = this._onDidHeightChange.event;
		this.contextViewProvider = contextViewProvider;
		this.options = options2;
		this.message = null;
		this.placeholder = this.options.placeholder || '';
		this.tooltip = this.options.tooltip || this.placeholder || '';
		if (this.options.validationOptions) {
			this.validation = this.options.validationOptions.validation;
		}
		this.element = append(container, createDomElement('.monaco-inputbox.idle'));
		const tagName = this.options.flexibleHeight ? 'textarea' : 'input';
		const wrapper = append(this.element, createDomElement('.ibwrapper'));
		this.input = append(wrapper, createDomElement(tagName + '.input.empty'));
		this.input.setAttribute('autocorrect', 'off');
		this.input.setAttribute('autocapitalize', 'off');
		this.input.setAttribute('spellcheck', 'false');
		this.onfocus(this.input, () => this.element.classList.add('synthetic-focus'));
		this.onblur(this.input, () => this.element.classList.remove('synthetic-focus'));
		if (this.options.flexibleHeight) {
			this.maxHeight = typeof this.options.flexibleMaxHeight === 'number' ? this.options.flexibleMaxHeight : Number.POSITIVE_INFINITY;
			this.mirror = append(wrapper, createDomElement('div.mirror'));
			this.mirror.innerText = '\xA0';
			this.scrollableElement = new ScrollableElement(this.element, {
				vertical: 1 //Auto
			});
			if (this.options.flexibleWidth) {
				this.input.setAttribute('wrap', 'off');
				this.mirror.style.whiteSpace = 'pre';
				this.mirror.style.wordWrap = 'initial';
			}
			append(container, this.scrollableElement.getDomNode());
			this._register(this.scrollableElement);
			this._register(this.scrollableElement.onScroll(e => (this.input.scrollTop = e.scrollTop)));
			const onSelectionChange = this._register(new DomEmitter(container.ownerDocument, 'selectionchange'));
			const onAnchoredSelectionChange = editorEventFilter(onSelectionChange.event, () => {
				return wrapper === container.ownerDocument.getSelection()?.anchorNode;
			});
			this._register(onAnchoredSelectionChange(this.updateScrollDimensions, this));
			this._register(this.onDidHeightChange(this.updateScrollDimensions, this));
		} else {
			this.input.type = this.options.type || 'text';
			this.input.setAttribute('wrap', 'off');
		}
		if (this.placeholder && !this.options.showPlaceholderOnFocus) {
			this.setPlaceHolder(this.placeholder);
		}
		if (this.tooltip) {
			this.setTooltip(this.tooltip);
		}
		this.oninput(this.input, () => this.onValueChange());
		this.onblur(this.input, () => this.onBlur());
		this.onfocus(this.input, () => this.onFocus());
		this._register(this.ignoreGesture(this.input));
		setTimeout(() => this.updateMirror(), 0);
		if (this.options.actions) {
			this.actionbar = this._register(new ActionBar(this.element));
			this.actionbar.push(this.options.actions, {
				icon: true,
				label: false
			});
		}
		this.applyStyles();
	}
	onBlur() {
		this._hideMessage();
		if (this.options.showPlaceholderOnFocus) {
			this.input.setAttribute('placeholder', '');
		}
	}
	onFocus() {
		this._showMessage();
		if (this.options.showPlaceholderOnFocus) {
			this.input.setAttribute('placeholder', this.placeholder || '');
		}
	}
	setPlaceHolder(placeHolder) {
		this.placeholder = placeHolder;
		this.input.setAttribute('placeholder', placeHolder);
	}
	setTooltip(tooltip) {
		this.tooltip = tooltip;
		if (!this.hover) {
			this.hover = this._register(
				getBaseLayerHoverDelegate().setupUpdatableHover(getDefaultHoverDelegate('mouse'), this.input, tooltip)
			);
		} else {
			this.hover.update(tooltip);
		}
	}
	get inputElement() {
		return this.input;
	}
	get value() {
		return this.input.value;
	}
	set value(newValue) {
		if (this.input.value !== newValue) {
			this.input.value = newValue;
			this.onValueChange();
		}
	}
	get height() {
		return typeof this.cachedHeight === 'number' ? this.cachedHeight : getTotalHeight(this.element);
	}
	focus() {
		this.input.focus();
	}
	blur() {
		this.input.blur();
	}
	hasFocus() {
		return isActiveElement(this.input);
	}
	select(range2 = null) {
		this.input.select();
		if (range2) {
			this.input.setSelectionRange(range2.start, range2.end);
			if (range2.end === this.input.value.length) {
				this.input.scrollLeft = this.input.scrollWidth;
			}
		}
	}
	isSelectionAtEnd() {
		return this.input.selectionEnd === this.input.value.length && this.input.selectionStart === this.input.selectionEnd;
	}
	getSelection() {
		const selectionStart = this.input.selectionStart;
		if (selectionStart === null) {
			return null;
		}
		const selectionEnd = this.input.selectionEnd ?? selectionStart;
		return {
			start: selectionStart,
			end: selectionEnd
		};
	}
	enable() {
		this.input.removeAttribute('disabled');
	}
	disable() {
		this.blur();
		this.input.disabled = true;
		this._hideMessage();
	}
	set paddingRight(paddingRight) {
		this.input.style.width = `calc(100% - ${paddingRight}px)`;
		if (this.mirror) {
			this.mirror.style.paddingRight = paddingRight + 'px';
		}
	}
	updateScrollDimensions() {
		if (typeof this.cachedContentHeight !== 'number' || typeof this.cachedHeight !== 'number' || !this.scrollableElement) {
			return;
		}
		const scrollHeight = this.cachedContentHeight;
		const height = this.cachedHeight;
		const scrollTop = this.input.scrollTop;
		this.scrollableElement.setScrollDimensions({ scrollHeight, height });
		this.scrollableElement.setScrollPosition({ scrollTop });
	}
	showMessage(message, force) {
		if (this.state === 'open' && isDeepEqual(this.message, message)) {
			return;
		}
		this.message = message;
		this.element.classList.remove('idle');
		this.element.classList.remove('info');
		this.element.classList.remove('warning');
		this.element.classList.remove('error');
		this.element.classList.add(this.classForType(message.type));
		const styles = this.stylesForType(this.message.type);
		this.element.style.border = `1px solid ${asCssValueWithDefault(styles.border, 'transparent')}`;
		if (this.message.content && (this.hasFocus() || force)) {
			this._showMessage();
		}
	}
	hideMessage() {
		this.message = null;
		this.element.classList.remove('info');
		this.element.classList.remove('warning');
		this.element.classList.remove('error');
		this.element.classList.add('idle');
		this._hideMessage();
		this.applyStyles();
	}
	validate() {
		let errorMsg = null;
		if (this.validation) {
			errorMsg = this.validation(this.value);
			if (errorMsg) {
				this.showMessage(errorMsg);
			}
		}
		return errorMsg?.type;
	}
	stylesForType(type) {
		const styles = this.options.inputBoxStyles;
		switch (type) {
			case 1:
				return {
					border: styles.inputValidationInfoBorder,
					background: styles.inputValidationInfoBackground,
					foreground: styles.inputValidationInfoForeground
				};
			case 2:
				return {
					border: styles.inputValidationWarningBorder,
					background: styles.inputValidationWarningBackground,
					foreground: styles.inputValidationWarningForeground
				};
			default:
				return {
					border: styles.inputValidationErrorBorder,
					background: styles.inputValidationErrorBackground,
					foreground: styles.inputValidationErrorForeground
				};
		}
	}
	classForType(type) {
		switch (type) {
			case 1:
				return 'info';
			case 2:
				return 'warning';
			default:
				return 'error';
		}
	}
	_showMessage() {
		if (!this.contextViewProvider || !this.message) {
			return;
		}
		let div;
		const layout2 = () => (div.style.width = getTotalWidth(this.element) + 'px');
		this.contextViewProvider.showContextView({
			getAnchor: () => this.element,
			anchorAlignment: 1,
			render: container => {
				if (this.message) {
					div = append(container, createDomElement('.monaco-inputbox-container'));
					layout2();
					const renderOptions = {
						inline: true,
						className: 'monaco-inputbox-message'
					};
					const spanElement = this.message.formatContent
						? renderFormattedText(this.message.content, renderOptions)
						: renderText(this.message.content, renderOptions);
					spanElement.classList.add(this.classForType(this.message.type));
					const styles = this.stylesForType(this.message.type);
					spanElement.style.backgroundColor = styles.background || '';
					spanElement.style.color = styles.foreground || '';
					spanElement.style.border = styles.border ? `1px solid ${styles.border}` : '';
					append(div, spanElement);
				}
				return null;
			},
			onHide: () => {
				this.state = 'closed';
			},
			layout: layout2
		});
		let alertText;
		if (this.message.type === 3) {
			alertText = localize(this.message.content);
		} else if (this.message.type === 2) {
			alertText = localize(this.message.content);
		} else {
			alertText = localize(this.message.content);
		}
		alert(alertText);
		this.state = 'open';
	}
	_hideMessage() {
		if (!this.contextViewProvider) {
			return;
		}
		if (this.state === 'open') {
			this.contextViewProvider.hideContextView();
		}
		this.state = 'idle';
	}
	onValueChange() {
		this._onDidChange.fire(this.value);
		this.validate();
		this.updateMirror();
		this.input.classList.toggle('empty', !this.value);
		if (this.state === 'open' && this.contextViewProvider) {
			this.contextViewProvider.layout();
		}
	}
	updateMirror() {
		if (!this.mirror) {
			return;
		}
		const value = this.value;
		const lastCharCode = value.charCodeAt(value.length - 1);
		const suffix = lastCharCode === 10 ? ' ' : '';
		const mirrorTextContent = (value + suffix).replace(/\u000c/g, '');
		if (mirrorTextContent) {
			this.mirror.textContent = value + suffix;
		} else {
			this.mirror.innerText = '\xA0';
		}
		this.layout();
	}
	applyStyles() {
		const styles = this.options.inputBoxStyles;
		const background = styles.inputBackground || '';
		const foreground2 = styles.inputForeground || '';
		const border = styles.inputBorder || '';
		this.element.style.backgroundColor = background;
		this.element.style.color = foreground2;
		this.input.style.backgroundColor = 'inherit';
		this.input.style.color = foreground2;
		this.element.style.border = `1px solid ${asCssValueWithDefault(border, 'transparent')}`;
	}
	layout() {
		if (!this.mirror) {
			return;
		}
		const previousHeight = this.cachedContentHeight;
		this.cachedContentHeight = getTotalHeight(this.mirror);
		if (previousHeight !== this.cachedContentHeight) {
			this.cachedHeight = Math.min(this.cachedContentHeight, this.maxHeight);
			this.input.style.height = this.cachedHeight + 'px';
			this._onDidHeightChange.fire(this.cachedContentHeight);
		}
	}
	insertAtCursor(text2) {
		const inputElement = this.inputElement;
		const start = inputElement.selectionStart;
		const end = inputElement.selectionEnd;
		const content = inputElement.value;
		if (start !== null && end !== null) {
			this.value = content.substr(0, start) + text2 + content.substr(end);
			inputElement.setSelectionRange(start + 1, start + 1);
			this.layout();
		}
	}
	dispose() {
		this._hideMessage();
		this.message = null;
		this.actionbar?.dispose();
		super.dispose();
	}
}


class HistoryInputBox extends InputBox {
	constructor(container, contextViewProvider, options2) {
		const NLS_PLACEHOLDER_HISTORY_HINT_SUFFIX_NO_PARENS = localize(`\u21C5`);
		const NLS_PLACEHOLDER_HISTORY_HINT_SUFFIX_IN_PARENS = localize(`\u21C5`);
		super(container, contextViewProvider, options2);
		this._onDidFocus = this._register(new Emitter());
		this.onDidFocus = this._onDidFocus.event;
		this._onDidBlur = this._register(new Emitter());
		this.onDidBlur = this._onDidBlur.event;
		this.history = new HistoryNavigator(options2.history, 100);
		const addSuffix = () => {
			if (
				options2.showHistoryHint &&
				options2.showHistoryHint() &&
				!this.placeholder.endsWith(NLS_PLACEHOLDER_HISTORY_HINT_SUFFIX_NO_PARENS) &&
				!this.placeholder.endsWith(NLS_PLACEHOLDER_HISTORY_HINT_SUFFIX_IN_PARENS) &&
				this.history.getHistory().length
			) {
				const suffix = this.placeholder.endsWith(')')
					? NLS_PLACEHOLDER_HISTORY_HINT_SUFFIX_NO_PARENS
					: NLS_PLACEHOLDER_HISTORY_HINT_SUFFIX_IN_PARENS;
				const suffixedPlaceholder = this.placeholder + suffix;
				if (options2.showPlaceholderOnFocus && !isActiveElement(this.input)) {
					this.placeholder = suffixedPlaceholder;
				} else {
					this.setPlaceHolder(suffixedPlaceholder);
				}
			}
		};
		this.observer = new MutationObserver((mutationList, observer) => {
			mutationList.forEach(mutation => {
				if (!mutation.target.textContent) {
					addSuffix();
				}
			});
		});
		this.observer.observe(this.input, { attributeFilter: ['class'] });
		this.onfocus(this.input, () => addSuffix());
		this.onblur(this.input, () => {
			const resetPlaceholder = historyHint => {
				if (!this.placeholder.endsWith(historyHint)) {
					return false;
				} else {
					const revertedPlaceholder = this.placeholder.slice(0, this.placeholder.length - historyHint.length);
					if (options2.showPlaceholderOnFocus) {
						this.placeholder = revertedPlaceholder;
					} else {
						this.setPlaceHolder(revertedPlaceholder);
					}
					return true;
				}
			};
			if (!resetPlaceholder(NLS_PLACEHOLDER_HISTORY_HINT_SUFFIX_IN_PARENS)) {
				resetPlaceholder(NLS_PLACEHOLDER_HISTORY_HINT_SUFFIX_NO_PARENS);
			}
		});
	}
	dispose() {
		super.dispose();
		if (this.observer) {
			this.observer.disconnect();
			this.observer = undefined;
		}
	}
	addToHistory(always) {
		if (this.value && (always || this.value !== this.getCurrentValue())) {
			this.history.add(this.value);
		}
	}
	isAtLastInHistory() {
		return this.history.isLast();
	}
	isNowhereInHistory() {
		return this.history.isNowhere();
	}
	showNextValue() {
		if (!this.history.has(this.value)) {
			this.addToHistory();
		}
		let next = this.getNextValue();
		if (next) {
			next = next === this.value ? this.getNextValue() : next;
		}
		this.value = next !== null && next !== undefined ? next : '';
	}
	showPreviousValue() {
		if (!this.history.has(this.value)) {
			this.addToHistory();
		}
		let previous = this.getPreviousValue();
		if (previous) {
			previous = previous === this.value ? this.getPreviousValue() : previous;
		}
		if (previous) {
			this.value = previous;
		}
	}
	setPlaceHolder(placeHolder) {
		super.setPlaceHolder(placeHolder);
		this.setTooltip(placeHolder);
	}
	onBlur() {
		super.onBlur();
		this._onDidBlur.fire();
	}
	onFocus() {
		super.onFocus();
		this._onDidFocus.fire();
	}
	getCurrentValue() {
		let currentValue = this.history.current();
		if (!currentValue) {
			currentValue = this.history.last();
			this.history.next();
		}
		return currentValue;
	}
	getPreviousValue() {
		return this.history.previous() || this.history.first();
	}
	getNextValue() {
		return this.history.next();
	}
}



class FindInput extends Widget {
	constructor(parent, contextViewProvider, options2) {
		super();
		this.fixFocusOnOptionClickEnabled = true;
		this.imeSessionInProgress = false;
		this.additionalTogglesDisposables = this._register(new MutableDisposable());
		this.additionalToggles = [];
		this._onDidOptionChange = this._register(new Emitter());
		this.onDidOptionChange = this._onDidOptionChange.event;
		this._onKeyDown = this._register(new Emitter());
		this.onKeyDown = this._onKeyDown.event;
		this._onMouseDown = this._register(new Emitter());
		this.onMouseDown = this._onMouseDown.event;
		this._onInput = this._register(new Emitter());
		this._onKeyUp = this._register(new Emitter());
		this._onCaseSensitiveKeyDown = this._register(new Emitter());
		this.onCaseSensitiveKeyDown = this._onCaseSensitiveKeyDown.event;
		this._onRegexKeyDown = this._register(new Emitter());
		this.onRegexKeyDown = this._onRegexKeyDown.event;
		this._lastHighlightFindOptions = 0;
		this.placeholder = options2.placeholder || '';
		this.validation = options2.validation;
		this.label = options2.label || localize('input');
		this.showCommonFindToggles = !!options2.showCommonFindToggles;
		const appendCaseSensitiveLabel = options2.appendCaseSensitiveLabel || '';
		const appendWholeWordsLabel = options2.appendWholeWordsLabel || '';
		const appendRegexLabel = options2.appendRegexLabel || '';
		const history = options2.history || [];
		const flexibleHeight = !!options2.flexibleHeight;
		const flexibleWidth = !!options2.flexibleWidth;
		const flexibleMaxHeight = options2.flexibleMaxHeight;
		this.domNode = document.createElement('div');
		this.domNode.classList.add('monaco-findInput');
		this.inputBox = this._register(
			new HistoryInputBox(this.domNode, contextViewProvider, {
				placeholder: this.placeholder || '',
				validationOptions: { validation: this.validation },
				history,
				showHistoryHint: options2.showHistoryHint,
				flexibleHeight,
				flexibleWidth,
				flexibleMaxHeight,
				inputBoxStyles: options2.inputBoxStyles
			})
		);
		const hoverDelegate = this._register(createInstantHoverDelegate());
		if (this.showCommonFindToggles) {
			this.regex = this._register(
				new RegexToggle({
					appendTitle: appendRegexLabel,
					isChecked: false,
					hoverDelegate,
					...options2.toggleStyles
				})
			);
			this._register(
				this.regex.onChange(viaKeyboard => {
					this._onDidOptionChange.fire(viaKeyboard);
					if (!viaKeyboard && this.fixFocusOnOptionClickEnabled) {
						this.inputBox.focus();
					}
					this.validate();
				})
			);
			this._register(
				this.regex.onKeyDown(e => {
					this._onRegexKeyDown.fire(e);
				})
			);
			this.wholeWords = this._register(
				new WholeWordsToggle({
					appendTitle: appendWholeWordsLabel,
					isChecked: false,
					hoverDelegate,
					...options2.toggleStyles
				})
			);
			this._register(
				this.wholeWords.onChange(viaKeyboard => {
					this._onDidOptionChange.fire(viaKeyboard);
					if (!viaKeyboard && this.fixFocusOnOptionClickEnabled) {
						this.inputBox.focus();
					}
					this.validate();
				})
			);
			this.caseSensitive = this._register(
				new CaseSensitiveToggle({
					appendTitle: appendCaseSensitiveLabel,
					isChecked: false,
					hoverDelegate,
					...options2.toggleStyles
				})
			);
			this._register(
				this.caseSensitive.onChange(viaKeyboard => {
					this._onDidOptionChange.fire(viaKeyboard);
					if (!viaKeyboard && this.fixFocusOnOptionClickEnabled) {
						this.inputBox.focus();
					}
					this.validate();
				})
			);
			this._register(
				this.caseSensitive.onKeyDown(e => {
					this._onCaseSensitiveKeyDown.fire(e);
				})
			);
			const indexes = [this.caseSensitive.domNode, this.wholeWords.domNode, this.regex.domNode];
			this.onkeydown(this.domNode, event => {
				if (
					event.equals(
						15 //LeftArrow
					) ||
					event.equals(
						17 //RightArrow
					) ||
					event.equals(
						9 //Escape
					)
				) {
					const index = indexes.indexOf(this.domNode.ownerDocument.activeElement);
					if (index >= 0) {
						let newIndex = -1;
						if (
							event.equals(
								17 //RightArrow
							)
						) {
							newIndex = (index + 1) % indexes.length;
						} else if (
							event.equals(
								15 //LeftArrow
							)
						) {
							if (index === 0) {
								newIndex = indexes.length - 1;
							} else {
								newIndex = index - 1;
							}
						}
						if (
							event.equals(
								9 //Escape
							)
						) {
							indexes[index].blur();
							this.inputBox.focus();
						} else if (newIndex >= 0) {
							indexes[newIndex].focus();
						}
						EventHelper.stop(event, true);
					}
				}
			});
		}
		this.controls = document.createElement('div');
		this.controls.className = 'controls';
		this.controls.style.display = this.showCommonFindToggles ? '' : 'none';
		if (this.caseSensitive) {
			this.controls.append(this.caseSensitive.domNode);
		}
		if (this.wholeWords) {
			this.controls.appendChild(this.wholeWords.domNode);
		}
		if (this.regex) {
			this.controls.appendChild(this.regex.domNode);
		}
		this.setAdditionalToggles(options2?.additionalToggles);
		if (this.controls) {
			this.domNode.appendChild(this.controls);
		}
		parent?.appendChild(this.domNode);
		this._register(
			addDisposableListener(this.inputBox.inputElement, 'compositionstart', e => {
				this.imeSessionInProgress = true;
			})
		);
		this._register(
			addDisposableListener(this.inputBox.inputElement, 'compositionend', e => {
				this.imeSessionInProgress = false;
				this._onInput.fire();
			})
		);
		this.onkeydown(this.inputBox.inputElement, e => this._onKeyDown.fire(e));
		this.onkeyup(this.inputBox.inputElement, e => this._onKeyUp.fire(e));
		this.oninput(this.inputBox.inputElement, e => this._onInput.fire());
		this.onmousedown(this.inputBox.inputElement, e => this._onMouseDown.fire(e));
	}
	get onDidChange() {
		return this.inputBox.onDidChange;
	}
	layout(style) {
		this.inputBox.layout();
		this.updateInputBoxPadding(style.collapsedFindWidget);
	}
	enable() {
		this.domNode.classList.remove('disabled');
		this.inputBox.enable();
		this.regex?.enable?.();
		this.wholeWords?.enable();
		this.caseSensitive?.enable();
		for (const toggle of this.additionalToggles) {
			toggle.enable();
		}
	}
	disable() {
		this.domNode.classList.add('disabled');
		this.inputBox.disable();
		this.regex?.disable?.();
		this.wholeWords?.disable?.();
		this.caseSensitive?.disable?.();
		for (const toggle of this.additionalToggles) {
			toggle.disable();
		}
	}
	setFocusInputOnOptionClick(value) {
		this.fixFocusOnOptionClickEnabled = value;
	}
	setEnabled(enabled) {
		if (enabled) {
			this.enable();
		} else {
			this.disable();
		}
	}
	setAdditionalToggles(toggles) {
		for (const currentToggle of this.additionalToggles) {
			currentToggle.domNode.remove();
		}
		this.additionalToggles = [];
		this.additionalTogglesDisposables.value = new DisposableStore();
		for (const toggle of toggles !== null && toggles !== undefined ? toggles : []) {
			this.additionalTogglesDisposables.value.add(toggle);
			this.controls.appendChild(toggle.domNode);
			this.additionalTogglesDisposables.value.add(
				toggle.onChange(viaKeyboard => {
					this._onDidOptionChange.fire(viaKeyboard);
					if (!viaKeyboard && this.fixFocusOnOptionClickEnabled) {
						this.inputBox.focus();
					}
				})
			);
			this.additionalToggles.push(toggle);
		}
		if (this.additionalToggles.length > 0) {
			this.controls.style.display = '';
		}
		this.updateInputBoxPadding();
	}
	updateInputBoxPadding(controlsHidden = false) {
		if (controlsHidden) {
			this.inputBox.paddingRight = 0;
		} else {
			this.inputBox.paddingRight =
				(this.caseSensitive?.width() ?? 0) +
				(this.wholeWords?.width() ?? 0) +
				(this.regex?.width() ?? 0) +
				this.additionalToggles.reduce((r, t) => r + t.width(), 0);
		}
	}
	getValue() {
		return this.inputBox.value;
	}
	setValue(value) {
		if (this.inputBox.value !== value) {
			this.inputBox.value = value;
		}
	}
	select() {
		this.inputBox.select();
	}
	focus() {
		this.inputBox.focus();
	}
	getCaseSensitive() {
		return this.caseSensitive?.checked ?? false;
	}
	setCaseSensitive(value) {
		if (this.caseSensitive) {
			this.caseSensitive.checked = value;
		}
	}
	getWholeWords() {
		return this.wholeWords?.checked ?? false;
	}
	setWholeWords(value) {
		if (this.wholeWords) {
			this.wholeWords.checked = value;
		}
	}
	getRegex() {
		return this.regex?.checked ?? false;
	}
	setRegex(value) {
		if (this.regex) {
			this.regex.checked = value;
			this.validate();
		}
	}
	focusOnCaseSensitive() {
		this.caseSensitive?.focus();
	}
	highlightFindOptions() {
		this.domNode.classList.remove('highlight-' + this._lastHighlightFindOptions);
		this._lastHighlightFindOptions = 1 - this._lastHighlightFindOptions;
		this.domNode.classList.add('highlight-' + this._lastHighlightFindOptions);
	}
	validate() {
		this.inputBox.validate();
	}
	showMessage(message) {
		this.inputBox.showMessage(message);
	}
	clearMessage() {
		this.inputBox.hideMessage();
	}
}





//AbstractTree

class FindFilter {
	get totalCount() {
		return this._totalCount;
	}
	get matchCount() {
		return this._matchCount;
	}
	constructor(tree, keyboardNavigationLabelProvider, _filter) {
		this.tree = tree;
		this.keyboardNavigationLabelProvider = keyboardNavigationLabelProvider;
		this._filter = _filter;
		this._totalCount = 0;
		this._matchCount = 0;
		this._pattern = '';
		this._lowercasePattern = '';
		this.disposables = new DisposableStore();
		tree.onWillRefilter(this.reset, this, this.disposables);
	}
	filter(element, parentVisibility) {
		let visibility = 1;
		if (this._filter) {
			const result = this._filter.filter(element, parentVisibility);
			if (typeof result === 'boolean') {
				visibility = result ? 1 : 0;
			} else if (isFilterResult(result)) {
				visibility = getVisibleState(result.visibility);
			} else {
				visibility = result;
			}
			if (visibility === 0) {
				return false;
			}
		}
		this._totalCount++;
		if (!this._pattern) {
			this._matchCount++;
			return { data: fuzzyScoreDefault, visibility };
		}
		const label = this.keyboardNavigationLabelProvider.getKeyboardNavigationLabel(element);
		const labels = isArray(label) ? label : [label];
		for (const l of labels) {
			const labelStr = l && l.toString();
			if (typeof labelStr === 'undefined') {
				return { data: fuzzyScoreDefault, visibility };
			}
			let score3;
			if (this.tree.findMatchType === TreeFindMatchType.Contiguous) {
				const index = labelStr.toLowerCase().indexOf(this._lowercasePattern);
				if (index > -1) {
					score3 = [Number.MAX_SAFE_INTEGER, 0];
					for (let i = this._lowercasePattern.length; i > 0; i--) {
						score3.push(index + i - 1);
					}
				}
			} else {
				score3 = fuzzyScore(this._pattern, this._lowercasePattern, 0, labelStr, labelStr.toLowerCase(), 0, {
					firstMatchCanBeWeak: true,
					boostFullMatch: true
				});
			}
			if (score3) {
				this._matchCount++;
				return labels.length === 1 ? { data: score3, visibility } : { data: { label: labelStr, score: score3 }, visibility };
			}
		}
		if (this.tree.findMode === 1) {
			if (typeof this.tree.options.defaultFindVisibility === 'number') {
				return this.tree.options.defaultFindVisibility;
			} else if (this.tree.options.defaultFindVisibility) {
				return this.tree.options.defaultFindVisibility(element);
			} else {
				return 2;
			}
		} else {
			return { data: fuzzyScoreDefault, visibility };
		}
	}
	reset() {
		this._totalCount = 0;
		this._matchCount = 0;
	}
	dispose() {
		dispose(this.disposables);
	}
}

class FindController {
	get pattern() {
		return this._pattern;
	}
	get mode() {
		return this._mode;
	}
	set mode(mode) {
		if (mode === this._mode) {
			return;
		}
		this._mode = mode;
		if (this.widget) {
			this.widget.mode = this._mode;
		}
		this.tree.refilter();
		this.render();
		this._onDidChangeMode.fire(mode);
	}
	get matchType() {
		return this._matchType;
	}
	set matchType(matchType) {
		if (matchType === this._matchType) {
			return;
		}
		this._matchType = matchType;
		if (this.widget) {
			this.widget.matchType = this._matchType;
		}
		this.tree.refilter();
		this.render();
		this._onDidChangeMatchType.fire(matchType);
	}
	constructor(tree, model, view, filter, contextViewProvider, options2 = {}) {
		this.tree = tree;
		this.view = view;
		this.filter = filter;
		this.contextViewProvider = contextViewProvider;
		this.options = options2;
		this._pattern = '';
		this.width = 0;
		this._onDidChangeMode = new Emitter();
		this.onDidChangeMode = this._onDidChangeMode.event;
		this._onDidChangeMatchType = new Emitter();
		this.onDidChangeMatchType = this._onDidChangeMatchType.event;
		this._onDidChangePattern = new Emitter();
		this._onDidChangeOpenState = new Emitter();
		this.onDidChangeOpenState = this._onDidChangeOpenState.event;
		this.enabledDisposables = new DisposableStore();
		this.disposables = new DisposableStore();
		this._mode = tree.options.defaultFindMode ?? 0;
		this._matchType = tree.options.defaultFindMatchType ?? TreeFindMatchType.Fuzzy;
		model.onDidSplice(this.onDidSpliceModel, this, this.disposables);
	}
	updateOptions(optionsUpdate = {}) {
		if (optionsUpdate.defaultFindMode !== undefined) {
			this.mode = optionsUpdate.defaultFindMode;
		}
		if (optionsUpdate.defaultFindMatchType !== undefined) {
			this.matchType = optionsUpdate.defaultFindMatchType;
		}
	}
	onDidSpliceModel() {
		if (!this.widget || this.pattern.length === 0) {
			return;
		}
		this.tree.refilter();
		this.render();
	}
	render() {
		const noMatches = this.filter.totalCount > 0 && this.filter.matchCount === 0;
		if (this.pattern && noMatches) {
			if (this.tree.options.showNotFoundMessage ?? true) {
				this.widget?.showMessage({
					type: 2,
					content: localize('No elements found.')
				});
			} else {
				this.widget?.showMessage({
					type: 2 //WARNING
				});
			}
		} else {
			this.widget?.clearMessage();
		}
	}
	shouldAllowFocus(node) {
		if (!this.widget || !this.pattern) {
			return true;
		}
		if (this.filter.totalCount > 0 && this.filter.matchCount <= 1) {
			return true;
		}
		return !isFuzzyScoreDefault(node.filterData);
	}
	layout(width2) {
		this.width = width2;
		this.widget?.layout(width2);
	}
	dispose() {
		this._history = undefined;
		this._onDidChangePattern.dispose();
		this.enabledDisposables.dispose();
		this.disposables.dispose();
	}
}


		if ((_options.findWidgetEnabled ?? true) && _options.keyboardNavigationLabelProvider && _options.contextViewProvider) {
			const opts = this.options.findWidgetStyles ? { styles: this.options.findWidgetStyles } : undefined;
			this.findController = new FindController(this, this.model, this.view, filter, _options.contextViewProvider, opts);
			this.focusNavigationFilter = node => this.findController.shouldAllowFocus(node);
			this.onDidChangeFindOpenState = this.findController.onDidChangeOpenState;
			this.disposables.add(this.findController);
			this.onDidChangeFindMode = this.findController.onDidChangeMode;
			this.onDidChangeFindMatchType = this.findController.onDidChangeMatchType;
		} else {
			this.onDidChangeFindMode = editorEvent_none;
			this.onDidChangeFindMatchType = editorEvent_none;
		}



		let filter;
		if (_options.keyboardNavigationLabelProvider) {
			filter = new FindFilter(this, _options.keyboardNavigationLabelProvider, _options.filter);
			_options = { ..._options, filter };
			this.disposables.add(filter);
		}