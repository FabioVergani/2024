



class LocalSelectionTransfer {
	constructor() {}
	static getInstance() {
		return LocalSelectionTransfer.INSTANCE;
	}
	hasData(proto) {
		return proto && proto === this.proto;
	}
	getData(proto) {
		if (this.hasData(proto)) {
			return this.data;
		}
		return;
	}
}
LocalSelectionTransfer.INSTANCE = new LocalSelectionTransfer();