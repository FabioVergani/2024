




const registerDocumentHighlightProvider = (languageSelector, provider) => {
	return getService_LanguageFeatures().documentHighlightProvider.register(languageSelector, provider);
};




class DocumentHighlightAdapter {
	constructor(_worker) {
		this._worker = _worker;
	}
	provideDocumentHighlights(model, position, token) {
		const resource = model.uri;
		return this._worker(resource)
			.then(worker2 => worker2.findDocumentHighlights(resource.toString(), fromPosition0(position)))
			.then(entries2 => {
				if (!entries2) {
					return;
				}
				return entries2.map(entry => {
					return {
						range: toRange0(entry.range),
						kind: toDocumentHighlightKind(entry.kind)
					};
				});
			});
	}
}



	if (modeConfiguration.documentHighlights) {
		providers.push(registerDocumentHighlightProvider(languageId, new DocumentHighlightAdapter(wk)));
	}

if (modeConfiguration.documentHighlights) {
		providers.push(registerDocumentHighlightProvider(languageId, new DocumentHighlightAdapter(wk)));
	}