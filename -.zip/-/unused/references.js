





















	registerColor(
		'symbolIcon.referenceForeground',
		{
			dark: colorId_foreground,
			light: colorId_foreground,
			hcDark: colorId_foreground,
			hcLight: colorId_foreground
		},
		localize(
			'The foreground color for reference symbols. These symbols appear in the outline, breadcrumb, and suggest widget.'
		)
	);


		this._register(_languageFeaturesService.referenceProvider.onDidChange(update));

			this._hasReferenceProvider.set(this._languageFeaturesService.referenceProvider.has(model));


		this.referenceProvider = new LanguageFeatureRegistry(this._score.bind(this));




class ReferenceAdapter {
	constructor(_worker) {
		this._worker = _worker;
	}
	provideReferences(model, position, context, token) {
		const resource = model.uri;
		return this._worker(resource)
			.then(worker2 => {
				return worker2.findReferences(resource.toString(), fromPosition0(position));
			})
			.then(entries2 => {
				if (!entries2) {
					return;
				}
				return entries2.map(toLocation);
			});
	}
}



	if (modeConfiguration.references) {
		const registerReferenceProvider = (languageSelector, provider) => {
			return getService_LanguageFeatures().referenceProvider.register(languageSelector, provider);
		};
		providers.push(registerReferenceProvider(languageId, new ReferenceAdapter(wk)));
	}

	if (!suggestOptions.showReferences) {
		result.add(
			21 // Reference
		);
	}