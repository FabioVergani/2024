


const createLocation0 = (uri, range) => ({ uri: uri, range: range });
const isValidLocation0 = e => isDefined(e) && isValidRange(e.range) && (isObjectString(e.uri) || isUndefined(e.uri));

const createLocationLink0 = (uri, targetRange, targetSelectionRange, originSelectionRange) => {
	return {
		targetUri: targetUri,
		targetRange: targetRange,
		targetSelectionRange: targetSelectionRange,
		originSelectionRange: originSelectionRange
	};
};
const isValidLocationLink0 = e => {
	return (
		isDefined(e) &&
		isValidRange0(e.targetRange) &&
		isObjectString(e.targetUri) &&
		(isValidRange0(e.targetSelectionRange) || isUndefined(e.targetSelectionRange)) &&
		(isValidRange0(e.originSelectionRange) || isUndefined(e.originSelectionRange))
	);
};

