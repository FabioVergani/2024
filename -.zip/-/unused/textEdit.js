



function TextEdit_replace(range2, newText) {
	return { range: range2, newText };
}

function TextEdit_insert(position, newText) {
	return { range: { start: position, end: position }, newText };
}

function TextEdit_del(range2) {
	return { range: range2, newText: '' };
}





function TextEdit_is(value) {
	var candidate = value;
	return isObjectLiteral(candidate) && isObjectString(candidate.newText) && isValidRange0(candidate.range);
}



const mergeSort = (data, fn) => {
	if (data.length <= 1) {
		return data;
	}
	var p = (data.length / 2) | 0;
	var left = data.slice(0, p);
	var right = data.slice(p);
	mergeSort(left, fn);
	mergeSort(right, fn);
	var leftIdx = 0;
	var rightIdx = 0;
	var i = 0;
	while (leftIdx < left.length && rightIdx < right.length) {
		var ret = fn(left[leftIdx], right[rightIdx]);
		if (ret <= 0) {
			data[i++] = left[leftIdx++];
		} else {
			data[i++] = right[rightIdx++];
		}
	}
	while (leftIdx < left.length) {
		data[i++] = left[leftIdx++];
	}
	while (rightIdx < right.length) {
		data[i++] = right[rightIdx++];
	}
	return data;
};


const applyEdits = (content, edits) => {
	var text2 = content.getText();
	var sortedEdits = mergeSort(edits, function (a, b) {
		var diff = a.range.start.line - b.range.start.line;
		if (diff === 0) {
			return a.range.start.character - b.range.start.character;
		}
		return diff;
	});
	var lastModifiedOffset = text2.length;
	for (var i = sortedEdits.length - 1; i >= 0; i--) {
		var e = sortedEdits[i];
		var startOffset = content.offsetAt(e.range.start);
		var endOffset = content.offsetAt(e.range.end);
		if (endOffset <= lastModifiedOffset) {
			text2 = text2.substring(0, startOffset) + e.newText + text2.substring(endOffset, text2.length);
		} else {
			throw new Error('Overlapping edit');
		}
		lastModifiedOffset = startOffset;
	}
	return text2;
};


class FullTextDocument {
	constructor(uri, languageId, version2, content) {
		this._uri = uri;
		this._languageId = languageId;
		this._version = version2;
		this._content = content;
		this._lineOffsets = undefined;
	}
	get uri() {
		return this._uri;
	}
	get languageId() {
		return this._languageId;
	}
	get version() {
		return this._version;
	}
	getText(range2) {
		if (range2) {
			const start = this.offsetAt(range2.start);
			const end = this.offsetAt(range2.end);
			return this._content.substring(start, end);
		}
		return this._content;
	}
	update({ text }, version2) {
		this._content = text;
		this._version = version2;
		this._lineOffsets = undefined;
	}
	getLineOffsets() {
		if (this._lineOffsets === undefined) {
			const lineOffsets = [];
			const text2 = this._content;
			let isLineStart = true;
			for (let i = 0; i < text2.length; i++) {
				if (isLineStart) {
					lineOffsets.push(i);
					isLineStart = false;
				}
				const ch = text2.charAt(i);
				isLineStart = ch === '\r' || ch === '\n';
				if (ch === '\r' && i + 1 < text2.length && text2.charAt(i + 1) === '\n') {
					i++;
				}
			}
			if (isLineStart && text2.length > 0) {
				lineOffsets.push(text2.length);
			}
			this._lineOffsets = lineOffsets;
		}
		return this._lineOffsets;
	}
	positionAt(offset) {
		offset = Math.max(Math.min(offset, this._content.length), 0);
		const lineOffsets = this.getLineOffsets();
		let low = 0,
			high = lineOffsets.length;
		if (high === 0) {
			return createPosition0(0, offset);
		}
		while (low < high) {
			const mid = Math.floor((low + high) / 2);
			if (lineOffsets[mid] > offset) {
				high = mid;
			} else {
				low = mid + 1;
			}
		}
		const line = low - 1;
		return createPosition0(line, offset - lineOffsets[line]);
	}
	offsetAt({ line, character }) {
		const lineOffsets = this.getLineOffsets();
		if (line >= lineOffsets.length) {
			return this._content.length;
		} else if (line < 0) {
			return 0;
		}
		const lineOffset = lineOffsets[line];
		const nextLineOffset = line + 1 < lineOffsets.length ? lineOffsets[line + 1] : this._content.length;
		return Math.max(Math.min(lineOffset + character, nextLineOffset), lineOffset);
	}
	get lineCount() {
		return this.getLineOffsets().length;
	}
}


function isValidTextDocument(e) {
	return isDefined(e) &&
		isObjectString(e.uri) &&
		(isUndefined(e.languageId) || isObjectString(e.languageId)) &&
		isUinteger(e.lineCount) &&
		isObjectFunction(e.getText) &&
		isObjectFunction(e.positionAt) &&
		isObjectFunction(e.offsetAt)
		? true
		: false;
}

function isValidChangeAnnotation(value) {
	var candidate = value;
	return (
		candidate !== undefined &&
		isObjectLiteral(candidate) &&
		isObjectString(candidate.label) &&
		(isBoolean(candidate.needsConfirmation) || candidate.needsConfirmation === undefined) &&
		(isObjectString(candidate.description) || candidate.description === undefined)
	);
}


function annotatedTextEdit_replace(range2, newText, annotation) {
	return { range: range2, newText, annotationId: annotation };
}
function annotatedTextEdit_insert(position, newText, annotation) {
	return {
		range: { start: position, end: position },
		newText,
		annotationId: annotation
	};
}
function annotatedTextEdit_del(range2, annotation) {
	return { range: range2, newText: '', annotationId: annotation };
}
function textDocumentEdit_is(value) {
	var candidate = value;
	return isDefined(candidate) && OptionalVersionedTextDocumentIdentifier.is(candidate.textDocument) && isArray(candidate.edits);
}