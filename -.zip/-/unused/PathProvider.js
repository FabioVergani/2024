class PathProvider extends SimplePasteAndDropProvider {
	constructor() {
		super(...arguments);
		this.kind = new HierarchicalKind('uri.absolute');
		this.dropMimeTypes = ['text/uri-list'];
		this.pasteMimeTypes = ['text/uri-list'];
	}
	async getEdit(dataTransfer, token) {
		const entries2 = await extractUriList(dataTransfer);
		if (!entries2.length || token.isCancellationRequested) {
			return;
		}
		let uriCount = 0;
		const insertText = entries2
			.map(({ uri, originalText }) => {
				if (uri.scheme === Schemas.file) {
					return uri.fsPath;
				} else {
					uriCount++;
					return originalText;
				}
			})
			.join(' ');
		let label;
		if (uriCount > 0) {
			label = entries2.length > 1 ? localize('Insert Uris') : localize('Insert Uri');
		} else {
			label = entries2.length > 1 ? localize('Insert Paths') : localize('Insert Path');
		}
		return {
			handledMimeType: 'text/uri-list',
			insertText,
			title: label,
			kind: this.kind
		};
	}
}
