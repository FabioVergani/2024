


function _merge(obj) {
	var i = 1,
		target,
		key;
	for (; i < arguments.length; i++) {
		target = arguments[i];
		for (key in target) {
			if (Object.prototype.hasOwnProperty.call(target, key)) {
				obj[key] = target[key];
			}
		}
	}
	return obj;
}


function use() {
	for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
		args[_key] = arguments[_key];
	}
	var opts = merge.apply(undefined, [{}].concat(args));
	var extensions = {
		renderers: {},
		childTokens: {}
	};
	var hasExtensions;
	args.forEach(function (pack) {
		if (pack.extensions) {
			hasExtensions = true;
			pack.extensions.forEach(function (ext) {
				if (!ext.name) {
					throw new Error('extension name required');
				}
				if (ext.renderer) {
					var prevRenderer = extensions.renderers ? extensions.renderers[ext.name] : null;
					if (prevRenderer) {
						extensions.renderers[ext.name] = function () {
							for (var _len2 = arguments.length, args2 = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
								args2[_key2] = arguments[_key2];
							}
							var ret = ext.renderer.apply(this, args2);
							if (ret === false) {
								ret = prevRenderer.apply(this, args2);
							}
							return ret;
						};
					} else {
						extensions.renderers[ext.name] = ext.renderer;
					}
				}
				if (ext.tokenizer) {
					if (!ext.level || (ext.level !== 'block' && ext.level !== 'inline')) {
						throw new Error("extension level must be 'block' or 'inline'");
					}
					if (extensions[ext.level]) {
						extensions[ext.level].unshift(ext.tokenizer);
					} else {
						extensions[ext.level] = [ext.tokenizer];
					}
					if (ext.start) {
						if (ext.level === 'block') {
							if (extensions.startBlock) {
								extensions.startBlock.push(ext.start);
							} else {
								extensions.startBlock = [ext.start];
							}
						} else if (ext.level === 'inline') {
							if (extensions.startInline) {
								extensions.startInline.push(ext.start);
							} else {
								extensions.startInline = [ext.start];
							}
						}
					}
				}
				if (ext.childTokens) {
					extensions.childTokens[ext.name] = ext.childTokens;
				}
			});
		}
		if (pack.renderer) {
			(function () {
				var renderer = editorDefaults.renderer || new Renderer2();
				var _loop = function _loop2(prop2) {
					var prevRenderer = renderer[prop2];
					renderer[prop2] = function () {
						for (var _len3 = arguments.length, args2 = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
							args2[_key3] = arguments[_key3];
						}
						var ret = pack.renderer[prop2].apply(renderer, args2);
						if (ret === false) {
							ret = prevRenderer.apply(renderer, args2);
						}
						return ret;
					};
				};
				for (var prop in pack.renderer) {
					_loop(prop);
				}
				opts.renderer = renderer;
			})();
		}
		if (pack.tokenizer) {
			(function () {
				var tokenizer = editorDefaults.tokenizer || new Tokenizer2();
				var _loop2 = function _loop22(prop2) {
					var prevTokenizer = tokenizer[prop2];
					tokenizer[prop2] = function () {
						for (var _len4 = arguments.length, args2 = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
							args2[_key4] = arguments[_key4];
						}
						var ret = pack.tokenizer[prop2].apply(tokenizer, args2);
						if (ret === false) {
							ret = prevTokenizer.apply(tokenizer, args2);
						}
						return ret;
					};
				};
				for (var prop in pack.tokenizer) {
					_loop2(prop);
				}
				opts.tokenizer = tokenizer;
			})();
		}
		if (pack.walkTokens) {
			var _walkTokens = editorDefaults.walkTokens;
			opts.walkTokens = function (token) {
				var values = [];
				values.push(pack.walkTokens.call(this, token));
				if (_walkTokens) {
					values = values.concat(_walkTokens.call(this, token));
				}
				return values;
			};
		}
		if (hasExtensions) {
			opts.extensions = extensions;
		}
		marked2.setOptions(opts);
	});
}



function _splitCells(tableRow, count) {
	const row = tableRow.replace(/\|/g, (match2, offset, str) => {
			let escaped = false,
				curr = offset;
			while (--curr >= 0 && str[curr] === '\\') {
				escaped = !escaped;
			}
			if (escaped) {
				return '|';
			} else {
				return ' |';
			}
		}),
		cells = row.split(/ \|/);
	let i = 0;
	if (!cells[0].trim()) {
		cells.shift();
	}
	if (cells.length > 0 && !cells[cells.length - 1].trim()) {
		cells.pop();
	}
	if (cells.length > count) {
		cells.splice(count);
	} else {
		while (cells.length < count) {
			cells.push('');
		}
	}
	for (; i < cells.length; i++) {
		cells[i] = cells[i].trim().replace(/\\\|/g, '|');
	}
	return cells;
}
function _findClosingBracket(str, b) {
	if (str.indexOf(b[1]) === -1) {
		return -1;
	}
	var l = str.length;
	var level = 0,
		i = 0;
	for (; i < l; i++) {
		if (str[i] === '\\') {
			i++;
		} else if (str[i] === b[0]) {
			level++;
		} else if (str[i] === b[1]) {
			level--;
			if (level < 0) {
				return i;
			}
		}
	}
	return -1;
}
function _repeatString(pattern, count) {
	if (count < 1) {
		return '';
	}
	var result = '';
	while (count > 1) {
		if (count & 1) {
			result += pattern;
		}
		count >>= 1;
		pattern += pattern;
	}
	return result + pattern;
}
function _outputLink(cap, link, raw, lexer3) {
	var href = link.href;
	var title = link.title ? _escape(link.title) : null;
	var text2 = cap[1].replace(/\\([\[\]])/g, '$1');
	if (cap[0].charAt(0) !== '!') {
		lexer3.state.inLink = true;
		var token = {
			type: 'link',
			raw,
			href,
			title,
			text: text2,
			tokens: lexer3.inlineTokens(text2)
		};
		lexer3.state.inLink = false;
		return token;
	}
	return {
		type: 'image',
		raw,
		href,
		title,
		text: _escape(text2)
	};
}
function _indentCodeCompensation(raw, text2) {
	var matchIndentToCode = raw.match(/^(\s+)(?:```)/);
	if (matchIndentToCode === null) {
		return text2;
	}
	var indentToCode = matchIndentToCode[1];
	return text2
		.split('\n')
		.map(function (node) {
			var matchIndentInNode = node.match(/^\s+/);
			if (matchIndentInNode === null) {
				return node;
			}
			var indentInNode = matchIndentInNode[0];
			if (indentInNode.length >= indentToCode.length) {
				return node.slice(indentToCode.length);
			}
			return node;
		})
		.join('\n');
}

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -



const caret_RE = /(^|[^\[])\^/g;

const _edit = (regex, opt) => {
	regex = typeof regex === 'string' ? regex : regex.source;
	opt = opt || '';
	const obj = {
		replace: function replace(name, val) {
			val = val.source || val;
			val = val.replace(caret_RE, '$1');
			regex = regex.replace(name, val);
			return obj;
		},
		getRegex: function getRegex() {
			return new RegExp(regex, opt);
		}
	};
	return obj;
};


const noopTest = {
	exec: function noopTest2() {}
};

