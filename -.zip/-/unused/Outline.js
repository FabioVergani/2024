



























class OutlineAdapterJS extends AdapterJS {
	async provideDocumentSymbols(model, token) {
		const resource = model.uri;
		const worker2 = await this._worker(resource);
		if (model.isDisposed()) {
			return;
		}
		const root = await worker2.getNavigationTree(resource.toString());
		if (!root || model.isDisposed()) {
			return;
		}
		const convert = (item, containerLabel) => {
			const _outlineTypeTableJS = {
				module: 1,
				class: 4,
				enum: 9, //<<
				interface: 10,
				method: 5,
				property: 6,
				getter: 6,
				setter: 6,
				var: 12,
				const: 12,
				'local var': 12,
				function: 11,
				'local function': 11
			};
			const result2 = {
				name: item.text,
				detail: '',
				kind: _outlineTypeTableJS[item.kind] || 12,
				range: this._textSpanToRange(model, item.spans[0]),
				selectionRange: this._textSpanToRange(model, item.spans[0]),
				tags: [],
				children: item.childItems?.map(child => convert(child, item.text)),
				containerName: containerLabel
			};
			return result2;
		};
		const result = root.childItems ? root.childItems.map(item => convert(item)) : [];
		return result;
	}
}






class DocumentSymbolAdapter {
	constructor(_worker) {
		this._worker = _worker;
	}
	provideDocumentSymbols(model, token) {
		const resource = model.uri;
		return this._worker(resource)
			.then(worker2 => worker2.findDocumentSymbols(resource.toString()))
			.then(items => {
				if (!items) {
					return;
				}

				function _toDocumentSymbol(symbol) {
					return {
						name: symbol.name,
						detail: symbol.detail ?? '',
						kind: toSymbolKind(symbol.kind),
						range: toRange0(symbol.range),
						selectionRange: toRange0(symbol.selectionRange),
						tags: symbol.tags ?? [],
						children: (symbol.children ?? []).map(item => _toDocumentSymbol(item))
					};
				}

				return items.map(item => {
					if ('children' in item) {
						return _toDocumentSymbol(item);
					}
					return {
						name: item.name,
						detail: '',
						containerName: item.containerName,
						kind: toSymbolKind(item.kind),
						range: toRange0(item.location.range),
						selectionRange: toRange0(item.location.range),
						tags: []
					};
				});
			});
	}
}



const registerDocumentSymbolProvider = (languageSelector, provider) => {
	return getService_LanguageFeatures().documentSymbolProvider.register(languageSelector, provider);
};
	if (modeConfiguration.documentSymbols) {
		providers.push(registerDocumentSymbolProvider(modeId, new OutlineAdapterJS(wk)));
	}


	//css
	if (modeConfiguration.documentSymbols) {
		providers.push(registerDocumentSymbolProvider(languageId, new DocumentSymbolAdapter(wk)));
	}
	//html
	if (modeConfiguration.documentSymbols) {
		providers.push(registerDocumentSymbolProvider(languageId, new DocumentSymbolAdapter(wk)));
	}
	//json
	if (modeConfiguration.documentSymbols) {
		providers.push(registerDocumentSymbolProvider(languageId, new DocumentSymbolAdapter(wk)));
	}

