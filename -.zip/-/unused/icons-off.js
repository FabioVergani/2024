
const codicon_symbolReference = registerFontCharacter('symbol-reference', 60052);




const codicon_wholeWord = registerFontCharacter('whole-word', 60286);
const codicon_regex = registerFontCharacter('regex', 60216);
const codicon_fold = registerFontCharacter('fold', 60149);

const codicon_preserveCase = registerFontCharacter('preserve-case', 60206);
const codicon_caseSensitive = registerFontCharacter('case-sensitive', 60081);





const codicon_lightBulb = registerFontCharacter('light-bulb', 60001);
const codicon_lightbulbAutofix = registerFontCharacter('lightbulb-autofix', 60179);
const codicon_lightbulbSparkle = registerFontCharacter('lightbulb-sparkle', 60447);
const codicon_lightbulbSparkleAutofix = registerFontCharacter('lightbulb-sparkle-autofix', 60447);

const codicon_more = registerFontCharacter('more', 60028);
const codicon_toolBarMore = registerFontCharacter('toolbar-more', 'more');


const codicon_sparkle = registerFontCharacter('sparkle', 60432);
const codicon_sparkleFilled = registerFontCharacter('sparkle-filled', 60449);


const codicon_arrowSwap = registerFontCharacter('arrow-swap', 60363);


const codicon_selection = registerFontCharacter('selection', 60293);
const codicon_primitiveSquare = registerFontCharacter('primitive-square', 60018);


const codicon_map = registerFontCharacter('map', 60421);
const codicon_unfold = registerFontCharacter('unfold', 60275);
const codicon_move = registerFontCharacter('move', 60194);
const codicon_discard = registerFontCharacter('discard', 60130);
const codicon_surroundWith = registerFontCharacter('surround-with', 60452);
const codicon_compareChanges = registerFontCharacter('compare-changes', 60157);


const codicon_replace = registerFontCharacter('replace', 60221);
const codicon_replaceAll = registerFontCharacter('replace-all', 60220);



const codicon_wrench = registerFontCharacter('wrench', 60261);

const codicon_splitHorizontal = registerFontCharacter('split-horizontal', 60246);
const codicon_splitVertical = registerFontCharacter('split-vertical', 60247);





