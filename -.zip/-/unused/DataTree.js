const getVisibleState = e => {
	switch (e) {
		case true:
			return 1;
		case false:
			return 0;
		default:
			return e;
	}
};

class TreeNodeListMouseController extends MouseController {
	constructor(list, tree, stickyScrollProvider) {
		super(list);
		this.tree = tree;
		this.stickyScrollProvider = stickyScrollProvider;
	}
	onViewPointer(e) {
		if (isButton(e.browserEvent.target) || isInputElement(e.browserEvent.target) || isMonacoEditor(e.browserEvent.target)) {
			return;
		}
		if (e.browserEvent.isHandledByList) {
			return;
		}
		const node = e.element;
		if (!node) {
			return super.onViewPointer(e);
		}
		if (this.isSelectionRangeChangeEvent(e) || this.isSelectionSingleChangeEvent(e)) {
			return super.onViewPointer(e);
		}
		const target = e.browserEvent.target;
		const onTwistie =
			target.classList.contains('monaco-tl-twistie') ||
			(target.classList.contains('monaco-icon-label') && target.classList.contains('folder-icon') && e.browserEvent.offsetX < 16);
		const isStickyElement = isStickyScrollElement(e.browserEvent.target);
		let expandOnlyOnTwistieClick = false;
		if (isStickyElement) {
			expandOnlyOnTwistieClick = true;
		} else if (typeof this.tree.expandOnlyOnTwistieClick === 'function') {
			expandOnlyOnTwistieClick = this.tree.expandOnlyOnTwistieClick(node.element);
		} else {
			expandOnlyOnTwistieClick = !!this.tree.expandOnlyOnTwistieClick;
		}
		if (!isStickyElement) {
			if (expandOnlyOnTwistieClick && !onTwistie && e.browserEvent.detail !== 2) {
				return super.onViewPointer(e);
			}
			if (!this.tree.expandOnDoubleClick && e.browserEvent.detail === 2) {
				return super.onViewPointer(e);
			}
		} else {
			this.handleStickyScrollMouseEvent(e, node);
		}
		if (node.collapsible && (!isStickyElement || onTwistie)) {
			const location = this.tree.getNodeLocation(node);
			const recursive = e.browserEvent.altKey;
			this.tree.setFocus([location]);
			this.tree.toggleCollapsed(location, recursive);
			if (onTwistie) {
				e.browserEvent.isHandledByList = true;
				return;
			}
		}
		if (!isStickyElement) {
			super.onViewPointer(e);
		}
	}
	handleStickyScrollMouseEvent(e, node) {
		if (isMonacoCustomToggle(e.browserEvent.target) || isActionItem(e.browserEvent.target)) {
			return;
		}
		const stickyScrollController = this.stickyScrollProvider();
		if (!stickyScrollController) {
			throw new Error('Sticky scroll controller not found');
		}
		const nodeIndex = this.list.indexOf(node);
		const elementScrollTop = this.list.getElementTop(nodeIndex);
		const elementTargetViewTop = stickyScrollController.nodePositionTopBelowWidget(node);
		this.tree.scrollTop = elementScrollTop - elementTargetViewTop;
		this.list.domFocus();
		this.list.setFocus([nodeIndex]);
		this.list.setSelection([nodeIndex]);
	}
	onDoubleClick(e) {
		const onTwistie = e.browserEvent.target.classList.contains('monaco-tl-twistie');
		if (onTwistie || !this.tree.expandOnDoubleClick) {
			return;
		}
		if (e.browserEvent.isHandledByList) {
			return;
		}
		super.onDoubleClick(e);
	}
	// to make sure dom focus is not stolen (for example with context menu)
	onMouseDown(e) {
		const target = e.browserEvent.target;
		if (!isStickyScrollContainer(target) && !isStickyScrollElement(target)) {
			super.onMouseDown(e);
			return;
		}
	}
	onContextMenu(e) {
		const target = e.browserEvent.target;
		if (!isStickyScrollContainer(target) && !isStickyScrollElement(target)) {
			super.onContextMenu(e);
			return;
		}
	}
}
class TreeNodeList extends List {
	constructor(user, container, virtualDelegate, renderers, focusTrait, selectionTrait, anchorTrait, options2) {
		super(user, container, virtualDelegate, renderers, options2);
		this.focusTrait = focusTrait;
		this.selectionTrait = selectionTrait;
		this.anchorTrait = anchorTrait;
	}
	createMouseController(options2) {
		return new TreeNodeListMouseController(this, options2.tree, options2.stickyScrollProvider);
	}
	splice(start, deleteCount, elements = []) {
		super.splice(start, deleteCount, elements);
		if (elements.length === 0) {
			return;
		}
		const additionalFocus = [];
		const additionalSelection = [];
		let anchor;
		elements.forEach((node, index) => {
			if (this.focusTrait.has(node)) {
				additionalFocus.push(start + index);
			}
			if (this.selectionTrait.has(node)) {
				additionalSelection.push(start + index);
			}
			if (this.anchorTrait.has(node)) {
				anchor = start + index;
			}
		});
		if (additionalFocus.length > 0) {
			super.setFocus(distinct([...super.getFocus(), ...additionalFocus]));
		}
		if (additionalSelection.length > 0) {
			super.setSelection(distinct([...super.getSelection(), ...additionalSelection]));
		}
		if (typeof anchor === 'number') {
			super.setAnchor(anchor);
		}
	}
	setFocus(indexes, browserEvent, fromAPI = false) {
		super.setFocus(indexes, browserEvent);
		if (!fromAPI) {
			this.focusTrait.set(
				indexes.map(i => this.element(i)),
				browserEvent
			);
		}
	}
	setSelection(indexes, browserEvent, fromAPI = false) {
		super.setSelection(indexes, browserEvent);
		if (!fromAPI) {
			this.selectionTrait.set(
				indexes.map(i => this.element(i)),
				browserEvent
			);
		}
	}
	setAnchor(index, fromAPI = false) {
		super.setAnchor(index);
		if (!fromAPI) {
			if (typeof index === 'undefined') {
				this.anchorTrait.set([]);
			} else {
				this.anchorTrait.set([this.element(index)]);
			}
		}
	}
}

class ComposedTreeDelegate {
	constructor(delegate) {
		this.delegate = delegate;
	}
	getHeight(element) {
		return this.delegate.getHeight(element.element);
	}
	getTemplateId(element) {
		return this.delegate.getTemplateId(element.element);
	}
	hasDynamicHeight(element) {
		return !!this.delegate.hasDynamicHeight && this.delegate.hasDynamicHeight(element.element);
	}
	setDynamicHeight(element, height) {
		this.delegate.setDynamicHeight?.call(this.delegate, element.element, height);
	}
}

class TreeElementsDragAndDropData extends ElementsDragAndDropData {
	constructor(data) {
		super(data.elements.map(node => node.element));
		this.data = data;
	}
}

class TreeNodeListDragAndDrop {
	constructor(modelProvider, dnd) {
		this.modelProvider = modelProvider;
		this.dnd = dnd;
		this.autoExpandDisposable = disposableNone;
		this.disposables = new DisposableStore();
	}
	getDragURI(node) {
		return this.dnd.getDragURI(node.element);
	}
	getDragLabel(nodes, originalEvent) {
		if (this.dnd.getDragLabel) {
			return this.dnd.getDragLabel(
				nodes.map(node => node.element),
				originalEvent
			);
		}
		return;
	}
	onDragStart(data, originalEvent) {
		this.dnd.onDragStart?.call(
			this.dnd,
			data instanceof ElementsDragAndDropData ? new TreeElementsDragAndDropData(data) : data,
			originalEvent
		);
	}
	onDragOver(data, targetNode, targetIndex, targetSector, originalEvent, raw = true) {
		const result = this.dnd.onDragOver(
			data instanceof ElementsDragAndDropData ? new TreeElementsDragAndDropData(data) : data,
			targetNode && targetNode.element,
			targetIndex,
			targetSector,
			originalEvent
		);
		const didChangeAutoExpandNode = this.autoExpandNode !== targetNode;
		if (didChangeAutoExpandNode) {
			this.autoExpandDisposable.dispose();
			this.autoExpandNode = targetNode;
		}
		if (typeof targetNode === 'undefined') {
			return result;
		}
		if (didChangeAutoExpandNode && typeof result !== 'boolean' && result.autoExpand) {
			this.autoExpandDisposable = disposableTimeout(
				() => {
					const model2 = this.modelProvider();
					const ref2 = model2.getNodeLocation(targetNode);
					if (model2.isCollapsed(ref2)) {
						model2.setCollapsed(ref2, false);
					}
					this.autoExpandNode = undefined;
				},
				500,
				this.disposables
			);
		}
		if (typeof result === 'boolean' || !result.accept || typeof result.bubble === 'undefined' || result.feedback) {
			if (!raw) {
				const accept = typeof result === 'boolean' ? result : result.accept;
				const effect = typeof result === 'boolean' ? undefined : result.effect;
				return { accept, effect, feedback: [targetIndex] };
			}
			return result;
		}
		if (result.bubble === 1) {
			const model2 = this.modelProvider();
			const ref2 = model2.getNodeLocation(targetNode);
			const parentRef = model2.getParentNodeLocation(ref2);
			const parentNode = model2.getNode(parentRef);
			const parentIndex = parentRef && model2.getListIndex(parentRef);
			return this.onDragOver(data, parentNode, parentIndex, targetSector, originalEvent, false);
		}
		const model = this.modelProvider();
		const ref = model.getNodeLocation(targetNode);
		const start = model.getListIndex(ref);
		const length = model.getListRenderCount(ref);
		return { ...result, feedback: range(start, start + length) };
	}
	drop(data, targetNode, targetIndex, targetSector, originalEvent) {
		this.autoExpandDisposable.dispose();
		this.autoExpandNode = undefined;
		this.dnd.drop(
			data instanceof ElementsDragAndDropData ? new TreeElementsDragAndDropData(data) : data,
			targetNode && targetNode.element,
			targetIndex,
			targetSector,
			originalEvent
		);
	}
	onDragEnd(originalEvent) {
		this.dnd.onDragEnd?.call(this.dnd, originalEvent);
	}
	dispose() {
		this.disposables.dispose();
		this.dnd.dispose();
	}
}

class EventCollection {
	get elements() {
		return this._elements;
	}
	constructor(onDidChange, _elements = []) {
		this._elements = _elements;
		this.disposables = new DisposableStore();
		this.onDidChange = editorEventForEach(onDidChange, elements => (this._elements = elements), this.disposables);
	}
	dispose() {
		this.disposables.dispose();
	}
}
class TreeRenderer {
	constructor(renderer, modelProvider, onDidChangeCollapseState, activeNodes, renderedIndentGuides, options2 = {}) {
		this.renderer = renderer;
		this.modelProvider = modelProvider;
		this.activeNodes = activeNodes;
		this.renderedIndentGuides = renderedIndentGuides;
		this.renderedElements = new Map();
		this.renderedNodes = new Map();
		this.indent = 8;
		this.hideTwistiesOfChildlessElements = false;
		this.shouldRenderIndentGuides = false;
		this.activeIndentNodes = new Set();
		this.indentGuidesDisposable = disposableNone;
		this.disposables = new DisposableStore();
		this.templateId = renderer.templateId;
		this.updateOptions(options2);
		editorEventMap(onDidChangeCollapseState, e => e.node)(this.onDidChangeNodeTwistieState, this, this.disposables);
		renderer.onDidChangeTwistieState?.call(renderer, this.onDidChangeTwistieState, this, this.disposables);
	}
	updateOptions(options2 = {}) {
		if (typeof options2.indent !== 'undefined') {
			const indent = clamp(options2.indent, 0, 40);
			if (indent !== this.indent) {
				this.indent = indent;
				for (const [node, templateData] of this.renderedNodes) {
					this.renderTreeElement(node, templateData);
				}
			}
		}
		if (typeof options2.renderIndentGuides !== 'undefined') {
			const shouldRenderIndentGuides = options2.renderIndentGuides !== RenderIndentGuides.None;
			if (shouldRenderIndentGuides !== this.shouldRenderIndentGuides) {
				this.shouldRenderIndentGuides = shouldRenderIndentGuides;
				for (const [node, templateData] of this.renderedNodes) {
					this._renderIndentGuides(node, templateData);
				}
				this.indentGuidesDisposable.dispose();
				if (shouldRenderIndentGuides) {
					const disposables = new DisposableStore();
					this.activeNodes.onDidChange(this._onDidChangeActiveNodes, this, disposables);
					this.indentGuidesDisposable = disposables;
					this._onDidChangeActiveNodes(this.activeNodes.elements);
				}
			}
		}
		if (typeof options2.hideTwistiesOfChildlessElements !== 'undefined') {
			this.hideTwistiesOfChildlessElements = options2.hideTwistiesOfChildlessElements;
		}
	}
	renderTemplate(container) {
		const el = append(container, createDomElement('.monaco-tl-row'));
		const indent = append(el, createDomElement('.monaco-tl-indent'));
		const twistie = append(el, createDomElement('.monaco-tl-twistie'));
		const contents = append(el, createDomElement('.monaco-tl-contents'));
		const templateData = this.renderer.renderTemplate(contents);
		return {
			container,
			indent,
			twistie,
			indentGuidesDisposable: disposableNone,
			templateData
		};
	}
	renderElement(node, index, templateData, height) {
		this.renderedNodes.set(node, templateData);
		this.renderedElements.set(node.element, node);
		this.renderTreeElement(node, templateData);
		this.renderer.renderElement(node, index, templateData.templateData, height);
	}
	disposeElement(node, index, templateData, height) {
		templateData.indentGuidesDisposable.dispose();
		this.renderer.disposeElement?.call(this.renderer, node, index, templateData.templateData, height);
		if (typeof height === 'number') {
			this.renderedNodes.delete(node);
			this.renderedElements.delete(node.element);
		}
	}
	disposeTemplate(templateData) {
		this.renderer.disposeTemplate(templateData.templateData);
	}
	onDidChangeTwistieState(element) {
		const node = this.renderedElements.get(element);
		if (!node) {
			return;
		}
		this.onDidChangeNodeTwistieState(node);
	}
	onDidChangeNodeTwistieState(node) {
		const templateData = this.renderedNodes.get(node);
		if (!templateData) {
			return;
		}
		this._onDidChangeActiveNodes(this.activeNodes.elements);
		this.renderTreeElement(node, templateData);
	}
	renderTreeElement(node, templateData) {
		const indent = 8 + (node.depth - 1) * this.indent;
		templateData.twistie.style.paddingLeft = `${indent}px`;
		templateData.indent.style.width = `${indent + this.indent - 16}px`;
		templateData.twistie.classList.remove(...asThemeIconClassNameArray(codicon_chevronDown));
		let twistieRendered = false;
		if (this.renderer.renderTwistie) {
			twistieRendered = this.renderer.renderTwistie(node.element, templateData.twistie);
		}
		if (node.collapsible && (!this.hideTwistiesOfChildlessElements || node.visibleChildrenCount > 0)) {
			if (!twistieRendered) {
				templateData.twistie.classList.add(...asThemeIconClassNameArray(codicon_chevronDown));
			}
			templateData.twistie.classList.add('collapsible');
			templateData.twistie.classList.toggle('collapsed', node.collapsed);
		} else {
			templateData.twistie.classList.remove('collapsible', 'collapsed');
		}
		this._renderIndentGuides(node, templateData);
	}
	_renderIndentGuides(node, templateData) {
		clearNode(templateData.indent);
		templateData.indentGuidesDisposable.dispose();
		if (!this.shouldRenderIndentGuides) {
			return;
		}
		const disposableStore = new DisposableStore();
		const model = this.modelProvider();
		while (true) {
			const ref = model.getNodeLocation(node);
			const parentRef = model.getParentNodeLocation(ref);
			if (!parentRef) {
				break;
			}
			const parent = model.getNode(parentRef);
			const guide = createDomElement('.indent-guide', {
				style: `width: ${this.indent}px`
			});
			if (this.activeIndentNodes.has(parent)) {
				guide.classList.add('active');
			}
			if (templateData.indent.childElementCount === 0) {
				templateData.indent.appendChild(guide);
			} else {
				templateData.indent.insertBefore(guide, templateData.indent.firstElementChild);
			}
			this.renderedIndentGuides.add(parent, guide);
			disposableStore.add(toDisposable(() => this.renderedIndentGuides.delete(parent, guide)));
			node = parent;
		}
		templateData.indentGuidesDisposable = disposableStore;
	}
	_onDidChangeActiveNodes(nodes) {
		if (!this.shouldRenderIndentGuides) {
			return;
		}
		const set = new Set();
		const model = this.modelProvider();
		nodes.forEach(node => {
			const ref = model.getNodeLocation(node);
			try {
				const parentRef = model.getParentNodeLocation(ref);
				if (node.collapsible && node.children.length > 0 && !node.collapsed) {
					set.add(node);
				} else if (parentRef) {
					set.add(model.getNode(parentRef));
				}
			} catch (exception) {}
		});
		this.activeIndentNodes.forEach(node => {
			if (!set.has(node)) {
				this.renderedIndentGuides.forEach(node, line => line.classList.remove('active'));
			}
		});
		set.forEach(node => {
			if (!this.activeIndentNodes.has(node)) {
				this.renderedIndentGuides.forEach(node, line => line.classList.add('active'));
			}
		});
		this.activeIndentNodes = set;
	}
	dispose() {
		this.renderedNodes.clear();
		this.renderedElements.clear();
		this.indentGuidesDisposable.dispose();
		dispose(this.disposables);
	}
}

class Trait2 {
	get nodeSet() {
		if (!this._nodeSet) {
			this._nodeSet = this.createNodeSet();
		}
		return this._nodeSet;
	}
	constructor(getFirstViewElementWithTrait, identityProvider) {
		this.getFirstViewElementWithTrait = getFirstViewElementWithTrait;
		this.identityProvider = identityProvider;
		this.nodes = [];
		this._onDidChange = new Emitter();
		this.onDidChange = this._onDidChange.event;
	}
	set(nodes, browserEvent) {
		if (!browserEvent?.__forceEvent && equals(this.nodes, nodes)) {
			return;
		}
		this._set(nodes, false, browserEvent);
	}
	_set(nodes, silent, browserEvent) {
		this.nodes = [...nodes];
		this.elements = undefined;
		this._nodeSet = undefined;
		if (!silent) {
			const that = this;
			this._onDidChange.fire({
				get elements() {
					return that.get();
				},
				browserEvent
			});
		}
	}
	get() {
		if (!this.elements) {
			this.elements = this.nodes.map(node => node.element);
		}
		return [...this.elements];
	}
	getNodes() {
		return this.nodes;
	}
	has(node) {
		return this.nodeSet.has(node);
	}
	onDidModelSplice({ insertedNodes, deletedNodes }) {
		const _dfs = (node, fn) => {
			fn(node);
			node.children.forEach(e => _dfs(e, fn));
		};

		if (!this.identityProvider) {
			const set = this.createNodeSet();
			const visit = node => set.delete(node);
			deletedNodes.forEach(node => _dfs(node, visit));
			this.set([...set.values()]);
			return;
		}
		const deletedNodesIdSet = new Set();
		const deletedNodesVisitor = node => deletedNodesIdSet.add(this.identityProvider.getId(node.element).toString());
		deletedNodes.forEach(node => _dfs(node, deletedNodesVisitor));
		const insertedNodesMap = new Map();
		const insertedNodesVisitor = node => insertedNodesMap.set(this.identityProvider.getId(node.element).toString(), node);
		insertedNodes.forEach(node => _dfs(node, insertedNodesVisitor));
		const nodes = [];
		for (const node of this.nodes) {
			const id = this.identityProvider.getId(node.element).toString();
			const wasDeleted = deletedNodesIdSet.has(id);
			if (!wasDeleted) {
				nodes.push(node);
			} else {
				const insertedNode = insertedNodesMap.get(id);
				if (insertedNode && insertedNode.visible) {
					nodes.push(insertedNode);
				}
			}
		}
		if (this.nodes.length > 0 && nodes.length === 0) {
			const node = this.getFirstViewElementWithTrait();
			if (node) {
				nodes.push(node);
			}
		}
		this._set(nodes, true);
	}
	createNodeSet() {
		const set = new Set();
		for (const node of this.nodes) {
			set.add(node);
		}
		return set;
	}
}

class AbstractTree {
	get onDidScroll() {
		return this.view.onDidScroll;
	}
	get onDidChangeFocus() {
		return this.eventBufferer.wrapEvent(this.focus.onDidChange);
	}
	get onDidChangeSelection() {
		return this.eventBufferer.wrapEvent(this.selection.onDidChange);
	}
	get onMouseDblClick() {
		return editorEventFilter(
			editorEventMap(this.view.onMouseDblClick, asTreeMouseEvent),
			e => e.target !== 3 //Filter
		);
	}
	get onMouseOver() {
		return editorEventMap(this.view.onMouseOver, asTreeMouseEvent);
	}
	get onMouseOut() {
		return editorEventMap(this.view.onMouseOut, asTreeMouseEvent);
	}
	get onContextMenu() {
		function _asTreeContextMenuEvent(event) {
			const { browserEvent, anchor, element } = event;
			return {
				element: element?.element || null,
				browserEvent: browserEvent,
				anchor: anchor,
				isStickyScroll: isStickyScrollContainer(browserEvent.target)
			};
		}
		return editorEventAny(
			editorEventFilter(editorEventMap(this.view.onContextMenu, _asTreeContextMenuEvent), e => !e.isStickyScroll),
			this.stickyScrollController?.onContextMenu ?? editorEvent_none
		);
	}
	get onPointer() {
		return editorEventMap(this.view.onPointer, asTreeMouseEvent);
	}
	get onKeyDown() {
		return this.view.onKeyDown;
	}
	get onDidFocus() {
		return this.view.onDidFocus;
	}
	get onDidChangeModel() {
		return this.model.onDidSplice;
	}
	get onDidChangeCollapseState() {
		return this.model.onDidChangeCollapseState;
	}
	get findMode() {
		return this.findController?.mode ?? 0;
	}
	set findMode(findMode) {
		if (this.findController) {
			this.findController.mode = findMode;
		}
	}
	get findMatchType() {
		return this.findController?.matchType ?? TreeFindMatchType.Fuzzy;
	}
	set findMatchType(findFuzzy) {
		if (this.findController) {
			this.findController.matchType = findFuzzy;
		}
	}
	get expandOnDoubleClick() {
		return typeof this._options.expandOnDoubleClick === 'undefined' ? true : this._options.expandOnDoubleClick;
	}
	get expandOnlyOnTwistieClick() {
		return typeof this._options.expandOnlyOnTwistieClick === 'undefined' ? true : this._options.expandOnlyOnTwistieClick;
	}
	get onDidDispose() {
		return this.view.onDidDispose;
	}
	constructor(_user, container, delegate, renderers, _options = {}) {
		this._user = _user;
		this._options = _options;
		this.eventBufferer = new EventBufferer();
		this.onDidChangeFindOpenState = editorEvent_none;
		this.onDidChangeStickyScrollFocused = editorEvent_none;
		this.disposables = new DisposableStore();
		this._onWillRefilter = new Emitter();
		this.onWillRefilter = this._onWillRefilter.event;
		this._onDidUpdateOptions = new Emitter();
		this.treeDelegate = new ComposedTreeDelegate(delegate);
		const onDidChangeCollapseStateRelay = new Relay();
		const onDidChangeActiveNodes = new Relay();
		const activeNodes = this.disposables.add(new EventCollection(onDidChangeActiveNodes.event));
		const renderedIndentGuides = new SetMap();
		this.renderers = renderers.map(
			r => new TreeRenderer(r, () => this.model, onDidChangeCollapseStateRelay.event, activeNodes, renderedIndentGuides, _options)
		);
		for (const r of this.renderers) {
			this.disposables.add(r);
		}

		let filter;

		this.focus = new Trait2(() => this.view.getFocusedElements()[0], _options.identityProvider);
		this.selection = new Trait2(() => this.view.getSelectedElements()[0], _options.identityProvider);
		this.anchor = new Trait2(() => this.view.getAnchorElement(), _options.identityProvider);
		function _asListOptions(modelProvider, options2) {
			return (
				options2 && {
					...options2,
					identityProvider: options2.identityProvider && {
						getId(el) {
							return options2.identityProvider.getId(el.element);
						}
					},
					dnd: options2.dnd && new TreeNodeListDragAndDrop(modelProvider, options2.dnd),
					multipleSelectionController: options2.multipleSelectionController && {
						isSelectionSingleChangeEvent(e) {
							return options2.multipleSelectionController.isSelectionSingleChangeEvent({
								...e,
								element: e.element
							});
						},
						isSelectionRangeChangeEvent(e) {
							return options2.multipleSelectionController.isSelectionRangeChangeEvent({
								...e,
								element: e.element
							});
						}
					},
					keyboardNavigationLabelProvider: options2.keyboardNavigationLabelProvider && {
						...options2.keyboardNavigationLabelProvider,
						getKeyboardNavigationLabel(node) {
							return options2.keyboardNavigationLabelProvider.getKeyboardNavigationLabel(node.element);
						}
					}
				}
			);
		}
		this.view = new TreeNodeList(_user, container, this.treeDelegate, this.renderers, this.focus, this.selection, this.anchor, {
			..._asListOptions(() => this.model, _options),
			tree: this,
			stickyScrollProvider: () => this.stickyScrollController
		});
		this.model = this.createModel(_user, this.view, _options);
		onDidChangeCollapseStateRelay.input = this.model.onDidChangeCollapseState;
		const onDidModelSplice = editorEventForEach(
			this.model.onDidSplice,
			e => {
				this.eventBufferer.bufferEvents(() => {
					this.focus.onDidModelSplice(e);
					this.selection.onDidModelSplice(e);
				});
			},
			this.disposables
		);
		onDidModelSplice(() => null, null, this.disposables);
		const activeNodesEmitter = this.disposables.add(new Emitter());
		const activeNodesDebounce = this.disposables.add(new Delayer(0));
		this.disposables.add(
			editorEventAny(
				onDidModelSplice,
				this.focus.onDidChange,
				this.selection.onDidChange
			)(() => {
				activeNodesDebounce.trigger(() => {
					const set = new Set();
					for (const node of this.focus.getNodes()) {
						set.add(node);
					}
					for (const node of this.selection.getNodes()) {
						set.add(node);
					}
					activeNodesEmitter.fire([...set.values()]);
				});
			})
		);
		onDidChangeActiveNodes.input = activeNodesEmitter.event;
		if (_options.keyboardSupport !== false) {
			const onKeyDown = editorEventChain(this.view.onKeyDown, $16 =>
				$16.filter(e => !isInputElement(e.target)).map(e => new StandardKeyboardEvent(e))
			);
			editorEventChain(onKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 15 //LeftArrow
				)
			)(this.onLeftArrow, this, this.disposables);
			editorEventChain(onKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 17 //RightArrow
				)
			)(this.onRightArrow, this, this.disposables);
			editorEventChain(onKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 10 //Space
				)
			)(this.onSpace, this, this.disposables);
		}

		this.onDidChangeFindMode = editorEvent_none;
		this.onDidChangeFindMatchType = editorEvent_none;

		if (_options.enableStickyScroll) {
			this.stickyScrollController = new StickyScrollController(
				this,
				this.model,
				this.view,
				this.renderers,
				this.treeDelegate,
				_options
			);
			this.onDidChangeStickyScrollFocused = this.stickyScrollController.onDidChangeHasFocus;
		}
		this.styleElement = createStyleSheet(this.view.getHTMLElement());
		this.getHTMLElement().classList.toggle('always', this._options.renderIndentGuides === RenderIndentGuides.Always);
	}
	updateOptions(optionsUpdate = {}) {
		this._options = { ...this._options, ...optionsUpdate };
		for (const renderer of this.renderers) {
			renderer.updateOptions(optionsUpdate);
		}
		this.view.updateOptions(this._options);
		this.findController?.updateOptions(optionsUpdate);
		this.updateStickyScroll(optionsUpdate);
		this._onDidUpdateOptions.fire(this._options);
		this.getHTMLElement().classList.toggle('always', this._options.renderIndentGuides === RenderIndentGuides.Always);
	}
	get options() {
		return this._options;
	}
	updateStickyScroll(optionsUpdate) {
		if (!this.stickyScrollController && this._options.enableStickyScroll) {
			this.stickyScrollController = new StickyScrollController(
				this,
				this.model,
				this.view,
				this.renderers,
				this.treeDelegate,
				this._options
			);
			this.onDidChangeStickyScrollFocused = this.stickyScrollController.onDidChangeHasFocus;
		} else if (this.stickyScrollController && !this._options.enableStickyScroll) {
			this.onDidChangeStickyScrollFocused = editorEvent_none;
			this.stickyScrollController.dispose();
			this.stickyScrollController = undefined;
		}
		this.stickyScrollController?.updateOptions(optionsUpdate);
	}
	getHTMLElement() {
		return this.view.getHTMLElement();
	}
	get scrollTop() {
		return this.view.scrollTop;
	}
	set scrollTop(scrollTop) {
		this.view.scrollTop = scrollTop;
	}
	get scrollHeight() {
		return this.view.scrollHeight;
	}
	get renderHeight() {
		return this.view.renderHeight;
	}
	domFocus() {
		if (this.stickyScrollController?.focusedLast()) {
			this.stickyScrollController.domFocus();
		} else {
			this.view.domFocus();
		}
	}
	layout(height, width) {
		this.view.layout(height, width);
		if (isNumberTypeAndIsNotNaN(width)) {
			this.findController?.layout(width);
		}
	}
	style(styles) {
		const suffix = `.${this.view.domId}`;
		const content = [];
		if (styles.treeIndentGuidesStroke) {
			content.push(
				`.monaco-list${suffix}:hover .monaco-tl-indent > .indent-guide, .monaco-list${suffix}.always .monaco-tl-indent > .indent-guide  { border-color: ${styles.treeInactiveIndentGuidesStroke}; }`
			);
			content.push(
				`.monaco-list${suffix} .monaco-tl-indent > .indent-guide.active { border-color: ${styles.treeIndentGuidesStroke}; }`
			);
		}
		const stickyScrollBackground = styles.treeStickyScrollBackground ?? styles.listBackground;
		if (stickyScrollBackground) {
			content.push(
				`.monaco-list${suffix} .monaco-scrollable-element .monaco-tree-sticky-container { background-color: ${stickyScrollBackground}; }`
			);
			content.push(
				`.monaco-list${suffix} .monaco-scrollable-element .monaco-tree-sticky-container .monaco-tree-sticky-row { background-color: ${stickyScrollBackground}; }`
			);
		}
		if (styles.treeStickyScrollBorder) {
			content.push(
				`.monaco-list${suffix} .monaco-scrollable-element .monaco-tree-sticky-container { border-bottom: 1px solid ${styles.treeStickyScrollBorder}; }`
			);
		}
		if (styles.treeStickyScrollShadow) {
			content.push(
				`.monaco-list${suffix} .monaco-scrollable-element .monaco-tree-sticky-container .monaco-tree-sticky-container-shadow { box-shadow: ${styles.treeStickyScrollShadow} 0 6px 6px -6px inset; height: 3px; }`
			);
		}
		if (styles.listFocusForeground) {
			content.push(
				`.monaco-list${suffix}.sticky-scroll-focused .monaco-scrollable-element .monaco-tree-sticky-container:focus .monaco-list-row.focused { color: ${styles.listFocusForeground}; }`
			);
			content.push(
				`.monaco-list${suffix}:not(.sticky-scroll-focused) .monaco-scrollable-element .monaco-tree-sticky-container .monaco-list-row.focused { color: inherit; }`
			);
		}
		const focusAndSelectionOutline = asCssValueWithDefault(
			styles.listFocusAndSelectionOutline,
			asCssValueWithDefault(styles.listSelectionOutline, styles.listFocusOutline || '')
		);
		if (focusAndSelectionOutline) {
			content.push(
				`.monaco-list${suffix}.sticky-scroll-focused .monaco-scrollable-element .monaco-tree-sticky-container:focus .monaco-list-row.focused.selected { outline: 1px solid ${focusAndSelectionOutline}; outline-offset: -1px;}`
			);
			content.push(
				`.monaco-list${suffix}:not(.sticky-scroll-focused) .monaco-scrollable-element .monaco-tree-sticky-container .monaco-list-row.focused.selected { outline: inherit;}`
			);
		}
		if (styles.listFocusOutline) {
			content.push(
				`.monaco-list${suffix}.sticky-scroll-focused .monaco-scrollable-element .monaco-tree-sticky-container:focus .monaco-list-row.focused { outline: 1px solid ${styles.listFocusOutline}; outline-offset: -1px; }`
			);
			content.push(
				`.monaco-list${suffix}:not(.sticky-scroll-focused) .monaco-scrollable-element .monaco-tree-sticky-container .monaco-list-row.focused { outline: inherit; }`
			);
			content.push(
				`.monaco-workbench.context-menu-visible .monaco-list${suffix}.last-focused.sticky-scroll-focused .monaco-scrollable-element .monaco-tree-sticky-container .monaco-list-row.passive-focused { outline: 1px solid ${styles.listFocusOutline}; outline-offset: -1px; }`
			);
			content.push(
				`.monaco-workbench.context-menu-visible .monaco-list${suffix}.last-focused.sticky-scroll-focused .monaco-list-rows .monaco-list-row.focused { outline: inherit; }`
			);
			content.push(
				`.monaco-workbench.context-menu-visible .monaco-list${suffix}.last-focused:not(.sticky-scroll-focused) .monaco-tree-sticky-container .monaco-list-rows .monaco-list-row.focused { outline: inherit; }`
			);
		}
		this.styleElement.textContent = content.join('\n');
		this.view.style(styles);
	}
	// Tree navigation
	getParentElement(location) {
		const parentRef = this.model.getParentNodeLocation(location);
		const parentNode = this.model.getNode(parentRef);
		return parentNode.element;
	}
	getFirstElementChild(location) {
		return this.model.getFirstElementChild(location);
	}
	// Tree
	getNode(location) {
		return this.model.getNode(location);
	}
	getNodeLocation(node) {
		return this.model.getNodeLocation(node);
	}
	collapse(location, recursive = false) {
		return this.model.setCollapsed(location, true, recursive);
	}
	expand(location, recursive = false) {
		return this.model.setCollapsed(location, false, recursive);
	}
	toggleCollapsed(location, recursive = false) {
		return this.model.setCollapsed(location, undefined, recursive);
	}
	isCollapsible(location) {
		return this.model.isCollapsible(location);
	}
	setCollapsible(location, collapsible) {
		return this.model.setCollapsible(location, collapsible);
	}
	isCollapsed(location) {
		return this.model.isCollapsed(location);
	}
	refilter() {
		this._onWillRefilter.fire(undefined);
		this.model.refilter();
	}
	setSelection(elements, browserEvent) {
		this.eventBufferer.bufferEvents(() => {
			const nodes = elements.map(e => this.model.getNode(e));
			this.selection.set(nodes, browserEvent);
			const indexes = elements.map(e => this.model.getListIndex(e)).filter(i => i > -1);
			this.view.setSelection(indexes, browserEvent, true);
		});
	}
	getSelection() {
		return this.selection.get();
	}
	setFocus(elements, browserEvent) {
		this.eventBufferer.bufferEvents(() => {
			const nodes = elements.map(e => this.model.getNode(e));
			this.focus.set(nodes, browserEvent);
			const indexes = elements.map(e => this.model.getListIndex(e)).filter(i => i > -1);
			this.view.setFocus(indexes, browserEvent, true);
		});
	}
	focusNext(
		n = 1,
		loop = false,
		browserEvent,
		filter = isKeyboardEvent(browserEvent) && browserEvent.altKey ? undefined : this.focusNavigationFilter
	) {
		this.view.focusNext(n, loop, browserEvent, filter);
	}
	focusPrevious(
		n = 1,
		loop = false,
		browserEvent,
		filter = isKeyboardEvent(browserEvent) && browserEvent.altKey ? undefined : this.focusNavigationFilter
	) {
		this.view.focusPrevious(n, loop, browserEvent, filter);
	}
	focusNextPage(browserEvent, filter = isKeyboardEvent(browserEvent) && browserEvent.altKey ? undefined : this.focusNavigationFilter) {
		return this.view.focusNextPage(browserEvent, filter);
	}
	focusPreviousPage(
		browserEvent,
		filter = isKeyboardEvent(browserEvent) && browserEvent.altKey ? undefined : this.focusNavigationFilter
	) {
		return this.view.focusPreviousPage(browserEvent, filter, () => {
			return this.stickyScrollController?.height ?? 0;
		});
	}
	focusFirst(browserEvent, filter = isKeyboardEvent(browserEvent) && browserEvent.altKey ? undefined : this.focusNavigationFilter) {
		this.view.focusFirst(browserEvent, filter);
	}
	getFocus() {
		return this.focus.get();
	}
	reveal(location, relativeTop) {
		this.model.expandTo(location);
		const index = this.model.getListIndex(location);
		if (index === -1) {
			return;
		}
		if (!this.stickyScrollController) {
			this.view.reveal(index, relativeTop);
		} else {
			const paddingTop = this.stickyScrollController.nodePositionTopBelowWidget(this.getNode(location));
			this.view.reveal(index, relativeTop, paddingTop);
		}
	}
	// List
	onLeftArrow(e) {
		e.preventDefault();
		e.stopPropagation();
		const nodes = this.view.getFocusedElements();
		if (nodes.length === 0) {
			return;
		}
		const node = nodes[0];
		const location = this.model.getNodeLocation(node);
		const didChange = this.model.setCollapsed(location, true);
		if (!didChange) {
			const parentLocation = this.model.getParentNodeLocation(location);
			if (!parentLocation) {
				return;
			}
			const parentListIndex = this.model.getListIndex(parentLocation);
			this.view.reveal(parentListIndex);
			this.view.setFocus([parentListIndex]);
		}
	}
	onRightArrow(e) {
		e.preventDefault();
		e.stopPropagation();
		const nodes = this.view.getFocusedElements();
		if (nodes.length === 0) {
			return;
		}
		const node = nodes[0];
		const location = this.model.getNodeLocation(node);
		const didChange = this.model.setCollapsed(location, false);
		if (!didChange) {
			if (!node.children.some(child => child.visible)) {
				return;
			}
			const [focusedIndex] = this.view.getFocus();
			const firstChildIndex = focusedIndex + 1;
			this.view.reveal(firstChildIndex);
			this.view.setFocus([firstChildIndex]);
		}
	}
	onSpace(e) {
		e.preventDefault();
		e.stopPropagation();
		const nodes = this.view.getFocusedElements();
		if (nodes.length === 0) {
			return;
		}
		const node = nodes[0];
		const location = this.model.getNodeLocation(node);
		const recursive = e.browserEvent.altKey;
		this.model.setCollapsed(location, undefined, recursive);
	}
	dispose() {
		dispose(this.disposables);
		this.stickyScrollController?.dispose();
		this.view.dispose();
	}
}

const _isFilterResult = e => typeof e === 'object' && 'visibility' in e && 'data' in e;

class IndexTreeModel {
	constructor(user, list, rootElement, options2 = {}) {
		this.user = user;
		this.list = list;
		this.rootRef = [];
		this.eventBufferer = new EventBufferer();
		this._onDidChangeCollapseState = new Emitter();
		this.onDidChangeCollapseState = this.eventBufferer.wrapEvent(this._onDidChangeCollapseState.event);
		this._onDidChangeRenderNodeCount = new Emitter();
		this.onDidChangeRenderNodeCount = this.eventBufferer.wrapEvent(this._onDidChangeRenderNodeCount.event);
		this._onDidSplice = new Emitter();
		this.onDidSplice = this._onDidSplice.event;
		this.refilterDelayer = new Delayer(MicrotaskDelay);
		this.collapseByDefault = typeof options2.collapseByDefault === 'undefined' ? false : options2.collapseByDefault;
		this.allowNonCollapsibleParents = options2.allowNonCollapsibleParents ?? false;
		this.filter = options2.filter;
		this.autoExpandSingleChildren =
			typeof options2.autoExpandSingleChildren === 'undefined' ? false : options2.autoExpandSingleChildren;
		this.root = {
			parent: undefined,
			element: rootElement,
			children: [],
			depth: 0,
			visibleChildrenCount: 0,
			visibleChildIndex: -1,
			collapsible: false,
			collapsed: false,
			renderNodeCount: 0,
			visibility: 1,
			visible: true,
			filterData: undefined
		};
	}
	splice(location, deleteCount, toInsert = [], options2 = {}) {
		if (location.length === 0) {
			throw new Error(`[${this.user}] Invalid tree location`);
		}
		if (options2.diffIdentityProvider) {
			this.spliceSmart(options2.diffIdentityProvider, location, deleteCount, toInsert, options2);
		} else {
			this.spliceSimple(location, deleteCount, toInsert, options2);
		}
	}
	spliceSmart(identity2, location, deleteCount, toInsertIterable, options2, recurseLevels) {
		if (toInsertIterable === undefined) {
			toInsertIterable = [];
		}
		if (recurseLevels === undefined) {
			recurseLevels = options2.diffDepth ?? 0;
		}
		const { parentNode } = this.getParentNodeWithListIndex(location);
		if (!parentNode.lastDiffIds) {
			return this.spliceSimple(location, deleteCount, toInsertIterable, options2);
		}
		const toInsert = [...toInsertIterable];
		const index = location[location.length - 1];
		const diff = new LcsDiff(
			{ getElements: () => parentNode.lastDiffIds },
			{
				getElements: () =>
					[...parentNode.children.slice(0, index), ...toInsert, ...parentNode.children.slice(index + deleteCount)].map(e =>
						identity2.getId(e.element).toString()
					)
			}
		).ComputeDiff(false);
		if (diff.quitEarly) {
			parentNode.lastDiffIds = undefined;
			return this.spliceSimple(location, deleteCount, toInsert, options2);
		}
		const locationPrefix = location.slice(0, -1);
		const recurseSplice = (fromOriginal, fromModified, count) => {
			if (recurseLevels > 0) {
				for (let i = 0; i < count; i++) {
					fromOriginal--;
					fromModified--;
					this.spliceSmart(
						identity2,
						[...locationPrefix, fromOriginal, 0],
						Number.MAX_SAFE_INTEGER,
						toInsert[fromModified].children,
						options2,
						recurseLevels - 1
					);
				}
			}
		};
		let lastStartO = Math.min(parentNode.children.length, index + deleteCount);
		let lastStartM = toInsert.length;
		for (const change of diff.changes.sort((a, b) => b.originalStart - a.originalStart)) {
			recurseSplice(lastStartO, lastStartM, lastStartO - (change.originalStart + change.originalLength));
			lastStartO = change.originalStart;
			lastStartM = change.modifiedStart - index;
			this.spliceSimple(
				[...locationPrefix, lastStartO],
				change.originalLength,
				iterableSlice(toInsert, lastStartM, lastStartM + change.modifiedLength),
				options2
			);
		}
		recurseSplice(lastStartO, lastStartM, lastStartO);
	}
	spliceSimple(location, deleteCount, toInsert = [], { onDidCreateNode, onDidDeleteNode, diffIdentityProvider }) {
		const { parentNode, listIndex, revealed, visible } = this.getParentNodeWithListIndex(location);
		const treeListElementsToInsert = [];
		const nodesToInsertIterator = iterableMap(toInsert, el =>
			this.createTreeNode(el, parentNode, parentNode.visible ? 1 : 0, revealed, treeListElementsToInsert, onDidCreateNode)
		);
		const lastIndex = location[location.length - 1];
		let visibleChildStartIndex = 0;
		for (let i = lastIndex; i >= 0 && i < parentNode.children.length; i--) {
			const child = parentNode.children[i];
			if (child.visible) {
				visibleChildStartIndex = child.visibleChildIndex;
				break;
			}
		}
		const nodesToInsert = [];
		let insertedVisibleChildrenCount = 0;
		let renderNodeCount = 0;
		for (const child of nodesToInsertIterator) {
			nodesToInsert.push(child);
			renderNodeCount += child.renderNodeCount;
			if (child.visible) {
				child.visibleChildIndex = visibleChildStartIndex + insertedVisibleChildrenCount++;
			}
		}
		const deletedNodes = splice(parentNode.children, lastIndex, deleteCount, nodesToInsert);
		if (!diffIdentityProvider) {
			parentNode.lastDiffIds = undefined;
		} else if (parentNode.lastDiffIds) {
			splice(
				parentNode.lastDiffIds,
				lastIndex,
				deleteCount,
				nodesToInsert.map(n => diffIdentityProvider.getId(n.element).toString())
			);
		} else {
			parentNode.lastDiffIds = parentNode.children.map(n => diffIdentityProvider.getId(n.element).toString());
		}
		let deletedVisibleChildrenCount = 0;
		for (const child of deletedNodes) {
			if (child.visible) {
				deletedVisibleChildrenCount++;
			}
		}
		if (deletedVisibleChildrenCount !== 0) {
			for (let i = lastIndex + nodesToInsert.length; i < parentNode.children.length; i++) {
				const child = parentNode.children[i];
				if (child.visible) {
					child.visibleChildIndex -= deletedVisibleChildrenCount;
				}
			}
		}
		parentNode.visibleChildrenCount += insertedVisibleChildrenCount - deletedVisibleChildrenCount;
		if (revealed && visible) {
			const visibleDeleteCount = deletedNodes.reduce((r, node2) => r + (node2.visible ? node2.renderNodeCount : 0), 0);
			this._updateAncestorsRenderNodeCount(parentNode, renderNodeCount - visibleDeleteCount);
			this.list.splice(listIndex, visibleDeleteCount, treeListElementsToInsert);
		}
		if (deletedNodes.length > 0 && onDidDeleteNode) {
			const visit = node2 => {
				onDidDeleteNode(node2);
				node2.children.forEach(visit);
			};
			deletedNodes.forEach(visit);
		}
		this._onDidSplice.fire({ insertedNodes: nodesToInsert, deletedNodes });
		let node = parentNode;
		while (node) {
			if (node.visibility === 2) {
				this.refilterDelayer.trigger(() => this.refilter());
				break;
			}
			node = node.parent;
		}
	}
	rerender(location) {
		if (location.length === 0) {
			throw new Error(`[${this.user}] Invalid tree location`);
		}
		const { node, listIndex, revealed } = this.getTreeNodeWithListIndex(location);
		if (node.visible && revealed) {
			this.list.splice(listIndex, 1, [node]);
		}
	}
	has(location) {
		return this.hasTreeNode(location);
	}
	getListIndex(location) {
		const { listIndex, visible, revealed } = this.getTreeNodeWithListIndex(location);
		return visible && revealed ? listIndex : -1;
	}
	getListRenderCount(location) {
		return this.getTreeNode(location).renderNodeCount;
	}
	isCollapsible(location) {
		return this.getTreeNode(location).collapsible;
	}
	setCollapsible(location, collapsible) {
		const node = this.getTreeNode(location);
		if (typeof collapsible === 'undefined') {
			collapsible = !node.collapsible;
		}
		const update = { collapsible };
		return this.eventBufferer.bufferEvents(() => this._setCollapseState(location, update));
	}
	isCollapsed(location) {
		return this.getTreeNode(location).collapsed;
	}
	setCollapsed(location, collapsed2, recursive) {
		const node = this.getTreeNode(location);
		if (typeof collapsed2 === 'undefined') {
			collapsed2 = !node.collapsed;
		}
		const update = { collapsed: collapsed2, recursive: recursive || false };
		return this.eventBufferer.bufferEvents(() => this._setCollapseState(location, update));
	}
	_setCollapseState(location, update) {
		const { node, listIndex, revealed } = this.getTreeNodeWithListIndex(location);
		const result = this._setListNodeCollapseState(node, listIndex, revealed, update);
		if (
			node !== this.root &&
			this.autoExpandSingleChildren &&
			result &&
			'boolean' !== update.collapsible &&
			node.collapsible &&
			!node.collapsed &&
			!update.recursive
		) {
			let onlyVisibleChildIndex = -1;
			for (let i = 0; i < node.children.length; i++) {
				const child = node.children[i];
				if (child.visible) {
					if (onlyVisibleChildIndex > -1) {
						onlyVisibleChildIndex = -1;
						break;
					} else {
						onlyVisibleChildIndex = i;
					}
				}
			}
			if (onlyVisibleChildIndex > -1) {
				this._setCollapseState([...location, onlyVisibleChildIndex], update);
			}
		}
		return result;
	}
	_setListNodeCollapseState(node, listIndex, revealed, update) {
		const result = this._setNodeCollapseState(node, update, false);
		if (!revealed || !node.visible || !result) {
			return result;
		}
		const previousRenderNodeCount = node.renderNodeCount;
		const toInsert = this.updateNodeAfterCollapseChange(node);
		const deleteCount = previousRenderNodeCount - (listIndex === -1 ? 0 : 1);
		this.list.splice(listIndex + 1, deleteCount, toInsert.slice(1));
		return result;
	}
	_setNodeCollapseState(node, update, deep) {
		let result;
		if (node === this.root) {
			result = false;
		} else {
			if ('boolean' === update.collapsible) {
				result = node.collapsible !== update.collapsible;
				node.collapsible = update.collapsible;
			} else if (!node.collapsible) {
				result = false;
			} else {
				result = node.collapsed !== update.collapsed;
				node.collapsed = update.collapsed;
			}
			if (result) {
				this._onDidChangeCollapseState.fire({ node, deep });
			}
		}
		if ('boolean' !== update.collapsible && update.recursive) {
			for (const child of node.children) {
				result = this._setNodeCollapseState(child, update, true) || result;
			}
		}
		return result;
	}
	expandTo(location) {
		this.eventBufferer.bufferEvents(() => {
			let node = this.getTreeNode(location);
			while (node.parent) {
				node = node.parent;
				location = location.slice(0, location.length - 1);
				if (node.collapsed) {
					this._setCollapseState(location, {
						collapsed: false,
						recursive: false
					});
				}
			}
		});
	}
	refilter() {
		const previousRenderNodeCount = this.root.renderNodeCount;
		const toInsert = this.updateNodeAfterFilterChange(this.root);
		this.list.splice(0, previousRenderNodeCount, toInsert);
		this.refilterDelayer.cancel();
	}
	createTreeNode(treeElement, parent, parentVisibility, revealed, treeListElements, onDidCreateNode) {
		const node = {
			parent,
			element: treeElement.element,
			children: [],
			depth: parent.depth + 1,
			visibleChildrenCount: 0,
			visibleChildIndex: -1,
			collapsible:
				typeof treeElement.collapsible === 'boolean' ? treeElement.collapsible : typeof treeElement.collapsed !== 'undefined',
			collapsed: typeof treeElement.collapsed === 'undefined' ? this.collapseByDefault : treeElement.collapsed,
			renderNodeCount: 1,
			visibility: 1,
			visible: true,
			filterData: undefined
		};
		const visibility = this._filterNode(node, parentVisibility);
		node.visibility = visibility;
		if (revealed) {
			treeListElements.push(node);
		}
		const childElements = treeElement.children || [];
		const childRevealed = revealed && visibility !== 0 && !node.collapsed;
		let visibleChildrenCount = 0;
		let renderNodeCount = 1;
		for (const el of childElements) {
			const child = this.createTreeNode(el, node, visibility, childRevealed, treeListElements, onDidCreateNode);
			node.children.push(child);
			renderNodeCount += child.renderNodeCount;
			if (child.visible) {
				child.visibleChildIndex = visibleChildrenCount++;
			}
		}
		if (!this.allowNonCollapsibleParents) {
			node.collapsible = node.collapsible || node.children.length > 0;
		}
		node.visibleChildrenCount = visibleChildrenCount;
		node.visible = visibility === 2 ? visibleChildrenCount > 0 : visibility === 1;
		if (!node.visible) {
			node.renderNodeCount = 0;
			if (revealed) {
				treeListElements.pop();
			}
		} else if (!node.collapsed) {
			node.renderNodeCount = renderNodeCount;
		}
		onDidCreateNode?.(node);
		return node;
	}
	updateNodeAfterCollapseChange(node) {
		const previousRenderNodeCount = node.renderNodeCount;
		const result = [];
		this._updateNodeAfterCollapseChange(node, result);
		this._updateAncestorsRenderNodeCount(node.parent, result.length - previousRenderNodeCount);
		return result;
	}
	_updateNodeAfterCollapseChange(node, result) {
		if (node.visible === false) {
			return 0;
		}
		result.push(node);
		node.renderNodeCount = 1;
		if (!node.collapsed) {
			for (const child of node.children) {
				node.renderNodeCount += this._updateNodeAfterCollapseChange(child, result);
			}
		}
		this._onDidChangeRenderNodeCount.fire(node);
		return node.renderNodeCount;
	}
	updateNodeAfterFilterChange(node) {
		const previousRenderNodeCount = node.renderNodeCount;
		const result = [];
		this._updateNodeAfterFilterChange(node, node.visible ? 1 : 0, result);
		this._updateAncestorsRenderNodeCount(node.parent, result.length - previousRenderNodeCount);
		return result;
	}
	_updateNodeAfterFilterChange(node, parentVisibility, result, revealed = true) {
		let visibility;
		if (node !== this.root) {
			visibility = this._filterNode(node, parentVisibility);
			if (visibility === 0) {
				node.visible = false;
				node.renderNodeCount = 0;
				return false;
			}
			if (revealed) {
				result.push(node);
			}
		}
		const resultStartLength = result.length;
		node.renderNodeCount = node === this.root ? 0 : 1;
		let hasVisibleDescendants = false;
		if (!node.collapsed || visibility !== 0) {
			let visibleChildIndex = 0;
			for (const child of node.children) {
				hasVisibleDescendants =
					this._updateNodeAfterFilterChange(child, visibility, result, revealed && !node.collapsed) || hasVisibleDescendants;
				if (child.visible) {
					child.visibleChildIndex = visibleChildIndex++;
				}
			}
			node.visibleChildrenCount = visibleChildIndex;
		} else {
			node.visibleChildrenCount = 0;
		}
		if (node !== this.root) {
			node.visible = visibility === 2 ? hasVisibleDescendants : visibility === 1;
			node.visibility = visibility;
		}
		if (!node.visible) {
			node.renderNodeCount = 0;
			if (revealed) {
				result.pop();
			}
		} else if (!node.collapsed) {
			node.renderNodeCount += result.length - resultStartLength;
		}
		this._onDidChangeRenderNodeCount.fire(node);
		return node.visible;
	}
	_updateAncestorsRenderNodeCount(node, diff) {
		if (diff === 0) {
			return;
		}
		while (node) {
			node.renderNodeCount += diff;
			this._onDidChangeRenderNodeCount.fire(node);
			node = node.parent;
		}
	}
	_filterNode(node, parentVisibility) {
		const result = this.filter ? this.filter.filter(node.element, parentVisibility) : 1;
		if (typeof result === 'boolean') {
			node.filterData = undefined;
			return result ? 1 : 0;
		} else if (_isFilterResult(result)) {
			node.filterData = result.data;
			return getVisibleState(result.visibility);
		} else {
			node.filterData = undefined;
			return getVisibleState(result);
		}
	}
	hasTreeNode(location, node = this.root) {
		if (!location || location.length === 0) {
			return true;
		}
		const [index, ...rest] = location;
		if (index < 0 || index > node.children.length) {
			return false;
		}
		return this.hasTreeNode(rest, node.children[index]);
	}
	getTreeNode(location, node = this.root) {
		if (!location || location.length === 0) {
			return node;
		}
		const [index, ...rest] = location;
		if (index < 0 || index > node.children.length) {
			throw new Error(`[${this.user}] Invalid tree location`);
		}
		return this.getTreeNode(rest, node.children[index]);
	}
	getTreeNodeWithListIndex(location) {
		if (location.length === 0) {
			return {
				node: this.root,
				listIndex: -1,
				revealed: true,
				visible: false
			};
		}
		const { parentNode, listIndex, revealed, visible } = this.getParentNodeWithListIndex(location);
		const index = location[location.length - 1];
		if (index < 0 || index > parentNode.children.length) {
			throw new Error(`[${this.user}] Invalid tree location`);
		}
		const node = parentNode.children[index];
		return { node, listIndex, revealed, visible: visible && node.visible };
	}
	getParentNodeWithListIndex(location, node = this.root, listIndex = 0, revealed = true, visible = true) {
		const [index, ...rest] = location;
		if (index < 0 || index > node.children.length) {
			throw new Error(`[${this.user}] Invalid tree location`);
		}
		for (let i = 0; i < index; i++) {
			listIndex += node.children[i].renderNodeCount;
		}
		revealed = revealed && !node.collapsed;
		visible = visible && node.visible;
		if (rest.length === 0) {
			return { parentNode: node, listIndex, revealed, visible };
		}
		return this.getParentNodeWithListIndex(rest, node.children[index], listIndex + 1, revealed, visible);
	}
	getNode(location = []) {
		return this.getTreeNode(location);
	}
	// TODO@joao perf!
	getNodeLocation(node) {
		const location = [];
		let indexTreeNode = node;
		while (indexTreeNode.parent) {
			location.push(indexTreeNode.parent.children.indexOf(indexTreeNode));
			indexTreeNode = indexTreeNode.parent;
		}
		return location.reverse();
	}
	getParentNodeLocation(e) {
		const n = e.length;
		if (n === 0) {
			return;
		} else if (n === 1) {
			return [];
		} else {
			return e.slice(0, n - 1);
		}
	}
	getFirstElementChild(location) {
		const node = this.getTreeNode(location);
		if (node.children.length === 0) {
			return;
		}
		return node.children[0].element;
	}
}

const asTreeMouseEvent = event => {
	let target = 0; //Unknown
	if (hasParentWithClass(event.browserEvent.target, 'monaco-tl-twistie', 'monaco-tl-row')) {
		target = 1; //Twistie
	} else if (hasParentWithClass(event.browserEvent.target, 'monaco-tl-contents', 'monaco-tl-row')) {
		target = 2; //Element
	} else if (hasParentWithClass(event.browserEvent.target, 'monaco-tree-type-filter', 'monaco-list')) {
		target = 3; //Filter
	}
	return {
		browserEvent: event.browserEvent,
		element: event.element ? event.element.element : null,
		target
	};
};

class ObjectTreeModel {
	constructor(user, list, options2 = {}) {
		this.user = user;
		this.rootRef = null;
		this.nodes = new Map();
		this.nodesByIdentity = new Map();
		this.model = new IndexTreeModel(user, list, null, options2);
		this.onDidSplice = this.model.onDidSplice;
		this.onDidChangeCollapseState = this.model.onDidChangeCollapseState;
		this.onDidChangeRenderNodeCount = this.model.onDidChangeRenderNodeCount;
		if (options2.sorter) {
			this.sorter = {
				compare(a, b) {
					return options2.sorter.compare(a.element, b.element);
				}
			};
		}
		this.identityProvider = options2.identityProvider;
	}
	setChildren(element, children = [], options2 = {}) {
		const location = this.getElementLocation(element);
		this._setChildren(location, this.preserveCollapseState(children), options2);
	}
	_setChildren(location, children = [], options2) {
		const insertedElements = new Set();
		const insertedElementIds = new Set();
		const onDidCreateNode = node => {
			if (node.element === null) {
				return;
			}
			const tnode = node;
			insertedElements.add(tnode.element);
			this.nodes.set(tnode.element, tnode);
			if (this.identityProvider) {
				const id = this.identityProvider.getId(tnode.element).toString();
				insertedElementIds.add(id);
				this.nodesByIdentity.set(id, tnode);
			}
			options2.onDidCreateNode?.call(options2, tnode);
		};
		const onDidDeleteNode = node => {
			if (node.element === null) {
				return;
			}
			const tnode = node;
			if (!insertedElements.has(tnode.element)) {
				this.nodes.delete(tnode.element);
			}
			if (this.identityProvider) {
				const id = this.identityProvider.getId(tnode.element).toString();
				if (!insertedElementIds.has(id)) {
					this.nodesByIdentity.delete(id);
				}
			}
			options2.onDidDeleteNode?.call(options2, tnode);
		};
		this.model.splice([...location, 0], Number.MAX_VALUE, children, {
			...options2,
			onDidCreateNode,
			onDidDeleteNode
		});
	}
	preserveCollapseState(elements = []) {
		if (this.sorter) {
			elements = [...elements].sort(this.sorter.compare.bind(this.sorter));
		}
		return iterableMap(elements, treeElement => {
			let node = this.nodes.get(treeElement.element);
			if (!node && this.identityProvider) {
				const id = this.identityProvider.getId(treeElement.element).toString();
				node = this.nodesByIdentity.get(id);
			}
			if (!node) {
				let collapsed3;
				if (typeof treeElement.collapsed === 'undefined') {
					collapsed3 = undefined;
				} else if (
					treeElement.collapsed === 1 || //Collapsed
					treeElement.collapsed === 3 //PreserveOrCollapsed
				) {
					collapsed3 = true;
				} else if (
					treeElement.collapsed === 0 || // Expanded
					treeElement.collapsed === 2 //PreserveOrExpanded
				) {
					collapsed3 = false;
				} else {
					collapsed3 = Boolean(treeElement.collapsed);
				}
				return {
					...treeElement,
					children: this.preserveCollapseState(treeElement.children),
					collapsed: collapsed3
				};
			}
			const collapsible = typeof treeElement.collapsible === 'boolean' ? treeElement.collapsible : node.collapsible;
			let iscollpsed;
			if (
				typeof treeElement.collapsed === 'undefined' ||
				treeElement.collapsed === 3 || //PreserveOrCollapsed
				treeElement.collapsed === 2 //PreserveOrExpanded
			) {
				iscollpsed = node.collapsed;
			} else if (
				treeElement.collapsed === 1 //Collapsed
			) {
				iscollpsed = true;
			} else if (
				treeElement.collapsed === 0 //Expanded
			) {
				iscollpsed = false;
			} else {
				iscollpsed = Boolean(treeElement.collapsed);
			}
			return {
				...treeElement,
				collapsible,
				collapsed: iscollpsed,
				children: this.preserveCollapseState(treeElement.children)
			};
		});
	}
	rerender(element) {
		const location = this.getElementLocation(element);
		this.model.rerender(location);
	}
	getFirstElementChild(ref = null) {
		const location = this.getElementLocation(ref);
		return this.model.getFirstElementChild(location);
	}
	has(element) {
		return this.nodes.has(element);
	}
	getListIndex(element) {
		const location = this.getElementLocation(element);
		return this.model.getListIndex(location);
	}
	getListRenderCount(element) {
		const location = this.getElementLocation(element);
		return this.model.getListRenderCount(location);
	}
	isCollapsible(element) {
		const location = this.getElementLocation(element);
		return this.model.isCollapsible(location);
	}
	setCollapsible(element, collapsible) {
		const location = this.getElementLocation(element);
		return this.model.setCollapsible(location, collapsible);
	}
	isCollapsed(element) {
		const location = this.getElementLocation(element);
		return this.model.isCollapsed(location);
	}
	setCollapsed(element, collapsed2, recursive) {
		const location = this.getElementLocation(element);
		return this.model.setCollapsed(location, collapsed2, recursive);
	}
	expandTo(element) {
		const location = this.getElementLocation(element);
		this.model.expandTo(location);
	}
	refilter() {
		this.model.refilter();
	}
	getNode(element = null) {
		if (element === null) {
			return this.model.getNode(this.model.rootRef);
		}
		const node = this.nodes.get(element);
		if (!node) {
			throw new Error(`[${this.user}] Tree element not found: ${element}`);
		}
		return node;
	}
	getNodeLocation(node) {
		return node.element;
	}
	getParentNodeLocation(element) {
		if (element === null) {
			throw new Error(`[${this.user}] Invalid getParentNodeLocation call`);
		}
		const node = this.nodes.get(element);
		if (!node) {
			throw new Error(`[${this.user}] Tree element not found: ${element}`);
		}
		const location = this.model.getNodeLocation(node);
		const parentLocation = this.model.getParentNodeLocation(location);
		const parent = this.model.getNode(parentLocation);
		return parent.element;
	}
	getElementLocation(element) {
		if (element === null) {
			return [];
		}
		const node = this.nodes.get(element);
		if (!node) {
			throw new Error(`[${this.user}] Tree element not found: ${element}`);
		}
		return this.model.getNodeLocation(node);
	}
}

const noCompress = e => {
	return {
		element: {
			elements: [e.element],
			incompressible: e.incompressible || false
		},
		children: iterableMap(e.children || [], noCompress),
		collapsible: e.collapsible,
		collapsed: e.collapsed
	};
};

const compress = e => {
	const array = [e.element];
	function _consume(iterable, atMost = Number.POSITIVE_INFINITY) {
		const consumed = [];
		if (atMost === 0) {
			return [consumed, iterable];
		}
		const iterator = iterable[Symbol.iterator]();
		for (let i = 0; i < atMost; i++) {
			const next = iterator.next();
			if (next.done) {
				return [consumed, []];
			}
			consumed.push(next.value);
		}
		return [
			consumed,
			{
				[Symbol.iterator]() {
					return iterator;
				}
			}
		];
	}
	let childrenIterator;
	let children;
	while (true) {
		[children, childrenIterator] = _consume(e.children || [], 2);
		if (children.length !== 1) {
			break;
		}
		if (children[0].incompressible) {
			break;
		}
		e = children[0];
		array.push(e.element);
	}
	return {
		element: {
			elements: array,
			incompressible: e.incompressible || false
		},
		children: iterableMap(iterableConcat(children, childrenIterator), compress),
		collapsible: e.collapsible,
		collapsed: e.collapsed
	};
};

const decompress = x => {
	const _decompress = (e, index = 0) => {
		return {
			collapsible: e.collapsible,
			collapsed: e.collapsed,
			incompressible: index === 0 && e.element.incompressible ? true : false,
			element: e.element.elements[index],
			children:
				index < e.element.elements.length - 1
					? [_decompress(e, index + 1)]
					: iterableMap(e.children || [], el => _decompress(el, 0))
		};
	};
	return _decompress(x, 0);
};

const splice2 = (treeElement, element, children) => {
	return {
		...treeElement,
		children: element === treeElement.element ? children : iterableMap(treeElement.children || [], e => splice2(e, element, children))
	};
};

class CompressedTreeNodeWrapper {
	get element() {
		return this.node.element === null ? null : this.unwrapper(this.node.element);
	}
	get children() {
		return this.node.children.map(node => new CompressedTreeNodeWrapper(this.unwrapper, node));
	}
	get depth() {
		return this.node.depth;
	}
	get visibleChildrenCount() {
		return this.node.visibleChildrenCount;
	}
	get visibleChildIndex() {
		return this.node.visibleChildIndex;
	}
	get collapsible() {
		return this.node.collapsible;
	}
	get collapsed() {
		return this.node.collapsed;
	}
	get visible() {
		return this.node.visible;
	}
	get filterData() {
		return this.node.filterData;
	}
	constructor(unwrapper, node) {
		this.unwrapper = unwrapper;
		this.node = node;
	}
}

class WeakMapper {
	constructor(fn) {
		this.fn = fn;
		this._map = new WeakMap();
	}
	map(key) {
		let result = this._map.get(key);
		if (!result) {
			result = this.fn(key);
			this._map.set(key, result);
		}
		return result;
	}
}

class CompressedObjectTreeModel {
	get onDidSplice() {
		return this.model.onDidSplice;
	}
	get onDidChangeCollapseState() {
		return this.model.onDidChangeCollapseState;
	}
	get onDidChangeRenderNodeCount() {
		return this.model.onDidChangeRenderNodeCount;
	}
	constructor(user, list, options2 = {}) {
		this.user = user;
		this.rootRef = null;
		this.nodes = new Map();
		this.model = new ObjectTreeModel(user, list, options2);
		this.enabled = typeof options2.compressionEnabled === 'undefined' ? true : options2.compressionEnabled;
		this.identityProvider = options2.identityProvider;
	}
	setChildren(element, children = [], options2) {
		const _wrapIdentityProvider = base => ({
			getId(node) {
				return node.elements.map(e => base.getId(e).toString()).join('\0');
			}
		});
		const diffIdentityProvider = options2.diffIdentityProvider && _wrapIdentityProvider(options2.diffIdentityProvider);
		if (element === null) {
			const compressedChildren = iterableMap(children, this.enabled ? compress : noCompress);
			this._setChildren(null, compressedChildren, {
				diffIdentityProvider,
				diffDepth: Infinity
			});
			return;
		}
		const compressedNode = this.nodes.get(element);
		if (!compressedNode) {
			throw new Error(`[${this.user}] Unknown compressed tree node`);
		}
		const node = this.model.getNode(compressedNode);
		const compressedParentNode = this.model.getParentNodeLocation(compressedNode);
		const parent = this.model.getNode(compressedParentNode);
		const decompressedElement = decompress(node);
		const splicedElement = splice2(decompressedElement, element, children);
		const recompressedElement = (this.enabled ? compress : noCompress)(splicedElement);
		const elementComparator = options2.diffIdentityProvider
			? (a, b) => options2.diffIdentityProvider.getId(a) === options2.diffIdentityProvider.getId(b)
			: undefined;
		if (equals(recompressedElement.element.elements, node.element.elements, elementComparator)) {
			this._setChildren(compressedNode, recompressedElement.children || [], {
				diffIdentityProvider,
				diffDepth: 1
			});
			return;
		}
		const parentChildren = parent.children.map(child => (child === node ? recompressedElement : child));
		this._setChildren(parent.element, parentChildren, {
			diffIdentityProvider,
			diffDepth: node.depth - parent.depth
		});
	}
	isCompressionEnabled() {
		return this.enabled;
	}
	setCompressionEnabled(enabled) {
		if (enabled === this.enabled) {
			return;
		}
		this.enabled = enabled;
		const root = this.model.getNode();
		const rootChildren = root.children;
		const decompressedRootChildren = iterableMap(rootChildren, decompress);
		const recompressedRootChildren = iterableMap(decompressedRootChildren, enabled ? compress : noCompress);
		this._setChildren(null, recompressedRootChildren, {
			diffIdentityProvider: this.identityProvider,
			diffDepth: Infinity
		});
	}
	_setChildren(node, children, options2) {
		const insertedElements = new Set();
		const onDidCreateNode = node2 => {
			for (const element of node2.element.elements) {
				insertedElements.add(element);
				this.nodes.set(element, node2.element);
			}
		};
		const onDidDeleteNode = node2 => {
			for (const element of node2.element.elements) {
				if (!insertedElements.has(element)) {
					this.nodes.delete(element);
				}
			}
		};
		this.model.setChildren(node, children, {
			...options2,
			onDidCreateNode,
			onDidDeleteNode
		});
	}
	has(element) {
		return this.nodes.has(element);
	}
	getListIndex(location) {
		const node = this.getCompressedNode(location);
		return this.model.getListIndex(node);
	}
	getListRenderCount(location) {
		const node = this.getCompressedNode(location);
		return this.model.getListRenderCount(node);
	}
	getNode(location) {
		if (typeof location === 'undefined') {
			return this.model.getNode();
		}
		const node = this.getCompressedNode(location);
		return this.model.getNode(node);
	}
	// TODO: review this
	getNodeLocation(node) {
		const compressedNode = this.model.getNodeLocation(node);
		if (compressedNode === null) {
			return null;
		}
		return compressedNode.elements[compressedNode.elements.length - 1];
	}
	// TODO: review this
	getParentNodeLocation(location) {
		const compressedNode = this.getCompressedNode(location);
		const parentNode = this.model.getParentNodeLocation(compressedNode);
		if (parentNode === null) {
			return null;
		}
		return parentNode.elements[parentNode.elements.length - 1];
	}
	getFirstElementChild(location) {
		const compressedNode = this.getCompressedNode(location);
		return this.model.getFirstElementChild(compressedNode);
	}
	isCollapsible(location) {
		const compressedNode = this.getCompressedNode(location);
		return this.model.isCollapsible(compressedNode);
	}
	setCollapsible(location, collapsible) {
		const compressedNode = this.getCompressedNode(location);
		return this.model.setCollapsible(compressedNode, collapsible);
	}
	isCollapsed(location) {
		const compressedNode = this.getCompressedNode(location);
		return this.model.isCollapsed(compressedNode);
	}
	setCollapsed(location, collapsed2, recursive) {
		const compressedNode = this.getCompressedNode(location);
		return this.model.setCollapsed(compressedNode, collapsed2, recursive);
	}
	expandTo(location) {
		const compressedNode = this.getCompressedNode(location);
		this.model.expandTo(compressedNode);
	}
	rerender(location) {
		const compressedNode = this.getCompressedNode(location);
		this.model.rerender(compressedNode);
	}
	refilter() {
		this.model.refilter();
	}
	getCompressedNode(element) {
		if (element === null) {
			return null;
		}
		const node = this.nodes.get(element);
		if (!node) {
			throw new Error(`[${this.user}] Tree element not found: ${element}`);
		}
		return node;
	}
}

class CompressibleObjectTreeModel {
	get onDidSplice() {
		return editorEventMap(this.model.onDidSplice, ({ insertedNodes, deletedNodes }) => ({
			insertedNodes: insertedNodes.map(node => this.nodeMapper.map(node)),
			deletedNodes: deletedNodes.map(node => this.nodeMapper.map(node))
		}));
	}
	get onDidChangeCollapseState() {
		return editorEventMap(this.model.onDidChangeCollapseState, ({ node, deep }) => ({
			node: this.nodeMapper.map(node),
			deep
		}));
	}
	get onDidChangeRenderNodeCount() {
		return editorEventMap(this.model.onDidChangeRenderNodeCount, node => this.nodeMapper.map(node));
	}
	constructor(user, list, options2 = {}) {
		this.rootRef = null;
		this.elementMapper = options2.elementMapper || (e => e[e.length - 1]);
		const compressedNodeUnwrapper = node => this.elementMapper(node.elements);
		this.nodeMapper = new WeakMapper(node => new CompressedTreeNodeWrapper(compressedNodeUnwrapper, node));
		function _mapList(nodeMapper, list) {
			return {
				splice(start, deleteCount, toInsert) {
					list.splice(
						start,
						deleteCount,
						toInsert.map(node => nodeMapper.map(node))
					);
				},
				updateElementHeight(index, height) {
					list.updateElementHeight(index, height);
				}
			};
		}
		function _mapOptions(compressedNodeUnwrapper, options2) {
			return {
				...options2,
				identityProvider: options2.identityProvider && {
					getId(node) {
						return options2.identityProvider.getId(compressedNodeUnwrapper(node));
					}
				},
				sorter: options2.sorter && {
					compare(node, otherNode) {
						return options2.sorter.compare(node.elements[0], otherNode.elements[0]);
					}
				},
				filter: options2.filter && {
					filter(node, parentVisibility) {
						return options2.filter.filter(compressedNodeUnwrapper(node), parentVisibility);
					}
				}
			};
		}
		this.model = new CompressedObjectTreeModel(user, _mapList(this.nodeMapper, list), _mapOptions(compressedNodeUnwrapper, options2));
	}
	setChildren(element, children = [], options2 = {}) {
		this.model.setChildren(element, children, options2);
	}
	isCompressionEnabled() {
		return this.model.isCompressionEnabled();
	}
	setCompressionEnabled(enabled) {
		this.model.setCompressionEnabled(enabled);
	}
	has(location) {
		return this.model.has(location);
	}
	getListIndex(location) {
		return this.model.getListIndex(location);
	}
	getListRenderCount(location) {
		return this.model.getListRenderCount(location);
	}
	getNode(location) {
		return this.nodeMapper.map(this.model.getNode(location));
	}
	getNodeLocation(node) {
		return node.element;
	}
	getParentNodeLocation(location) {
		return this.model.getParentNodeLocation(location);
	}
	getFirstElementChild(location) {
		const result = this.model.getFirstElementChild(location);
		if (result === null || typeof result === 'undefined') {
			return result;
		}
		return this.elementMapper(result.elements);
	}
	isCollapsible(location) {
		return this.model.isCollapsible(location);
	}
	setCollapsible(location, collapsed2) {
		return this.model.setCollapsible(location, collapsed2);
	}
	isCollapsed(location) {
		return this.model.isCollapsed(location);
	}
	setCollapsed(location, collapsed2, recursive) {
		return this.model.setCollapsed(location, collapsed2, recursive);
	}
	expandTo(location) {
		return this.model.expandTo(location);
	}
	rerender(location) {
		return this.model.rerender(location);
	}
	refilter() {
		return this.model.refilter();
	}
	getCompressedTreeNode(location = null) {
		return this.model.getNode(location);
	}
}

class ObjectTree extends AbstractTree {
	get onDidChangeCollapseState() {
		return this.model.onDidChangeCollapseState;
	}
	constructor(user, container, delegate, renderers, options2 = {}) {
		super(user, container, delegate, renderers, options2);
		this.user = user;
	}
	setChildren(element, children = [], options2) {
		this.model.setChildren(element, children, options2);
	}
	rerender(element) {
		if (element === undefined) {
			this.view.rerender();
			return;
		}
		this.model.rerender(element);
	}
	hasElement(element) {
		return this.model.has(element);
	}
	createModel(user, view, options2) {
		return new ObjectTreeModel(user, view, options2);
	}
}

class CompressibleRenderer {
	get compressedTreeNodeProvider() {
		return this._compressedTreeNodeProvider();
	}
	constructor(_compressedTreeNodeProvider, stickyScrollDelegate, renderer) {
		this._compressedTreeNodeProvider = _compressedTreeNodeProvider;
		this.stickyScrollDelegate = stickyScrollDelegate;
		this.renderer = renderer;
		this.templateId = renderer.templateId;
		if (renderer.onDidChangeTwistieState) {
			this.onDidChangeTwistieState = renderer.onDidChangeTwistieState;
		}
	}
	renderTemplate(container) {
		const data = this.renderer.renderTemplate(container);
		return { compressedTreeNode: undefined, data };
	}
	renderElement(node, index, templateData, height) {
		let compressedTreeNode = this.stickyScrollDelegate.getCompressedNode(node);
		if (!compressedTreeNode) {
			compressedTreeNode = this.compressedTreeNodeProvider.getCompressedTreeNode(node.element);
		}
		if (compressedTreeNode.element.elements.length === 1) {
			templateData.compressedTreeNode = undefined;
			this.renderer.renderElement(node, index, templateData.data, height);
		} else {
			templateData.compressedTreeNode = compressedTreeNode;
			this.renderer.renderCompressedElements(compressedTreeNode, index, templateData.data, height);
		}
	}
	disposeElement(node, index, templateData, height) {
		if (templateData.compressedTreeNode) {
			this.renderer.disposeCompressedElements?.call(this.renderer, templateData.compressedTreeNode, index, templateData.data, height);
		} else {
			this.renderer.disposeElement?.call(this.renderer, node, index, templateData.data, height);
		}
	}
	disposeTemplate(templateData) {
		this.renderer.disposeTemplate(templateData.data);
	}
	renderTwistie(element, twistieElement) {
		if (this.renderer.renderTwistie) {
			return this.renderer.renderTwistie(element, twistieElement);
		}
		return false;
	}
}
__decorate([memoizeMethod], CompressibleRenderer.prototype, 'compressedTreeNodeProvider', null);

class CompressibleStickyScrollDelegate {
	constructor(modelProvider) {
		this.modelProvider = modelProvider;
		this.compressedStickyNodes = new Map();
	}
	getCompressedNode(node) {
		return this.compressedStickyNodes.get(node);
	}
	constrainStickyScrollNodes(stickyNodes, stickyScrollMaxItemCount, maxWidgetHeight) {
		this.compressedStickyNodes.clear();
		if (stickyNodes.length === 0) {
			return [];
		}
		for (let i = 0; i < stickyNodes.length; i++) {
			const stickyNode = stickyNodes[i];
			const stickyNodeBottom = stickyNode.position + stickyNode.height;
			const followingReachesMaxHeight = i + 1 < stickyNodes.length && stickyNodeBottom + stickyNodes[i + 1].height > maxWidgetHeight;
			if (followingReachesMaxHeight || (i >= stickyScrollMaxItemCount - 1 && stickyScrollMaxItemCount < stickyNodes.length)) {
				const uncompressedStickyNodes = stickyNodes.slice(0, i);
				const overflowingStickyNodes = stickyNodes.slice(i);
				const compressedStickyNode = this.compressStickyNodes(overflowingStickyNodes);
				return [...uncompressedStickyNodes, compressedStickyNode];
			}
		}
		return stickyNodes;
	}
	compressStickyNodes(stickyNodes) {
		if (stickyNodes.length === 0) {
			throw new Error("Can't compress empty sticky nodes");
		}
		const compressionModel = this.modelProvider();
		if (!compressionModel.isCompressionEnabled()) {
			return stickyNodes[0];
		}
		const elements = [];
		for (let i = 0; i < stickyNodes.length; i++) {
			const stickyNode = stickyNodes[i];
			const compressedNode2 = compressionModel.getCompressedTreeNode(stickyNode.node.element);
			if (compressedNode2.element) {
				if (i !== 0 && compressedNode2.element.incompressible) {
					break;
				}
				elements.push(...compressedNode2.element.elements);
			}
		}
		if (elements.length < 2) {
			return stickyNodes[0];
		}
		const lastStickyNode = stickyNodes[stickyNodes.length - 1];
		const compressedElement = { elements, incompressible: false };
		const compressedNode = {
			...lastStickyNode.node,
			children: [],
			element: compressedElement
		};
		const stickyTreeNode = new Proxy(stickyNodes[0].node, {});
		const compressedStickyNode = {
			node: stickyTreeNode,
			startIndex: stickyNodes[0].startIndex,
			endIndex: lastStickyNode.endIndex,
			position: stickyNodes[0].position,
			height: stickyNodes[0].height
		};
		this.compressedStickyNodes.set(stickyTreeNode, compressedNode);
		return compressedStickyNode;
	}
}

class CompressibleObjectTree extends ObjectTree {
	constructor(user, container, delegate, renderers, options2 = {}) {
		const compressedTreeNodeProvider = () => this;
		const stickyScrollDelegate = new CompressibleStickyScrollDelegate(() => this.model);
		const compressibleRenderers = renderers.map(r => new CompressibleRenderer(compressedTreeNodeProvider, stickyScrollDelegate, r));
		function _asObjectTreeOptions(compressedTreeNodeProvider, options2) {
			return (
				options2 && {
					...options2,
					keyboardNavigationLabelProvider: options2.keyboardNavigationLabelProvider && {
						getKeyboardNavigationLabel(e) {
							let compressedTreeNode;
							try {
								compressedTreeNode = compressedTreeNodeProvider().getCompressedTreeNode(e);
							} catch (exception) {
								return options2.keyboardNavigationLabelProvider.getKeyboardNavigationLabel(e);
							}
							if (compressedTreeNode.element.elements.length === 1) {
								return options2.keyboardNavigationLabelProvider.getKeyboardNavigationLabel(e);
							} else {
								return options2.keyboardNavigationLabelProvider.getCompressedNodeKeyboardNavigationLabel(
									compressedTreeNode.element.elements
								);
							}
						}
					}
				}
			);
		}
		super(user, container, delegate, compressibleRenderers, {
			..._asObjectTreeOptions(compressedTreeNodeProvider, options2),
			stickyScrollDelegate
		});
	}
	setChildren(element, children = [], options2) {
		this.model.setChildren(element, children, options2);
	}
	createModel(user, view, options2) {
		return new CompressibleObjectTreeModel(user, view, options2);
	}
	updateOptions(optionsUpdate = {}) {
		super.updateOptions(optionsUpdate);
		if (typeof optionsUpdate.compressionEnabled !== 'undefined') {
			this.model.setCompressionEnabled(optionsUpdate.compressionEnabled);
		}
	}
	getCompressedTreeNode(element = null) {
		return this.model.getCompressedTreeNode(element);
	}
}

class AsyncDataTreeElementsDragAndDropData extends ElementsDragAndDropData {
	constructor(data) {
		super(data.elements.map(node => node.element));
		this.data = data;
	}
}

class AsyncDataTreeNodeListDragAndDrop {
	constructor(dnd) {
		this.dnd = dnd;
	}
	getDragURI(node) {
		return this.dnd.getDragURI(node.element);
	}
	getDragLabel(nodes, originalEvent) {
		if (this.dnd.getDragLabel) {
			return this.dnd.getDragLabel(
				nodes.map(node => node.element),
				originalEvent
			);
		}
		return;
	}
	onDragStart(data, originalEvent) {
		this.dnd?.call(
			this.dnd,
			data instanceof ElementsDragAndDropData ? new AsyncDataTreeElementsDragAndDropData(data) : data,
			originalEvent
		);
	}
	onDragOver(data, targetNode, targetIndex, targetSector, originalEvent, raw = true) {
		return this.dnd.onDragOver(
			data instanceof ElementsDragAndDropData ? new AsyncDataTreeElementsDragAndDropData(data) : data,
			targetNode && targetNode.element,
			targetIndex,
			targetSector,
			originalEvent
		);
	}
	drop(data, targetNode, targetIndex, targetSector, originalEvent) {
		this.dnd.drop(
			data instanceof ElementsDragAndDropData ? new AsyncDataTreeElementsDragAndDropData(data) : data,
			targetNode && targetNode.element,
			targetIndex,
			targetSector,
			originalEvent
		);
	}
	onDragEnd(originalEvent) {
		this.dnd?.onDragEnd?.call(this.dnd, originalEvent);
	}
	dispose() {
		this.dnd.dispose();
	}
}

function asObjectTreeOptions2(options2) {
	return (
		options2 && {
			...options2,
			collapseByDefault: true,
			identityProvider: options2.identityProvider && {
				getId(el) {
					return options2.identityProvider.getId(el.element);
				}
			},
			dnd: options2.dnd && new AsyncDataTreeNodeListDragAndDrop(options2.dnd),
			multipleSelectionController: options2.multipleSelectionController && {
				isSelectionSingleChangeEvent(e) {
					return options2.multipleSelectionController.isSelectionSingleChangeEvent({
						...e,
						element: e.element
					});
				},
				isSelectionRangeChangeEvent(e) {
					return options2.multipleSelectionController.isSelectionRangeChangeEvent({
						...e,
						element: e.element
					});
				}
			},
			filter: options2.filter && {
				filter(e, parentVisibility) {
					return options2.filter.filter(e.element, parentVisibility);
				}
			},
			keyboardNavigationLabelProvider: options2.keyboardNavigationLabelProvider && {
				...options2.keyboardNavigationLabelProvider,
				getKeyboardNavigationLabel(e) {
					return options2.keyboardNavigationLabelProvider.getKeyboardNavigationLabel(e.element);
				}
			},
			sorter: undefined,
			expandOnlyOnTwistieClick:
				typeof options2.expandOnlyOnTwistieClick === 'undefined'
					? undefined
					: typeof options2.expandOnlyOnTwistieClick !== 'function'
						? options2.expandOnlyOnTwistieClick
						: e => options2.expandOnlyOnTwistieClick(e.element),
			defaultFindVisibility: e => {
				if (e.hasChildren && e.stale) {
					return 1;
				} else if (typeof options2.defaultFindVisibility === 'number') {
					return options2.defaultFindVisibility;
				} else if (typeof options2.defaultFindVisibility === 'undefined') {
					return 2;
				} else {
					return options2.defaultFindVisibility(e.element);
				}
			}
		}
	);
}

function dfs2(node, fn) {
	fn(node);
	node.children.forEach(child => dfs2(child, fn));
}

class AsyncDataTreeNodeWrapper {
	get element() {
		return this.node.element.element;
	}
	get children() {
		return this.node.children.map(node => new AsyncDataTreeNodeWrapper(node));
	}
	get depth() {
		return this.node.depth;
	}
	get visibleChildrenCount() {
		return this.node.visibleChildrenCount;
	}
	get visibleChildIndex() {
		return this.node.visibleChildIndex;
	}
	get collapsible() {
		return this.node.collapsible;
	}
	get collapsed() {
		return this.node.collapsed;
	}
	get visible() {
		return this.node.visible;
	}
	get filterData() {
		return this.node.filterData;
	}
	constructor(node) {
		this.node = node;
	}
}
class AsyncDataTreeRenderer {
	constructor(renderer, nodeMapper, onDidChangeTwistieState) {
		this.renderer = renderer;
		this.nodeMapper = nodeMapper;
		this.onDidChangeTwistieState = onDidChangeTwistieState;
		this.renderedNodes = new Map();
		this.templateId = renderer.templateId;
	}
	renderTemplate(container) {
		const templateData = this.renderer.renderTemplate(container);
		return { templateData };
	}
	renderElement(node, index, templateData, height) {
		this.renderer.renderElement(this.nodeMapper.map(node), index, templateData.templateData, height);
	}
	renderTwistie(element, twistieElement) {
		if (element.slow) {
			twistieElement.classList.add(...asThemeIconClassNameArray(codicon_loading));
			return true;
		} else {
			twistieElement.classList.remove(...asThemeIconClassNameArray(codicon_loading));
			return false;
		}
	}
	disposeElement(node, index, templateData, height) {
		this.renderer?.disposeElement?.call(this.renderer, this.nodeMapper.map(node), index, templateData.templateData, height);
	}
	disposeTemplate(templateData) {
		this.renderer.disposeTemplate(templateData.templateData);
	}
	dispose() {
		this.renderedNodes.clear();
	}
}

function asTreeEvent(e) {
	return {
		browserEvent: e.browserEvent,
		elements: e.elements.map(e2 => e2.element)
	};
}

function asTreeMouseEvent2(e) {
	return {
		browserEvent: e.browserEvent,
		element: e.element && e.element.element,
		target: e.target
	};
}

class AsyncDataTree {
	get onDidScroll() {
		return this.tree.onDidScroll;
	}
	get onDidChangeFocus() {
		return editorEventMap(this.tree.onDidChangeFocus, asTreeEvent);
	}
	get onDidChangeSelection() {
		return editorEventMap(this.tree.onDidChangeSelection, asTreeEvent);
	}
	get onMouseDblClick() {
		return editorEventMap(this.tree.onMouseDblClick, asTreeMouseEvent2);
	}
	get onPointer() {
		return editorEventMap(this.tree.onPointer, asTreeMouseEvent2);
	}
	get onDidFocus() {
		return this.tree.onDidFocus;
	}
	get onDidChangeModel() {
		return this.tree.onDidChangeModel;
	}
	get onDidChangeCollapseState() {
		return this.tree.onDidChangeCollapseState;
	}
	get onDidChangeFindOpenState() {
		return this.tree.onDidChangeFindOpenState;
	}
	get onDidChangeStickyScrollFocused() {
		return this.tree.onDidChangeStickyScrollFocused;
	}
	get onDidDispose() {
		return this.tree.onDidDispose;
	}
	constructor(user, container, delegate, renderers, dataSource, options2 = {}) {
		this.user = user;
		this.dataSource = dataSource;
		this.nodes = new Map();
		this.subTreeRefreshPromises = new Map();
		this.refreshPromises = new Map();
		this._onDidRender = new Emitter();
		this._onDidChangeNodeSlowState = new Emitter();
		this.nodeMapper = new WeakMapper(node => new AsyncDataTreeNodeWrapper(node));
		this.disposables = new DisposableStore();
		this.identityProvider = options2.identityProvider;
		this.autoExpandSingleChildren =
			typeof options2.autoExpandSingleChildren === 'undefined' ? false : options2.autoExpandSingleChildren;
		this.sorter = options2.sorter;
		this.getDefaultCollapseState = e =>
			options2.collapseByDefault
				? options2.collapseByDefault(e)
					? 3 //PreserveOrCollapsed
					: 2 //PreserveOrExpanded
				: undefined;
		this.tree = this.createTree(user, container, delegate, renderers, options2);
		this.onDidChangeFindMode = this.tree.onDidChangeFindMode;
		this.onDidChangeFindMatchType = this.tree.onDidChangeFindMatchType;
		this.root = {
			parent: null,
			hasChildren: true,
			children: [],
			stale: true,
			slow: false,
			forceExpanded: false
		};
		if (this.identityProvider) {
			this.root = {
				...this.root,
				id: null
			};
		}
		this.nodes.set(null, this.root);
		this.tree.onDidChangeCollapseState(this._onDidChangeCollapseState, this, this.disposables);
	}
	createTree(user, container, delegate, renderers, options2) {
		const objectTreeDelegate = new ComposedTreeDelegate(delegate);
		const objectTreeRenderers = renderers.map(r => new AsyncDataTreeRenderer(r, this.nodeMapper, this._onDidChangeNodeSlowState.event));
		const objectTreeOptions = asObjectTreeOptions2(options2) || {};
		return new ObjectTree(user, container, objectTreeDelegate, objectTreeRenderers, objectTreeOptions);
	}
	updateOptions(options2 = {}) {
		this.tree.updateOptions(options2);
	}
	getHTMLElement() {
		return this.tree.getHTMLElement();
	}
	get scrollTop() {
		return this.tree.scrollTop;
	}
	set scrollTop(scrollTop) {
		this.tree.scrollTop = scrollTop;
	}
	get scrollHeight() {
		return this.tree.scrollHeight;
	}
	get renderHeight() {
		return this.tree.renderHeight;
	}
	domFocus() {
		this.tree.domFocus();
	}
	layout(height, width2) {
		this.tree.layout(height, width2);
	}
	style(styles) {
		this.tree.style(styles);
	}
	getInput() {
		return this.root.element;
	}
	async setInput(input, viewState) {
		this.refreshPromises.forEach(promise => promise.cancel());
		this.refreshPromises.clear();
		this.root.element = input;
		const viewStateContext = viewState && {
			viewState,
			focus: [],
			selection: []
		};
		await this._updateChildren(input, true, false, viewStateContext);
		if (viewStateContext) {
			this.tree.setFocus(viewStateContext.focus);
			this.tree.setSelection(viewStateContext.selection);
		}
		if (viewState && typeof viewState.scrollTop === 'number') {
			this.scrollTop = viewState.scrollTop;
		}
	}
	async _updateChildren(element = this.root.element, recursive = true, rerender = false, viewStateContext, options2) {
		if (typeof this.root.element === 'undefined') {
			throw new Error(`[${this.user}] Tree input not set`);
		}
		if (this.root.refreshPromise) {
			await this.root.refreshPromise;
			await editorEventToPromise(this._onDidRender.event);
		}
		const node = this.getDataNode(element);
		await this.refreshAndRenderNode(node, recursive, viewStateContext, options2);
		if (rerender) {
			try {
				this.tree.rerender(node);
			} catch (exception) {}
		}
	}
	rerender(element) {
		if (element === undefined || element === this.root.element) {
			this.tree.rerender();
			return;
		}
		const node = this.getDataNode(element);
		this.tree.rerender(node);
	}
	getNode(element = this.root.element) {
		const dataNode = this.getDataNode(element);
		const node = this.tree.getNode(dataNode === this.root ? null : dataNode);
		return this.nodeMapper.map(node);
	}
	collapse(element, recursive = false) {
		const node = this.getDataNode(element);
		return this.tree.collapse(node === this.root ? null : node, recursive);
	}
	async expand(element, recursive = false) {
		if (typeof this.root.element === 'undefined') {
			throw new Error(`[${this.user}] Tree input not set`);
		}
		if (this.root.refreshPromise) {
			await this.root.refreshPromise;
			await editorEventToPromise(this._onDidRender.event);
		}
		const node = this.getDataNode(element);
		if (this.tree.hasElement(node) && !this.tree.isCollapsible(node)) {
			return false;
		}
		if (node.refreshPromise) {
			await this.root.refreshPromise;
			await editorEventToPromise(this._onDidRender.event);
		}
		if (node !== this.root && !node.refreshPromise && !this.tree.isCollapsed(node)) {
			return false;
		}
		const result = this.tree.expand(node === this.root ? null : node, recursive);
		if (node.refreshPromise) {
			await this.root.refreshPromise;
			await editorEventToPromise(this._onDidRender.event);
		}
		return result;
	}
	setSelection(elements, browserEvent) {
		const nodes = elements.map(e => this.getDataNode(e));
		this.tree.setSelection(nodes, browserEvent);
	}
	getSelection() {
		const nodes = this.tree.getSelection();
		return nodes.map(n => n.element);
	}
	setFocus(elements, browserEvent) {
		const nodes = elements.map(e => this.getDataNode(e));
		this.tree.setFocus(nodes, browserEvent);
	}
	getFocus() {
		const nodes = this.tree.getFocus();
		return nodes.map(n => n.element);
	}
	reveal(element, relativeTop) {
		this.tree.reveal(this.getDataNode(element), relativeTop);
	}
	getParentElement(element) {
		const node = this.tree.getParentElement(this.getDataNode(element));
		return node && node.element;
	}
	getFirstElementChild(element = this.root.element) {
		const dataNode = this.getDataNode(element);
		const node = this.tree.getFirstElementChild(dataNode === this.root ? null : dataNode);
		return node && node.element;
	}
	getDataNode(element) {
		const node = this.nodes.get(element === this.root.element ? null : element);
		if (!node) {
			throw new Error(`[${this.user}] Data tree node not found: ${element}`);
		}
		return node;
	}
	async refreshAndRenderNode(node, recursive, viewStateContext, options2) {
		await this.refreshNode(node, recursive, viewStateContext);
		if (this.disposables.isDisposed) {
			return;
		}
		this.render(node, viewStateContext, options2);
	}
	async refreshNode(node, recursive, viewStateContext) {
		function _isAncestor2(ancestor, descendant) {
			if (!descendant.parent) {
				return false;
			} else if (descendant.parent === ancestor) {
				return true;
			} else {
				return isAncestor2(ancestor, descendant.parent);
			}
		}
		let result;
		this.subTreeRefreshPromises.forEach((refreshPromise, refreshNode) => {
			if (!result && (refreshNode === node || _isAncestor2(refreshNode, node) || _isAncestor2(node, refreshNode))) {
				result = refreshPromise.then(() => this.refreshNode(node, recursive, viewStateContext));
			}
		});
		if (result) {
			return result;
		}
		if (node !== this.root) {
			const treeNode = this.tree.getNode(node);
			if (treeNode.collapsed) {
				node.hasChildren = !!this.dataSource.hasChildren(node.element);
				node.stale = true;
				this.setChildren(node, [], recursive, viewStateContext);
				return;
			}
		}
		return this.doRefreshSubTree(node, recursive, viewStateContext);
	}
	async doRefreshSubTree(node, recursive, viewStateContext) {
		let done;
		node.refreshPromise = new Promise(c => (done = c));
		this.subTreeRefreshPromises.set(node, node.refreshPromise);
		node.refreshPromise.finally(() => {
			node.refreshPromise = undefined;
			this.subTreeRefreshPromises.delete(node);
		});
		try {
			const childrenToRefresh = await this.doRefreshNode(node, recursive, viewStateContext);
			node.stale = false;
			await Promises.settled(childrenToRefresh.map(child => this.doRefreshSubTree(child, recursive, viewStateContext)));
		} finally {
			done();
		}
	}
	async doRefreshNode(node, recursive, viewStateContext) {
		node.hasChildren = !!this.dataSource.hasChildren(node.element);
		let childrenPromise;
		if (!node.hasChildren) {
			childrenPromise = Promise.resolve([]);
		} else {
			const children = this.doGetChildren(node);
			if (isIterable(children)) {
				childrenPromise = Promise.resolve(children);
			} else {
				const slowTimeout = timeout(800);
				slowTimeout.then(
					() => {
						node.slow = true;
						this._onDidChangeNodeSlowState.fire(node);
					},
					_ => null
				);
				childrenPromise = children.finally(() => slowTimeout.cancel());
			}
		}
		try {
			const children = await childrenPromise;
			return this.setChildren(node, children, recursive, viewStateContext);
		} catch (err) {
			if (node !== this.root && this.tree.hasElement(node)) {
				this.tree.collapse(node);
			}
			if (isCancellationError(err)) {
				return [];
			}
			throw err;
		} finally {
			if (node.slow) {
				node.slow = false;
				this._onDidChangeNodeSlowState.fire(node);
			}
		}
	}
	doGetChildren(node) {
		let result = this.refreshPromises.get(node);
		if (result) {
			return result;
		}
		const children = this.dataSource.getChildren(node.element);
		if (isIterable(children)) {
			return this.processChildren(children);
		} else {
			result = createCancelablePromise(async () => this.processChildren(await children));
			this.refreshPromises.set(node, result);
			return result.finally(() => {
				this.refreshPromises.delete(node);
			});
		}
	}
	_onDidChangeCollapseState({ node, deep }) {
		if (node.element === null) {
			return;
		}
		if (!node.collapsed && node.element.stale) {
			if (deep) {
				this.collapse(node.element.element);
			} else {
				this.refreshAndRenderNode(node.element, false).catch(onUnexpectedError);
			}
		}
	}
	setChildren(node, childrenElementsIterable, recursive, viewStateContext) {
		const childrenElements = [...childrenElementsIterable];
		if (node.children.length === 0 && childrenElements.length === 0) {
			return [];
		}
		const nodesToForget = new Map();
		const childrenTreeNodesById = new Map();
		for (const child of node.children) {
			nodesToForget.set(child.element, child);
			if (this.identityProvider) {
				childrenTreeNodesById.set(child.id, {
					node: child,
					collapsed: this.tree.hasElement(child) && this.tree.isCollapsed(child)
				});
			}
		}
		const childrenToRefresh = [];
		const children = childrenElements.map(element => {
			const hasChildren = !!this.dataSource.hasChildren(element);
			if (!this.identityProvider) {
				const asyncDataTreeNode = {
					element: element,
					parent: node,
					hasChildren,
					defaultCollapseState: this.getDefaultCollapseState(element),
					children: [],
					stale: true,
					slow: false,
					forceExpanded: false
				};
				if (
					hasChildren &&
					asyncDataTreeNode.defaultCollapseState === 2 //PreserveOrExpanded
				) {
					childrenToRefresh.push(asyncDataTreeNode);
				}
				return asyncDataTreeNode;
			}
			const id = this.identityProvider.getId(element).toString();
			const result = childrenTreeNodesById.get(id);
			if (result) {
				const asyncDataTreeNode = result.node;
				nodesToForget.delete(asyncDataTreeNode.element);
				this.nodes.delete(asyncDataTreeNode.element);
				this.nodes.set(element, asyncDataTreeNode);
				asyncDataTreeNode.element = element;
				asyncDataTreeNode.hasChildren = hasChildren;
				if (recursive) {
					if (result.collapsed) {
						asyncDataTreeNode.children.forEach(node2 => dfs2(node2, node3 => this.nodes.delete(node3.element)));
						asyncDataTreeNode.children.splice(0, asyncDataTreeNode.children.length);
						asyncDataTreeNode.stale = true;
					} else {
						childrenToRefresh.push(asyncDataTreeNode);
					}
				} else if (hasChildren && !result.collapsed) {
					childrenToRefresh.push(asyncDataTreeNode);
				}
				return asyncDataTreeNode;
			}
			const childAsyncDataTreeNode = createAsyncDataTreeNode({
				element: element,
				parent: node,
				id: id,
				hasChildren,
				defaultCollapseState: this.getDefaultCollapseState(element),
				children: [],
				stale: true,
				slow: false,
				forceExpanded: false
			});
			if (viewStateContext && viewStateContext.viewState.focus && viewStateContext.viewState.focus.indexOf(id) > -1) {
				viewStateContext.focus.push(childAsyncDataTreeNode);
			}
			if (viewStateContext && viewStateContext.viewState.selection && viewStateContext.viewState.selection.indexOf(id) > -1) {
				viewStateContext.selection.push(childAsyncDataTreeNode);
			}
			if (viewStateContext && viewStateContext.viewState.expanded && viewStateContext.viewState.expanded.indexOf(id) > -1) {
				childrenToRefresh.push(childAsyncDataTreeNode);
			} else if (
				hasChildren &&
				childAsyncDataTreeNode.defaultCollapseState === 2 //PreserveOrExpanded
			) {
				childrenToRefresh.push(childAsyncDataTreeNode);
			}
			return childAsyncDataTreeNode;
		});
		for (const node2 of nodesToForget.values()) {
			dfs2(node2, node3 => this.nodes.delete(node3.element));
		}
		for (const child of children) {
			this.nodes.set(child.element, child);
		}
		node.children.splice(0, node.children.length, ...children);
		if (node !== this.root && this.autoExpandSingleChildren && children.length === 1 && childrenToRefresh.length === 0) {
			children[0].forceExpanded = true;
			childrenToRefresh.push(children[0]);
		}
		return childrenToRefresh;
	}
	render(node, viewStateContext, options2) {
		const children = node.children.map(node2 => this.asTreeElement(node2, viewStateContext));
		const objectTreeOptions = options2 && {
			...options2,
			diffIdentityProvider: options2.diffIdentityProvider && {
				getId(node2) {
					return options2.diffIdentityProvider.getId(node2.element);
				}
			}
		};
		this.tree.setChildren(node === this.root ? null : node, children, objectTreeOptions);
		if (node !== this.root) {
			this.tree.setCollapsible(node, node.hasChildren);
		}
		this._onDidRender.fire();
	}
	asTreeElement(node, viewStateContext) {
		if (node.stale) {
			return {
				element: node,
				collapsible: node.hasChildren,
				collapsed: true
			};
		}
		let collapsed2;
		if (
			viewStateContext &&
			viewStateContext.viewState.expanded &&
			node.id &&
			viewStateContext.viewState.expanded.indexOf(node.id) > -1
		) {
			collapsed2 = false;
		} else if (node.forceExpanded) {
			collapsed2 = false;
			node.forceExpanded = false;
		} else {
			collapsed2 = node.defaultCollapseState;
		}
		return {
			element: node,
			children: node.hasChildren ? iterableMap(node.children, child => this.asTreeElement(child, viewStateContext)) : [],
			collapsible: node.hasChildren,
			collapsed: collapsed2
		};
	}
	processChildren(children) {
		if (this.sorter) {
			children = [...children].sort(this.sorter.compare.bind(this.sorter));
		}
		return children;
	}
	dispose() {
		this.disposables.dispose();
		this.tree.dispose();
	}
}
class CompressibleAsyncDataTreeNodeWrapper {
	get element() {
		return {
			elements: this.node.element.elements.map(e => e.element),
			incompressible: this.node.element.incompressible
		};
	}
	get children() {
		return this.node.children.map(node => new CompressibleAsyncDataTreeNodeWrapper(node));
	}
	get depth() {
		return this.node.depth;
	}
	get visibleChildrenCount() {
		return this.node.visibleChildrenCount;
	}
	get visibleChildIndex() {
		return this.node.visibleChildIndex;
	}
	get collapsible() {
		return this.node.collapsible;
	}
	get collapsed() {
		return this.node.collapsed;
	}
	get visible() {
		return this.node.visible;
	}
	get filterData() {
		return this.node.filterData;
	}
	constructor(node) {
		this.node = node;
	}
}
class CompressibleAsyncDataTreeRenderer {
	constructor(renderer, nodeMapper, compressibleNodeMapperProvider, onDidChangeTwistieState) {
		this.renderer = renderer;
		this.nodeMapper = nodeMapper;
		this.compressibleNodeMapperProvider = compressibleNodeMapperProvider;
		this.onDidChangeTwistieState = onDidChangeTwistieState;
		this.renderedNodes = new Map();
		this.disposables = [];
		this.templateId = renderer.templateId;
	}
	renderTemplate(container) {
		const templateData = this.renderer.renderTemplate(container);
		return { templateData };
	}
	renderElement(node, index, templateData, height) {
		this.renderer.renderElement(this.nodeMapper.map(node), index, templateData.templateData, height);
	}
	renderCompressedElements(node, index, templateData, height) {
		this.renderer.renderCompressedElements(this.compressibleNodeMapperProvider().map(node), index, templateData.templateData, height);
	}
	renderTwistie(element, twistieElement) {
		if (element.slow) {
			twistieElement.classList.add(...asThemeIconClassNameArray(codicon_loading));
			return true;
		} else {
			twistieElement.classList.remove(...asThemeIconClassNameArray(codicon_loading));
			return false;
		}
	}
	disposeElement(node, index, templateData, height) {
		this.renderer?.disposeElement?.call(this.renderer, this.nodeMapper.map(node), index, templateData.templateData, height);
	}
	disposeCompressedElements(node, index, templateData, height) {
		this.renderer?.disposeCompressedElements?.call(
			this.renderer,
			this.compressibleNodeMapperProvider().map(node),
			index,
			templateData.templateData,
			height
		);
	}
	disposeTemplate(templateData) {
		this.renderer.disposeTemplate(templateData.templateData);
	}
	dispose() {
		this.renderedNodes.clear();
		this.disposables = dispose(this.disposables);
	}
}
class CompressibleAsyncDataTree extends AsyncDataTree {
	constructor(user, container, virtualDelegate, compressionDelegate, renderers, dataSource, options2 = {}) {
		super(user, container, virtualDelegate, renderers, dataSource, options2);
		this.compressionDelegate = compressionDelegate;
		this.compressibleNodeMapper = new WeakMapper(node => new CompressibleAsyncDataTreeNodeWrapper(node));
		this.filter = options2.filter;
	}
	createTree(user, container, delegate, renderers, options2) {
		const objectTreeDelegate = new ComposedTreeDelegate(delegate);
		const objectTreeRenderers = renderers.map(
			r =>
				new CompressibleAsyncDataTreeRenderer(
					r,
					this.nodeMapper,
					() => this.compressibleNodeMapper,
					this._onDidChangeNodeSlowState.event
				)
		);
		function _asCompressibleObjectTreeOptions(options2) {
			const objectTreeOptions = options2 && asObjectTreeOptions2(options2);
			return (
				objectTreeOptions && {
					...objectTreeOptions,
					keyboardNavigationLabelProvider: objectTreeOptions.keyboardNavigationLabelProvider && {
						...objectTreeOptions.keyboardNavigationLabelProvider,
						getCompressedNodeKeyboardNavigationLabel(els) {
							return options2.keyboardNavigationLabelProvider.getCompressedNodeKeyboardNavigationLabel(
								els.map(e => e.element)
							);
						}
					}
				}
			);
		}
		const objectTreeOptions = _asCompressibleObjectTreeOptions(options2) || {};
		return new CompressibleObjectTree(user, container, objectTreeDelegate, objectTreeRenderers, objectTreeOptions);
	}
	asTreeElement(node, viewStateContext) {
		return {
			incompressible: this.compressionDelegate.isIncompressible(node.element),
			...super.asTreeElement(node, viewStateContext)
		};
	}
	updateOptions(options2 = {}) {
		this.tree.updateOptions(options2);
	}
	render(node, viewStateContext, options2) {
		if (!this.identityProvider) {
			return super.render(node, viewStateContext);
		}
		const getId = element => this.identityProvider.getId(element).toString();
		const getUncompressedIds = nodes => {
			const result = new Set();
			for (const node2 of nodes) {
				const compressedNode = this.tree.getCompressedTreeNode(node2 === this.root ? null : node2);
				if (!compressedNode.element) {
					continue;
				}
				for (const node3 of compressedNode.element.elements) {
					result.add(getId(node3.element));
				}
			}
			return result;
		};
		const oldSelection = getUncompressedIds(this.tree.getSelection());
		const oldFocus = getUncompressedIds(this.tree.getFocus());
		super.render(node, viewStateContext, options2);
		const selection = this.getSelection();
		let didChangeSelection = false;
		const focus = this.getFocus();
		let didChangeFocus = false;
		const visit = node2 => {
			const compressedNode = node2.element;
			if (compressedNode) {
				for (let i = 0; i < compressedNode.elements.length; i++) {
					const id = getId(compressedNode.elements[i].element);
					const element = compressedNode.elements[compressedNode.elements.length - 1].element;
					if (oldSelection.has(id) && selection.indexOf(element) === -1) {
						selection.push(element);
						didChangeSelection = true;
					}
					if (oldFocus.has(id) && focus.indexOf(element) === -1) {
						focus.push(element);
						didChangeFocus = true;
					}
				}
			}
			node2.children.forEach(visit);
		};
		visit(this.tree.getCompressedTreeNode(node === this.root ? null : node));
		if (didChangeSelection) {
			this.setSelection(selection);
		}
		if (didChangeFocus) {
			this.setFocus(focus);
		}
	}
	// For compressed async data trees, `TreeVisibility.Recurse` doesn't currently work
	// and we have to filter everything beforehand
	// Related to #85193 and #85835
	processChildren(children) {
		if (this.filter) {
			children = iterableFilter(children, e => {
				const result = this.filter.filter(
					e,
					1 //TreeVisibility.Visible
				);

				function _getVisibility(e) {
					if (typeof e === 'boolean') {
						return e ? 1 : 0;
					} else if (_isFilterResult(e)) {
						return getVisibleState(e.visibility);
					} else {
						return getVisibleState(e);
					}
				}
				const visibility = _getVisibility(result);
				if (visibility === 2) {
					throw new Error('Recursive tree visibility not supported in async data compressed trees');
				}
				return visibility === 1;
			});
		}
		return super.processChildren(children);
	}
}

class DataTree extends AbstractTree {
	constructor(user, container, delegate, renderers, dataSource, options2 = {}) {
		super(user, container, delegate, renderers, options2);
		this.user = user;
		this.dataSource = dataSource;
		this.identityProvider = options2.identityProvider;
	}
	createModel(user, view, options2) {
		return new ObjectTreeModel(user, view, options2);
	}
}
