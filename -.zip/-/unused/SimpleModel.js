class SimpleModel {
	constructor(model) {
		this.disposed = false;
		this.model = model;
		this._onWillDispose = new Emitter();
	}
	get textEditorModel() {
		return this.model;
	}
	dispose() {
		this.disposed = true;
		this._onWillDispose.fire();
	}
}

