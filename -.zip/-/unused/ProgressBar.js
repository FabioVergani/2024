






const emptyProgressRunner = freeze({
	total() {},
	worked() {},
	done() {}
});

const IEditorProgressService = createEditorServiceDecorator('editorProgressService');



class Progress {
	constructor(callback) {
		this.callback = callback;
	}
	report(item) {
		this._value = item;
		this.callback(this._value);
	}
}




class ProgressBar extends Disposable {
	constructor(container, options2) {
		super();
		this.progressSignal = this._register(new MutableDisposable());
		this.workedVal = 0;
		this.showDelayedScheduler = this._register(new RunOnceScheduler(() => show(this.element), 0));
		this.longRunningScheduler = this._register(new RunOnceScheduler(() => this.infiniteLongRunning(), 1e4));
		this.create(container, options2);
	}
	create(container, options2) {
		this.element = document.createElement('div');
		this.element.classList.add('monaco-progress-container');
		this.element.setAttribute('role', 'progressbar');
		container.appendChild(this.element);
		this.bit = document.createElement('div');
		this.bit.classList.add('progress-bit');
		this.bit.style.backgroundColor = options2?.progressBarBackground || '#0E70C0';
		this.element.appendChild(this.bit);
	}
	off() {
		this.bit.style.width = 'inherit';
		this.bit.style.opacity = '1';
		this.element.classList.remove('active', 'infinite', 'infinite-long-running', 'discrete');
		this.workedVal = 0;
		this.totalWork = undefined;
		this.longRunningScheduler.cancel();
		this.progressSignal.clear();
	}
	stop() {
		return this.doDone(false);
	}
	doDone(delayed) {
		this.element.classList.add('done');
		if (!this.element.classList.contains('infinite')) {
			this.bit.style.width = 'inherit';
			if (delayed) {
				setTimeout(() => this.off(), 200);
			} else {
				this.off();
			}
		} else {
			this.bit.style.opacity = '0';
			if (delayed) {
				setTimeout(() => this.off(), 200);
			} else {
				this.off();
			}
		}
		return this;
	}
	infinite() {
		this.bit.style.width = '2%';
		this.bit.style.opacity = '1';
		this.element.classList.remove('discrete', 'done', 'infinite-long-running');
		this.element.classList.add('active', 'infinite');
		this.longRunningScheduler.schedule();
		return this;
	}
	infiniteLongRunning() {
		this.element.classList.add('infinite-long-running');
	}
	getContainer() {
		return this.element;
	}
}
