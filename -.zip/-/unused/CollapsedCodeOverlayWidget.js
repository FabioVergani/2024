function applyObservableDecorations(editor2, decorations) {
	const d = new DisposableStore();
	const decorationsCollection = editor2.createDecorationsCollection();
	d.add(
		autorunOpts(
			{
				debugName: () => `Apply decorations from ${decorations.debugName}`
			},
			reader => {
				const d2 = decorations.read(reader);
				decorationsCollection.set(d2);
			}
		)
	);
	d.add({
		dispose: () => {
			decorationsCollection.clear();
		}
	});
	return d;
}

function applyStyle(domNode, style) {
	return autorun(reader => {
		for (let [key, val] of entries(style)) {
			if (val && typeof val === 'object' && 'read' in val) {
				val = val.read(reader);
			}
			if (typeof val === 'number') {
				val = `${val}px`;
			}
			key = key.replace(/[A-Z]/g, m => '-' + m.toLowerCase());
			domNode.style[key] = val;
		}
	});
}

function applyViewZones(editor2, viewZones, setIsUpdating, zoneIds) {
	const store = new DisposableStore();
	const lastViewZoneIds = [];
	store.add(
		autorunWithStore((reader, store2) => {
			const curViewZones = viewZones.read(reader);
			const viewZonIdsPerViewZone = new Map();
			const viewZoneIdPerOnChangeObservable = new Map();
			if (setIsUpdating) {
				setIsUpdating(true);
			}
			editor2.changeViewZones(a => {
				for (const id of lastViewZoneIds) {
					a.removeZone(id);
					zoneIds?.delete(id);
				}
				lastViewZoneIds.length = 0;
				for (const z of curViewZones) {
					const id = a.addZone(z);
					if (z.setZoneId) {
						z.setZoneId(id);
					}
					lastViewZoneIds.push(id);
					zoneIds?.add(id);
					viewZonIdsPerViewZone.set(z, id);
				}
			});
			if (setIsUpdating) {
				setIsUpdating(false);
			}
			store2.add(
				autorunHandleChanges(
					{
						createEmptyChangeSummary() {
							return { zoneIds: [] };
						},
						handleChange(context, changeSummary) {
							const id = viewZoneIdPerOnChangeObservable.get(context.changedObservable);
							if (id !== undefined) {
								changeSummary.zoneIds.push(id);
							}
							return true;
						}
					},
					(reader2, changeSummary) => {
						for (const vz of curViewZones) {
							if (vz.onChange) {
								viewZoneIdPerOnChangeObservable.set(vz.onChange, viewZonIdsPerViewZone.get(vz));
								vz.onChange.read(reader2);
							}
						}
						if (setIsUpdating) {
							setIsUpdating(true);
						}
						editor2.changeViewZones(a => {
							for (const id of changeSummary.zoneIds) {
								a.layoutZone(id);
							}
						});
						if (setIsUpdating) {
							setIsUpdating(false);
						}
					}
				)
			);
		})
	);
	store.add({
		dispose() {
			if (setIsUpdating) {
				setIsUpdating(true);
			}
			editor2.changeViewZones(a => {
				for (const id of lastViewZoneIds) {
					a.removeZone(id);
				}
			});
			zoneIds?.clear();
			if (setIsUpdating) {
				setIsUpdating(false);
			}
		}
	});
	return store;
}


class ManagedOverlayWidget {
	constructor(_editor, _domElement) {
		this._editor = _editor;
		this._domElement = _domElement;
		this._overlayWidgetId = `managedOverlayWidget-${ManagedOverlayWidget._counter++}`;
		this._overlayWidget = {
			getId: () => this._overlayWidgetId,
			getDomNode: () => this._domElement,
			getPosition: () => null
		};
		this._editor.addOverlayWidget(this._overlayWidget);
	}
	dispose() {
		this._editor.removeOverlayWidget(this._overlayWidget);
	}
}
ManagedOverlayWidget._counter = 0;

class PlaceholderViewZone {
	get afterLineNumber() {
		return this._afterLineNumber.get();
	}
	constructor(_afterLineNumber, heightInPx) {
		this._afterLineNumber = _afterLineNumber;
		this.heightInPx = heightInPx;
		this.domNode = document.createElement('div');
		this._actualTop = observableValue(this, undefined);
		this._actualHeight = observableValue(this, undefined);
		this.actualTop = this._actualTop;
		this.actualHeight = this._actualHeight;
		this.showInHiddenAreas = true;
		this.onChange = this._afterLineNumber;
		this.onDomNodeTop = top => {
			this._actualTop.set(top, undefined);
		};
		this.onComputedHeight = height => {
			this._actualHeight.set(height, undefined);
		};
	}
}

const obs_breadcrumbsSourceFactory = observableValue('breadcrumbsSourceFactory');

class HideUnchangedRegionsFeature extends Disposable {
	static setBreadcrumbsSourceFactory(factory) {
		this._breadcrumbsSourceFactory.set(factory, undefined);
	}
	get isUpdatingHiddenAreas() {
		return this._isUpdatingHiddenAreas;
	}
	constructor(_editors, _diffModel, _options, _instantiationService) {
		super();
		this._editors = _editors;
		this._diffModel = _diffModel;
		this._options = _options;
		this._instantiationService = _instantiationService;
		this._modifiedOutlineSource = derivedDisposable(this, reader => {
			const m = this._editors.modifiedModel.read(reader);
			const factory = obs_breadcrumbsSourceFactory.read(reader);
			return !m || !factory ? undefined : factory(m, this._instantiationService);
		});
		this._isUpdatingHiddenAreas = false;
		this._register(
			this._editors.original.onDidChangeCursorPosition(e => {
				if (e.reason === 1) {
					return;
				}
				const m = this._diffModel.get();
				transaction(tx => {
					for (const s of this._editors.original.getSelections() || []) {
						m?.ensureOriginalLineIsVisible(s.getStartPosition().lineNumber, 0, tx);
						m?.ensureOriginalLineIsVisible(s.getEndPosition().lineNumber, 0, tx);
					}
				});
			})
		);
		this._register(
			this._editors.modified.onDidChangeCursorPosition(e => {
				if (e.reason === 1) {
					return;
				}
				const m = this._diffModel.get();
				transaction(tx => {
					for (const s of this._editors.modified.getSelections() || []) {
						m?.ensureModifiedLineIsVisible(s.getStartPosition().lineNumber, 0, tx);
						m?.ensureModifiedLineIsVisible(s.getEndPosition().lineNumber, 0, tx);
					}
				});
			})
		);
		const unchangedRegions = this._diffModel.map((m, reader) => {
			const regions = m?.unchangedRegions.read(reader) ?? [];
			if (
				regions.length === 1 &&
				regions[0].modifiedLineNumber === 1 &&
				regions[0].lineCount === this._editors.modifiedModel.read(reader)?.getLineCount()
			) {
				return [];
			}
			return regions;
		});
		this.viewZones = derivedWithStore(this, (reader, store) => {
			const modifiedOutlineSource = this._modifiedOutlineSource.read(reader);
			if (!modifiedOutlineSource) {
				return { origViewZones: [], modViewZones: [] };
			}
			const origViewZones = [];
			const modViewZones = [];
			const sideBySide = this._options.renderSideBySide.read(reader);
			const curUnchangedRegions = unchangedRegions.read(reader);
			for (const r of curUnchangedRegions) {
				if (r.shouldHideControls(reader)) {
					continue;
				}
				{
					const d = derived(this, reader2 => r.getHiddenOriginalRange(reader2).startLineNumber - 1);
					const origVz = new PlaceholderViewZone(d, 24);
					origViewZones.push(origVz);
					store.add(
						new CollapsedCodeOverlayWidget(
							this._editors.original,
							origVz,
							r,
							r.originalUnchangedRange,
							!sideBySide,
							modifiedOutlineSource,
							l => this._diffModel.get().ensureModifiedLineIsVisible(l, 2, undefined),
							this._options
						)
					);
				}
				{
					const d = derived(this, reader2 => r.getHiddenModifiedRange(reader2).startLineNumber - 1);
					const modViewZone = new PlaceholderViewZone(d, 24);
					modViewZones.push(modViewZone);
					store.add(
						new CollapsedCodeOverlayWidget(
							this._editors.modified,
							modViewZone,
							r,
							r.modifiedUnchangedRange,
							false,
							modifiedOutlineSource,
							l => this._diffModel.get().ensureModifiedLineIsVisible(l, 2, undefined),
							this._options
						)
					);
				}
			}
			return { origViewZones, modViewZones };
		});
		const unchangedLinesDecoration = {
			description: 'unchanged lines',
			className: 'diff-unchanged-lines',
			isWholeLine: true
		};
		const unchangedLinesDecorationShow = {
			description: 'Fold Unchanged',
			glyphMarginHoverMessage: new MarkdownString(undefined, {
				isTrusted: true,
				supportThemeIcons: true
			}).appendMarkdown(localize('Fold Unchanged Region')),
			glyphMarginClassName: 'fold-unchanged ' + asThemeIconClassNameString(codicon_fold),
			zIndex: 10001
		};
		this._register(
			applyObservableDecorations(
				this._editors.original,
				derived(this, reader => {
					const curUnchangedRegions = unchangedRegions.read(reader);
					const result = curUnchangedRegions.map(r => ({
						range: r.originalUnchangedRange.toInclusiveRange(),
						options: unchangedLinesDecoration
					}));
					for (const r of curUnchangedRegions) {
						if (r.shouldHideControls(reader)) {
							result.push({
								range: Range.fromPositions(new Position(r.originalLineNumber, 1)),
								options: unchangedLinesDecorationShow
							});
						}
					}
					return result;
				})
			)
		);
		this._register(
			applyObservableDecorations(
				this._editors.modified,
				derived(this, reader => {
					const curUnchangedRegions = unchangedRegions.read(reader);
					const result = curUnchangedRegions.map(r => ({
						range: r.modifiedUnchangedRange.toInclusiveRange(),
						options: unchangedLinesDecoration
					}));
					for (const r of curUnchangedRegions) {
						if (r.shouldHideControls(reader)) {
							result.push({
								range: LineRange.ofLength(r.modifiedLineNumber, 1).toInclusiveRange(),
								options: unchangedLinesDecorationShow
							});
						}
					}
					return result;
				})
			)
		);
		this._register(
			autorun(reader => {
				const curUnchangedRegions = unchangedRegions.read(reader);
				this._isUpdatingHiddenAreas = true;
				try {
					this._editors.original.setHiddenAreas(
						curUnchangedRegions.map(r => r.getHiddenOriginalRange(reader).toInclusiveRange()).filter(notIsNullOrUndefined)
					);
					this._editors.modified.setHiddenAreas(
						curUnchangedRegions.map(r => r.getHiddenModifiedRange(reader).toInclusiveRange()).filter(notIsNullOrUndefined)
					);
				} finally {
					this._isUpdatingHiddenAreas = false;
				}
			})
		);
		this._register(
			this._editors.modified.onMouseUp(event => {
				if (!event.event.rightButton && event.target.position && event.target.element?.className.includes('fold-unchanged')) {
					const lineNumber = event.target.position.lineNumber;
					const model = this._diffModel.get();
					if (!model) {
						return;
					}
					const region = model.unchangedRegions.get().find(r => r.modifiedUnchangedRange.includes(lineNumber));
					if (!region) {
						return;
					}
					region.collapseAll(undefined);
					event.event.stopPropagation();
					event.event.preventDefault();
				}
			})
		);
		this._register(
			this._editors.original.onMouseUp(event => {
				if (!event.event.rightButton && event.target.position && event.target.element?.className.includes('fold-unchanged')) {
					const lineNumber = event.target.position.lineNumber;
					const model = this._diffModel.get();
					if (!model) {
						return;
					}
					const region = model.unchangedRegions.get().find(r => r.originalUnchangedRange.includes(lineNumber));
					if (!region) {
						return;
					}
					region.collapseAll(undefined);
					event.event.stopPropagation();
					event.event.preventDefault();
				}
			})
		);
	}
}
__decorate(
	[
		__param(3, IInstantiationService)
		//...
	],
	HideUnchangedRegionsFeature
);

class ViewZoneOverlayWidget extends Disposable {
	constructor(editor2, viewZone, htmlElement) {
		super();
		this._register(new ManagedOverlayWidget(editor2, htmlElement));
		this._register(
			applyStyle(htmlElement, {
				height: viewZone.actualHeight,
				top: viewZone.actualTop
			})
		);
	}
}
class CollapsedCodeOverlayWidget extends ViewZoneOverlayWidget {
	constructor(
		_editor,
		_viewZone,
		_unchangedRegion,
		_unchangedRegionRange,
		_hide,
		_modifiedOutlineSource,
		_revealModifiedHiddenLine,
		_options
	) {
		const root = h('div.diff-hidden-lines-widget');
		super(_editor, _viewZone, root.root);
		this._editor = _editor;
		this._unchangedRegion = _unchangedRegion;
		this._unchangedRegionRange = _unchangedRegionRange;
		this._hide = _hide;
		this._modifiedOutlineSource = _modifiedOutlineSource;
		this._revealModifiedHiddenLine = _revealModifiedHiddenLine;
		this._options = _options;
		this._nodes = h('div.diff-hidden-lines', [
			h('div.top@top', {
				title: localize('Click or drag to show more above')
			}),
			h('div.center@content', { style: { display: 'flex' } }, [
				h(
					'div@first',
					{
						style: {
							display: 'flex',
							justifyContent: 'center',
							alignItems: 'center',
							flexShrink: '0'
						}
					},
					[
						createDomElement(
							'a',
							{
								title: localize('Show Unchanged Region'),
								role: 'button',
								onclick: () => {
									this._unchangedRegion.showAll(undefined);
								}
							},
							...renderLabelWithIcons('$(unfold)')
						)
					]
				),
				h('div@others', {
					style: {
						display: 'flex',
						justifyContent: 'center',
						alignItems: 'center'
					}
				})
			]),
			h('div.bottom@bottom', {
				title: localize('Click or drag to show more below'),
				role: 'button'
			})
		]);
		root.root.appendChild(this._nodes.root);
		const layoutInfo = observableFromEvent(this._editor.onDidLayoutChange, () => this._editor.getLayoutInfo());
		if (!this._hide) {
			this._register(
				applyStyle(this._nodes.first, {
					width: layoutInfo.map(l => l.contentLeft)
				})
			);
		} else {
			reset(this._nodes.first);
		}
		this._register(
			autorun(reader => {
				const isFullyRevealed =
					this._unchangedRegion.visibleLineCountTop.read(reader) + this._unchangedRegion.visibleLineCountBottom.read(reader) ===
					this._unchangedRegion.lineCount;
				this._nodes.bottom.classList.toggle('canMoveTop', !isFullyRevealed);
				this._nodes.bottom.classList.toggle('canMoveBottom', this._unchangedRegion.visibleLineCountBottom.read(reader) > 0);
				this._nodes.top.classList.toggle('canMoveTop', this._unchangedRegion.visibleLineCountTop.read(reader) > 0);
				this._nodes.top.classList.toggle('canMoveBottom', !isFullyRevealed);
				const isDragged = this._unchangedRegion.isDragged.read(reader);
				const domNode = this._editor.getDomNode();
				if (domNode) {
					domNode.classList.toggle('draggingUnchangedRegion', !!isDragged);
					if (isDragged === 'top') {
						domNode.classList.toggle('canMoveTop', this._unchangedRegion.visibleLineCountTop.read(reader) > 0);
						domNode.classList.toggle('canMoveBottom', !isFullyRevealed);
					} else if (isDragged === 'bottom') {
						domNode.classList.toggle('canMoveTop', !isFullyRevealed);
						domNode.classList.toggle('canMoveBottom', this._unchangedRegion.visibleLineCountBottom.read(reader) > 0);
					} else {
						domNode.classList.toggle('canMoveTop', false);
						domNode.classList.toggle('canMoveBottom', false);
					}
				}
			})
		);
		const editor2 = this._editor;
		this._register(
			addDisposableListener(this._nodes.top, 'mousedown', e => {
				if (e.button !== 0) {
					return;
				}
				this._nodes.top.classList.toggle('dragging', true);
				this._nodes.root.classList.toggle('dragging', true);
				e.preventDefault();
				const startTop = e.clientY;
				let didMove = false;
				const cur = this._unchangedRegion.visibleLineCountTop.get();
				this._unchangedRegion.isDragged.set('top', undefined);
				const window2 = getWindow(this._nodes.top);
				const mouseMoveListener = addDisposableListener(window2, 'mousemove', e2 => {
					const currentTop = e2.clientY;
					const delta = currentTop - startTop;
					didMove = didMove || Math.abs(delta) > 2;
					const lineDelta = Math.round(
						delta /
							editor2.getOption(
								67 // lineHeight
							)
					);
					const newVal = Math.max(0, Math.min(cur + lineDelta, this._unchangedRegion.getMaxVisibleLineCountTop()));
					this._unchangedRegion.visibleLineCountTop.set(newVal, undefined);
				});
				const mouseUpListener = addDisposableListener(window2, 'mouseup', e2 => {
					if (!didMove) {
						this._unchangedRegion.showMoreAbove(this._options.hideUnchangedRegionsRevealLineCount.get(), undefined);
					}
					this._nodes.top.classList.toggle('dragging', false);
					this._nodes.root.classList.toggle('dragging', false);
					this._unchangedRegion.isDragged.set(undefined, undefined);
					mouseMoveListener.dispose();
					mouseUpListener.dispose();
				});
			})
		);
		this._register(
			addDisposableListener(this._nodes.bottom, 'mousedown', e => {
				if (e.button !== 0) {
					return;
				}
				this._nodes.bottom.classList.toggle('dragging', true);
				this._nodes.root.classList.toggle('dragging', true);
				e.preventDefault();
				const startTop = e.clientY;
				let didMove = false;
				const cur = this._unchangedRegion.visibleLineCountBottom.get();
				this._unchangedRegion.isDragged.set('bottom', undefined);
				const window2 = getWindow(this._nodes.bottom);
				const mouseMoveListener = addDisposableListener(window2, 'mousemove', e2 => {
					const currentTop = e2.clientY;
					const delta = currentTop - startTop;
					didMove = didMove || Math.abs(delta) > 2;
					const lineDelta = Math.round(
						delta /
							editor2.getOption(
								67 // lineHeight
							)
					);
					const newVal = Math.max(0, Math.min(cur - lineDelta, this._unchangedRegion.getMaxVisibleLineCountBottom()));
					const top =
						this._unchangedRegionRange.endLineNumberExclusive > editor2.getModel().getLineCount()
							? editor2.getContentHeight()
							: editor2.getTopForLineNumber(this._unchangedRegionRange.endLineNumberExclusive);
					this._unchangedRegion.visibleLineCountBottom.set(newVal, undefined);
					const top2 =
						this._unchangedRegionRange.endLineNumberExclusive > editor2.getModel().getLineCount()
							? editor2.getContentHeight()
							: editor2.getTopForLineNumber(this._unchangedRegionRange.endLineNumberExclusive);
					editor2.setScrollTop(editor2.getScrollTop() + (top2 - top));
				});
				const mouseUpListener = addDisposableListener(window2, 'mouseup', e2 => {
					this._unchangedRegion.isDragged.set(undefined, undefined);
					if (!didMove) {
						const top = editor2.getTopForLineNumber(this._unchangedRegionRange.endLineNumberExclusive);
						this._unchangedRegion.showMoreBelow(this._options.hideUnchangedRegionsRevealLineCount.get(), undefined);
						const top2 = editor2.getTopForLineNumber(this._unchangedRegionRange.endLineNumberExclusive);
						editor2.setScrollTop(editor2.getScrollTop() + (top2 - top));
					}
					this._nodes.bottom.classList.toggle('dragging', false);
					this._nodes.root.classList.toggle('dragging', false);
					mouseMoveListener.dispose();
					mouseUpListener.dispose();
				});
			})
		);
		this._register(
			autorun(reader => {
				const children = [];
				if (!this._hide) {
					const lineCount = _unchangedRegion.getHiddenModifiedRange(reader).length;
					const linesHiddenText = localize(lineCount);
					const span = createDomElement('span', { title: localize('Double click to unfold') }, linesHiddenText);
					span.addEventListener('dblclick', e => {
						if (e.button !== 0) {
							return;
						}
						e.preventDefault();
						this._unchangedRegion.showAll(undefined);
					});
					children.push(span);
					const range2 = this._unchangedRegion.getHiddenModifiedRange(reader);
					const items = this._modifiedOutlineSource.getBreadcrumbItems(range2, reader);
					if (items.length > 0) {
						children.push(createDomElement('span', undefined, '\xA0\xA0|\xA0\xA0'));
						for (let i = 0; i < items.length; i++) {
							const item = items[i];
							const icon = symbolKindsToIcon(item.kind);
							const divItem = h(
								'div.breadcrumb-item',
								{
									style: {
										display: 'flex',
										alignItems: 'center'
									}
								},
								[renderIcon(icon), '\xA0', item.name, ...(i === items.length - 1 ? [] : [renderIcon(codicon_chevronRight)])]
							).root;
							children.push(divItem);
							divItem.onclick = () => {
								this._revealModifiedHiddenLine(item.startLineNumber);
							};
						}
					}
				}
				reset(this._nodes.others, ...children);
			})
		);
	}
}