menuRegistry.appendMenuItem(menubarEditMenu_menuId, {
	submenu: menubarCopy_menuId,
	title: localize('Copy As'),
	group: '2_ccp',
	order: 3
});

menuRegistry.appendMenuItem(editorContext_menuId, {
	submenu: { id: 'EditorContextShare' },
	title: localize('Share'),
	group: '11_share',
	order: -1,
	when: ContextKeyExpr.and(ContextKeyExpr.notEquals('resourceScheme', 'output'), ck_editorFocus_text)
});


menuRegistry.appendMenuItem({ id: 'EditorTitleContext' }, {
	submenu: editorTitleContextShare_menuId,
	title: localize('Share'),
	group: '11_share',
	order: -1
});


menuRegistry.appendMenuItem({ id: 'ExplorerContext' }, {
	submenu: explorerContextShare_menuId,
	title: localize('Share'),
	group: '11_share',
	order: -1
});