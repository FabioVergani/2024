function createAndFillInActionBarActions(menu, options2, target, primaryGroup, shouldInlineSubmenu, useSeparatorsInPrimaryActions) {
	const groups = menu.getActions(options2);
	const isPrimaryAction = typeof primaryGroup === 'string' ? actionGroup => actionGroup === primaryGroup : primaryGroup;
	fillInActions(groups, target, false, isPrimaryAction, shouldInlineSubmenu, useSeparatorsInPrimaryActions);
}

function createActionViewItem(instaService, action, options2) {
	if (action instanceof MenuItemAction) {
		return instaService.createInstance(MenuEntryActionViewItem, action, options2);
	} else if (action instanceof SubmenuItemAction) {
		if (action.item.isSelection) {
			return instaService.createInstance(SubmenuEntrySelectActionViewItem, action);
		} else {
			if (action.item.rememberDefaultAction) {
				return instaService.createInstance(DropdownWithDefaultActionViewItem, action, {
					...options2,
					persistLastActionId: true
				});
			} else {
				return instaService.createInstance(SubmenuEntryActionViewItem, action, options2);
			}
		}
	} else {
		return;
	}
}


class SubmenuEntryActionViewItem extends DropdownMenuActionViewItem {
	constructor(action, options2, _keybindingService, _contextMenuService, _themeService) {
		const dropdownOptions = {
			...options2,
			menuAsChild: options2?.menuAsChild ?? false,
			classNames: options2?.classNames ?? isThemeIcon(action.item.icon) ? asThemeIconClassNameString(action.item.icon) : undefined,
			keybindingProvider: options2?.keybindingProvider ?? (action2 => _keybindingService.lookupKeybinding(action2.id))
		};
		super(action, { getActions: () => action.actions }, _contextMenuService, dropdownOptions);
		this._keybindingService = _keybindingService;
		this._contextMenuService = _contextMenuService;
		this._themeService = _themeService;
	}
	render(container) {
		super.render(container);
		const el = this.element;
		if (el) {
			container.classList.add('menu-entry');
			const action = this._action;
			const itemIcon = action.item.icon;
			if (
				itemIcon &&
				!isThemeIcon(itemIcon) //
			) {
				el.classList.add('icon');
				const setBackgroundImage = () => {
					this.element.style.backgroundImage = asCSSUrl(
						isDark(this._themeService.getColorTheme().type) ? itemIcon.dark : itemIcon.light //
					);
				};
				setBackgroundImage();
				this._register(
					this._themeService.onDidColorThemeChange(
						setBackgroundImage //
					)
				);
			}
		} else {
			console.error();
		}
	}
}
__decorate(
	[
		__param(2, IKeybindingService),
		__param(3, IContextMenuService),
		__param(4, IThemeService)
		//...
	],
	SubmenuEntryActionViewItem
);

class DropdownWithDefaultActionViewItem extends BaseActionViewItem {
	constructor(
		submenuAction,
		options2,
		_keybindingService,
		_notificationService,
		_contextMenuService,
		_menuService,
		_instaService,
		_storageService
	) {
		super(null, submenuAction);
		this._keybindingService = _keybindingService;
		this._notificationService = _notificationService;
		this._contextMenuService = _contextMenuService;
		this._menuService = _menuService;
		this._instaService = _instaService;
		this._storageService = _storageService;
		this._container = null;
		this._options = options2;
		this._storageKey = `${submenuAction.item.submenu.id}_lastActionId`;
		let defaultAction;
		const defaultActionId = options2?.persistLastActionId
			? _storageService.get(
					this._storageKey,
					1 // WORKSPACE
				)
			: undefined;
		if (defaultActionId) {
			defaultAction = submenuAction.actions.find(a => defaultActionId === a.id);
		}
		if (!defaultAction) {
			defaultAction = submenuAction.actions[0];
		}
		this._defaultAction = this._instaService.createInstance(MenuEntryActionViewItem, defaultAction, {
			keybinding: this._getDefaultActionKeybindingLabel(defaultAction)
		});
		const dropdownOptions = {
			keybindingProvider: action => this._keybindingService.lookupKeybinding(action.id),
			...options2,
			menuAsChild: options2?.menuAsChild ?? true,
			classNames: options2?.classNames ?? ['codicon', 'codicon-chevron-down'],
			actionRunner: options2?.actionRunner ?? new ActionRunner()
		};
		this._dropdown = new DropdownMenuActionViewItem(submenuAction, submenuAction.actions, this._contextMenuService, dropdownOptions);
		this._register(
			this._dropdown.actionRunner.onDidRun(e => {
				if (e.action instanceof MenuItemAction) {
					this.update(e.action);
				}
			})
		);
	}
	update(lastAction) {
		if (this._options?.persistLastActionId) {
			this._storageService.store(
				this._storageKey,
				lastAction.id,
				1,
				1 //MACHINE
			);
		}
		this._defaultAction.dispose();
		this._defaultAction = this._instaService.createInstance(MenuEntryActionViewItem, lastAction, {
			keybinding: this._getDefaultActionKeybindingLabel(lastAction)
		});
		this._defaultAction.actionRunner = new ActionRunner2();
		if (this._container) {
			this._defaultAction.render(prepend(this._container, createDomElement('.action-container')));
		}
	}
	_getDefaultActionKeybindingLabel(defaultAction) {
		let defaultActionKeybinding;
		if (this._options?.renderKeybindingWithDefaultActionLabel) {
			const kb = this._keybindingService.lookupKeybinding(defaultAction.id);
			if (kb) {
				defaultActionKeybinding = `(${kb.getLabel()})`;
			}
		}
		return defaultActionKeybinding;
	}
	setActionContext(newContext) {
		super.setActionContext(newContext);
		this._defaultAction.setActionContext(newContext);
		this._dropdown.setActionContext(newContext);
	}
	render(container) {
		this._container = container;
		super.render(this._container);
		this._container.classList.add('monaco-dropdown-with-default');
		const primaryContainer = createDomElement('.action-container');
		this._defaultAction.render(append(this._container, primaryContainer));
		this._register(
			addDisposableListener(primaryContainer, EventType.KEY_DOWN, e => {
				const event = new StandardKeyboardEvent(e);
				if (
					event.equals(
						17 // RightArrow
					)
				) {
					this._defaultAction.element.tabIndex = -1;
					this._dropdown.focus();
					event.stopPropagation();
				}
			})
		);
		const dropdownContainer = createDomElement('.dropdown-action-container');
		this._dropdown.render(append(this._container, dropdownContainer));
		this._register(
			addDisposableListener(dropdownContainer, EventType.KEY_DOWN, e => {
				const event = new StandardKeyboardEvent(e);
				if (
					event.equals(
						15 // LeftArrow
					)
				) {
					this._defaultAction.element.tabIndex = 0;
					this._dropdown.setFocusable(false);
					this._defaultAction.element?.focus();
					event.stopPropagation();
				}
			})
		);
	}
	focus(fromRight) {
		if (fromRight) {
			this._dropdown.focus();
		} else {
			this._defaultAction.element.tabIndex = 0;
			this._defaultAction.element.focus();
		}
	}
	blur() {
		this._defaultAction.element.tabIndex = -1;
		this._dropdown.blur();
		this._container.blur();
	}
	setFocusable(focusable) {
		if (focusable) {
			this._defaultAction.element.tabIndex = 0;
		} else {
			this._defaultAction.element.tabIndex = -1;
			this._dropdown.setFocusable(false);
		}
	}
	dispose() {
		this._defaultAction.dispose();
		this._dropdown.dispose();
		super.dispose();
	}
}
__decorate(
	[
		__param(2, IKeybindingService),
		__param(3, INotificationService),
		__param(4, IContextMenuService),
		__param(5, IMenuService),
		__param(6, IInstantiationService),
		__param(7, IStorageService)
	],
	DropdownWithDefaultActionViewItem
);

class ActionRunner2 extends ActionRunner {
	async runAction(action, context) {
		await action.run(undefined);
	}
}
class SubmenuEntrySelectActionViewItem extends SelectActionViewItem {
	constructor(action, contextViewService) {
		super(
			null,
			action,
			action.actions.map(a => ({
				text: a.id === Separator.ID ? '\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500' : a.label,
				isDisabled: !a.enabled
			})),
			0,
			contextViewService,
			{
				selectBackground: asCssVariable(colorId_select_background),
				selectListBackground: asCssVariable(colorId_selectList_background),
				selectForeground: asCssVariable(colorId_select_foreground),
				decoratorRightForeground: asCssVariable(colorId_pickerGroup_foreground),
				selectBorder: asCssVariable(colorId_select_border),
				focusBorder: asCssVariable(colorId_focus_border),
				listFocusBackground: asCssVariable(colorId_quickInputListFocus_background),
				listInactiveSelectionIconForeground: asCssVariable(colorId_quickInputListFocusIcon_background),
				listFocusForeground: asCssVariable(colorId_quickInputListFocus_foreground),
				listFocusOutline: asCssVariableWithDefault(colorId_activeContrast_border, colorTransparent.toString()),
				listHoverBackground: asCssVariable(colorId_listHover_background),
				listHoverForeground: asCssVariable(colorId_listHover_foreground),
				listHoverOutline: asCssVariable(colorId_activeContrast_border),
				selectListBorder: asCssVariable(colorId_editorWidget_border)
			},
			{
				optionsAsChildren: true
			}
		);
		this.select(
			Math.max(
				0,
				action.actions.findIndex(a => a.checked)
			)
		);
	}
	render(container) {
		super.render(container);
		container.style.borderColor = asCssVariable(colorId_select_border);
	}
	runAction(option, index) {
		const action = this.action.actions[index];
		if (action) {
			this.actionRunner.run(action);
		}
	}
}
__decorate(
	[
		__param(1, IContextViewService)
		//...
	],
	SubmenuEntrySelectActionViewItem
);