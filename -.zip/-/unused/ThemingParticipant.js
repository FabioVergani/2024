
const isDark = e => e === 'dark' || e === 'hcDark';

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



		addMatchMediaChangeListener(mainWindow, '(forced-colors: active)', () => {
			this._onOSSchemeChanged();
		});
const isHighContrast = e => e === 'hcDark' || e === 'hcLight';

					if (isHighContrast(options2.themeType)) {
						actualInlineDecorations.push(
							new LineDecoration(
								startColumn,
								endColumn,
								'inline-selected-text',
								0 //InlineDecorationType.Regular
							)
						);
					}

	_onOSSchemeChanged() {
		if (this._autoDetectHighContrast) {
			const wantsHighContrast = mainWindow.matchMedia(`(forced-colors: active)`).matches;
			if (wantsHighContrast !== isHighContrast(this._theme.type)) {
				let newThemeName;
				if (isDark(this._theme.type)) {
					newThemeName = wantsHighContrast ? themeName_DARK_HC : themeName_DARK;
				} else {
					newThemeName = wantsHighContrast ? themeName_LIGHT_HC : themeName_LIGHT;
				}
				this._updateActualTheme(this._knownThemes.get(newThemeName));
			}
		}
	}





// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const isThemeColor = e => (e ? typeof e === 'object' && typeof e.id === 'string' : false);

const isThemeIcon = e => {
	return e && typeof e === 'object' && typeof e.id === 'string' && (typeof e.color === 'undefined' || isThemeColor(e.color));
};


const ThemeIcon = {};

const themeIconModify = (icon, modifier) => {
	let id = icon.id;
	const tildeIndex = id.lastIndexOf('~');
	if (tildeIndex !== -1) {
		id = id.substring(0, tildeIndex);
	}
	if (modifier) {
		id = `${id}~${modifier}`;
	}
	return { id };
};


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




class ThemingRegistry {
	constructor() {
		this.themingParticipants = [];
		this.onThemingParticipantAddedEmitter = new Emitter();
	}
	onColorThemeChange(e) {
		this.themingParticipants.push(e);
		this.onThemingParticipantAddedEmitter.fire(e);
		return toDisposable(() => {
			this.themingParticipants.splice(this.themingParticipants.indexOf(e), 1);
		});
	}
	getThemingParticipants() {
		return this.themingParticipants;
	}
}
const themingRegistry = new ThemingRegistry();
registry.add('base.contributions.theming', themingRegistry);



const registerThemingParticipant = e => themingRegistry.onColorThemeChange(e);

	registerThemingParticipant((theme, collector) => {
		const a = theme.getColor(colorId_lineNumberDimmed_foreground);
		if (a) {
			collector.addRule(`.monaco-editor .line-numbers.dimmed-line-number { color: ${a}; }`);
		} else {
			const b = theme.getColor(colorId_lineNumber_foreground);
			if (b) {
				collector.addRule(`.monaco-editor .line-numbers.dimmed-line-number { color: ${b.transparent(0.4)}; }`);
			}
		}
	});
	registerThemingParticipant((theme, collector) => {
		const a = theme.getColor(colorId_lineHighlight_background);
		if (a) {
			collector.addRule(`.monaco-editor .view-overlays .current-line { background-color: ${a}; }`);
			collector.addRule(`.monaco-editor .margin-view-overlays .current-line-margin { background-color: ${a}; border: none; }`);
		}
		if (!a || a.isTransparent()) {
			const b = theme.getColor(colorId_lineHighlight_border);
			if (b) {
				collector.addRule(`.monaco-editor .view-overlays .current-line-exact { border: 2px solid ${b}; }`);
				collector.addRule(`.monaco-editor .margin-view-overlays .current-line-exact-margin { border: 2px solid ${b}; }`);
				if (isHighContrast(theme.type)) {
					collector.addRule(`.monaco-editor .view-overlays .current-line-exact { border-width: 1px; }`);
					collector.addRule(`.monaco-editor .margin-view-overlays .current-line-exact-margin { border-width: 1px; }`);
				}
			}
		}
	});
	registerThemingParticipant((theme, collector) => {
		const a = theme.getColor(colorId_selection_foreground);
		if (a && !a.isTransparent()) {
			collector.addRule(`.monaco-editor .view-line span.inline-selected-text { color: ${a}; }`);
		}
	});
	registerThemingParticipant((theme, collector) => {
		for (const cursorTheme of [
			{
				class: '.cursor',
				foreground: colorId_cursor_foreground,
				background: colorId_cursor_background
			},
			{
				class: '.cursor-primary',
				foreground: colorId_multiCursorPrimary_foreground,
				background: colorId_multiCursorPrimary_background
			},
			{
				class: '.cursor-secondary',
				foreground: colorId_multiCursorSecondary_foreground,
				background: colorId_multiCursorSecondary_background
			}
		]) {
			const a = theme.getColor(cursorTheme.foreground);
			if (a) {
				const e = theme.getColor(cursorTheme.background) || a.opposite();
				collector.addRule(`.monaco-editor .cursors-layer ${cursorTheme.class} { background-color: ${a}; border-color: ${a}; color: ${e}; }`);
				if (isHighContrast(theme.type)) {
					collector.addRule(`.monaco-editor .cursors-layer.has-selection ${cursorTheme.class} { border-left: 1px solid ${e}; border-right: 1px solid ${e}; }`);
				}
			}
		}
	});
	registerThemingParticipant((theme, collector) => {
		const a = theme.getColor(colorId_widgetHover_border);
		if (a) {
			collector.addRule(`.monaco-workbench .workbench-hover .hover-row:not(:first-child):not(:empty) { border-top: 1px solid ${a.transparent(0.5)}; }`);
			collector.addRule(`.monaco-workbench .workbench-hover hr { border-top: 1px solid ${a.transparent(0.5)}; }`);
		}
	});
	registerThemingParticipant((theme, collector) => {
		const background = theme.getColor(colorId_background);
		const lineHighlight = theme.getColor(colorId_lineHighlight_background);
		const e = lineHighlight && !lineHighlight.isTransparent() ? lineHighlight : background;
		if (e) {
			collector.addRule(`.monaco-editor .inputarea.ime-input { background-color: ${e}; }`);
		}
	});



registerThemingParticipant((theme, collector) => {
	const colors = [
		{
			bracketColor: colorId_bracketHighlighting_foreground1,
			guideColor: colorId_bracketPairGuide_background1,
			guideColorActive: colorId_bracketPairGuideActive_background1
		},
		{
			bracketColor: colorId_bracketHighlighting_foreground2,
			guideColor: colorId_bracketPairGuide_background2,
			guideColorActive: colorId_bracketPairGuideActive_background2
		},
		{
			bracketColor: colorId_bracketHighlighting_foreground3,
			guideColor: colorId_bracketPairGuide_background3,
			guideColorActive: colorId_bracketPairGuideActive_background3
		},
		{
			bracketColor: colorId_bracketHighlighting_foreground4,
			guideColor: colorId_bracketPairGuide_background4,
			guideColorActive: colorId_bracketPairGuideActive_background4
		},
		{
			bracketColor: colorId_bracketHighlighting_foreground5,
			guideColor: colorId_bracketPairGuide_background5,
			guideColorActive: colorId_bracketPairGuideActive_background5
		},
		{
			bracketColor: colorId_bracketHighlighting_foreground6,
			guideColor: colorId_bracketPairGuide_background6,
			guideColorActive: colorId_bracketPairGuideActive_background6
		}
	];
	const colorProvider = new BracketPairGuidesClassNames();
	const indentColors = [
		{
			indentColor: colorId_indentGuide_background1,
			indentColorActive: colorId_indentGuideActive_background1
		},
		{
			indentColor: colorId_indentGuide_background2,
			indentColorActive: colorId_indentGuideActive_background2
		},
		{
			indentColor: colorId_indentGuide_background3,
			indentColorActive: colorId_indentGuideActive_background3
		},
		{
			indentColor: colorId_indentGuide_background4,
			indentColorActive: colorId_indentGuideActive_background4
		},
		{
			indentColor: colorId_indentGuide_background5,
			indentColorActive: colorId_indentGuideActive_background5
		},
		{
			indentColor: colorId_indentGuide_background6,
			indentColorActive: colorId_indentGuideActive_background6
		}
	];
	const colorValues = colors
		.map(c => {
			const bracketColor = theme.getColor(c.bracketColor);
			const effectiveGuideColor = transparentToUndefined(transparentToUndefined(theme.getColor(c.guideColor)) ?? bracketColor?.transparent(0.3));
			const effectiveGuideColorActive = transparentToUndefined(transparentToUndefined(theme.getColor(c.guideColorActive)) ?? bracketColor);
			return effectiveGuideColor && effectiveGuideColorActive
				? {
						guideColor: effectiveGuideColor,
						guideColorActive: effectiveGuideColorActive
					}
				: null;
		})
		.filter(notIsNullOrUndefined);
	const indentColorValues = indentColors
		.map(c => {
			const indentColor = theme.getColor(c.indentColor);
			const indentColorActive = theme.getColor(c.indentColorActive);
			const effectiveIndentColor = transparentToUndefined(indentColor);
			const effectiveIndentColorActive = transparentToUndefined(indentColorActive);
			if (!effectiveIndentColor || !effectiveIndentColorActive) {
				return;
			}
			return {
				indentColor: effectiveIndentColor,
				indentColorActive: effectiveIndentColorActive
			};
		})
		.filter(notIsNullOrUndefined);
	if (colorValues.length > 0) {
		for (let level = 0; level < 30; level++) {
			const colors2 = colorValues[level % colorValues.length];
			collector.addRule(`.monaco-editor .${colorProvider.getInlineClassNameOfLevel(level).replace(/ /g, '.')} { --guide-color: ${colors2.guideColor}; --guide-color-active: ${colors2.guideColorActive}; }`);
		}
		collector.addRule(`.monaco-editor .vertical { box-shadow: 1px 0 0 0 var(--guide-color) inset; }`);
		collector.addRule(`.monaco-editor .horizontal-top { border-top: 1px solid var(--guide-color); }`);
		collector.addRule(`.monaco-editor .horizontal-bottom { border-bottom: 1px solid var(--guide-color); }`);
		collector.addRule(`.monaco-editor .vertical.${colorProvider.activeClassName} { box-shadow: 1px 0 0 0 var(--guide-color-active) inset; }`);
		collector.addRule(`.monaco-editor .horizontal-top.${colorProvider.activeClassName} { border-top: 1px solid var(--guide-color-active); }`);
		collector.addRule(`.monaco-editor .horizontal-bottom.${colorProvider.activeClassName} { border-bottom: 1px solid var(--guide-color-active); }`);
	}
	if (indentColorValues.length > 0) {
		for (let level = 0; level < 30; level++) {
			const colors2 = indentColorValues[level % indentColorValues.length];
			collector.addRule(`.monaco-editor .lines-content .core-guide-indent.lvl-${level} { --indent-color: ${colors2.indentColor}; --indent-color-active: ${colors2.indentColorActive}; }`);
		}
		collector.addRule(`.monaco-editor .lines-content .core-guide-indent { box-shadow: 1px 0 0 0 var(--indent-color) inset; }`);
		collector.addRule(`.monaco-editor .lines-content .core-guide-indent.indent-active { box-shadow: 1px 0 0 0 var(--indent-color-active) inset; }`);
	}
});

registerThemingParticipant((theme, collector) => {
	const colors = [colorId_bracketHighlighting_foreground1, colorId_bracketHighlighting_foreground2, colorId_bracketHighlighting_foreground3, colorId_bracketHighlighting_foreground4, colorId_bracketHighlighting_foreground5, colorId_bracketHighlighting_foreground6];
	const colorProvider = new ColorProvider();
	collector.addRule(`.monaco-editor .${colorProvider.unexpectedClosingBracketClassName} { color: ${theme.getColor(colorId_bracketHighlighting_unexpectedBracket_foreground)}; }`);
	const colorValues = colors
		.map(c => theme.getColor(c))
		.filter(c => !!c)
		.filter(c => !c.isTransparent());
	for (let level = 0; level < 30; level++) {
		const color = colorValues[level % colorValues.length];
		collector.addRule(`.monaco-editor .${colorProvider.getInlineClassNameOfLevel(level)} { color: ${color}; }`);
	}
});

registerThemingParticipant((theme, collector) => {
	const errorForeground = theme.getColor(colorId_error_foreground);
	if (errorForeground) {
		collector.addRule(`.monaco-editor .squiggly-error { background: url("data:image/svg+xml,${getSquigglySVGData(errorForeground)}") repeat-x bottom left; }`);
	}
	const warningForeground = theme.getColor(colorId_warning_foreground);
	if (warningForeground) {
		collector.addRule(`.monaco-editor .squiggly-warning { background: url("data:image/svg+xml,${getSquigglySVGData(warningForeground)}") repeat-x bottom left; }`);
	}
	const infoForeground = theme.getColor(colorId_info_foreground);
	if (infoForeground) {
		collector.addRule(`.monaco-editor .squiggly-info { background: url("data:image/svg+xml,${getSquigglySVGData(infoForeground)}") repeat-x bottom left; }`);
	}
	const hintForeground = theme.getColor(colorId_hint_foreground);
	if (hintForeground) {
		collector.addRule(`.monaco-editor .squiggly-hint { background: url("data:image/svg+xml,${getDotDotDotSVGData(hintForeground)}") no-repeat bottom left; }`);
	}
	const unnecessaryForeground = theme.getColor(colorId_unnecessaryCode_opacity);
	if (unnecessaryForeground) {
		collector.addRule(`.monaco-editor.showUnused .squiggly-inline-unnecessary { opacity: ${unnecessaryForeground.rgba.a}; }`);
	}
});



registerThemingParticipant((theme, collector) => {
	const hoverBorder = theme.getColor(colorId_widgetHover_border);
	if (hoverBorder) {
		const bs = '.monaco-editor .monaco-hover';
		collector.addRule(`${bs} .hover-row:not(:first-child):not(:empty) { border-top: 1px solid ${hoverBorder.transparent(0.5)}; }`);
		collector.addRule(`${bs} hr { border-top: 1px solid ${hoverBorder.transparent(0.5)}; }`);
		collector.addRule(`${bs} hr { border-bottom: 0px solid ${hoverBorder.transparent(0.5)}; }`);
	}
});

registerThemingParticipant((theme, collector) => {
	const selectionHighlight = theme.getColor(colorId_selectionHighlight_background);
	if (selectionHighlight) {
		collector.addRule(`.monaco-editor .selectionHighlight { background-color: ${selectionHighlight.transparent(0.5)}; }`);
	}
});

themingRegistry.getThemingParticipants().forEach(p => p(this._theme, ruleCollector, this._environment));