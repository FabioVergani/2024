




class StandaloneTextModelService {
	constructor(modelService) {
		this.modelService = modelService;
	}
	createModelReference(resource) {
		const model = this.modelService.getModel(resource);
		if (!model) {
			return Promise.reject(new Error(`Model not found`));
		}
		return Promise.resolve(new ImmortalReference(new SimpleModel(model)));
	}
}
__decorate([__param(0, IModelService)], StandaloneTextModelService);
registerSingleton(
	ITextModelService,
	StandaloneTextModelService,
	0 //Eager
);

class StandaloneEditorProgressService {
	show() {
		return StandaloneEditorProgressService.NULL_PROGRESS_RUNNER;
	}
	async showWhile(promise, delay) {
		await promise;
	}
}
StandaloneEditorProgressService.NULL_PROGRESS_RUNNER = {
	done: dummyArrowFn,
	total: dummyArrowFn,
	worked: dummyArrowFn
};
registerSingleton(
	IEditorProgressService,
	StandaloneEditorProgressService,
	0 //Eager
);




class StandaloneProgressService {
	withProgress(_options, task, onDidCancel) {
		return task({
			report: dummyArrowFn
		});
	}
}
registerSingleton(
	IProgressService,
	StandaloneProgressService,
	0 //Eager
);