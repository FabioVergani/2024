



class EditorScopedLayoutService extends StandaloneLayoutService {
	get mainContainer() {
		return this._container;
	}
	constructor(_container, codeEditorService) {
		super(codeEditorService);
		this._container = _container;
	}
}
__decorate([__param(1, ICodeEditorService)], EditorScopedLayoutService);