function isButton(e) {
	if (
		(e.tagName === 'A' && e.classList.contains('monaco-button')) ||
		(e.tagName === 'DIV' && e.classList.contains('monaco-button-dropdown'))
	) {
		return true;
	}
	if (e.classList.contains('monaco-list')) {
		return false;
	}
	if (!e.parentElement) {
		return false;
	}
	return isButton(e.parentElement);
}