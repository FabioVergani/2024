const ck_isMac = new RawContextKey('isMac', isMacintosh);
const ck_isIOS = new RawContextKey('isIOS', isIOS);

const ck_isLinux = new RawContextKey('isLinux', isLinux);
const ck_isWindows = new RawContextKey('isWindows', isWindows);
const ck_isMobile = new RawContextKey('isMobile', isMobile);

const ck_isWeb = new RawContextKey('isWeb', true);
const ck_inputFocus = new RawContextKey('inputFocus', false);


const WorkbenchListTypeNavigationModeKey = 'listTypeNavigationMode';
const WorkbenchListAutomaticKeyboardNavigationLegacyKey = 'listAutomaticKeyboardNavigation';
const multiSelectModifierSettingKey = 'workbench.list.multiSelectModifier';
const openModeSettingKey = 'workbench.list.openMode';
const horizontalScrollingKey = 'workbench.list.horizontalScrolling';
const defaultFindModeSettingKey = 'workbench.list.defaultFindMode';
const typeNavigationModeSettingKey = 'workbench.list.typeNavigationMode';
const keyboardNavigationSettingKey = 'workbench.list.keyboardNavigation';
const scrollByPageKey = 'workbench.list.scrollByPage';
const defaultFindMatchTypeSettingKey = 'workbench.list.defaultFindMatchType';
const treeIndentKey = 'workbench.tree.indent';
const treeRenderIndentGuidesKey = 'workbench.tree.renderIndentGuides';
const listSmoothScrolling = 'workbench.list.smoothScrolling';
const mouseWheelScrollSensitivityKey = 'workbench.list.mouseWheelScrollSensitivity';
const fastScrollSensitivityKey = 'workbench.list.fastScrollSensitivity';
const treeExpandMode = 'workbench.tree.expandMode';
const treeStickyScroll = 'workbench.tree.enableStickyScroll';
const treeStickyScrollMaxElements = 'workbench.tree.stickyScrollMaxItemCount';

function createScopedContextKeyService(contextKeyService, widget) {
	const result = contextKeyService.createScoped(widget.getHTMLElement());
	ck_listFocus.bindTo(result);
	return result;
}
function createScrollObserver(contextKeyService, widget) {
	const listScrollAt = ck_listScrollAtBoundary.bindTo(contextKeyService);
	const update = () => {
		const atTop = widget.scrollTop === 0;
		const atBottom = widget.scrollHeight - widget.renderHeight - widget.scrollTop < 1;
		if (atTop && atBottom) {
			listScrollAt.set('both');
		} else if (atTop) {
			listScrollAt.set('top');
		} else if (atBottom) {
			listScrollAt.set('bottom');
		} else {
			listScrollAt.set('none');
		}
	};
	update();
	return widget.onDidScroll(update);
}
function useAltAsMultipleSelectionModifier(configurationService) {
	return configurationService.getValue(multiSelectModifierSettingKey) === 'alt';
}
function toWorkbenchListOptions(accessor, options2) {
	const configurationService = accessor.get(IConfigurationService);
	const keybindingService = accessor.get(IKeybindingService);
	const disposables = new DisposableStore();
	function _createKeyboardNavigationEventFilter(keybindingService) {
		let inMultiChord = false;
		return event => {
			if (event.toKeyCodeChord().isModifierKey()) {
				return false;
			}
			if (inMultiChord) {
				inMultiChord = false;
				return false;
			}
			const result = keybindingService.softDispatch(event, event.target);
			if (result.kind === 1) {
				inMultiChord = true;
				return false;
			}
			inMultiChord = false;
			return result.kind === 0;
		};
	}
	const result = {
		...options2,
		keyboardNavigationDelegate: {
			mightProducePrintableCharacter(e) {
				return keybindingService.mightProducePrintableCharacter(e);
			}
		},
		smoothScrolling: Boolean(configurationService.getValue(listSmoothScrolling)),
		mouseWheelScrollSensitivity: configurationService.getValue(mouseWheelScrollSensitivityKey),
		fastScrollSensitivity: configurationService.getValue(fastScrollSensitivityKey),
		multipleSelectionController:
			options2.multipleSelectionController ?? disposables.add(new MultipleSelectionController(configurationService)),
		keyboardNavigationEventFilter: _createKeyboardNavigationEventFilter(keybindingService),
		scrollByPage: Boolean(configurationService.getValue(scrollByPageKey))
	};
	return [result, disposables];
}
function getDefaultTreeFindMode(configurationService) {
	const value = configurationService.getValue(defaultFindModeSettingKey);
	if (value === 'highlight') {
		return 0;
	} else if (value === 'filter') {
		return 1;
	}
	const deprecatedValue = configurationService.getValue(keyboardNavigationSettingKey);
	if (deprecatedValue === 'simple' || deprecatedValue === 'highlight') {
		return 0;
	} else if (deprecatedValue === 'filter') {
		return 1;
	}
	return;
}
function getDefaultTreeFindMatchType(configurationService) {
	const value = configurationService.getValue(defaultFindMatchTypeSettingKey);
	if (value === 'fuzzy') {
		return TreeFindMatchType.Fuzzy;
	} else if (value === 'contiguous') {
		return TreeFindMatchType.Contiguous;
	}
	return;
}
function workbenchTreeDataPreamble(accessor, options2) {
	const configurationService = accessor.get(IConfigurationService);
	const contextViewService = accessor.get(IContextViewService);
	const contextKeyService = accessor.get(IContextKeyService);
	const instantiationService = accessor.get(IInstantiationService);
	const getTypeNavigationMode = () => {
		const modeString = contextKeyService.getContextKeyValue(WorkbenchListTypeNavigationModeKey);
		if (modeString === 'automatic') {
			return TypeNavigationMode.Automatic;
		} else if (modeString === 'trigger') {
			return TypeNavigationMode.Trigger;
		}
		const modeBoolean = contextKeyService.getContextKeyValue(WorkbenchListAutomaticKeyboardNavigationLegacyKey);
		if (modeBoolean === false) {
			return TypeNavigationMode.Trigger;
		}
		const configString = configurationService.getValue(typeNavigationModeSettingKey);
		if (configString === 'automatic') {
			return TypeNavigationMode.Automatic;
		} else if (configString === 'trigger') {
			return TypeNavigationMode.Trigger;
		}
		return;
	};
	const horizontalScrolling =
		options2.horizontalScrolling !== undefined
			? options2.horizontalScrolling
			: Boolean(configurationService.getValue(horizontalScrollingKey));
	const [workbenchListOptions, disposable] = instantiationService.invokeFunction(toWorkbenchListOptions, options2);
	const paddingBottom = options2.paddingBottom;
	const renderIndentGuides =
		options2.renderIndentGuides !== undefined ? options2.renderIndentGuides : configurationService.getValue(treeRenderIndentGuidesKey);
	return {
		getTypeNavigationMode,
		disposable,
		options: {
			// ...options, // TODO@Joao why is this not splatted here?
			keyboardSupport: false,
			...workbenchListOptions,
			indent:
				typeof configurationService.getValue(treeIndentKey) === 'number' ? configurationService.getValue(treeIndentKey) : undefined,
			renderIndentGuides,
			smoothScrolling: Boolean(configurationService.getValue(listSmoothScrolling)),
			defaultFindMode: getDefaultTreeFindMode(configurationService),
			defaultFindMatchType: getDefaultTreeFindMatchType(configurationService),
			horizontalScrolling,
			scrollByPage: Boolean(configurationService.getValue(scrollByPageKey)),
			paddingBottom,
			hideTwistiesOfChildlessElements: options2.hideTwistiesOfChildlessElements,
			expandOnlyOnTwistieClick: options2.expandOnlyOnTwistieClick ?? configurationService.getValue(treeExpandMode) === 'doubleClick',
			contextViewProvider: contextViewService,
			findWidgetStyles: defaultStyle_widget,
			enableStickyScroll: Boolean(configurationService.getValue(treeStickyScroll)),
			stickyScrollMaxItemCount: Number(configurationService.getValue(treeStickyScrollMaxElements))
		}
	};
}

const IListService = createEditorServiceDecorator('listService');

class ListService {
	get lastFocusedList() {
		return this._lastFocusedWidget;
	}
	constructor() {
		this.disposables = new DisposableStore();
		this.lists = [];
		this._lastFocusedWidget = undefined;
		this._hasCreatedStyleController = false;
	}
	setLastFocusedList(widget) {
		if (widget !== this._lastFocusedWidget) {
			this._lastFocusedWidget?.getHTMLElement().classList.remove('last-focused');
			(this._lastFocusedWidget = widget)?.getHTMLElement().classList.add('last-focused');
		}
	}
	register(widget, extraContextKeys) {
		if (!this._hasCreatedStyleController) {
			this._hasCreatedStyleController = true;
			const styleController = new DefaultStyleController(createStyleSheet(), '');
			styleController.style(defaultStyle_list);
		}
		if (this.lists.some(l => l.widget === widget)) {
			throw new Error('Cannot register the same widget multiple times');
		}
		const registeredList = { widget, extraContextKeys };
		this.lists.push(registeredList);
		if (isActiveElement(widget.getHTMLElement())) {
			this.setLastFocusedList(widget);
		}
		return combinedDisposable(
			widget.onDidFocus(() => this.setLastFocusedList(widget)),
			toDisposable(() => this.lists.splice(this.lists.indexOf(registeredList), 1)),
			widget.onDidDispose(() => {
				this.lists = this.lists.filter(l => l !== registeredList);
				if (this._lastFocusedWidget === widget) {
					this.setLastFocusedList(undefined);
				}
			})
		);
	}
	dispose() {
		this.disposables.dispose();
	}
}
registerSingleton(
	IListService,
	ListService,
	0 //Eager
);

const ck_listScrollAtBoundary = new RawContextKey('listScrollAtBoundary', 'none');
const ck_listFocus = new RawContextKey('listFocus', true);

const ck_listScrollAtTop = ContextKeyExpr.or(ck_listScrollAtBoundary.isEqualTo('top'), ck_listScrollAtBoundary.isEqualTo('both'));

const ck_listScrollAtBottom = ContextKeyExpr.or(ck_listScrollAtBoundary.isEqualTo('bottom'), ck_listScrollAtBoundary.isEqualTo('both'));

const ck_treeStickyScrollFocused = new RawContextKey('treestickyScrollFocused', false);

const ck_listSupportsMultiSelectContextKey = new RawContextKey('listSupportsMultiselect', true);

const ck_listX = ContextKeyExpr.and(ck_listFocus, ContextKeyExpr.not('inputFocus'), ck_treeStickyScrollFocused.negate());
const ck_listHasSelectionOrFocus = new RawContextKey('listHasSelectionOrFocus', false);
const ck_listDoubleSelection = new RawContextKey('listDoubleSelection', false);
const ck_listMultiSelection = new RawContextKey('listMultiSelection', false);
const ck_listSelectionNavigation = new RawContextKey('listSelectionNavigation', false);
const ck_listSupportsFind = new RawContextKey('listSupportsFind', true);
const ck_treeElementCanCollapse = new RawContextKey('treeElementCanCollapse', false);
const ck_treeElementHasParent = new RawContextKey('treeElementHasParent', false);
const ck_treeElementCanExpand = new RawContextKey('treeElementCanExpand', false);
const ck_treeElementHasChild = new RawContextKey('treeElementHasChild', false);
const ck_treeFindOpen = new RawContextKey('treeFindOpen', false);

class MultipleSelectionController extends Disposable {
	constructor(configurationService) {
		super();
		this.configurationService = configurationService;
		this.useAltAsMultipleSelectionModifier = useAltAsMultipleSelectionModifier(configurationService);
		this.registerListeners();
	}
	registerListeners() {
		this._register(
			this.configurationService.onDidChangeConfiguration(e => {
				if (e.affectsConfiguration(multiSelectModifierSettingKey)) {
					this.useAltAsMultipleSelectionModifier = useAltAsMultipleSelectionModifier(this.configurationService);
				}
			})
		);
	}
	isSelectionSingleChangeEvent(event) {
		if (this.useAltAsMultipleSelectionModifier) {
			return event.browserEvent.altKey;
		}
		return isSelectionSingleChangeEvent(event);
	}
	isSelectionRangeChangeEvent(event) {
		return isSelectionRangeChangeEvent(event);
	}
}

class WorkbenchList extends List {
	constructor(
		user,
		container,
		delegate,
		renderers,
		options2,
		contextKeyService,
		listService,
		configurationService,
		instantiationService
	) {
		const horizontalScrolling =
			typeof options2.horizontalScrolling !== 'undefined'
				? options2.horizontalScrolling
				: Boolean(configurationService.getValue(horizontalScrollingKey));
		const [workbenchListOptions, workbenchListOptionsDisposable] = instantiationService.invokeFunction(
			toWorkbenchListOptions,
			options2
		);
		super(user, container, delegate, renderers, {
			keyboardSupport: false,
			...workbenchListOptions,
			horizontalScrolling
		});
		this.disposables.add(workbenchListOptionsDisposable);
		this.contextKeyService = createScopedContextKeyService(contextKeyService, this);
		this.disposables.add(createScrollObserver(this.contextKeyService, this));
		this.listSupportsMultiSelect = ck_listSupportsMultiSelectContextKey.bindTo(this.contextKeyService);
		this.listSupportsMultiSelect.set(options2.multipleSelectionSupport !== false);
		const listSelectionNavigation = ck_listSelectionNavigation.bindTo(this.contextKeyService);
		listSelectionNavigation.set(Boolean(options2.selectionNavigation));
		this.listHasSelectionOrFocus = ck_listHasSelectionOrFocus.bindTo(this.contextKeyService);
		this.listDoubleSelection = ck_listDoubleSelection.bindTo(this.contextKeyService);
		this.listMultiSelection = ck_listMultiSelection.bindTo(this.contextKeyService);
		this.horizontalScrolling = options2.horizontalScrolling;
		this._useAltAsMultipleSelectionModifier = useAltAsMultipleSelectionModifier(configurationService);
		this.disposables.add(this.contextKeyService);
		this.disposables.add(listService.register(this));
		this.updateStyles(options2.overrideStyles);
		this.disposables.add(
			this.onDidChangeSelection(() => {
				const selection = this.getSelection();
				const focus = this.getFocus();
				this.contextKeyService.bufferChangeEvents(() => {
					this.listHasSelectionOrFocus.set(selection.length > 0 || focus.length > 0);
					this.listMultiSelection.set(selection.length > 1);
					this.listDoubleSelection.set(selection.length === 2);
				});
			})
		);
		this.disposables.add(
			this.onDidChangeFocus(() => {
				const selection = this.getSelection();
				const focus = this.getFocus();
				this.listHasSelectionOrFocus.set(selection.length > 0 || focus.length > 0);
			})
		);
		this.disposables.add(
			configurationService.onDidChangeConfiguration(e => {
				if (e.affectsConfiguration(multiSelectModifierSettingKey)) {
					this._useAltAsMultipleSelectionModifier = useAltAsMultipleSelectionModifier(configurationService);
				}
				let options3 = {};
				if (e.affectsConfiguration(horizontalScrollingKey) && this.horizontalScrolling === undefined) {
					const horizontalScrolling2 = Boolean(configurationService.getValue(horizontalScrollingKey));
					options3 = {
						...options3,
						horizontalScrolling: horizontalScrolling2
					};
				}
				if (e.affectsConfiguration(scrollByPageKey)) {
					const scrollByPage = Boolean(configurationService.getValue(scrollByPageKey));
					options3 = { ...options3, scrollByPage };
				}
				if (e.affectsConfiguration(listSmoothScrolling)) {
					const smoothScrolling = Boolean(configurationService.getValue(listSmoothScrolling));
					options3 = { ...options3, smoothScrolling };
				}
				if (e.affectsConfiguration(mouseWheelScrollSensitivityKey)) {
					const mouseWheelScrollSensitivity = configurationService.getValue(mouseWheelScrollSensitivityKey);
					options3 = { ...options3, mouseWheelScrollSensitivity };
				}
				if (e.affectsConfiguration(fastScrollSensitivityKey)) {
					const fastScrollSensitivity = configurationService.getValue(fastScrollSensitivityKey);
					options3 = { ...options3, fastScrollSensitivity };
				}
				if (Object.keys(options3).length > 0) {
					this.updateOptions(options3);
				}
			})
		);
		this.navigator = new ListResourceNavigator(this, {
			configurationService,
			...options2
		});
		this.disposables.add(this.navigator);
	}
	updateOptions(options2) {
		super.updateOptions(options2);
		if (options2.overrideStyles !== undefined) {
			this.updateStyles(options2.overrideStyles);
		}
		if (options2.multipleSelectionSupport !== undefined) {
			this.listSupportsMultiSelect.set(!!options2.multipleSelectionSupport);
		}
	}
	updateStyles(styles) {
		this.style(styles ? getListStyles(styles) : defaultStyle_list);
	}
}
__decorate(
	[
		__param(5, IContextKeyService)
		__param(6, IListService),
		__param(7, IConfigurationService),
		__param(8, IInstantiationService)
		//...
	],
	WorkbenchList
);

class WorkbenchPagedList extends PagedList {
	constructor(
		user,
		container,
		delegate,
		renderers,
		options2,
		contextKeyService,
		listService,
		configurationService,
		instantiationService
	) {
		const horizontalScrolling =
			typeof options2.horizontalScrolling !== 'undefined'
				? options2.horizontalScrolling
				: Boolean(configurationService.getValue(horizontalScrollingKey));
		const [workbenchListOptions, workbenchListOptionsDisposable] = instantiationService.invokeFunction(
			toWorkbenchListOptions,
			options2
		);
		super(user, container, delegate, renderers, {
			keyboardSupport: false,
			...workbenchListOptions,
			horizontalScrolling
		});
		this.disposables = new DisposableStore();
		this.disposables.add(workbenchListOptionsDisposable);
		this.contextKeyService = createScopedContextKeyService(contextKeyService, this);
		this.disposables.add(createScrollObserver(this.contextKeyService, this.widget));
		this.horizontalScrolling = options2.horizontalScrolling;
		this.listSupportsMultiSelect = ck_listSupportsMultiSelectContextKey.bindTo(this.contextKeyService);
		this.listSupportsMultiSelect.set(options2.multipleSelectionSupport !== false);
		const listSelectionNavigation = ck_listSelectionNavigation.bindTo(this.contextKeyService);
		listSelectionNavigation.set(Boolean(options2.selectionNavigation));
		this._useAltAsMultipleSelectionModifier = useAltAsMultipleSelectionModifier(configurationService);
		this.disposables.add(this.contextKeyService);
		this.disposables.add(listService.register(this));
		this.updateStyles(options2.overrideStyles);
		this.disposables.add(
			configurationService.onDidChangeConfiguration(e => {
				if (e.affectsConfiguration(multiSelectModifierSettingKey)) {
					this._useAltAsMultipleSelectionModifier = useAltAsMultipleSelectionModifier(configurationService);
				}
				let options3 = {};
				if (e.affectsConfiguration(horizontalScrollingKey) && this.horizontalScrolling === undefined) {
					const horizontalScrolling2 = Boolean(configurationService.getValue(horizontalScrollingKey));
					options3 = {
						...options3,
						horizontalScrolling: horizontalScrolling2
					};
				}
				if (e.affectsConfiguration(scrollByPageKey)) {
					const scrollByPage = Boolean(configurationService.getValue(scrollByPageKey));
					options3 = { ...options3, scrollByPage };
				}
				if (e.affectsConfiguration(listSmoothScrolling)) {
					const smoothScrolling = Boolean(configurationService.getValue(listSmoothScrolling));
					options3 = { ...options3, smoothScrolling };
				}
				if (e.affectsConfiguration(mouseWheelScrollSensitivityKey)) {
					const mouseWheelScrollSensitivity = configurationService.getValue(mouseWheelScrollSensitivityKey);
					options3 = { ...options3, mouseWheelScrollSensitivity };
				}
				if (e.affectsConfiguration(fastScrollSensitivityKey)) {
					const fastScrollSensitivity = configurationService.getValue(fastScrollSensitivityKey);
					options3 = { ...options3, fastScrollSensitivity };
				}
				if (Object.keys(options3).length > 0) {
					this.updateOptions(options3);
				}
			})
		);
		this.navigator = new ListResourceNavigator(this, {
			configurationService,
			...options2
		});
		this.disposables.add(this.navigator);
	}
	updateOptions(options2) {
		super.updateOptions(options2);
		if (options2.overrideStyles !== undefined) {
			this.updateStyles(options2.overrideStyles);
		}
		if (options2.multipleSelectionSupport !== undefined) {
			this.listSupportsMultiSelect.set(!!options2.multipleSelectionSupport);
		}
	}
	updateStyles(styles) {
		this.style(styles ? getListStyles(styles) : defaultStyle_list);
	}
	dispose() {
		this.disposables.dispose();
		super.dispose();
	}
}
__decorate(
	[
		__param(5, IContextKeyService),
		__param(6, IListService),
		__param(7, IConfigurationService),
		__param(8, IInstantiationService)
		//..
	],
	WorkbenchPagedList
);


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class ViewItem {
	set size(size2) {
		this._size = size2;
	}
	get size() {
		return this._size;
	}
	get visible() {
		return typeof this._cachedVisibleSize === 'undefined';
	}
	setVisible(visible, size2) {
		if (visible !== this.visible) {
			if (visible) {
				this.size = clamp(this._cachedVisibleSize, this.viewMinimumSize, this.viewMaximumSize);
				this._cachedVisibleSize = undefined;
			} else {
				this._cachedVisibleSize = typeof size2 === 'number' ? size2 : this.size;
				this.size = 0;
			}
			this.container.classList.toggle('visible', visible);
			try {
				this.view.setVisible?.call(this.view, visible);
			} catch (e) {
				console.error(e);
			}
		}
	}
	get minimumSize() {
		return this.visible ? this.view.minimumSize : 0;
	}
	get viewMinimumSize() {
		return this.view.minimumSize;
	}
	get maximumSize() {
		return this.visible ? this.view.maximumSize : 0;
	}
	get viewMaximumSize() {
		return this.view.maximumSize;
	}
	get priority() {
		return this.view.priority;
	}
	get proportionalLayout() {
		return this.view.proportionalLayout ?? true;
	}
	get snap() {
		return !!this.view.snap;
	}
	set enabled(enabled) {
		this.container.style.pointerEvents = enabled ? '' : 'none';
	}
	constructor(container, view, size2, disposable) {
		this.container = container;
		this.view = view;
		this.disposable = disposable;
		this._cachedVisibleSize = undefined;
		if (typeof size2 === 'number') {
			this._size = size2;
			this._cachedVisibleSize = undefined;
			container.classList.add('visible');
		} else {
			this._size = 0;
			this._cachedVisibleSize = size2.cachedVisibleSize;
		}
	}
	layout(offset, layoutContext) {
		this.layoutContainer(offset);
		try {
			this.view.layout(this.size, offset, layoutContext);
		} catch (e) {
			console.error('Splitview: Failed to layout view');
			console.error(e);
		}
	}
	dispose() {
		this.disposable.dispose();
	}
}

class VerticalViewItem extends ViewItem {
	layoutContainer(offset) {
		this.container.style.top = `${offset}px`;
		this.container.style.height = `${this.size}px`;
	}
}

class HorizontalViewItem extends ViewItem {
	layoutContainer(offset) {
		this.container.style.left = `${offset}px`;
		this.container.style.width = `${this.size}px`;
	}
}

class SplitView extends Disposable {
	get orthogonalStartSash() {
		return this._orthogonalStartSash;
	}
	get orthogonalEndSash() {
		return this._orthogonalEndSash;
	}
	get startSnappingEnabled() {
		return this._startSnappingEnabled;
	}
	get endSnappingEnabled() {
		return this._endSnappingEnabled;
	}
	set orthogonalStartSash(sash) {
		for (const sashItem of this.sashItems) {
			sashItem.sash.orthogonalStartSash = sash;
		}
		this._orthogonalStartSash = sash;
	}
	set orthogonalEndSash(sash) {
		for (const sashItem of this.sashItems) {
			sashItem.sash.orthogonalEndSash = sash;
		}
		this._orthogonalEndSash = sash;
	}
	set startSnappingEnabled(startSnappingEnabled) {
		if (this._startSnappingEnabled === startSnappingEnabled) {
			return;
		}
		this._startSnappingEnabled = startSnappingEnabled;
		this.updateSashEnablement();
	}
	set endSnappingEnabled(endSnappingEnabled) {
		if (this._endSnappingEnabled === endSnappingEnabled) {
			return;
		}
		this._endSnappingEnabled = endSnappingEnabled;
		this.updateSashEnablement();
	}
	constructor(container, options2 = {}) {
		super();
		this.size = 0;
		this._contentSize = 0;
		this.proportions = undefined;
		this.viewItems = [];
		this.sashItems = [];
		this.state = 0; //Idle
		this._onDidSashChange = this._register(new Emitter());
		this._onDidSashReset = this._register(new Emitter());
		this._startSnappingEnabled = true;
		this._endSnappingEnabled = true;
		this.onDidSashChange = this._onDidSashChange.event;
		this.onDidSashReset = this._onDidSashReset.event;
		this.orientation = options2.orientation ?? 0;
		this.inverseAltBehavior = options2.inverseAltBehavior ?? false;
		this.proportionalLayout = options2.proportionalLayout ?? true;
		this.getSashOrthogonalSize = options2.getSashOrthogonalSize;
		this.el = document.createElement('div');
		this.el.classList.add('monaco-split-view2');
		this.el.classList.add(this.orientation === 0 ? 'vertical' : 'horizontal');
		container.appendChild(this.el);
		this.sashContainer = append(this.el, createDomElement('.sash-container'));
		this.viewContainer = createDomElement('.split-view-container');
		this.scrollable = this._register(
			new Scrollable({
				forceIntegerValues: true,
				smoothScrollDuration: 125,
				scheduleAtNextAnimationFrame: callback => scheduleAtNextAnimationFrame(getWindow(this.el), callback)
			})
		);
		this.scrollableElement = this._register(
			new SmoothScrollableElement(
				this.viewContainer,
				{
					vertical: this.orientation === 0 ? options2.scrollbarVisibility ?? 1 : 2,
					horizontal: this.orientation === 1 ? options2.scrollbarVisibility ?? 1 : 2
				},
				this.scrollable
			)
		);
		const onDidScrollViewContainer = this._register(new DomEmitter(this.viewContainer, 'scroll')).event;
		this._register(
			onDidScrollViewContainer(_ => {
				const position = this.scrollableElement.getScrollPosition();
				const scrollLeft =
					Math.abs(this.viewContainer.scrollLeft - position.scrollLeft) <= 1 ? undefined : this.viewContainer.scrollLeft;
				const scrollTop =
					Math.abs(this.viewContainer.scrollTop - position.scrollTop) <= 1 ? undefined : this.viewContainer.scrollTop;
				if (scrollLeft !== undefined || scrollTop !== undefined) {
					this.scrollableElement.setScrollPosition({
						scrollLeft,
						scrollTop
					});
				}
			})
		);
		this.onDidScroll = this.scrollableElement.onScroll;
		this._register(
			this.onDidScroll(e => {
				if (e.scrollTopChanged) {
					this.viewContainer.scrollTop = e.scrollTop;
				}
				if (e.scrollLeftChanged) {
					this.viewContainer.scrollLeft = e.scrollLeft;
				}
			})
		);
		append(this.el, this.scrollableElement.getDomNode());
		this.style(
			options2.styles || {
				inputbox: defaultStyle_inputbox,
				toggle: defaultStyle_toggle,
				widget: defaultStyle_widget,
				countBadge: defaultStyle_countBadge,
				list: defaultStyle_list,
				separatorBorder: colorTransparent,
				breadcrumbsWidget: {
					breadcrumbsBackground: asCssVariable(colorId_breadcrumbs_background),
					breadcrumbsForeground: asCssVariable(colorId_breadcrumbs_foreground),
					breadcrumbsHoverForeground: asCssVariable(colorId_breadcrumbsFocus_foreground),
					breadcrumbsFocusForeground: asCssVariable(colorId_breadcrumbsFocus_foreground),
					breadcrumbsFocusAndSelectionForeground: asCssVariable(colorId_breadcrumbsActiveSelection_foreground)
				},
				checkbox: {
					checkboxBackground: asCssVariable(colorId_checkbox_background),
					checkboxBorder: asCssVariable(colorId_checkbox_border),
					checkboxForeground: asCssVariable(colorId_checkbox_foreground)
				},
				dialog: {
					dialogBackground: asCssVariable(colorId_widget_background),
					dialogForeground: asCssVariable(colorId_editorWidget_foreground),
					dialogShadow: asCssVariable(colorId_widget_shadow),
					dialogBorder: asCssVariable(colorId_contrast_border),
					errorIconForeground: asCssVariable(colorId_problemsIconError_foreground),
					warningIconForeground: asCssVariable(colorId_problemsIconWarning_foreground),
					infoIconForeground: asCssVariable(colorId_problemsIconInfo_foreground),
					textLinkForeground: asCssVariable(colorId_textLink_foreground)
				}
			}
		);
		if (options2.descriptor) {
			this.size = options2.descriptor.size;
			options2.descriptor.views.forEach((viewDescriptor, index) => {
				const sizing =
					isUndefined(viewDescriptor.visible) || viewDescriptor.visible
						? viewDescriptor.size
						: {
								type: 'invisible',
								cachedVisibleSize: viewDescriptor.size
							};
				const view = viewDescriptor.view;
				this.doAddView(view, sizing, index, true);
			});
			this._contentSize = this.viewItems.reduce((r, i) => r + i.size, 0);
			this.saveProportions();
		}
	}
	style(styles) {
		if (styles.separatorBorder.isTransparent()) {
			this.el.classList.remove('separator-border');
			this.el.style.removeProperty('--separator-border');
		} else {
			this.el.classList.add('separator-border');
			this.el.style.setProperty('--separator-border', styles.separatorBorder.toString());
		}
	}
	addView(view, size2, index = this.viewItems.length, skipLayout) {
		this.doAddView(view, size2, index, skipLayout);
	}
	layout(size2, layoutContext) {
		const previousSize = Math.max(this.size, this._contentSize);
		this.size = size2;
		this.layoutContext = layoutContext;
		if (!this.proportions) {
			const indexes = range(this.viewItems.length);
			const lowPriorityIndexes = indexes.filter(i => this.viewItems[i].priority === 1);
			const highPriorityIndexes = indexes.filter(i => this.viewItems[i].priority === 2);
			this.resize(this.viewItems.length - 1, size2 - previousSize, undefined, lowPriorityIndexes, highPriorityIndexes);
		} else {
			let total = 0;
			for (let i = 0; i < this.viewItems.length; i++) {
				const item = this.viewItems[i];
				const proportion = this.proportions[i];
				if (typeof proportion === 'number') {
					total += proportion;
				} else {
					size2 -= item.size;
				}
			}
			for (let i = 0; i < this.viewItems.length; i++) {
				const item = this.viewItems[i];
				const proportion = this.proportions[i];
				if (typeof proportion === 'number' && total > 0) {
					item.size = clamp(Math.round((proportion * size2) / total), item.minimumSize, item.maximumSize);
				}
			}
		}
		this.distributeEmptySpace();
		this.layoutViews();
	}
	saveProportions() {
		if (this.proportionalLayout && this._contentSize > 0) {
			this.proportions = this.viewItems.map(v => (v.proportionalLayout && v.visible ? v.size / this._contentSize : undefined));
		}
	}
	onSashStart({ sash, start, alt }) {
		for (const item of this.viewItems) {
			item.enabled = false;
		}
		const index = this.sashItems.findIndex(item => item.sash === sash);
		const disposable = combinedDisposable(
			addDisposableListener(this.el.ownerDocument.body, 'keydown', e => resetSashDragState(this.sashDragState.current, e.altKey)),
			addDisposableListener(this.el.ownerDocument.body, 'keyup', () => resetSashDragState(this.sashDragState.current, false))
		);
		const resetSashDragState = (start2, alt2) => {
			const sizes = this.viewItems.map(i => i.size);
			let minDelta = Number.NEGATIVE_INFINITY;
			let maxDelta = Number.POSITIVE_INFINITY;
			if (this.inverseAltBehavior) {
				alt2 = !alt2;
			}
			if (alt2) {
				const isLastSash = index === this.sashItems.length - 1;
				if (isLastSash) {
					const viewItem = this.viewItems[index];
					minDelta = (viewItem.minimumSize - viewItem.size) / 2;
					maxDelta = (viewItem.maximumSize - viewItem.size) / 2;
				} else {
					const viewItem = this.viewItems[index + 1];
					minDelta = (viewItem.size - viewItem.maximumSize) / 2;
					maxDelta = (viewItem.size - viewItem.minimumSize) / 2;
				}
			}
			let snapBefore;
			let snapAfter;
			if (!alt2) {
				const upIndexes = range(index, -1);
				const downIndexes = range(index + 1, this.viewItems.length);
				const minDeltaUp = upIndexes.reduce((r, i) => r + (this.viewItems[i].minimumSize - sizes[i]), 0);
				const maxDeltaUp = upIndexes.reduce((r, i) => r + (this.viewItems[i].viewMaximumSize - sizes[i]), 0);
				const maxDeltaDown =
					downIndexes.length === 0
						? Number.POSITIVE_INFINITY
						: downIndexes.reduce((r, i) => r + (sizes[i] - this.viewItems[i].minimumSize), 0);
				const minDeltaDown =
					downIndexes.length === 0
						? Number.NEGATIVE_INFINITY
						: downIndexes.reduce((r, i) => r + (sizes[i] - this.viewItems[i].viewMaximumSize), 0);
				const minDelta2 = Math.max(minDeltaUp, minDeltaDown);
				const maxDelta2 = Math.min(maxDeltaDown, maxDeltaUp);
				const snapBeforeIndex = this.findFirstSnapIndex(upIndexes);
				const snapAfterIndex = this.findFirstSnapIndex(downIndexes);
				if (typeof snapBeforeIndex === 'number') {
					const viewItem = this.viewItems[snapBeforeIndex];
					const halfSize = Math.floor(viewItem.viewMinimumSize / 2);
					snapBefore = {
						index: snapBeforeIndex,
						limitDelta: viewItem.visible ? minDelta2 - halfSize : minDelta2 + halfSize,
						size: viewItem.size
					};
				}
				if (typeof snapAfterIndex === 'number') {
					const viewItem = this.viewItems[snapAfterIndex];
					const halfSize = Math.floor(viewItem.viewMinimumSize / 2);
					snapAfter = {
						index: snapAfterIndex,
						limitDelta: viewItem.visible ? maxDelta2 + halfSize : maxDelta2 - halfSize,
						size: viewItem.size
					};
				}
			}
			this.sashDragState = {
				start: start2,
				current: start2,
				index,
				sizes,
				minDelta,
				maxDelta,
				alt: alt2,
				snapBefore,
				snapAfter,
				disposable
			};
		};
		resetSashDragState(start, alt);
	}
	onSashChange({ current }) {
		const { index, start, sizes, alt, minDelta, maxDelta, snapBefore, snapAfter } = this.sashDragState;
		this.sashDragState.current = current;
		const delta = current - start;
		const newDelta = this.resize(index, delta, sizes, undefined, undefined, minDelta, maxDelta, snapBefore, snapAfter);
		if (alt) {
			const isLastSash = index === this.sashItems.length - 1;
			const newSizes = this.viewItems.map(i => i.size);
			const viewItemIndex = isLastSash ? index : index + 1;
			const viewItem = this.viewItems[viewItemIndex];
			const newMinDelta = viewItem.size - viewItem.maximumSize;
			const newMaxDelta = viewItem.size - viewItem.minimumSize;
			const resizeIndex = isLastSash ? index - 1 : index + 1;
			this.resize(resizeIndex, -newDelta, newSizes, undefined, undefined, newMinDelta, newMaxDelta);
		}
		this.distributeEmptySpace();
		this.layoutViews();
	}
	onSashEnd(index) {
		this._onDidSashChange.fire(index);
		this.sashDragState.disposable.dispose();
		this.saveProportions();
		for (const item of this.viewItems) {
			item.enabled = true;
		}
	}
	onViewChange(item, size2) {
		const index = this.viewItems.indexOf(item);
		if (index < 0 || index >= this.viewItems.length) {
			return;
		}
		size2 = typeof size2 === 'number' ? size2 : item.size;
		size2 = clamp(size2, item.minimumSize, item.maximumSize);
		if (this.inverseAltBehavior && index > 0) {
			this.resize(index - 1, Math.floor((item.size - size2) / 2));
			this.distributeEmptySpace();
			this.layoutViews();
		} else {
			item.size = size2;
			this.relayout([index], undefined);
		}
	}
	resizeView(index, size2) {
		if (index < 0 || index >= this.viewItems.length) {
			return;
		}
		if (this.state !== 0) {
			throw new Error('Cant modify splitview');
		}
		this.state = 1; //Busy
		try {
			const indexes = range(this.viewItems.length).filter(i => i !== index);
			const lowPriorityIndexes = [...indexes.filter(i => this.viewItems[i].priority === 1), index];
			const highPriorityIndexes = indexes.filter(i => this.viewItems[i].priority === 2);
			const item = this.viewItems[index];
			size2 = Math.round(size2);
			size2 = clamp(size2, item.minimumSize, Math.min(item.maximumSize, this.size));
			item.size = size2;
			this.relayout(lowPriorityIndexes, highPriorityIndexes);
		} finally {
			this.state = 0;
		}
	}
	distributeViewSizes() {
		const flexibleViewItems = [];
		let flexibleSize = 0;
		for (const item of this.viewItems) {
			if (item.maximumSize - item.minimumSize > 0) {
				flexibleViewItems.push(item);
				flexibleSize += item.size;
			}
		}
		const size2 = Math.floor(flexibleSize / flexibleViewItems.length);
		for (const item of flexibleViewItems) {
			item.size = clamp(size2, item.minimumSize, item.maximumSize);
		}
		const indexes = range(this.viewItems.length);
		const lowPriorityIndexes = indexes.filter(i => this.viewItems[i].priority === 1);
		const highPriorityIndexes = indexes.filter(i => this.viewItems[i].priority === 2);
		this.relayout(lowPriorityIndexes, highPriorityIndexes);
	}
	getViewSize(index) {
		if (index < 0 || index >= this.viewItems.length) {
			return -1;
		}
		return this.viewItems[index].size;
	}
	doAddView(view, size2, index = this.viewItems.length, skipLayout) {
		if (this.state !== 0) {
			throw new Error('Cant modify splitview');
		}
		this.state = 1;
		try {
			const container = createDomElement('.split-view-view');
			if (index === this.viewItems.length) {
				this.viewContainer.appendChild(container);
			} else {
				this.viewContainer.insertBefore(container, this.viewContainer.children.item(index));
			}
			const onChangeDisposable = view.onDidChange(size3 => this.onViewChange(item, size3));
			const containerDisposable = toDisposable(() => this.viewContainer.removeChild(container));
			const disposable = combinedDisposable(onChangeDisposable, containerDisposable);
			let viewSize;
			if (typeof size2 === 'number') {
				viewSize = size2;
			} else {
				if (size2.type === 'auto') {
					if (this.areViewsDistributed()) {
						size2 = { type: 'distribute' };
					} else {
						size2 = { type: 'split', index: size2.index };
					}
				}
				if (size2.type === 'split') {
					viewSize = this.getViewSize(size2.index) / 2;
				} else if (size2.type === 'invisible') {
					viewSize = { cachedVisibleSize: size2.cachedVisibleSize };
				} else {
					viewSize = view.minimumSize;
				}
			}
			const item =
				this.orientation === 0
					? new VerticalViewItem(container, view, viewSize, disposable)
					: new HorizontalViewItem(container, view, viewSize, disposable);
			this.viewItems.splice(index, 0, item);
			if (this.viewItems.length > 1) {
				const opts = {
					orthogonalStartSash: this.orthogonalStartSash,
					orthogonalEndSash: this.orthogonalEndSash
				};
				const sash =
					this.orientation === 0
						? new Sash(
								this.sashContainer,
								{
									getHorizontalSashTop: s => this.getSashPosition(s),
									getHorizontalSashWidth: this.getSashOrthogonalSize
								},
								{
									...opts,
									orientation: 1 //HORIZONTAL
								}
							)
						: new Sash(
								this.sashContainer,
								{
									getVerticalSashLeft: s => this.getSashPosition(s),
									getVerticalSashHeight: this.getSashOrthogonalSize
								},
								{
									...opts,
									orientation: 0 //VERTICAL
								}
							);
				const sashEventMapper =
					this.orientation === 0
						? e => ({
								sash,
								start: e.startY,
								current: e.currentY,
								alt: e.altKey
							})
						: e => ({
								sash,
								start: e.startX,
								current: e.currentX,
								alt: e.altKey
							});
				const onStart = editorEventMap(sash.onDidStart, sashEventMapper);
				const onStartDisposable = onStart(this.onSashStart, this);
				const onChange = editorEventMap(sash.onDidChange, sashEventMapper);
				const onChangeDisposable2 = onChange(this.onSashChange, this);
				const onEnd = editorEventMap(sash.onDidEnd, () => this.sashItems.findIndex(item2 => item2.sash === sash));
				const onEndDisposable = onEnd(this.onSashEnd, this);
				const onDidResetDisposable = sash.onDidReset(() => {
					const index2 = this.sashItems.findIndex(item2 => item2.sash === sash);
					const upIndexes = range(index2, -1);
					const downIndexes = range(index2 + 1, this.viewItems.length);
					const snapBeforeIndex = this.findFirstSnapIndex(upIndexes);
					const snapAfterIndex = this.findFirstSnapIndex(downIndexes);
					if (typeof snapBeforeIndex === 'number' && !this.viewItems[snapBeforeIndex].visible) {
						return;
					}
					if (typeof snapAfterIndex === 'number' && !this.viewItems[snapAfterIndex].visible) {
						return;
					}
					this._onDidSashReset.fire(index2);
				});
				const disposable2 = combinedDisposable(onStartDisposable, onChangeDisposable2, onEndDisposable, onDidResetDisposable, sash);
				const sashItem = { sash, disposable: disposable2 };
				this.sashItems.splice(index - 1, 0, sashItem);
			}
			container.appendChild(view.element);
			let highPriorityIndexes;
			if (typeof size2 !== 'number' && size2.type === 'split') {
				highPriorityIndexes = [size2.index];
			}
			if (!skipLayout) {
				this.relayout([index], highPriorityIndexes);
			}
			if (!skipLayout && typeof size2 !== 'number' && size2.type === 'distribute') {
				this.distributeViewSizes();
			}
		} finally {
			this.state = 0;
		}
	}
	relayout(lowPriorityIndexes, highPriorityIndexes) {
		const contentSize = this.viewItems.reduce((r, i) => r + i.size, 0);
		this.resize(this.viewItems.length - 1, this.size - contentSize, undefined, lowPriorityIndexes, highPriorityIndexes);
		this.distributeEmptySpace();
		this.layoutViews();
		this.saveProportions();
	}
	resize(
		index,
		delta,
		sizes = this.viewItems.map(i => i.size),
		lowPriorityIndexes,
		highPriorityIndexes,
		overloadMinDelta = Number.NEGATIVE_INFINITY,
		overloadMaxDelta = Number.POSITIVE_INFINITY,
		snapBefore,
		snapAfter
	) {
		if (index < 0 || index >= this.viewItems.length) {
			return 0;
		}
		const upIndexes = range(index, -1);
		const downIndexes = range(index + 1, this.viewItems.length);
		if (highPriorityIndexes) {
			for (const index2 of highPriorityIndexes) {
				pushToStart(upIndexes, index2);
				pushToStart(downIndexes, index2);
			}
		}
		if (lowPriorityIndexes) {
			for (const index2 of lowPriorityIndexes) {
				pushToEnd(upIndexes, index2);
				pushToEnd(downIndexes, index2);
			}
		}
		const upItems = upIndexes.map(i => this.viewItems[i]);
		const upSizes = upIndexes.map(i => sizes[i]);
		const downItems = downIndexes.map(i => this.viewItems[i]);
		const downSizes = downIndexes.map(i => sizes[i]);
		const minDeltaUp = upIndexes.reduce((r, i) => r + (this.viewItems[i].minimumSize - sizes[i]), 0);
		const maxDeltaUp = upIndexes.reduce((r, i) => r + (this.viewItems[i].maximumSize - sizes[i]), 0);
		const maxDeltaDown =
			downIndexes.length === 0
				? Number.POSITIVE_INFINITY
				: downIndexes.reduce((r, i) => r + (sizes[i] - this.viewItems[i].minimumSize), 0);
		const minDeltaDown =
			downIndexes.length === 0
				? Number.NEGATIVE_INFINITY
				: downIndexes.reduce((r, i) => r + (sizes[i] - this.viewItems[i].maximumSize), 0);
		const minDelta = Math.max(minDeltaUp, minDeltaDown, overloadMinDelta);
		const maxDelta = Math.min(maxDeltaDown, maxDeltaUp, overloadMaxDelta);
		let snapped = false;
		if (snapBefore) {
			const snapView = this.viewItems[snapBefore.index];
			const visible = delta >= snapBefore.limitDelta;
			snapped = visible !== snapView.visible;
			snapView.setVisible(visible, snapBefore.size);
		}
		if (!snapped && snapAfter) {
			const snapView = this.viewItems[snapAfter.index];
			const visible = delta < snapAfter.limitDelta;
			snapped = visible !== snapView.visible;
			snapView.setVisible(visible, snapAfter.size);
		}
		if (snapped) {
			return this.resize(index, delta, sizes, lowPriorityIndexes, highPriorityIndexes, overloadMinDelta, overloadMaxDelta);
		}
		delta = clamp(delta, minDelta, maxDelta);
		for (let i = 0, deltaUp = delta; i < upItems.length; i++) {
			const item = upItems[i];
			const size2 = clamp(upSizes[i] + deltaUp, item.minimumSize, item.maximumSize);
			const viewDelta = size2 - upSizes[i];
			deltaUp -= viewDelta;
			item.size = size2;
		}
		for (let i = 0, deltaDown = delta; i < downItems.length; i++) {
			const item = downItems[i];
			const size2 = clamp(downSizes[i] - deltaDown, item.minimumSize, item.maximumSize);
			const viewDelta = size2 - downSizes[i];
			deltaDown += viewDelta;
			item.size = size2;
		}
		return delta;
	}
	distributeEmptySpace(lowPriorityIndex) {
		const contentSize = this.viewItems.reduce((r, i) => r + i.size, 0);
		let emptyDelta = this.size - contentSize;
		const indexes = range(this.viewItems.length - 1, -1);
		const lowPriorityIndexes = indexes.filter(i => this.viewItems[i].priority === 1);
		const highPriorityIndexes = indexes.filter(i => this.viewItems[i].priority === 2);
		for (const index of highPriorityIndexes) {
			pushToStart(indexes, index);
		}
		for (const index of lowPriorityIndexes) {
			pushToEnd(indexes, index);
		}
		if (typeof lowPriorityIndex === 'number') {
			pushToEnd(indexes, lowPriorityIndex);
		}
		for (let i = 0; emptyDelta !== 0 && i < indexes.length; i++) {
			const item = this.viewItems[indexes[i]];
			const size2 = clamp(item.size + emptyDelta, item.minimumSize, item.maximumSize);
			const viewDelta = size2 - item.size;
			emptyDelta -= viewDelta;
			item.size = size2;
		}
	}
	layoutViews() {
		this._contentSize = this.viewItems.reduce((r, i) => r + i.size, 0);
		let offset = 0;
		for (const viewItem of this.viewItems) {
			viewItem.layout(offset, this.layoutContext);
			offset += viewItem.size;
		}
		this.sashItems.forEach(item => item.sash.layout());
		this.updateSashEnablement();
		this.updateScrollableElement();
	}
	updateScrollableElement() {
		if (this.orientation === 0) {
			this.scrollableElement.setScrollDimensions({
				height: this.size,
				scrollHeight: this._contentSize
			});
		} else {
			this.scrollableElement.setScrollDimensions({
				width: this.size,
				scrollWidth: this._contentSize
			});
		}
	}
	updateSashEnablement() {
		let previous = false;
		const collapsesDown = this.viewItems.map(i => (previous = i.size - i.minimumSize > 0 || previous));
		previous = false;
		const expandsDown = this.viewItems.map(i => (previous = i.maximumSize - i.size > 0 || previous));
		const reverseViews = [...this.viewItems].reverse();
		previous = false;
		const collapsesUp = reverseViews.map(i => (previous = i.size - i.minimumSize > 0 || previous)).reverse();
		previous = false;
		const expandsUp = reverseViews.map(i => (previous = i.maximumSize - i.size > 0 || previous)).reverse();
		let position = 0;
		for (let index = 0; index < this.sashItems.length; index++) {
			const { sash } = this.sashItems[index];
			const viewItem = this.viewItems[index];
			position += viewItem.size;
			const min = !(collapsesDown[index] && expandsUp[index + 1]);
			const max = !(expandsDown[index] && collapsesUp[index + 1]);
			if (min && max) {
				const upIndexes = range(index, -1);
				const downIndexes = range(index + 1, this.viewItems.length);
				const snapBeforeIndex = this.findFirstSnapIndex(upIndexes);
				const snapAfterIndex = this.findFirstSnapIndex(downIndexes);
				const snappedBefore = typeof snapBeforeIndex === 'number' && !this.viewItems[snapBeforeIndex].visible;
				const snappedAfter = typeof snapAfterIndex === 'number' && !this.viewItems[snapAfterIndex].visible;
				if (snappedBefore && collapsesUp[index] && (position > 0 || this.startSnappingEnabled)) {
					sash.state = 1;
				} else if (snappedAfter && collapsesDown[index] && (position < this._contentSize || this.endSnappingEnabled)) {
					sash.state = 2;
				} else {
					sash.state = 0;
				}
			} else if (min && !max) {
				sash.state = 1;
			} else if (!min && max) {
				sash.state = 2;
			} else {
				sash.state = 3;
			}
		}
	}
	getSashPosition(sash) {
		let position = 0;
		for (let i = 0; i < this.sashItems.length; i++) {
			position += this.viewItems[i].size;
			if (this.sashItems[i].sash === sash) {
				return position;
			}
		}
		return 0;
	}
	findFirstSnapIndex(indexes) {
		for (const index of indexes) {
			const viewItem = this.viewItems[index];
			if (!viewItem.visible) {
				continue;
			}
			if (viewItem.snap) {
				return index;
			}
		}
		for (const index of indexes) {
			const viewItem = this.viewItems[index];
			if (viewItem.visible && viewItem.maximumSize - viewItem.minimumSize > 0) {
				return;
			}
			if (!viewItem.visible && viewItem.snap) {
				return index;
			}
		}
		return;
	}
	areViewsDistributed() {
		let min = undefined,
			max = undefined;
		for (const view of this.viewItems) {
			min = min === undefined ? view.size : Math.min(min, view.size);
			max = max === undefined ? view.size : Math.max(max, view.size);
			if (max - min > 2) {
				return false;
			}
		}
		return true;
	}
	dispose() {
		this.sashDragState?.disposable.dispose();
		dispose(this.viewItems);
		this.viewItems = [];
		this.sashItems.forEach(i => i.disposable.dispose());
		this.sashItems = [];
		super.dispose();
	}
}

class TableListRenderer {
	constructor(columns, renderers, getColumnSize) {
		this.columns = columns;
		this.getColumnSize = getColumnSize;
		this.templateId = 'row';
		this.renderedTemplates = new Set();
		const rendererMap = new Map(renderers.map(r => [r.templateId, r]));
		this.renderers = [];
		for (const column of columns) {
			const renderer = rendererMap.get(column.templateId);
			if (!renderer) {
				throw new Error(`Table cell renderer for template id ${column.templateId} not found.`);
			}
			this.renderers.push(renderer);
		}
	}
	renderTemplate(container) {
		const rowContainer = append(container, createDomElement('.monaco-table-tr'));
		const cellContainers = [];
		const cellTemplateData = [];
		for (let i = 0; i < this.columns.length; i++) {
			const renderer = this.renderers[i];
			const cellContainer = append(rowContainer, createDomElement('.monaco-table-td', { 'data-col-index': i }));
			cellContainer.style.width = `${this.getColumnSize(i)}px`;
			cellContainers.push(cellContainer);
			cellTemplateData.push(renderer.renderTemplate(cellContainer));
		}
		const result = { container, cellContainers, cellTemplateData };
		this.renderedTemplates.add(result);
		return result;
	}
	renderElement(element, index, templateData, height) {
		for (let i = 0; i < this.columns.length; i++) {
			const column = this.columns[i];
			const cell = column.project(element);
			const renderer = this.renderers[i];
			renderer.renderElement(cell, index, templateData.cellTemplateData[i], height);
		}
	}
	disposeElement(element, index, templateData, height) {
		for (let i = 0; i < this.columns.length; i++) {
			const renderer = this.renderers[i];
			if (renderer.disposeElement) {
				const column = this.columns[i];
				const cell = column.project(element);
				renderer.disposeElement(cell, index, templateData.cellTemplateData[i], height);
			}
		}
	}
	disposeTemplate(templateData) {
		for (let i = 0; i < this.columns.length; i++) {
			const renderer = this.renderers[i];
			renderer.disposeTemplate(templateData.cellTemplateData[i]);
		}
		clearNode(templateData.container);
		this.renderedTemplates.delete(templateData);
	}
	layoutColumn(index, size2) {
		for (const { cellContainers } of this.renderedTemplates) {
			cellContainers[index].style.width = `${size2}px`;
		}
	}
}

class ColumnHeader extends Disposable {
	get minimumSize() {
		return this.column.minimumWidth ?? 120;
	}
	get maximumSize() {
		return this.column.maximumWidth ?? Number.POSITIVE_INFINITY;
	}
	get onDidChange() {
		return this.column.onDidChangeWidthConstraints ?? editorEvent_none;
	}
	constructor(column, index) {
		super();
		this.column = column;
		this.index = index;
		this._onDidLayout = new Emitter();
		this.onDidLayout = this._onDidLayout.event;
		this.element = createDomElement('.monaco-table-th', { 'data-col-index': index }, column.label);
		if (column.tooltip) {
			this._register(getBaseLayerHoverDelegate().setupUpdatableHover(getDefaultHoverDelegate('mouse'), this.element, column.tooltip));
		}
	}
	layout(size2) {
		this._onDidLayout.fire([this.index, size2]);
	}
}

let tableLastId = 0;
class Table {
	get onDidChangeFocus() {
		return this.list.onDidChangeFocus;
	}
	get onDidChangeSelection() {
		return this.list.onDidChangeSelection;
	}
	get onDidScroll() {
		return this.list.onDidScroll;
	}
	get onMouseDblClick() {
		return this.list.onMouseDblClick;
	}
	get onPointer() {
		return this.list.onPointer;
	}
	get onDidFocus() {
		return this.list.onDidFocus;
	}
	get scrollTop() {
		return this.list.scrollTop;
	}
	set scrollTop(scrollTop) {
		this.list.scrollTop = scrollTop;
	}
	get scrollHeight() {
		return this.list.scrollHeight;
	}
	get renderHeight() {
		return this.list.renderHeight;
	}
	get onDidDispose() {
		return this.list.onDidDispose;
	}
	constructor(user, container, virtualDelegate, columns, renderers, _options) {
		this.virtualDelegate = virtualDelegate;
		this.domId = `table_id_${++tableLastId}`;
		this.disposables = new DisposableStore();
		this.cachedWidth = 0;
		this.cachedHeight = 0;
		this.domNode = append(container, createDomElement(`.monaco-table.${this.domId}`));
		const headers = columns.map((c, i) => this.disposables.add(new ColumnHeader(c, i)));
		const descriptor = {
			size: headers.reduce((a, b) => a + b.column.weight, 0),
			views: headers.map(view => ({ size: view.column.weight, view }))
		};
		this.splitview = this.disposables.add(
			new SplitView(this.domNode, {
				orientation: 1,
				scrollbarVisibility: 2,
				getSashOrthogonalSize: () => this.cachedHeight,
				descriptor
			})
		);
		this.splitview.el.style.height = `${virtualDelegate.headerRowHeight}px`;
		this.splitview.el.style.lineHeight = `${virtualDelegate.headerRowHeight}px`;
		const renderer = new TableListRenderer(columns, renderers, i => this.splitview.getViewSize(i));
		function _asListVirtualDelegate(delegate) {
			return {
				getHeight(row) {
					return delegate.getHeight(row);
				},
				getTemplateId() {
					return 'row';
				}
			};
		}
		this.list = this.disposables.add(new List(user, this.domNode, _asListVirtualDelegate(virtualDelegate), [renderer], _options));
		editorEventAny(...headers.map(e => e.onDidLayout))(([index, size2]) => renderer.layoutColumn(index, size2), null, this.disposables);
		this.splitview.onDidSashReset(
			index => {
				const totalWeight = columns.reduce((r, c) => r + c.weight, 0);
				const size2 = (columns[index].weight / totalWeight) * this.cachedWidth;
				this.splitview.resizeView(index, size2);
			},
			null,
			this.disposables
		);
		this.styleElement = createStyleSheet(this.domNode);
		this.style(unthemedListStyles);
	}
	updateOptions(options2) {
		this.list.updateOptions(options2);
	}
	splice(start, deleteCount, elements = []) {
		this.list.splice(start, deleteCount, elements);
	}
	getHTMLElement() {
		return this.domNode;
	}
	style(styles) {
		const content = [];
		content.push(`.monaco-table.${this.domId} > .monaco-split-view2 .monaco-sash.vertical::before {
			top: ${this.virtualDelegate.headerRowHeight + 1}px;
			height: calc(100% - ${this.virtualDelegate.headerRowHeight}px);
		}`);
		this.styleElement.textContent = content.join('\n');
		this.list.style(styles);
	}
	getSelectedElements() {
		return this.list.getSelectedElements();
	}
	getSelection() {
		return this.list.getSelection();
	}
	getFocus() {
		return this.list.getFocus();
	}
	dispose() {
		this.disposables.dispose();
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class WorkbenchTable extends Table {
	constructor(
		user,
		container,
		delegate,
		columns,
		renderers,
		options2,
		contextKeyService,
		listService,
		configurationService,
		instantiationService
	) {
		const horizontalScrolling =
			typeof options2.horizontalScrolling !== 'undefined'
				? options2.horizontalScrolling
				: Boolean(configurationService.getValue(horizontalScrollingKey));
		const [workbenchListOptions, workbenchListOptionsDisposable] = instantiationService.invokeFunction(
			toWorkbenchListOptions,
			options2
		);
		super(user, container, delegate, columns, renderers, {
			keyboardSupport: false,
			...workbenchListOptions,
			horizontalScrolling
		});
		this.disposables.add(workbenchListOptionsDisposable);
		this.contextKeyService = createScopedContextKeyService(contextKeyService, this);
		this.disposables.add(createScrollObserver(this.contextKeyService, this));
		this.listSupportsMultiSelect = ck_listSupportsMultiSelectContextKey.bindTo(this.contextKeyService);
		this.listSupportsMultiSelect.set(options2.multipleSelectionSupport !== false);
		const listSelectionNavigation = ck_listSelectionNavigation.bindTo(this.contextKeyService);
		listSelectionNavigation.set(Boolean(options2.selectionNavigation));
		this.listHasSelectionOrFocus = ck_listHasSelectionOrFocus.bindTo(this.contextKeyService);
		this.listDoubleSelection = ck_listDoubleSelection.bindTo(this.contextKeyService);
		this.listMultiSelection = ck_listMultiSelection.bindTo(this.contextKeyService);
		this.horizontalScrolling = options2.horizontalScrolling;
		this._useAltAsMultipleSelectionModifier = useAltAsMultipleSelectionModifier(configurationService);
		this.disposables.add(this.contextKeyService);
		this.disposables.add(listService.register(this));
		this.updateStyles(options2.overrideStyles);
		this.disposables.add(
			this.onDidChangeSelection(() => {
				const selection = this.getSelection();
				const focus = this.getFocus();
				this.contextKeyService.bufferChangeEvents(() => {
					this.listHasSelectionOrFocus.set(selection.length > 0 || focus.length > 0);
					this.listMultiSelection.set(selection.length > 1);
					this.listDoubleSelection.set(selection.length === 2);
				});
			})
		);
		this.disposables.add(
			this.onDidChangeFocus(() => {
				const selection = this.getSelection();
				const focus = this.getFocus();
				this.listHasSelectionOrFocus.set(selection.length > 0 || focus.length > 0);
			})
		);
		this.disposables.add(
			configurationService.onDidChangeConfiguration(e => {
				if (e.affectsConfiguration(multiSelectModifierSettingKey)) {
					this._useAltAsMultipleSelectionModifier = useAltAsMultipleSelectionModifier(configurationService);
				}
				let options3 = {};
				if (e.affectsConfiguration(horizontalScrollingKey) && this.horizontalScrolling === undefined) {
					const horizontalScrolling2 = Boolean(configurationService.getValue(horizontalScrollingKey));
					options3 = {
						...options3,
						horizontalScrolling: horizontalScrolling2
					};
				}
				if (e.affectsConfiguration(scrollByPageKey)) {
					const scrollByPage = Boolean(configurationService.getValue(scrollByPageKey));
					options3 = { ...options3, scrollByPage };
				}
				if (e.affectsConfiguration(listSmoothScrolling)) {
					const smoothScrolling = Boolean(configurationService.getValue(listSmoothScrolling));
					options3 = { ...options3, smoothScrolling };
				}
				if (e.affectsConfiguration(mouseWheelScrollSensitivityKey)) {
					const mouseWheelScrollSensitivity = configurationService.getValue(mouseWheelScrollSensitivityKey);
					options3 = { ...options3, mouseWheelScrollSensitivity };
				}
				if (e.affectsConfiguration(fastScrollSensitivityKey)) {
					const fastScrollSensitivity = configurationService.getValue(fastScrollSensitivityKey);
					options3 = { ...options3, fastScrollSensitivity };
				}
				if (Object.keys(options3).length > 0) {
					this.updateOptions(options3);
				}
			})
		);
		this.navigator = new TableResourceNavigator(this, {
			configurationService,
			...options2
		});
		this.disposables.add(this.navigator);
	}
	updateOptions(options2) {
		super.updateOptions(options2);
		if (options2.overrideStyles !== undefined) {
			this.updateStyles(options2.overrideStyles);
		}
		if (options2.multipleSelectionSupport !== undefined) {
			this.listSupportsMultiSelect.set(!!options2.multipleSelectionSupport);
		}
	}
	updateStyles(styles) {
		this.style(styles ? getListStyles(styles) : defaultStyle_list);
	}
	dispose() {
		this.disposables.dispose();
		super.dispose();
	}
}
__decorate(
	[
		__param(6, IContextKeyService),
		__param(7, IListService),
		__param(8, IConfigurationService),
		__param(9, IInstantiationService)
		//...
	],
	WorkbenchTable
);

class ResourceNavigator extends Disposable {
	constructor(widget, options2) {
		super();
		this.widget = widget;
		this._onDidOpen = this._register(new Emitter());
		this.onDidOpen = this._onDidOpen.event;
		this._register(
			editorEventFilter(this.widget.onDidChangeSelection, e => isKeyboardEvent(e.browserEvent))(e => this.onSelectionFromKeyboard(e))
		);
		this._register(this.widget.onPointer(e => this.onPointer(e.element, e.browserEvent)));
		this._register(this.widget.onMouseDblClick(e => this.onMouseDblClick(e.element, e.browserEvent)));
		if (typeof options2?.openOnSingleClick !== 'boolean' && options2?.configurationService) {
			this.openOnSingleClick = options2?.configurationService.getValue(openModeSettingKey) !== 'doubleClick';
			this._register(
				options2 === null || options2 === undefined
					? undefined
					: options2.configurationService.onDidChangeConfiguration(e => {
							if (e.affectsConfiguration(openModeSettingKey)) {
								this.openOnSingleClick =
									(options2 === null || options2 === undefined
										? undefined
										: options2.configurationService.getValue(openModeSettingKey)) !== 'doubleClick';
							}
						})
			);
		} else {
			this.openOnSingleClick = options2?.openOnSingleClick ?? true;
		}
	}
	onSelectionFromKeyboard(event) {
		if (event.elements.length !== 1) {
			return;
		}
		const selectionKeyboardEvent = event.browserEvent;
		const preserveFocus = typeof selectionKeyboardEvent.preserveFocus === 'boolean' ? selectionKeyboardEvent.preserveFocus : true;
		const pinned = typeof selectionKeyboardEvent.pinned === 'boolean' ? selectionKeyboardEvent.pinned : !preserveFocus;
		const sideBySide = false;
		this._open(this.getSelectedElement(), preserveFocus, pinned, sideBySide, event.browserEvent);
	}
	onPointer(element, browserEvent) {
		if (!this.openOnSingleClick) {
			return;
		}
		const isDoubleClick = browserEvent.detail === 2;
		if (isDoubleClick) {
			return;
		}
		const isMiddleClick = browserEvent.button === 1;
		const preserveFocus = true;
		const pinned = isMiddleClick;
		const sideBySide = browserEvent.ctrlKey || browserEvent.metaKey || browserEvent.altKey;
		this._open(element, preserveFocus, pinned, sideBySide, browserEvent);
	}
	onMouseDblClick(element, browserEvent) {
		if (!browserEvent) {
			return;
		}
		const target = browserEvent.target;
		const onTwistie =
			target.classList.contains('monaco-tl-twistie') ||
			(target.classList.contains('monaco-icon-label') && target.classList.contains('folder-icon') && browserEvent.offsetX < 16);
		if (onTwistie) {
			return;
		}
		const preserveFocus = false;
		const pinned = true;
		const sideBySide = browserEvent.ctrlKey || browserEvent.metaKey || browserEvent.altKey;
		this._open(element, preserveFocus, pinned, sideBySide, browserEvent);
	}
	_open(element, preserveFocus, pinned, sideBySide, browserEvent) {
		if (!element) {
			return;
		}
		this._onDidOpen.fire({
			editorOptions: {
				preserveFocus,
				pinned,
				revealIfVisible: true
			},
			sideBySide,
			element,
			browserEvent
		});
	}
}

class ListResourceNavigator extends ResourceNavigator {
	constructor(widget, options2) {
		super(widget, options2);
		this.widget = widget;
	}
	getSelectedElement() {
		return this.widget.getSelectedElements()[0];
	}
}

class TableResourceNavigator extends ResourceNavigator {
	constructor(widget, options2) {
		super(widget, options2);
	}
	getSelectedElement() {
		return this.widget.getSelectedElements()[0];
	}
}

class TreeResourceNavigator extends ResourceNavigator {
	constructor(widget, options2) {
		super(widget, options2);
	}
	getSelectedElement() {
		return this.widget.getSelection()?.[0];
	}
}

class WorkbenchTreeInternals {
	get onDidOpen() {
		return this.navigator.onDidOpen;
	}
	constructor(tree, options2, getTypeNavigationMode, overrideStyles2, contextKeyService, listService, configurationService) {
		this.tree = tree;
		this.disposables = [];
		this.contextKeyService = createScopedContextKeyService(contextKeyService, tree);
		this.disposables.push(createScrollObserver(this.contextKeyService, tree));
		this.listSupportsMultiSelect = ck_listSupportsMultiSelectContextKey.bindTo(this.contextKeyService);
		this.listSupportsMultiSelect.set(options2.multipleSelectionSupport !== false);
		const listSelectionNavigation = ck_listSelectionNavigation.bindTo(this.contextKeyService);
		listSelectionNavigation.set(Boolean(options2.selectionNavigation));
		this.listSupportFindWidget = ck_listSupportsFind.bindTo(this.contextKeyService);
		this.listSupportFindWidget.set(options2.findWidgetEnabled ?? true);
		this.hasSelectionOrFocus = ck_listHasSelectionOrFocus.bindTo(this.contextKeyService);
		this.hasDoubleSelection = ck_listDoubleSelection.bindTo(this.contextKeyService);
		this.hasMultiSelection = ck_listMultiSelection.bindTo(this.contextKeyService);
		this.treeElementCanCollapse = ck_treeElementCanCollapse.bindTo(this.contextKeyService);
		this.treeElementHasParent = ck_treeElementHasParent.bindTo(this.contextKeyService);
		this.treeElementCanExpand = ck_treeElementCanExpand.bindTo(this.contextKeyService);
		this.treeElementHasChild = ck_treeElementHasChild.bindTo(this.contextKeyService);
		this.treeFindOpen = ck_treeFindOpen.bindTo(this.contextKeyService);
		this.treeStickyScrollFocused = ck_treeStickyScrollFocused.bindTo(this.contextKeyService);
		this._useAltAsMultipleSelectionModifier = useAltAsMultipleSelectionModifier(configurationService);
		this.updateStyleOverrides(overrideStyles2);
		const updateCollapseContextKeys = () => {
			const focus = tree.getFocus()[0];
			if (!focus) {
				return;
			}
			const node = tree.getNode(focus);
			this.treeElementCanCollapse.set(node.collapsible && !node.collapsed);
			this.treeElementHasParent.set(!!tree.getParentElement(focus));
			this.treeElementCanExpand.set(node.collapsible && node.collapsed);
			this.treeElementHasChild.set(!!tree.getFirstElementChild(focus));
		};
		const interestingContextKeys = new Set();
		interestingContextKeys.add(WorkbenchListTypeNavigationModeKey);
		interestingContextKeys.add(WorkbenchListAutomaticKeyboardNavigationLegacyKey);
		this.disposables.push(
			this.contextKeyService,
			listService.register(tree),
			tree.onDidChangeSelection(() => {
				const selection = tree.getSelection();
				const focus = tree.getFocus();
				this.contextKeyService.bufferChangeEvents(() => {
					this.hasSelectionOrFocus.set(selection.length > 0 || focus.length > 0);
					this.hasMultiSelection.set(selection.length > 1);
					this.hasDoubleSelection.set(selection.length === 2);
				});
			}),
			tree.onDidChangeFocus(() => {
				const selection = tree.getSelection();
				const focus = tree.getFocus();
				this.hasSelectionOrFocus.set(selection.length > 0 || focus.length > 0);
				updateCollapseContextKeys();
			}),
			tree.onDidChangeCollapseState(updateCollapseContextKeys),
			tree.onDidChangeModel(updateCollapseContextKeys),
			tree.onDidChangeFindOpenState(enabled => this.treeFindOpen.set(enabled)),
			tree.onDidChangeStickyScrollFocused(focused => this.treeStickyScrollFocused.set(focused)),
			configurationService.onDidChangeConfiguration(e => {
				let newOptions = {};
				if (e.affectsConfiguration(multiSelectModifierSettingKey)) {
					this._useAltAsMultipleSelectionModifier = useAltAsMultipleSelectionModifier(configurationService);
				}
				if (e.affectsConfiguration(treeIndentKey)) {
					const indent = configurationService.getValue(treeIndentKey);
					newOptions = { ...newOptions, indent };
				}
				if (e.affectsConfiguration(treeRenderIndentGuidesKey) && options2.renderIndentGuides === undefined) {
					const renderIndentGuides = configurationService.getValue(treeRenderIndentGuidesKey);
					newOptions = { ...newOptions, renderIndentGuides };
				}
				if (e.affectsConfiguration(listSmoothScrolling)) {
					const smoothScrolling = Boolean(configurationService.getValue(listSmoothScrolling));
					newOptions = { ...newOptions, smoothScrolling };
				}
				if (e.affectsConfiguration(defaultFindModeSettingKey) || e.affectsConfiguration(keyboardNavigationSettingKey)) {
					const defaultFindMode = getDefaultTreeFindMode(configurationService);
					newOptions = { ...newOptions, defaultFindMode };
				}
				if (e.affectsConfiguration(typeNavigationModeSettingKey) || e.affectsConfiguration(keyboardNavigationSettingKey)) {
					const typeNavigationMode = getTypeNavigationMode();
					newOptions = { ...newOptions, typeNavigationMode };
				}
				if (e.affectsConfiguration(defaultFindMatchTypeSettingKey)) {
					const defaultFindMatchType = getDefaultTreeFindMatchType(configurationService);
					newOptions = { ...newOptions, defaultFindMatchType };
				}
				if (e.affectsConfiguration(horizontalScrollingKey) && options2.horizontalScrolling === undefined) {
					const horizontalScrolling = Boolean(configurationService.getValue(horizontalScrollingKey));
					newOptions = { ...newOptions, horizontalScrolling };
				}
				if (e.affectsConfiguration(scrollByPageKey)) {
					const scrollByPage = Boolean(configurationService.getValue(scrollByPageKey));
					newOptions = { ...newOptions, scrollByPage };
				}
				if (e.affectsConfiguration(treeExpandMode) && options2.expandOnlyOnTwistieClick === undefined) {
					newOptions = {
						...newOptions,
						expandOnlyOnTwistieClick: configurationService.getValue(treeExpandMode) === 'doubleClick'
					};
				}
				if (e.affectsConfiguration(treeStickyScroll)) {
					const enableStickyScroll = configurationService.getValue(treeStickyScroll);
					newOptions = { ...newOptions, enableStickyScroll };
				}
				if (e.affectsConfiguration(treeStickyScrollMaxElements)) {
					const stickyScrollMaxItemCount = Math.max(1, configurationService.getValue(treeStickyScrollMaxElements));
					newOptions = { ...newOptions, stickyScrollMaxItemCount };
				}
				if (e.affectsConfiguration(mouseWheelScrollSensitivityKey)) {
					const mouseWheelScrollSensitivity = configurationService.getValue(mouseWheelScrollSensitivityKey);
					newOptions = { ...newOptions, mouseWheelScrollSensitivity };
				}
				if (e.affectsConfiguration(fastScrollSensitivityKey)) {
					const fastScrollSensitivity = configurationService.getValue(fastScrollSensitivityKey);
					newOptions = { ...newOptions, fastScrollSensitivity };
				}
				if (Object.keys(newOptions).length > 0) {
					tree.updateOptions(newOptions);
				}
			}),
			this.contextKeyService.onDidChangeContext(e => {
				if (e.affectsSome(interestingContextKeys)) {
					tree.updateOptions({
						typeNavigationMode: getTypeNavigationMode()
					});
				}
			})
		);
		this.navigator = new TreeResourceNavigator(tree, {
			configurationService,
			...options2
		});
		this.disposables.push(this.navigator);
	}
	updateOptions(options2) {
		if (options2.multipleSelectionSupport !== undefined) {
			this.listSupportsMultiSelect.set(!!options2.multipleSelectionSupport);
		}
	}
	updateStyleOverrides(overrideStyles2) {
		this.tree.style(overrideStyles2 ? getListStyles(overrideStyles2) : defaultStyle_list);
	}
	dispose() {
		this.disposables = dispose(this.disposables);
	}
}
__decorate([__param(4, IContextKeyService), __param(5, IListService), __param(6, IConfigurationService)], WorkbenchTreeInternals);

class WorkbenchObjectTree extends ObjectTree {
	constructor(
		user,
		container,
		delegate,
		renderers,
		options2,
		instantiationService,
		contextKeyService,
		listService,
		configurationService
	) {
		const {
			options: treeOptions,
			getTypeNavigationMode,
			disposable
		} = instantiationService.invokeFunction(workbenchTreeDataPreamble, options2);
		super(user, container, delegate, renderers, treeOptions);
		this.disposables.add(disposable);
		this.internals = new WorkbenchTreeInternals(
			this,
			options2,
			getTypeNavigationMode,
			options2.overrideStyles,
			contextKeyService,
			listService,
			configurationService
		);
		this.disposables.add(this.internals);
	}
	updateOptions(options2) {
		super.updateOptions(options2);
		this.internals.updateOptions(options2);
	}
}
__decorate(
	[__param(5, IInstantiationService), __param(6, IContextKeyService), __param(7, IListService), __param(8, IConfigurationService)],
	WorkbenchObjectTree
);

class WorkbenchCompressibleObjectTree extends CompressibleObjectTree {
	constructor(
		user,
		container,
		delegate,
		renderers,
		options2,
		instantiationService,
		contextKeyService,
		listService,
		configurationService
	) {
		const {
			options: treeOptions,
			getTypeNavigationMode,
			disposable
		} = instantiationService.invokeFunction(workbenchTreeDataPreamble, options2);
		super(user, container, delegate, renderers, treeOptions);
		this.disposables.add(disposable);
		this.internals = new WorkbenchTreeInternals(
			this,
			options2,
			getTypeNavigationMode,
			options2.overrideStyles,
			contextKeyService,
			listService,
			configurationService
		);
		this.disposables.add(this.internals);
	}
	updateOptions(options2 = {}) {
		super.updateOptions(options2);
		if (options2.overrideStyles) {
			this.internals.updateStyleOverrides(options2.overrideStyles);
		}
		this.internals.updateOptions(options2);
	}
}
__decorate(
	[__param(5, IInstantiationService), __param(6, IContextKeyService), __param(7, IListService), __param(8, IConfigurationService)],
	WorkbenchCompressibleObjectTree
);

class WorkbenchDataTree extends DataTree {
	constructor(
		user,
		container,
		delegate,
		renderers,
		dataSource,
		options2,
		instantiationService,
		contextKeyService,
		listService,
		configurationService
	) {
		const {
			options: treeOptions,
			getTypeNavigationMode,
			disposable
		} = instantiationService.invokeFunction(workbenchTreeDataPreamble, options2);
		super(user, container, delegate, renderers, dataSource, treeOptions);
		this.disposables.add(disposable);
		this.internals = new WorkbenchTreeInternals(
			this,
			options2,
			getTypeNavigationMode,
			options2.overrideStyles,
			contextKeyService,
			listService,
			configurationService
		);
		this.disposables.add(this.internals);
	}
	updateOptions(options2 = {}) {
		super.updateOptions(options2);
		if (options2.overrideStyles !== undefined) {
			this.internals.updateStyleOverrides(options2.overrideStyles);
		}
		this.internals.updateOptions(options2);
	}
}
__decorate(
	[__param(6, IInstantiationService), __param(7, IContextKeyService), __param(8, IListService), __param(9, IConfigurationService)],
	WorkbenchDataTree
);

class WorkbenchAsyncDataTree extends AsyncDataTree {
	get onDidOpen() {
		return this.internals.onDidOpen;
	}
	constructor(
		user,
		container,
		delegate,
		renderers,
		dataSource,
		options2,
		instantiationService,
		contextKeyService,
		listService,
		configurationService
	) {
		const {
			options: treeOptions,
			getTypeNavigationMode,
			disposable
		} = instantiationService.invokeFunction(workbenchTreeDataPreamble, options2);
		super(user, container, delegate, renderers, dataSource, treeOptions);
		this.disposables.add(disposable);
		this.internals = new WorkbenchTreeInternals(
			this,
			options2,
			getTypeNavigationMode,
			options2.overrideStyles,
			contextKeyService,
			listService,
			configurationService
		);
		this.disposables.add(this.internals);
	}
	updateOptions(options2 = {}) {
		super.updateOptions(options2);
		if (options2.overrideStyles) {
			this.internals.updateStyleOverrides(options2.overrideStyles);
		}
		this.internals.updateOptions(options2);
	}
}
__decorate(
	[__param(6, IInstantiationService), __param(7, IContextKeyService), __param(8, IListService), __param(9, IConfigurationService)],
	WorkbenchAsyncDataTree
);

class WorkbenchCompressibleAsyncDataTree extends CompressibleAsyncDataTree {
	constructor(
		user,
		container,
		virtualDelegate,
		compressionDelegate,
		renderers,
		dataSource,
		options2,
		instantiationService,
		contextKeyService,
		listService,
		configurationService
	) {
		const {
			options: treeOptions,
			getTypeNavigationMode,
			disposable
		} = instantiationService.invokeFunction(workbenchTreeDataPreamble, options2);
		super(user, container, virtualDelegate, compressionDelegate, renderers, dataSource, treeOptions);
		this.disposables.add(disposable);
		this.internals = new WorkbenchTreeInternals(
			this,
			options2,
			getTypeNavigationMode,
			options2.overrideStyles,
			contextKeyService,
			listService,
			configurationService
		);
		this.disposables.add(this.internals);
	}
	updateOptions(options2) {
		super.updateOptions(options2);
		this.internals.updateOptions(options2);
	}
}
__decorate(
	[__param(7, IInstantiationService), __param(8, IContextKeyService), __param(9, IListService), __param(10, IConfigurationService)],
	WorkbenchCompressibleAsyncDataTree
);

const configurationRegistry3 = registry.as(baseContributionId_Configuration);
configurationRegistry3.registerConfiguration({
	id: 'workbench',
	order: 7,
	title: localize('Workbench'),
	type: 'object',
	properties: {
		[multiSelectModifierSettingKey]: {
			type: 'string',
			enum: ['ctrlCmd', 'alt'],
			markdownEnumDescriptions: [
				localize('Maps to `Control` on Windows and Linux and to `Command` on macOS.'),
				localize('Maps to `Alt` on Windows and Linux and to `Option` on macOS.')
			],
			default: 'ctrlCmd',
			description: localize(
				"The modifier to be used to add an item in trees and lists to a multi-selection with the mouse (for example in the explorer, open editors and scm view). The 'Open to Side' mouse gestures - if supported - will adapt such that they do not conflict with the multiselect modifier."
			)
		},
		[openModeSettingKey]: {
			type: 'string',
			enum: ['singleClick', 'doubleClick'],
			default: 'singleClick',
			description: localize(
				'Controls how to open items in trees and lists using the mouse (if supported). Note that some trees and lists might choose to ignore this setting if it is not applicable.'
			)
		},
		[horizontalScrollingKey]: {
			type: 'boolean',
			default: false,
			description: localize(
				'Controls whether lists and trees support horizontal scrolling in the workbench. Warning: turning on this setting has a performance implication.'
			)
		},
		[scrollByPageKey]: {
			type: 'boolean',
			default: false
		},
		[treeIndentKey]: {
			type: 'number',
			default: 8,
			minimum: 4,
			maximum: 40
		},
		[treeRenderIndentGuidesKey]: {
			type: 'string',
			enum: ['none', 'onHover', 'always'],
			default: 'onHover'
		},
		[listSmoothScrolling]: {
			type: 'boolean',
			default: false
		},
		[mouseWheelScrollSensitivityKey]: {
			type: 'number',
			default: 1,
			markdownDescription: localize('A multiplier to be used on the `deltaX` and `deltaY` of mouse wheel scroll events.')
		},
		[fastScrollSensitivityKey]: {
			type: 'number',
			default: 5,
			markdownDescription: localize('Scrolling speed multiplier when pressing `Alt`.')
		},
		[defaultFindModeSettingKey]: {
			type: 'string',
			enum: ['highlight', 'filter'],
			enumDescriptions: [
				localize('Highlight elements when searching. Further up and down navigation will traverse only the highlighted elements.'),
				localize('Filter elements when searching.')
			],
			default: 'highlight'
		},
		[keyboardNavigationSettingKey]: {
			type: 'string',
			enum: ['simple', 'highlight', 'filter'],
			enumDescriptions: [
				localize('Simple keyboard navigation focuses elements which match the keyboard input. Matching is done only on prefixes.'),
				localize(
					'Highlight keyboard navigation highlights elements which match the keyboard input. Further up and down navigation will traverse only the highlighted elements.'
				),
				localize('Filter keyboard navigation will filter out and hide all the elements which do not match the keyboard input.')
			],
			default: 'highlight',
			description: localize(
				'Controls the keyboard navigation style for lists and trees in the workbench. Can be simple, highlight and filter.'
			),
			deprecated: true,
			deprecationMessage: localize("Please use 'workbench.list.defaultFindMode' and	'workbench.list.typeNavigationMode' instead.")
		},
		[defaultFindMatchTypeSettingKey]: {
			type: 'string',
			enum: ['fuzzy', 'contiguous'],
			enumDescriptions: [localize('Use fuzzy matching when searching.'), localize('Use contiguous matching when searching.')],
			default: 'fuzzy'
		},
		[treeExpandMode]: {
			type: 'string',
			enum: ['singleClick', 'doubleClick'],
			default: 'singleClick',
			description: localize(
				'Controls how tree folders are expanded when clicking the folder names. Note that some trees and lists might choose to ignore this setting if it is not applicable.'
			)
		},
		[treeStickyScroll]: {
			type: 'boolean',
			default: true
		},
		[treeStickyScrollMaxElements]: {
			type: 'number',
			minimum: 1,
			default: 7,
			markdownDescription: localize(
				'Controls the number of sticky elements displayed in the tree when `#workbench.tree.enableStickyScroll#` is enabled.'
			)
		},
		[typeNavigationModeSettingKey]: {
			type: 'string',
			enum: ['automatic', 'trigger'],
			default: 'automatic',
			markdownDescription: localize(
				'Controls how type navigation works in lists and trees in the workbench. When set to `trigger`, type navigation begins once the `list.triggerTypeNavigation` command is run.'
			)
		}
	}
});


class WorkbenchHoverDelegate extends Disposable {
	get delay() {
		if (this.isInstantlyHovering()) {
			return 0;
		}
		return this._delay;
	}
	constructor(placement, instantHover, overrideOptions = {}, configurationService, hoverService) {
		super();
		this.placement = placement;
		this.instantHover = instantHover;
		this.overrideOptions = overrideOptions;
		this.configurationService = configurationService;
		this.hoverService = hoverService;
		this.lastHoverHideTime = 0;
		this.timeLimit = 200;
		this.hoverDisposables = this._register(new DisposableStore());
		this._delay = this.configurationService.getValue('workbench.hover.delay');
		this._register(
			this.configurationService.onDidChangeConfiguration(e => {
				if (e.affectsConfiguration('workbench.hover.delay')) {
					this._delay = this.configurationService.getValue('workbench.hover.delay');
				}
			})
		);
	}
	showHover(options2, focus) {
		const overrideOptions = typeof this.overrideOptions === 'function' ? this.overrideOptions(options2, focus) : this.overrideOptions;
		this.hoverDisposables.clear();
		const targets = options2.target instanceof HTMLElement ? [options2.target] : options2.target.targetElements;
		for (const target of targets) {
			this.hoverDisposables.add(
				addStandardDisposableListener(target, 'keydown', e => {
					if (
						e.equals(
							9 //Escape
						)
					) {
						this.hoverService.hideHover();
					}
				})
			);
		}
		const id = options2.content instanceof HTMLElement ? undefined : options2.content.toString();
		return this.hoverService.showHover(
			{
				...options2,
				...overrideOptions,
				persistence: {
					hideOnKeyDown: true,
					...overrideOptions.persistence
				},
				id,
				appearance: {
					...options2.appearance,
					compact: true,
					skipFadeInAnimation: this.isInstantlyHovering(),
					...overrideOptions.appearance
				}
			},
			focus
		);
	}
	isInstantlyHovering() {
		return this.instantHover && Date.now() - this.lastHoverHideTime < this.timeLimit;
	}
	onDidHideHover() {
		this.hoverDisposables.clear();
		if (this.instantHover) {
			this.lastHoverHideTime = Date.now();
		}
	}
}
__decorate(
	[
		__param(3, IConfigurationService),
		__param(4, IHoverService)
		//...
	],
	WorkbenchHoverDelegate
);

hoverDelegateFactory = (placement, enableInstantHover) => instantiationService.createInstance(WorkbenchHoverDelegate, placement, enableInstantHover, {});

