



const unthemedListStyles = {
	listFocusBackground: '#7FB0D0',
	listActiveSelectionBackground: '#0E639C',
	listActiveSelectionForeground: '#FFFFFF',
	listActiveSelectionIconForeground: '#FFFFFF',
	listFocusAndSelectionOutline: '#90C2F9',
	listFocusAndSelectionBackground: '#094771',
	listFocusAndSelectionForeground: '#FFFFFF',
	listInactiveSelectionBackground: '#3F3F46',
	listInactiveSelectionIconForeground: '#FFFFFF',
	listHoverBackground: '#2A2D2E',
	listDropOverBackground: '#383B3D',
	listDropBetweenBackground: '#EEEEEE',
	treeIndentGuidesStroke: '#a9a9a9',
	treeInactiveIndentGuidesStroke: Color.fromHex('#a9a9a9').transparent(0.4).toString(),
	tableColumnsBorder: Color.fromHex('#cccccc').transparent(0.2).toString(),
	tableOddRowsBackgroundColor: Color.fromHex('#cccccc').transparent(0.04).toString(),
	listBackground: undefined,
	listFocusForeground: undefined,
	listInactiveSelectionForeground: undefined,
	listInactiveFocusForeground: undefined,
	listInactiveFocusBackground: undefined,
	listHoverForeground: undefined,
	listFocusOutline: undefined,
	listInactiveFocusOutline: undefined,
	listSelectionOutline: undefined,
	listHoverOutline: undefined,
	treeStickyScrollBackground: undefined,
	treeStickyScrollBorder: undefined,
	treeStickyScrollShadow: undefined
};


class SelectListRenderer {
	get templateId() {
		return 'selectOption.entry.template';
	}
	renderTemplate(container) {
		const data = Object.create(null);
		data.root = container;
		data.text = append(container, createDomElement('.option-text'));
		data.detail = append(container, createDomElement('.option-detail'));
		data.decoratorRight = append(container, createDomElement('.option-decorator-right'));
		return data;
	}
	renderElement(element, index, templateData) {
		const data = templateData;
		const text2 = element.text;
		const detail = element.detail;
		const decoratorRight = element.decoratorRight;
		const isDisabled = element.isDisabled;
		data.text.textContent = text2;
		data.detail.textContent = !!detail ? detail : '';
		data.decoratorRight.innerText = !!decoratorRight ? decoratorRight : '';
		if (isDisabled) {
			data.root.classList.add('option-disabled');
		} else {
			data.root.classList.remove('option-disabled');
		}
	}
	disposeTemplate(_templateData) {}
}

class SelectBoxList extends Disposable {
	constructor(options2, selected, contextViewProvider, styles, selectBoxOptions) {
		super();
		this.options = [];
		this._currentSelection = 0;
		this._hasDetails = false;
		this._skipLayout = false;
		this._sticky = false;
		this._isVisible = false;
		this.styles = styles;
		this.selectBoxOptions = selectBoxOptions || Object.create(null);
		if (typeof this.selectBoxOptions.minBottomMargin !== 'number') {
			this.selectBoxOptions.minBottomMargin = SelectBoxList.DEFAULT_DROPDOWN_MINIMUM_BOTTOM_MARGIN;
		} else if (this.selectBoxOptions.minBottomMargin < 0) {
			this.selectBoxOptions.minBottomMargin = 0;
		}
		this.selectElement = document.createElement('select');
		this.selectElement.className = 'monaco-select-box monaco-select-box-dropdown-padding';
		this._onDidSelect = new Emitter();
		this._register(this._onDidSelect);
		this.registerListeners();
		this.constructSelectDropDown(contextViewProvider);
		this.selected = selected || 0;
		if (options2) {
			this.setOptions(options2, selected);
		}
		this.initStyleSheet();
	}
	setTitle(title) {
		if (!this._hover && title) {
			this._hover = this._register(
				getBaseLayerHoverDelegate().setupUpdatableHover(getDefaultHoverDelegate('mouse'), this.selectElement, title)
			);
		} else if (this._hover) {
			this._hover.update(title);
		}
	} // IDelegate - List renderer
	getHeight() {
		return 22;
	}
	getTemplateId() {
		return 'selectOption.entry.template';
	}
	constructSelectDropDown(contextViewProvider) {
		this.contextViewProvider = contextViewProvider;
		this.selectDropDownContainer = createDomElement('.monaco-select-box-dropdown-container');
		this.selectDropDownContainer.classList.add('monaco-select-box-dropdown-padding');
		this.selectionDetailsPane = append(this.selectDropDownContainer, createDomElement('.select-box-details-pane'));
		const widthControlOuterDiv = append(this.selectDropDownContainer, createDomElement('.select-box-dropdown-container-width-control'));
		const widthControlInnerDiv = append(widthControlOuterDiv, createDomElement('.width-control-div'));
		this.widthControlElement = document.createElement('span');
		this.widthControlElement.className = 'option-text-width-control';
		append(widthControlInnerDiv, this.widthControlElement);
		this._dropDownPosition = 0;
		this.styleElement = createStyleSheet(this.selectDropDownContainer);
		this.selectDropDownContainer.setAttribute('draggable', 'true');
		this._register(
			addDisposableListener(this.selectDropDownContainer, EventType.DRAG_START, e => {
				EventHelper.stop(e, true);
			})
		);
	}
	registerListeners() {
		this._register(
			addStandardDisposableListener(this.selectElement, 'change', e => {
				this.selected = e.target.selectedIndex;
				this._onDidSelect.fire({
					index: e.target.selectedIndex,
					selected: e.target.value
				});
				if (!!this.options[this.selected] && !!this.options[this.selected].text) {
					this.setTitle(this.options[this.selected].text);
				}
			})
		);
		this._register(
			addDisposableListener(this.selectElement, EventType.CLICK, e => {
				EventHelper.stop(e);
				if (this._isVisible) {
					this.hideSelectDropDown(true);
				} else {
					this.showSelectDropDown();
				}
			})
		);
		this._register(
			addDisposableListener(this.selectElement, EventType.MOUSE_DOWN, e => {
				EventHelper.stop(e);
			})
		);
		let listIsVisibleOnTouchStart;
		this._register(
			addDisposableListener(this.selectElement, 'touchstart', e => {
				listIsVisibleOnTouchStart = this._isVisible;
			})
		);
		this._register(
			addDisposableListener(this.selectElement, 'touchend', e => {
				EventHelper.stop(e);
				if (listIsVisibleOnTouchStart) {
					this.hideSelectDropDown(true);
				} else {
					this.showSelectDropDown();
				}
			})
		);
		this._register(
			addDisposableListener(this.selectElement, EventType.KEY_DOWN, e => {
				const event = new StandardKeyboardEvent(e);
				let showDropDown = false;
				if (isMacintosh) {
					if (event.keyCode === 18 || event.keyCode === 16 || event.keyCode === 10 || event.keyCode === 3) {
						showDropDown = true;
					}
				} else {
					if (
						(event.keyCode === 18 && event.altKey) ||
						(event.keyCode === 16 && event.altKey) ||
						event.keyCode === 10 ||
						event.keyCode === 3
					) {
						showDropDown = true;
					}
				}
				if (showDropDown) {
					this.showSelectDropDown();
					EventHelper.stop(e, true);
				}
			})
		);
	}
	get onDidSelect() {
		return this._onDidSelect.event;
	}
	setOptions(options2, selected) {
		if (!equals(this.options, options2)) {
			this.options = options2;
			this.selectElement.options.length = 0;
			this._hasDetails = false;
			this._cachedMaxDetailsHeight = undefined;
			this.options.forEach((option, index) => {
				this.selectElement.add(this.createOption(option.text, index, option.isDisabled));
				if (typeof option.description === 'string') {
					this._hasDetails = true;
				}
			});
		}
		if (selected !== undefined) {
			this.select(selected);
			this._currentSelection = this.selected;
		}
	}
	setOptionsList() {
		this.selectList?.splice(0, this.selectList.length, this.options);
	}
	select(index) {
		if (index >= 0 && index < this.options.length) {
			this.selected = index;
		} else if (index > this.options.length - 1) {
			this.select(this.options.length - 1);
		} else if (this.selected < 0) {
			this.selected = 0;
		}
		this.selectElement.selectedIndex = this.selected;
		if (!!this.options[this.selected] && !!this.options[this.selected].text) {
			this.setTitle(this.options[this.selected].text);
		}
	}
	focus() {
		if (this.selectElement) {
			this.selectElement.tabIndex = 0;
			this.selectElement.focus();
		}
	}
	blur() {
		if (this.selectElement) {
			this.selectElement.tabIndex = -1;
			this.selectElement.blur();
		}
	}
	setFocusable(focusable) {
		this.selectElement.tabIndex = focusable ? 0 : -1;
	}
	render(container) {
		this.container = container;
		container.classList.add('select-container');
		container.appendChild(this.selectElement);
		this.styleSelectElement();
	}
	initStyleSheet() {
		const content = [];
		if (this.styles.listFocusBackground) {
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-dropdown-list-container .monaco-list .monaco-list-row.focused { background-color: ${this.styles.listFocusBackground} !important; }`
			);
		}
		if (this.styles.listFocusForeground) {
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-dropdown-list-container .monaco-list .monaco-list-row.focused { color: ${this.styles.listFocusForeground} !important; }`
			);
		}
		if (this.styles.decoratorRightForeground) {
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-dropdown-list-container .monaco-list .monaco-list-row:not(.focused) .option-decorator-right { color: ${this.styles.decoratorRightForeground}; }`
			);
		}
		if (this.styles.selectBackground && this.styles.selectBorder && this.styles.selectBorder !== this.styles.selectBackground) {
			content.push(`.monaco-select-box-dropdown-container { border: 1px solid ${this.styles.selectBorder} } `);
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-details-pane.border-top { border-top: 1px solid ${this.styles.selectBorder} } `
			);
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-details-pane.border-bottom { border-bottom: 1px solid ${this.styles.selectBorder} } `
			);
		} else if (this.styles.selectListBorder) {
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-details-pane.border-top { border-top: 1px solid ${this.styles.selectListBorder} } `
			);
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-details-pane.border-bottom { border-bottom: 1px solid ${this.styles.selectListBorder} } `
			);
		}
		if (this.styles.listHoverForeground) {
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-dropdown-list-container .monaco-list .monaco-list-row:not(.option-disabled):not(.focused):hover { color: ${this.styles.listHoverForeground} !important; }`
			);
		}
		if (this.styles.listHoverBackground) {
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-dropdown-list-container .monaco-list .monaco-list-row:not(.option-disabled):not(.focused):hover { background-color: ${this.styles.listHoverBackground} !important; }`
			);
		}
		if (this.styles.listFocusOutline) {
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-dropdown-list-container .monaco-list .monaco-list-row.focused { outline: 1.6px dotted ${this.styles.listFocusOutline} !important; outline-offset: -1.6px !important; }`
			);
		}
		if (this.styles.listHoverOutline) {
			content.push(
				`.monaco-select-box-dropdown-container > .select-box-dropdown-list-container .monaco-list .monaco-list-row:not(.option-disabled):not(.focused):hover { outline: 1.6px dashed ${this.styles.listHoverOutline} !important; outline-offset: -1.6px !important; }`
			);
		}
		content.push(
			`.monaco-select-box-dropdown-container > .select-box-dropdown-list-container .monaco-list .monaco-list-row.option-disabled.focused { background-color: transparent !important; color: inherit !important; outline: none !important; }`
		);
		content.push(
			`.monaco-select-box-dropdown-container > .select-box-dropdown-list-container .monaco-list .monaco-list-row.option-disabled:hover { background-color: transparent !important; color: inherit !important; outline: none !important; }`
		);
		this.styleElement.textContent = content.join('\n');
	}
	styleSelectElement() {
		const background = this.styles.selectBackground || '';
		const foreground2 = this.styles.selectForeground || '';
		const border = this.styles.selectBorder || '';
		this.selectElement.style.backgroundColor = background;
		this.selectElement.style.color = foreground2;
		this.selectElement.style.borderColor = border;
	}
	styleList() {
		const background = this.styles.selectBackground || '';
		const listBackground = asCssValueWithDefault(this.styles.selectListBackground, background);
		this.selectDropDownListContainer.style.backgroundColor = listBackground;
		this.selectionDetailsPane.style.backgroundColor = listBackground;
		const optionsBorder = this.styles.focusBorder || '';
		this.selectDropDownContainer.style.outlineColor = optionsBorder;
		this.selectDropDownContainer.style.outlineOffset = '-1px';
		this.selectList.style(this.styles);
	}
	createOption(value, index, disabled) {
		const option = document.createElement('option');
		option.value = value;
		option.text = value;
		option.disabled = !!disabled;
		return option;
	}
	// ContextView dropdown methods
	showSelectDropDown() {
		this.selectionDetailsPane.innerText = '';
		if (!this.contextViewProvider || this._isVisible) {
			return;
		}
		this.createSelectList(this.selectDropDownContainer);
		this.setOptionsList();
		this.contextViewProvider.showContextView(
			{
				getAnchor: () => this.selectElement,
				render: container => this.renderSelectDropDown(container, true),
				layout: () => {
					this.layoutSelectDropDown();
				},
				onHide: () => {
					this.selectDropDownContainer.classList.remove('visible');
					this.selectElement.classList.remove('synthetic-focus');
				},
				anchorPosition: this._dropDownPosition
			},
			this.selectBoxOptions.optionsAsChildren ? this.container : undefined
		);
		this._isVisible = true;
		this.hideSelectDropDown(false);
		this.contextViewProvider.showContextView(
			{
				getAnchor: () => this.selectElement,
				render: container => this.renderSelectDropDown(container),
				layout: () => this.layoutSelectDropDown(),
				onHide: () => {
					this.selectDropDownContainer.classList.remove('visible');
					this.selectElement.classList.remove('synthetic-focus');
				},
				anchorPosition: this._dropDownPosition
			},
			this.selectBoxOptions.optionsAsChildren ? this.container : undefined
		);
		this._currentSelection = this.selected;
		this._isVisible = true;
	}
	hideSelectDropDown(focusSelect) {
		if (!this.contextViewProvider || !this._isVisible) {
			return;
		}
		this._isVisible = false;
		if (focusSelect) {
			this.selectElement.focus();
		}
		this.contextViewProvider.hideContextView();
	}
	renderSelectDropDown(container, preLayoutPosition) {
		container.appendChild(this.selectDropDownContainer);
		this.layoutSelectDropDown(preLayoutPosition);
		return {
			dispose: () => {
				try {
					container.removeChild(this.selectDropDownContainer);
				} catch (error) {}
			}
		};
	}
	// Iterate over detailed descriptions, find max height
	measureMaxDetailsHeight() {
		let maxDetailsPaneHeight = 0;
		this.options.forEach((_option, index) => {
			this.updateDetail(index);
			if (this.selectionDetailsPane.offsetHeight > maxDetailsPaneHeight) {
				maxDetailsPaneHeight = this.selectionDetailsPane.offsetHeight;
			}
		});
		return maxDetailsPaneHeight;
	}
	layoutSelectDropDown(preLayoutPosition) {
		if (this._skipLayout) {
			return false;
		}
		if (this.selectList) {
			this.selectDropDownContainer.classList.add('visible');
			const window2 = getWindow(this.selectElement);
			const selectPosition = getDomNodePagePosition(this.selectElement);
			const styles = getWindow(this.selectElement).getComputedStyle(this.selectElement);
			const verticalPadding =
				parseFloat(styles.getPropertyValue('--dropdown-padding-top')) +
				parseFloat(styles.getPropertyValue('--dropdown-padding-bottom'));
			const maxSelectDropDownHeightBelow =
				window2.innerHeight - selectPosition.top - selectPosition.height - (this.selectBoxOptions.minBottomMargin || 0);
			const maxSelectDropDownHeightAbove = selectPosition.top - SelectBoxList.DEFAULT_DROPDOWN_MINIMUM_TOP_MARGIN;
			const selectWidth = this.selectElement.offsetWidth;
			const selectMinWidth = this.setWidthControlElement(this.widthControlElement);
			const selectOptimalWidth = Math.max(selectMinWidth, Math.round(selectWidth)).toString() + 'px';
			this.selectDropDownContainer.style.width = selectOptimalWidth;
			this.selectList.getHTMLElement().style.height = '';
			this.selectList.layout();
			let listHeight = this.selectList.contentHeight;
			if (this._hasDetails && this._cachedMaxDetailsHeight === undefined) {
				this._cachedMaxDetailsHeight = this.measureMaxDetailsHeight();
			}
			const maxDetailsPaneHeight = this._hasDetails ? this._cachedMaxDetailsHeight : 0;
			const minRequiredDropDownHeight = listHeight + verticalPadding + maxDetailsPaneHeight;
			const maxVisibleOptionsBelow = Math.floor(
				(maxSelectDropDownHeightBelow - verticalPadding - maxDetailsPaneHeight) / this.getHeight()
			);
			const maxVisibleOptionsAbove = Math.floor(
				(maxSelectDropDownHeightAbove - verticalPadding - maxDetailsPaneHeight) / this.getHeight()
			);
			if (preLayoutPosition) {
				if (
					selectPosition.top + selectPosition.height > window2.innerHeight - 22 ||
					selectPosition.top < SelectBoxList.DEFAULT_DROPDOWN_MINIMUM_TOP_MARGIN ||
					(maxVisibleOptionsBelow < 1 && maxVisibleOptionsAbove < 1)
				) {
					return false;
				}
				if (
					maxVisibleOptionsBelow < SelectBoxList.DEFAULT_MINIMUM_VISIBLE_OPTIONS &&
					maxVisibleOptionsAbove > maxVisibleOptionsBelow &&
					this.options.length > maxVisibleOptionsBelow
				) {
					this._dropDownPosition = 1;
					this.selectDropDownContainer.removeChild(this.selectDropDownListContainer);
					this.selectDropDownContainer.removeChild(this.selectionDetailsPane);
					this.selectDropDownContainer.appendChild(this.selectionDetailsPane);
					this.selectDropDownContainer.appendChild(this.selectDropDownListContainer);
					this.selectionDetailsPane.classList.remove('border-top');
					this.selectionDetailsPane.classList.add('border-bottom');
				} else {
					this._dropDownPosition = 0;
					this.selectDropDownContainer.removeChild(this.selectDropDownListContainer);
					this.selectDropDownContainer.removeChild(this.selectionDetailsPane);
					this.selectDropDownContainer.appendChild(this.selectDropDownListContainer);
					this.selectDropDownContainer.appendChild(this.selectionDetailsPane);
					this.selectionDetailsPane.classList.remove('border-bottom');
					this.selectionDetailsPane.classList.add('border-top');
				}
				return true;
			}
			if (
				selectPosition.top + selectPosition.height > window2.innerHeight - 22 ||
				selectPosition.top < SelectBoxList.DEFAULT_DROPDOWN_MINIMUM_TOP_MARGIN ||
				(this._dropDownPosition === 0 && maxVisibleOptionsBelow < 1) ||
				(this._dropDownPosition === 1 && maxVisibleOptionsAbove < 1)
			) {
				this.hideSelectDropDown(true);
				return false;
			}
			if (this._dropDownPosition === 0) {
				if (this._isVisible && maxVisibleOptionsBelow + maxVisibleOptionsAbove < 1) {
					this.hideSelectDropDown(true);
					return false;
				}
				if (minRequiredDropDownHeight > maxSelectDropDownHeightBelow) {
					listHeight = maxVisibleOptionsBelow * this.getHeight();
				}
			} else {
				if (minRequiredDropDownHeight > maxSelectDropDownHeightAbove) {
					listHeight = maxVisibleOptionsAbove * this.getHeight();
				}
			}
			this.selectList.layout(listHeight);
			this.selectList.domFocus();
			if (this.selectList.length > 0) {
				this.selectList.setFocus([this.selected || 0]);
				this.selectList.reveal(this.selectList.getFocus()[0] || 0);
			}
			if (this._hasDetails) {
				this.selectList.getHTMLElement().style.height = listHeight + verticalPadding + 'px';
				this.selectDropDownContainer.style.height = '';
			} else {
				this.selectDropDownContainer.style.height = listHeight + verticalPadding + 'px';
			}
			this.updateDetail(this.selected);
			this.selectDropDownContainer.style.width = selectOptimalWidth;
			this.selectDropDownListContainer.setAttribute('tabindex', '0');
			this.selectElement.classList.add('synthetic-focus');
			this.selectDropDownContainer.classList.add('synthetic-focus');
			return true;
		} else {
			return false;
		}
	}
	setWidthControlElement(container) {
		let elementWidth = 0;
		if (container) {
			let longest = 0;
			let longestLength = 0;
			this.options.forEach((option, index) => {
				const detailLength = !!option.detail ? option.detail.length : 0;
				const rightDecoratorLength = !!option.decoratorRight ? option.decoratorRight.length : 0;
				const len = option.text.length + detailLength + rightDecoratorLength;
				if (len > longestLength) {
					longest = index;
					longestLength = len;
				}
			});
			container.textContent =
				this.options[longest].text + (!!this.options[longest].decoratorRight ? this.options[longest].decoratorRight + ' ' : '');
			elementWidth = getTotalWidth(container);
		}
		return elementWidth;
	}
	createSelectList(parent) {
		if (this.selectList) {
			return;
		}
		this.selectDropDownListContainer = append(parent, createDomElement('.select-box-dropdown-list-container'));
		this.listRenderer = new SelectListRenderer();
		this.selectList = new List('SelectBoxCustom', this.selectDropDownListContainer, this, [this.listRenderer], {
			useShadows: false,
			verticalScrollMode: 3,
			keyboardSupport: false,
			mouseSupport: false
		});
		const onKeyDown = this._register(new DomEmitter(this.selectDropDownListContainer, 'keydown'));
		const onSelectDropDownKeyDown = editorEventChain(onKeyDown.event, $16 =>
			$16.filter(() => this.selectList.length > 0).map(e => new StandardKeyboardEvent(e))
		);
		this._register(
			editorEventChain(onSelectDropDownKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 3 //Enter
				)
			)(this.onEnter, this)
		);
		this._register(
			editorEventChain(onSelectDropDownKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 2 //Tab
				)
			)(this.onEnter, this)
		);
		this._register(
			editorEventChain(onSelectDropDownKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 9 //Escape
				)
			)(this.onEscape, this)
		);
		this._register(
			editorEventChain(onSelectDropDownKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 16 //UpArrow
				)
			)(this.onUpArrow, this)
		);
		this._register(
			editorEventChain(onSelectDropDownKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 18 // DownArrow
				)
			)(this.onDownArrow, this)
		);
		this._register(
			editorEventChain(onSelectDropDownKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 12 //PageDown
				)
			)(this.onPageDown, this)
		);
		this._register(
			editorEventChain(onSelectDropDownKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 11 //PageUp
				)
			)(this.onPageUp, this)
		);
		this._register(
			editorEventChain(onSelectDropDownKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 14 //Home
				)
			)(this.onHome, this)
		);
		this._register(
			editorEventChain(onSelectDropDownKeyDown, $16 =>
				$16.filter(
					e => e.keyCode === 13 //End
				)
			)(this.onEnd, this)
		);
		this._register(
			editorEventChain(onSelectDropDownKeyDown, $16 =>
				$16.filter(e => (e.keyCode >= 21 && e.keyCode <= 56) || (e.keyCode >= 85 && e.keyCode <= 113))
			)(this.onCharacter, this)
		);
		this._register(addDisposableListener(this.selectList.getHTMLElement(), EventType.POINTER_UP, e => this.onPointerUp(e)));
		this._register(this.selectList.onMouseOver(e => typeof e.index !== 'undefined' && this.selectList.setFocus([e.index])));
		this._register(this.selectList.onDidChangeFocus(e => this.onListFocus(e)));
		this._register(
			addDisposableListener(this.selectDropDownContainer, EventType.FOCUS_OUT, e => {
				if (!this._isVisible || isAncestor(e.relatedTarget, this.selectDropDownContainer)) {
					return;
				}
				this.onListBlur();
			})
		);
		this.styleList();
	}
	// List methods
	// List mouse controller - active exit, select option, fire onDidSelect if change, return focus to parent select
	// Also takes in touchend events
	onPointerUp(e) {
		if (!this.selectList.length) {
			return;
		}
		EventHelper.stop(e);
		const target = e.target;
		if (!target) {
			return;
		}
		if (target.classList.contains('slider')) {
			return;
		}
		const listRowElement = target.closest('.monaco-list-row');
		if (!listRowElement) {
			return;
		}
		const index = Number(listRowElement.getAttribute('data-index'));
		const disabled = listRowElement.classList.contains('option-disabled');
		if (index >= 0 && index < this.options.length && !disabled) {
			this.selected = index;
			this.select(this.selected);
			this.selectList.setFocus([this.selected]);
			this.selectList.reveal(this.selectList.getFocus()[0]);
			if (this.selected !== this._currentSelection) {
				this._currentSelection = this.selected;
				this._onDidSelect.fire({
					index: this.selectElement.selectedIndex,
					selected: this.options[this.selected].text
				});
				if (!!this.options[this.selected] && !!this.options[this.selected].text) {
					this.setTitle(this.options[this.selected].text);
				}
			}
			this.hideSelectDropDown(true);
		}
	}
	// List Exit - passive - implicit no selection change, hide drop-down
	onListBlur() {
		if (this._sticky) {
			return;
		}
		if (this.selected !== this._currentSelection) {
			this.select(this._currentSelection);
		}
		this.hideSelectDropDown(false);
	}
	renderDescriptionMarkdown(text2, actionHandler) {
		const cleanRenderedMarkdown = element => {
			for (let i = 0; i < element.childNodes.length; i++) {
				const child = element.childNodes.item(i);
				const tagName = child.tagName && child.tagName.toLowerCase();
				if (tagName === 'img') {
					element.removeChild(child);
				} else {
					cleanRenderedMarkdown(child);
				}
			}
		};
		const rendered = renderMarkdown({ value: text2, supportThemeIcons: true }, { actionHandler });
		rendered.element.classList.add('select-box-description-markdown');
		cleanRenderedMarkdown(rendered.element);
		return rendered.element;
	}
	// List Focus Change - passive - update details pane with newly focused element's data
	onListFocus(e) {
		if (!this._isVisible || !this._hasDetails) {
			return;
		}
		this.updateDetail(e.indexes[0]);
	}
	updateDetail(selectedIndex) {
		this.selectionDetailsPane.innerText = '';
		const option = this.options[selectedIndex];
		const description = option?.description || '';
		const descriptionIsMarkdown = option?.descriptionIsMarkdown ?? false;
		if (description) {
			if (descriptionIsMarkdown) {
				const actionHandler = option.descriptionMarkdownActionHandler;
				this.selectionDetailsPane.appendChild(this.renderDescriptionMarkdown(description, actionHandler));
			} else {
				this.selectionDetailsPane.innerText = description;
			}
			this.selectionDetailsPane.style.display = 'block';
		} else {
			this.selectionDetailsPane.style.display = 'none';
		}
		this._skipLayout = true;
		this.contextViewProvider.layout();
		this._skipLayout = false;
	}
	// List keyboard controller
	// List exit - active - hide ContextView dropdown, reset selection, return focus to parent select
	onEscape(e) {
		EventHelper.stop(e);
		this.select(this._currentSelection);
		this.hideSelectDropDown(true);
	}
	// List exit - active - hide ContextView dropdown, return focus to parent select, fire onDidSelect if change
	onEnter(e) {
		EventHelper.stop(e);
		if (this.selected !== this._currentSelection) {
			this._currentSelection = this.selected;
			this._onDidSelect.fire({
				index: this.selectElement.selectedIndex,
				selected: this.options[this.selected].text
			});
			if (!!this.options[this.selected] && !!this.options[this.selected].text) {
				this.setTitle(this.options[this.selected].text);
			}
		}
		this.hideSelectDropDown(true);
	}
	// List navigation - have to handle a disabled option (jump over)
	onDownArrow(e) {
		if (this.selected < this.options.length - 1) {
			EventHelper.stop(e, true);
			const nextOptionDisabled = this.options[this.selected + 1].isDisabled;
			if (nextOptionDisabled && this.options.length > this.selected + 2) {
				this.selected += 2;
			} else if (nextOptionDisabled) {
				return;
			} else {
				this.selected++;
			}
			this.select(this.selected);
			this.selectList.setFocus([this.selected]);
			this.selectList.reveal(this.selectList.getFocus()[0]);
		}
	}
	onUpArrow(e) {
		if (this.selected > 0) {
			EventHelper.stop(e, true);
			const previousOptionDisabled = this.options[this.selected - 1].isDisabled;
			if (previousOptionDisabled && this.selected > 1) {
				this.selected -= 2;
			} else {
				this.selected--;
			}
			this.select(this.selected);
			this.selectList.setFocus([this.selected]);
			this.selectList.reveal(this.selectList.getFocus()[0]);
		}
	}
	onPageUp(e) {
		EventHelper.stop(e);
		this.selectList.focusPreviousPage();
		setTimeout(() => {
			this.selected = this.selectList.getFocus()[0];
			if (this.options[this.selected].isDisabled && this.selected < this.options.length - 1) {
				this.selected++;
				this.selectList.setFocus([this.selected]);
			}
			this.selectList.reveal(this.selected);
			this.select(this.selected);
		}, 1);
	}
	onPageDown(e) {
		EventHelper.stop(e);
		this.selectList.focusNextPage();
		setTimeout(() => {
			this.selected = this.selectList.getFocus()[0];
			if (this.options[this.selected].isDisabled && this.selected > 0) {
				this.selected--;
				this.selectList.setFocus([this.selected]);
			}
			this.selectList.reveal(this.selected);
			this.select(this.selected);
		}, 1);
	}
	onHome(e) {
		EventHelper.stop(e);
		if (this.options.length < 2) {
			return;
		}
		this.selected = 0;
		if (this.options[this.selected].isDisabled && this.selected > 1) {
			this.selected++;
		}
		this.selectList.setFocus([this.selected]);
		this.selectList.reveal(this.selected);
		this.select(this.selected);
	}
	onEnd(e) {
		EventHelper.stop(e);
		if (this.options.length < 2) {
			return;
		}
		this.selected = this.options.length - 1;
		if (this.options[this.selected].isDisabled && this.selected > 1) {
			this.selected--;
		}
		this.selectList.setFocus([this.selected]);
		this.selectList.reveal(this.selected);
		this.select(this.selected);
	}
	// Mimic option first character navigation of native select
	onCharacter(e) {
		const ch = uiMap.keyCodeToStr(e.keyCode);
		let optionIndex = -1;
		for (let i = 0; i < this.options.length - 1; i++) {
			optionIndex = (i + this.selected + 1) % this.options.length;
			if (this.options[optionIndex].text.charAt(0).toUpperCase() === ch && !this.options[optionIndex].isDisabled) {
				this.select(optionIndex);
				this.selectList.setFocus([optionIndex]);
				this.selectList.reveal(this.selectList.getFocus()[0]);
				EventHelper.stop(e);
				break;
			}
		}
	}
	dispose() {
		this.hideSelectDropDown(false);
		super.dispose();
	}
}
SelectBoxList.DEFAULT_DROPDOWN_MINIMUM_BOTTOM_MARGIN = 32;
SelectBoxList.DEFAULT_DROPDOWN_MINIMUM_TOP_MARGIN = 2;
SelectBoxList.DEFAULT_MINIMUM_VISIBLE_OPTIONS = 3;

class SelectBoxNative extends Disposable {
	constructor(options2, selected, styles, selectBoxOptions) {
		super();
		this.selected = 0;
		this.selectBoxOptions = selectBoxOptions || Object.create(null);
		this.options = [];
		this.selectElement = document.createElement('select');
		this.selectElement.className = 'monaco-select-box';
		this._onDidSelect = this._register(new Emitter());
		this.styles = styles;
		this.registerListeners();
		this.setOptions(options2, selected);
	}
	registerListeners() {
		this._register(Gesture.addTarget(this.selectElement));
		[GestureType.Tap].forEach(eventType => {
			this._register(
				addDisposableListener(this.selectElement, eventType, e => {
					this.selectElement.focus();
				})
			);
		});
		this._register(
			addStandardDisposableListener(this.selectElement, 'click', e => {
				EventHelper.stop(e, true);
			})
		);
		this._register(
			addStandardDisposableListener(this.selectElement, 'change', e => {
				this.selectElement.title = e.target.value;
				this._onDidSelect.fire({
					index: e.target.selectedIndex,
					selected: e.target.value
				});
			})
		);
		this._register(
			addStandardDisposableListener(this.selectElement, 'keydown', e => {
				let showSelect = false;
				if (isMacintosh) {
					if (e.keyCode === 18 || e.keyCode === 16 || e.keyCode === 10) {
						showSelect = true;
					}
				} else {
					if ((e.keyCode === 18 && e.altKey) || e.keyCode === 10 || e.keyCode === 3) {
						showSelect = true;
					}
				}
				if (showSelect) {
					e.stopPropagation();
				}
			})
		);
	}
	get onDidSelect() {
		return this._onDidSelect.event;
	}
	setOptions(options2, selected) {
		if (!this.options || !equals(this.options, options2)) {
			this.options = options2;
			this.selectElement.options.length = 0;
			this.options.forEach((option, index) => {
				this.selectElement.add(this.createOption(option.text, index, option.isDisabled));
			});
		}
		if (selected !== undefined) {
			this.select(selected);
		}
	}
	select(index) {
		if (this.options.length === 0) {
			this.selected = 0;
		} else if (index >= 0 && index < this.options.length) {
			this.selected = index;
		} else if (index > this.options.length - 1) {
			this.select(this.options.length - 1);
		} else if (this.selected < 0) {
			this.selected = 0;
		}
		this.selectElement.selectedIndex = this.selected;
		if (this.selected < this.options.length && typeof this.options[this.selected].text === 'string') {
			this.selectElement.title = this.options[this.selected].text;
		} else {
			this.selectElement.title = '';
		}
	}
	focus() {
		if (this.selectElement) {
			this.selectElement.tabIndex = 0;
			this.selectElement.focus();
		}
	}
	blur() {
		if (this.selectElement) {
			this.selectElement.tabIndex = -1;
			this.selectElement.blur();
		}
	}
	setFocusable(focusable) {
		this.selectElement.tabIndex = focusable ? 0 : -1;
	}
	render(container) {
		container.classList.add('select-container');
		container.appendChild(this.selectElement);
		this.setOptions(this.options, this.selected);
		this.applyStyles();
	}
	applyStyles() {
		if (this.selectElement) {
			this.selectElement.style.backgroundColor = this.styles.selectBackground || '';
			this.selectElement.style.color = this.styles.selectForeground || '';
			this.selectElement.style.borderColor = this.styles.selectBorder || '';
		}
	}
	createOption(value, index, disabled) {
		const option = document.createElement('option');
		option.value = value;
		option.text = value;
		option.disabled = !!disabled;
		return option;
	}
}

class SelectBox extends Widget {
	constructor(options2, selected, contextViewProvider, styles, selectBoxOptions) {
		super();
		if (isMacintosh && !(selectBoxOptions === null || selectBoxOptions?.useCustomDrawn)) {
			this.selectBoxDelegate = new SelectBoxNative(options2, selected, styles, selectBoxOptions);
		} else {
			this.selectBoxDelegate = new SelectBoxList(options2, selected, contextViewProvider, styles, selectBoxOptions);
		}
		this._register(this.selectBoxDelegate);
	}
	// Public SelectBox Methods - routed through delegate interface
	get onDidSelect() {
		return this.selectBoxDelegate.onDidSelect;
	}
	setOptions(options2, selected) {
		this.selectBoxDelegate.setOptions(options2, selected);
	}
	select(index) {
		this.selectBoxDelegate.select(index);
	}
	focus() {
		this.selectBoxDelegate.focus();
	}
	blur() {
		this.selectBoxDelegate.blur();
	}
	setFocusable(focusable) {
		this.selectBoxDelegate.setFocusable(focusable);
	}
	render(container) {
		this.selectBoxDelegate.render(container);
	}
}


class SelectActionViewItem extends BaseActionViewItem {
	constructor(ctx, action, options2, selected, contextViewProvider, styles, selectBoxOptions) {
		super(ctx, action);
		this.selectBox = new SelectBox(options2, selected, contextViewProvider, styles, selectBoxOptions);
		this.selectBox.setFocusable(false);
		this._register(this.selectBox);
		this.registerListeners();
	}
	select(index) {
		this.selectBox.select(index);
	}
	registerListeners() {
		this._register(this.selectBox.onDidSelect(e => this.runAction(e.selected, e.index)));
	}
	runAction(option, index) {
		this.actionRunner.run(this._action, this.getActionContext(option, index));
	}
	getActionContext(option, index) {
		return option;
	}
	setFocusable(focusable) {
		this.selectBox.setFocusable(focusable);
	}
	focus() {
		this.selectBox?.focus();
	}
	blur() {
		this.selectBox?.blur();
	}
	render(container) {
		this.selectBox.render(container);
	}
}



class BaseDropdown extends ActionRunner {
	constructor(container, options2) {
		super();
		this._onDidChangeVisibility = this._register(new Emitter());
		this.onDidChangeVisibility = this._onDidChangeVisibility.event;
		this._element = append(container, createDomElement('.monaco-dropdown'));
		this._label = append(this._element, createDomElement('.dropdown-label'));
		let labelRenderer = options2.labelRenderer;
		if (!labelRenderer) {
			labelRenderer = container2 => {
				container2.textContent = options2.label || '';
				return null;
			};
		}
		for (const event of [EventType.CLICK, EventType.MOUSE_DOWN, GestureType.Tap]) {
			this._register(addDisposableListener(this.element, event, e => EventHelper.stop(e, true)));
		}
		for (const event of [EventType.MOUSE_DOWN, GestureType.Tap]) {
			this._register(
				addDisposableListener(this._label, event, e => {
					if (isMouseEvent(e) && (e.detail > 1 || e.button !== 0)) {
						return;
					}
					if (this.visible) {
						this.hide();
					} else {
						this.show();
					}
				})
			);
		}
		this._register(
			addDisposableListener(this._label, EventType.KEY_UP, e => {
				const event = new StandardKeyboardEvent(e);
				if (
					event.equals(
						3 //Enter
					) ||
					event.equals(
						10 //Space
					)
				) {
					EventHelper.stop(e, true);
					if (this.visible) {
						this.hide();
					} else {
						this.show();
					}
				}
			})
		);
		const cleanupFn = labelRenderer(this._label);
		if (cleanupFn) {
			this._register(cleanupFn);
		}
		this._register(Gesture.addTarget(this._label));
	}
	get element() {
		return this._element;
	}
	show() {
		if (!this.visible) {
			this.visible = true;
			this._onDidChangeVisibility.fire(true);
		}
	}
	hide() {
		if (this.visible) {
			this.visible = false;
			this._onDidChangeVisibility.fire(false);
		}
	}
	dispose() {
		super.dispose();
		this.hide();
		if (this.boxContainer) {
			this.boxContainer.remove();
			this.boxContainer = undefined;
		}
		if (this.contents) {
			this.contents.remove();
			this.contents = undefined;
		}
		if (this._label) {
			this._label.remove();
			this._label = undefined;
		}
	}
}
class DropdownMenu extends BaseDropdown {
	constructor(container, _options) {
		super(container, _options);
		this._options = _options;
		this._actions = [];
		this.actions = _options.actions || [];
	}
	set menuOptions(options2) {
		this._menuOptions = options2;
	}
	get menuOptions() {
		return this._menuOptions;
	}
	get actions() {
		if (this._options.actionProvider) {
			return this._options.actionProvider.getActions();
		}
		return this._actions;
	}
	set actions(actions) {
		this._actions = actions;
	}
	show() {
		super.show();
		this.element.classList.add('active');
		this._options.contextMenuProvider.showContextMenu({
			getAnchor: () => this.element,
			getActions: () => this.actions,
			getActionsContext: () => (this.menuOptions ? this.menuOptions.context : null),
			getActionViewItem: (action, options2) =>
				this.menuOptions && this.menuOptions.actionViewItemProvider
					? this.menuOptions.actionViewItemProvider(action, options2)
					: undefined,
			getKeyBinding: action =>
				this.menuOptions && this.menuOptions.getKeyBinding ? this.menuOptions.getKeyBinding(action) : undefined,
			getMenuClassName: () => this._options.menuClassName || '',
			onHide: () => this.onHide(),
			actionRunner: this.menuOptions ? this.menuOptions.actionRunner : undefined,
			anchorAlignment: this.menuOptions ? this.menuOptions.anchorAlignment : 0,
			domForShadowRoot: this._options.menuAsChild ? this.element : undefined
		});
	}
	hide() {
		super.hide();
	}
	onHide() {
		this.hide();
		this.element.classList.remove('active');
	}
}

class DropdownMenuActionViewItem extends BaseActionViewItem {
	constructor(action, menuActionsOrProvider, contextMenuProvider, options2 = Object.create(null)) {
		super(null, action, options2);
		this.actionItem = null;
		this._onDidChangeVisibility = this._register(new Emitter());
		this.onDidChangeVisibility = this._onDidChangeVisibility.event;
		this.menuActionsOrProvider = menuActionsOrProvider;
		this.contextMenuProvider = contextMenuProvider;
		this.options = options2;
		if (this.options.actionRunner) {
			this.actionRunner = this.options.actionRunner;
		}
	}
	render(container) {
		this.actionItem = container;
		const labelRenderer = el => {
			this.element = append(el, createDomElement('a.action-label'));
			let classNames = [];
			if (typeof this.options.classNames === 'string') {
				classNames = this.options.classNames.split(/\s+/g).filter(s => !!s);
			} else if (this.options.classNames) {
				classNames = this.options.classNames;
			}
			if (!classNames.find(c => c === 'icon')) {
				classNames.push('codicon');
			}
			this.element.classList.add(...classNames);
			this.element.setAttribute('role', 'button');
			if (this._action.label) {
				this._register(
					getBaseLayerHoverDelegate().setupUpdatableHover(
						this.options.hoverDelegate ?? getDefaultHoverDelegate('mouse'),
						this.element,
						this._action.label
					)
				);
			}
			return null;
		};
		const isActionsArray = isArray(this.menuActionsOrProvider);
		const options2 = {
			contextMenuProvider: this.contextMenuProvider,
			labelRenderer,
			menuAsChild: this.options.menuAsChild,
			actions: isActionsArray ? this.menuActionsOrProvider : undefined,
			actionProvider: isActionsArray ? undefined : this.menuActionsOrProvider
		};
		this.dropdownMenu = this._register(new DropdownMenu(container, options2));
		this._register(
			this.dropdownMenu.onDidChangeVisibility(visible => {
				this._onDidChangeVisibility.fire(visible);
			})
		);
		this.dropdownMenu.menuOptions = {
			actionViewItemProvider: this.options.actionViewItemProvider,
			actionRunner: this.actionRunner,
			getKeyBinding: this.options.keybindingProvider,
			context: this._context
		};
		if (this.options.anchorAlignmentProvider) {
			const that = this;
			this.dropdownMenu.menuOptions = {
				...this.dropdownMenu.menuOptions,
				get anchorAlignment() {
					return that.options.anchorAlignmentProvider();
				}
			};
		}
		this.updateTooltip();
		this.updateEnabled();
	}
	getTooltip() {
		let title = null;
		if (this.action.tooltip) {
			title = this.action.tooltip;
		} else if (this.action.label) {
			title = this.action.label;
		}
		return title !== null && title !== undefined ? title : undefined;
	}
	setActionContext(newContext) {
		super.setActionContext(newContext);
		if (this.dropdownMenu) {
			if (this.dropdownMenu.menuOptions) {
				this.dropdownMenu.menuOptions.context = newContext;
			} else {
				this.dropdownMenu.menuOptions = { context: newContext };
			}
		}
	}
	show() {
		this.dropdownMenu?.show();
	}
	updateEnabled() {
		const disabled = !this.action.enabled;
		this.actionItem?.classList.toggle('disabled', disabled);
		this.element?.classList.toggle('disabled', disabled);
	}
}