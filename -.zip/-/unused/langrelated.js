globalThis.monaco = {
	getModels: getAllModels,
			getModel: getModelById,
	createModel: createLangModel,
}


const createLangModel = (value, lang, uri) => {
	const languageService = getService_Language();
	return createTextModel(getService_Model(), languageService, value, languageService.getLanguageIdByMimeType(lang) || lang, uri);
};


const getModelMarkers = filter => getService_Marker().read(filter);
