



function itemsEquals(fn) {
	return (a, b) => equals(
		a, b, fn|| (a, b) => a === b
	);
}
function itemEquals() {
	return (a, b) => a.equals(b);
}
function equalsIfDefined(v1, v2, equals3) {
	if (!v1 || !v2) {
		return v1 === v2;
	}
	return equals3(v1, v2);
}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function _setRecomputeInitiallyAndOnChange(recomputeInitiallyAndOnChange2) {
	_recomputeInitiallyAndOnChange = recomputeInitiallyAndOnChange2;
}
function _setKeepObserved(keepObserved2) {
	_keepObserved = keepObserved2;
}
function _setDerivedOpts(derived2) {
	_derived = derived2;
}
function transaction(fn, getDebugName2) {
	const tx = new TransactionImpl(fn, getDebugName2);
	try {
		fn(tx);
	} finally {
		tx.finish();
	}
}
function globalTransaction(fn) {
	if (_globalTransaction) {
		fn(_globalTransaction);
	} else {
		const tx = new TransactionImpl(fn, undefined);
		_globalTransaction = tx;
		try {
			fn(tx);
		} finally {
			tx.finish();
			_globalTransaction = undefined;
		}
	}
}
async function asyncTransaction(fn, getDebugName2) {
	const tx = new TransactionImpl(fn, getDebugName2);
	try {
		await fn(tx);
	} finally {
		tx.finish();
	}
}
function subtransaction(tx, fn, getDebugName2) {
	if (!tx) {
		transaction(fn, getDebugName2);
	} else {
		fn(tx);
	}
}
function observableValue(nameOrOwner, initialValue) {
	let debugNameData;
	if (typeof nameOrOwner === 'string') {
		debugNameData = new DebugNameData(undefined, nameOrOwner, undefined);
	} else {
		debugNameData = new DebugNameData(nameOrOwner, undefined, undefined);
	}
	return new ObservableValue(debugNameData, initialValue, strictEquals);
}
function observableValueOpts(options2, initialValue) {
	return new ObservableValue(
		new DebugNameData(options2.owner, options2.debugName, undefined),
		initialValue,
		options2.equalsFn ?? strictEquals
	);
}
function disposableObservableValue(nameOrOwner, initialValue) {
	let debugNameData;
	if (typeof nameOrOwner === 'string') {
		debugNameData = new DebugNameData(undefined, nameOrOwner, undefined);
	} else {
		debugNameData = new DebugNameData(nameOrOwner, undefined, undefined);
	}
	return new DisposableObservableValue(debugNameData, initialValue, strictEquals);
}
let _recomputeInitiallyAndOnChange, _keepObserved, _derived;

class ConvenientObservable {
	get TChange() {
		return null;
	}
	reportChanges() {
		this.get();
	}
	read(reader) {
		if (reader) {
			return reader.readObservable(this);
		} else {
			return this.get();
		}
	}
	map(fnOrOwner, fnOrUndefined) {
		const owner = fnOrUndefined === undefined ? undefined : fnOrOwner;
		const fn = fnOrUndefined === undefined ? fnOrOwner : fnOrUndefined;
		return _derived(
			{
				owner,
				debugName: () => {
					const name = getFunctionName(fn);
					if (name !== undefined) {
						return name;
					}
					const regexp = /^\s*\(?\s*([a-zA-Z_$][a-zA-Z_$0-9]*)\s*\)?\s*=>\s*\1(?:\??)\.([a-zA-Z_$][a-zA-Z_$0-9]*)\s*$/;
					const match2 = regexp.exec(fn.toString());
					if (match2) {
						return `${this.debugName}.${match2[2]}`;
					}
					if (!owner) {
						return `${this.debugName} (mapped)`;
					}
					return;
				},
				debugReferenceFn: fn
			},
			reader => fn(this.read(reader), reader)
		);
	}
	recomputeInitiallyAndOnChange(store, handleValue) {
		store.add(_recomputeInitiallyAndOnChange(this, handleValue));
		return this;
	}
}
class BaseObservable extends ConvenientObservable {
	constructor() {
		super(...arguments);
		this.observers = new Set();
	}
	addObserver(observer) {
		const len = this.observers.size;
		this.observers.add(observer);
		if (len === 0) {
			this.onFirstObserverAdded();
		}
	}
	removeObserver(observer) {
		const deleted = this.observers.delete(observer);
		if (deleted && this.observers.size === 0) {
			this.onLastObserverRemoved();
		}
	}
	onFirstObserverAdded() {}
	onLastObserverRemoved() {}
}
let _globalTransaction;
class TransactionImpl {
	constructor(_fn, _getDebugName) {
		this._fn = _fn;
		this._getDebugName = _getDebugName;
		this.updatingObservers = [];
		getLogger()?.handleBeginTransaction(this);
	}
	getDebugName() {
		if (this._getDebugName) {
			return this._getDebugName();
		}
		return getFunctionName(this._fn);
	}
	updateObserver(observer, observable) {
		this.updatingObservers.push({ observer, observable });
		observer.beginUpdate(observable);
	}
	finish() {
		const updatingObservers = this.updatingObservers;
		for (let i = 0; i < updatingObservers.length; i++) {
			const { observer, observable } = updatingObservers[i];
			observer.endUpdate(observable);
		}
		this.updatingObservers = null;
		getLogger()?.handleEndTransaction();
	}
}
class ObservableValue extends BaseObservable {
	get debugName() {
		return this._debugNameData.getDebugName(this) ?? 'ObservableValue';
	}
	constructor(_debugNameData, initialValue, _equalityComparator) {
		super();
		this._debugNameData = _debugNameData;
		this._equalityComparator = _equalityComparator;
		this._value = initialValue;
	}
	get() {
		return this._value;
	}
	set(value, tx, change) {
		if (this._equalityComparator(this._value, value)) {
			return;
		}
		let _tx;
		if (!tx) {
			tx = _tx = new TransactionImpl(dummyArrowFn, () => `Setting ${this.debugName}`);
		}
		try {
			const oldValue = this._value;
			this._setValue(value);
			getLogger()?.handleObservableChanged(this, {
				oldValue,
				newValue: value,
				change,
				didChange: true,
				hadValue: true
			});
			for (const observer of this.observers) {
				tx.updateObserver(observer, this);
				observer.handleChange(this, change);
			}
		} finally {
			if (_tx) {
				_tx.finish();
			}
		}
	}
	toString() {
		return `${this.debugName}: ${this._value}`;
	}
	_setValue(newValue) {
		this._value = newValue;
	}
}
class DisposableObservableValue extends ObservableValue {
	_setValue(newValue) {
		if (this._value === newValue) {
			return;
		}
		if (this._value) {
			this._value.dispose();
		}
		this._value = newValue;
	}
	dispose() {
		this._value?.dispose();
	}
}
function derived(computeFnOrOwner, computeFn) {
	if (computeFn !== undefined) {
		return new Derived(
			new DebugNameData(computeFnOrOwner, undefined, computeFn),
			computeFn,
			undefined,
			undefined,
			undefined,
			strictEquals
		);
	}
	return new Derived(
		new DebugNameData(undefined, undefined, computeFnOrOwner),
		computeFnOrOwner,
		undefined,
		undefined,
		undefined,
		strictEquals
	);
}
function derivedOpts(options2, computeFn) {
	return new Derived(
		new DebugNameData(options2.owner, options2.debugName, options2.debugReferenceFn),
		computeFn,
		undefined,
		undefined,
		options2.onLastObserverRemoved,
		options2.equalsFn ?? strictEquals
	);
}
function derivedHandleChanges(options2, computeFn) {
	return new Derived(
		new DebugNameData(options2.owner, options2.debugName, undefined),
		computeFn,
		options2.createEmptyChangeSummary,
		options2.handleChange,
		undefined,
		options2.equalityComparer ?? strictEquals
	);
}
function derivedWithStore(computeFnOrOwner, computeFnOrUndefined) {
	let computeFn;
	let owner;
	if (computeFnOrUndefined === undefined) {
		computeFn = computeFnOrOwner;
		owner = undefined;
	} else {
		owner = computeFnOrOwner;
		computeFn = computeFnOrUndefined;
	}
	const store = new DisposableStore();
	return new Derived(
		new DebugNameData(owner, undefined, computeFn),
		r => {
			store.clear();
			return computeFn(r, store);
		},
		undefined,
		undefined,
		() => store.dispose(),
		strictEquals
	);
}
function derivedDisposable(computeFnOrOwner, computeFnOrUndefined) {
	let computeFn;
	let owner;
	if (computeFnOrUndefined === undefined) {
		computeFn = computeFnOrOwner;
		owner = undefined;
	} else {
		owner = computeFnOrOwner;
		computeFn = computeFnOrUndefined;
	}
	const store = new DisposableStore();
	return new Derived(
		new DebugNameData(owner, undefined, computeFn),
		r => {
			store.clear();
			const result = computeFn(r);
			if (result) {
				store.add(result);
			}
			return result;
		},
		undefined,
		undefined,
		() => store.dispose(),
		strictEquals
	);
}
_setDerivedOpts(derivedOpts);
class Derived extends BaseObservable {
	get debugName() {
		return this._debugNameData.getDebugName(this) ?? '(anonymous)';
	}
	constructor(
		_debugNameData,
		_computeFn,
		createChangeSummary,
		_handleChange,
		_handleLastObserverRemoved = undefined,
		_equalityComparator
	) {
		super();
		this._debugNameData = _debugNameData;
		this._computeFn = _computeFn;
		this.createChangeSummary = createChangeSummary;
		this._handleChange = _handleChange;
		this._handleLastObserverRemoved = _handleLastObserverRemoved;
		this._equalityComparator = _equalityComparator;
		this.state = 0;
		this.value = undefined;
		this.updateCount = 0;
		this.dependencies = new Set();
		this.dependenciesToBeRemoved = new Set();
		this.changeSummary = undefined;
		this.changeSummary = this.createChangeSummary?.call(this);
		getLogger()?.handleDerivedCreated(this);
	}
	onLastObserverRemoved() {
		this.state = 0;
		this.value = undefined;
		for (const d of this.dependencies) {
			d.removeObserver(this);
		}
		this.dependencies.clear();
		this._handleLastObserverRemoved?.call(this);
	}
	get() {
		if (this.observers.size === 0) {
			const result = this._computeFn(this, this.createChangeSummary?.call(this));
			this.onLastObserverRemoved();
			return result;
		} else {
			do {
				if (this.state === 1) {
					for (const d of this.dependencies) {
						d.reportChanges();
						if (this.state === 2) {
							break;
						}
					}
				}
				if (this.state === 1) {
					this.state = 3;
				}
				this._recomputeIfNeeded();
			} while (this.state !== 3);
			return this.value;
		}
	}
	_recomputeIfNeeded() {
		if (this.state !== 3) {
			const emptySet = this.dependenciesToBeRemoved;
			this.dependenciesToBeRemoved = this.dependencies;
			this.dependencies = emptySet;
			const hadValue = this.state !== 0;
			const oldValue = this.value;
			this.state = 3;
			const changeSummary = this.changeSummary;
			this.changeSummary = this.createChangeSummary?.call(this);
			try {
				this.value = this._computeFn(this, changeSummary);
			} finally {
				for (const o of this.dependenciesToBeRemoved) {
					o.removeObserver(this);
				}
				this.dependenciesToBeRemoved.clear();
			}
			const didChange = hadValue && !this._equalityComparator(oldValue, this.value);
			getLogger()?.handleDerivedRecomputed(this, {
				oldValue,
				newValue: this.value,
				change: undefined,
				didChange,
				hadValue
			});
			if (didChange) {
				for (const r of this.observers) {
					r.handleChange(this, undefined);
				}
			}
		}
	}
	toString() {
		return `LazyDerived<${this.debugName}>`;
	}
	// IObserver Implementation
	beginUpdate(_observable) {
		this.updateCount++;
		const propagateBeginUpdate = this.updateCount === 1;
		if (this.state === 3) {
			this.state = 1;
			if (!propagateBeginUpdate) {
				for (const r of this.observers) {
					r.handlePossibleChange(this);
				}
			}
		}
		if (propagateBeginUpdate) {
			for (const r of this.observers) {
				r.beginUpdate(this);
			}
		}
	}
	endUpdate(_observable) {
		this.updateCount--;
		if (this.updateCount === 0) {
			const observers = [...this.observers];
			for (const r of observers) {
				r.endUpdate(this);
			}
		}
		if (!(this.updateCount >= 0)) {
			onUnexpectedError(new Error(''));
		}
	}
	handlePossibleChange(observable) {
		if (this.state === 3 && this.dependencies.has(observable) && !this.dependenciesToBeRemoved.has(observable)) {
			this.state = 1;
			for (const r of this.observers) {
				r.handlePossibleChange(this);
			}
		}
	}
	handleChange(observable, change) {
		if (this.dependencies.has(observable) && !this.dependenciesToBeRemoved.has(observable)) {
			const shouldReact = this._handleChange
				? this._handleChange(
						{
							changedObservable: observable,
							change,
							didChange: o => o === observable
						},
						this.changeSummary
					)
				: true;
			const wasUpToDate = this.state === 3;
			if (shouldReact && (this.state === 1 || wasUpToDate)) {
				this.state = 2;
				if (wasUpToDate) {
					for (const r of this.observers) {
						r.handlePossibleChange(this);
					}
				}
			}
		}
	}
	// IReader Implementation
	readObservable(observable) {
		observable.addObserver(this);
		const value = observable.get();
		this.dependencies.add(observable);
		this.dependenciesToBeRemoved.delete(observable);
		return value;
	}
	addObserver(observer) {
		const shouldCallBeginUpdate = !this.observers.has(observer) && this.updateCount > 0;
		super.addObserver(observer);
		if (shouldCallBeginUpdate) {
			observer.beginUpdate(this);
		}
	}
	removeObserver(observer) {
		const shouldCallEndUpdate = this.observers.has(observer) && this.updateCount > 0;
		super.removeObserver(observer);
		if (shouldCallEndUpdate) {
			observer.endUpdate(this);
		}
	}
}

class AutorunObserver {
	get debugName() {
		return this._debugNameData.getDebugName(this) ?? '(anonymous)';
	}
	constructor(_debugNameData, _runFn, createChangeSummary, _handleChange) {
		this._debugNameData = _debugNameData;
		this._runFn = _runFn;
		this.createChangeSummary = createChangeSummary;
		this._handleChange = _handleChange;
		this.state = 2;
		this.updateCount = 0;
		this.disposed = false;
		this.dependencies = new Set();
		this.dependenciesToBeRemoved = new Set();
		this.changeSummary = this.createChangeSummary?.call(this);
		getLogger()?.handleAutorunCreated(this);
		this._runIfNeeded();
		trackDisposable(this);
	}
	dispose() {
		this.disposed = true;
		for (const o of this.dependencies) {
			o.removeObserver(this);
		}
		this.dependencies.clear();
		markAsDisposed(this);
	}
	_runIfNeeded() {
		if (this.state === 3) {
			return;
		}
		const emptySet = this.dependenciesToBeRemoved;
		this.dependenciesToBeRemoved = this.dependencies;
		this.dependencies = emptySet;
		this.state = 3;
		const isDisposed = this.disposed;
		try {
			if (!isDisposed) {
				getLogger()?.handleAutorunTriggered(this);
				const changeSummary = this.changeSummary;
				this.changeSummary = this.createChangeSummary?.call(this);
				this._runFn(this, changeSummary);
			}
		} finally {
			if (!isDisposed) {
				getLogger()?.handleAutorunFinished(this);
			}
			for (const o of this.dependenciesToBeRemoved) {
				o.removeObserver(this);
			}
			this.dependenciesToBeRemoved.clear();
		}
	}
	toString() {
		return `Autorun<${this.debugName}>`;
	}
	// IObserver implementation
	beginUpdate() {
		if (this.state === 3) {
			this.state = 1;
		}
		this.updateCount++;
	}
	endUpdate() {
		if (this.updateCount === 1) {
			do {
				if (this.state === 1) {
					this.state = 3;
					for (const d of this.dependencies) {
						d.reportChanges();
						if (this.state === 2) {
							break;
						}
					}
				}
				this._runIfNeeded();
			} while (this.state !== 3);
		}
		this.updateCount--;
		if (!(this.updateCount >= 0)) {
			onUnexpectedError(new Error(''));
		}
	}
	handlePossibleChange(observable) {
		if (this.state === 3 && this.dependencies.has(observable) && !this.dependenciesToBeRemoved.has(observable)) {
			this.state = 1;
		}
	}
	handleChange(observable, change) {
		if (this.dependencies.has(observable) && !this.dependenciesToBeRemoved.has(observable)) {
			const shouldReact = this._handleChange
				? this._handleChange(
						{
							changedObservable: observable,
							change,
							didChange: o => o === observable
						},
						this.changeSummary
					)
				: true;
			if (shouldReact) {
				this.state = 2;
			}
		}
	}
	// IReader implementation
	readObservable(observable) {
		if (this.disposed) {
			return observable.get();
		}
		observable.addObserver(this);
		const value = observable.get();
		this.dependencies.add(observable);
		this.dependenciesToBeRemoved.delete(observable);
		return value;
	}
}

function autorun(fn) {
	return new AutorunObserver(new DebugNameData(undefined, undefined, fn), fn, undefined, undefined);
}
autorun.Observer = AutorunObserver;

function autorunOpts(options2, fn) {
	return new AutorunObserver(
		new DebugNameData(options2.owner, options2.debugName, options2.debugReferenceFn ?? fn),
		fn,
		undefined,
		undefined
	);
}
function autorunHandleChanges(options2, fn) {
	return new AutorunObserver(
		new DebugNameData(options2.owner, options2.debugName, options2.debugReferenceFn ?? fn),
		fn,
		options2.createEmptyChangeSummary,
		options2.handleChange
	);
}
function autorunWithStore(fn) {
	const store = new DisposableStore();
	const disposable = autorunOpts(
		{
			owner: undefined,
			debugName: undefined,
			debugReferenceFn: fn
		},
		reader => {
			store.clear();
			fn(reader, store);
		}
	);
	return toDisposable(() => {
		disposable.dispose();
		store.dispose();
	});
}

function constObservable(value) {
	return new ConstObservable(value);
}
function observableFromEvent(event, getValue) {
	return new FromEventObservable(event, getValue);
}
function observableSignalFromEvent(debugName, event) {
	return new FromEventObservableSignal(debugName, event);
}
function observableSignal(debugNameOrOwner) {
	if (typeof debugNameOrOwner === 'string') {
		return new ObservableSignal(debugNameOrOwner);
	} else {
		return new ObservableSignal(undefined, debugNameOrOwner);
	}
}
function keepObserved(observable) {
	const o = new KeepAliveObserver(false, undefined);
	observable.addObserver(o);
	return toDisposable(() => {
		observable.removeObserver(o);
	});
}
function recomputeInitiallyAndOnChange(observable, handleValue) {
	const o = new KeepAliveObserver(true, handleValue);
	observable.addObserver(o);
	if (handleValue) {
		handleValue(observable.get());
	} else {
		observable.reportChanges();
	}
	return toDisposable(() => {
		observable.removeObserver(o);
	});
}
function mapObservableArrayCached(owner, items, map, keySelector) {
	let m = new ArrayMap(map, keySelector);
	const self2 = derivedOpts(
		{
			debugReferenceFn: map,
			owner,
			onLastObserverRemoved: () => {
				m.dispose();
				m = new ArrayMap(map);
			}
		},
		reader => {
			m.setItems(items.read(reader));
			return m.getItems();
		}
	);
	return self2;
}

class ConstObservable extends ConvenientObservable {
	constructor(value) {
		super();
		this.value = value;
	}
	get debugName() {
		return this.toString();
	}
	get() {
		return this.value;
	}
	addObserver(observer) {}
	removeObserver(observer) {}
	toString() {
		return `Const: ${this.value}`;
	}
}
class FromEventObservable extends BaseObservable {
	constructor(event, _getValue) {
		super();
		this.event = event;
		this._getValue = _getValue;
		this.hasValue = false;
		this.handleEvent = args => {
			const newValue = this._getValue(args);
			const oldValue = this.value;
			const didChange = !this.hasValue || oldValue !== newValue;
			let didRunTransaction = false;
			if (didChange) {
				this.value = newValue;
				if (this.hasValue) {
					didRunTransaction = true;
					subtransaction(
						FromEventObservable.globalTransaction,
						tx => {
							getLogger()?.handleFromEventObservableTriggered(this, {
								oldValue,
								newValue,
								change: undefined,
								didChange,
								hadValue: this.hasValue
							});
							for (const o of this.observers) {
								tx.updateObserver(o, this);
								o.handleChange(this, undefined);
							}
						},
						() => {
							const name = this.getDebugName();
							return 'Event fired' + (name ? `: ${name}` : '');
						}
					);
				}
				this.hasValue = true;
			}
			if (!didRunTransaction) {
				getLogger()?.handleFromEventObservableTriggered(this, {
					oldValue,
					newValue,
					change: undefined,
					didChange,
					hadValue: this.hasValue
				});
			}
		};
	}
	getDebugName() {
		return getFunctionName(this._getValue);
	}
	get debugName() {
		const name = this.getDebugName();
		return 'From Event' + (name ? `: ${name}` : '');
	}
	onFirstObserverAdded() {
		this.subscription = this.event(this.handleEvent);
	}
	onLastObserverRemoved() {
		this.subscription.dispose();
		this.subscription = undefined;
		this.hasValue = false;
		this.value = undefined;
	}
	get() {
		if (this.subscription) {
			if (!this.hasValue) {
				this.handleEvent(undefined);
			}
			return this.value;
		} else {
			const value = this._getValue(undefined);
			return value;
		}
	}
}
const batchObsEventsGlobally = (tx, fn) => {
	let didSet = false;
	if (FromEventObservable.globalTransaction === undefined) {
		FromEventObservable.globalTransaction = tx;
		didSet = true;
	}
	try {
		fn();
	} finally {
		if (didSet) {
			FromEventObservable.globalTransaction = undefined;
		}
	}
};

class FromEventObservableSignal extends BaseObservable {
	constructor(debugName, event) {
		super();
		this.debugName = debugName;
		this.event = event;
		this.handleEvent = () => {
			transaction(
				tx => {
					for (const o of this.observers) {
						tx.updateObserver(o, this);
						o.handleChange(this, undefined);
					}
				},
				() => this.debugName
			);
		};
	}
	onFirstObserverAdded() {
		this.subscription = this.event(this.handleEvent);
	}
	onLastObserverRemoved() {
		this.subscription.dispose();
		this.subscription = undefined;
	}
	get() {}
}
class ObservableSignal extends BaseObservable {
	get debugName() {
		return new DebugNameData(this._owner, this._debugName, undefined).getDebugName(this) ?? 'Observable Signal';
	}
	constructor(_debugName, _owner) {
		super();
		this._debugName = _debugName;
		this._owner = _owner;
	}
	trigger(tx, change) {
		if (!tx) {
			transaction(
				tx2 => {
					this.trigger(tx2, change);
				},
				() => `Trigger signal ${this.debugName}`
			);
			return;
		}
		for (const o of this.observers) {
			tx.updateObserver(o, this);
			o.handleChange(this, change);
		}
	}
	get() {}
}
_setKeepObserved(keepObserved);
_setRecomputeInitiallyAndOnChange(recomputeInitiallyAndOnChange);
class KeepAliveObserver {
	constructor(_forceRecompute, _handleValue) {
		this._forceRecompute = _forceRecompute;
		this._handleValue = _handleValue;
		this._counter = 0;
	}
	beginUpdate(observable) {
		this._counter++;
	}
	endUpdate(observable) {
		this._counter--;
		if (this._counter === 0 && this._forceRecompute) {
			if (this._handleValue) {
				this._handleValue(observable.get());
			} else {
				observable.reportChanges();
			}
		}
	}
	handlePossibleChange(observable) {}
	handleChange(observable, change) {}
}
class ArrayMap {
	constructor(_map, _keySelector) {
		this._map = _map;
		this._keySelector = _keySelector;
		this._cache = new Map();
		this._items = [];
	}
	dispose() {
		this._cache.forEach(entry => entry.store.dispose());
		this._cache.clear();
	}
	setItems(items) {
		const newItems = [];
		const itemsToRemove = new Set(this._cache.keys());
		for (const item of items) {
			const key = this._keySelector ? this._keySelector(item) : item;
			let entry = this._cache.get(key);
			if (!entry) {
				const store = new DisposableStore();
				const out = this._map(item, store);
				entry = { out, store };
				this._cache.set(key, entry);
			} else {
				itemsToRemove.delete(key);
			}
			newItems.push(entry.out);
		}
		for (const item of itemsToRemove) {
			const entry = this._cache.get(item);
			entry.store.dispose();
			this._cache.delete(item);
		}
		this._items = newItems;
	}
	getItems() {
		return this._items;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -






function getDebugName(target, data) {
	const cached = cachedDebugName.get(target);
	if (cached) {
		return cached;
	}
	const dbgName = computeDebugName(target, data);
	if (dbgName) {
		let count = countPerName.get(dbgName) ?? 0;
		count++;
		countPerName.set(dbgName, count);
		const result = count === 1 ? dbgName : `${dbgName}#${count}`;
		cachedDebugName.set(target, result);
		return result;
	}
	return;
}
function computeDebugName(self2, data) {
	const cached = cachedDebugName.get(self2);
	if (cached) {
		return cached;
	}
	const ownerStr = data.owner ? formatOwner(data.owner) + `.` : '';
	let result;
	const debugNameSource = data.debugNameSource;
	if (debugNameSource !== undefined) {
		if (typeof debugNameSource === 'function') {
			result = debugNameSource();
			if (result !== undefined) {
				return ownerStr + result;
			}
		} else {
			return ownerStr + debugNameSource;
		}
	}
	const referenceFn = data.referenceFn;
	if (referenceFn !== undefined) {
		result = getFunctionName(referenceFn);
		if (result !== undefined) {
			return ownerStr + result;
		}
	}
	if (data.owner !== undefined) {
		const key = findKey(data.owner, self2);
		if (key !== undefined) {
			return ownerStr + key;
		}
	}
	return;
}
function findKey(obj, value) {
	for (const key in obj) {
		if (obj[key] === value) {
			return key;
		}
	}
	return;
}

function formatOwner(owner) {
	const id = ownerId.get(owner);
	if (id) {
		return id;
	}
	const className = getClassName(owner);
	let count = countPerClassName.get(className) ?? 0;
	count++;
	countPerClassName.set(className, count);
	const result = count === 1 ? className : `${className}#${count}`;
	ownerId.set(owner, result);
	return result;
}

function getClassName(obj) {
	const ctor = obj.constructor;
	if (ctor) {
		return ctor.name;
	}
	return 'Object';
}

function getFunctionName(fn) {
	const fnSrc = fn.toString();
	const regexp = /\/\*\*\s*@description\s*([^*]*)\*\//;
	const match2 = regexp.exec(fnSrc);
	const result = match2 ? match2[1] : undefined;
	return result?.trim();
}
class DebugNameData {
	constructor(owner, debugNameSource, referenceFn) {
		this.owner = owner;
		this.debugNameSource = debugNameSource;
		this.referenceFn = referenceFn;
	}
	getDebugName(target) {
		return getDebugName(target, this);
	}
}
const countPerName = new Map();
const cachedDebugName = new WeakMap();
const countPerClassName = new Map();
const ownerId = new WeakMap();

function setLogger(logger) {
	globalObservableLogger = logger;
}
function getLogger() {
	return globalObservableLogger;
}
function consoleTextToArgs(text2) {
	const styles = new Array();
	const data = [];
	let firstArg = '';
	function process2(t) {
		if ('length' in t) {
			for (const item of t) {
				if (item) {
					process2(item);
				}
			}
		} else if ('text' in t) {
			firstArg += `%c${t.text}`;
			styles.push(t.style);
			if (t.data) {
				data.push(...t.data);
			}
		} else if ('data' in t) {
			data.push(...t.data);
		}
	}
	process2(text2);
	const result = [firstArg, ...styles];
	result.push(...data);
	return result;
}
function normalText(text2) {
	return styled(text2, { color: 'black' });
}
function formatKind(kind) {
	return styled(padStr(`${kind}: `, 10), { color: 'black', bold: true });
}
function styled(
	text2,
	options2 = {
		color: 'black'
	}
) {
	function objToCss(styleObj) {
		return entries(styleObj).reduce((styleString, [propName, propValue]) => {
			return `${styleString}${propName}:${propValue};`;
		}, '');
	}
	const style = {
		color: options2.color
	};
	if (options2.strikeThrough) {
		style['text-decoration'] = 'line-through';
	}
	if (options2.bold) {
		style['font-weight'] = 'bold';
	}
	return {
		text: text2,
		style: objToCss(style)
	};
}
function formatValue(value, availableLen) {
	switch (typeof value) {
		case 'number':
			return '' + value;
		case 'string':
			if (value.length + 2 <= availableLen) {
				return `"${value}"`;
			}
			return `"${value.substr(0, availableLen - 7)}"+...`;
		case 'boolean':
			return value ? 'true' : 'false';
		case 'undefined':
			return 'undefined';
		case 'object':
			if (value === null) {
				return 'null';
			}
			if (isArray(value)) {
				return formatArray(value, availableLen);
			}
			return formatObject(value, availableLen);
		case 'symbol':
			return value.toString();
		case 'function':
			return `[[Function${value.name ? ' ' + value.name : ''}]]`;
		default:
			return '' + value;
	}
}
function formatArray(value, availableLen) {
	let result = '[ ';
	let first2 = true;
	for (const val of value) {
		if (!first2) {
			result += ', ';
		}
		if (result.length - 5 > availableLen) {
			result += '...';
			break;
		}
		first2 = false;
		result += `${formatValue(val, availableLen - result.length)}`;
	}
	result += ' ]';
	return result;
}
function formatObject(value, availableLen) {
	let result = '{ ';
	let first2 = true;
	for (const [key, val] of entries(value)) {
		if (!first2) {
			result += ', ';
		}
		if (result.length - 5 > availableLen) {
			result += '...';
			break;
		}
		first2 = false;
		result += `${key}: ${formatValue(val, availableLen - result.length)}`;
	}
	result += ' }';
	return result;
}
function repeat(str, count) {
	let result = '';
	for (let i = 1; i <= count; i++) {
		result += str;
	}
	return result;
}
function padStr(str, length) {
	while (str.length < length) {
		str += ' ';
	}
	return str;
}

let globalObservableLogger;

class ConsoleObservableLogger {
	constructor() {
		this.indentation = 0;
		this.changedObservablesSets = new WeakMap();
	}
	textToConsoleArgs(text2) {
		return consoleTextToArgs([normalText(repeat('|  ', this.indentation)), text2]);
	}
	formatInfo(info) {
		if (!info.hadValue) {
			return [
				normalText(` `),
				styled(formatValue(info.newValue, 60), {
					color: 'green'
				}),
				normalText(` (initial)`)
			];
		}
		return info.didChange
			? [
					normalText(` `),
					styled(formatValue(info.oldValue, 70), {
						color: 'red',
						strikeThrough: true
					}),
					normalText(` `),
					styled(formatValue(info.newValue, 60), {
						color: 'green'
					})
				]
			: [normalText(` (unchanged)`)];
	}
	handleObservableChanged(observable, info) {
		console.log(
			...this.textToConsoleArgs([
				formatKind('observable value changed'),
				styled(observable.debugName, { color: 'BlueViolet' }),
				...this.formatInfo(info)
			])
		);
	}
	formatChanges(changes) {
		if (changes.size === 0) {
			return;
		}
		return styled(' (changed deps: ' + [...changes].map(o => o.debugName).join(', ') + ')', {
			color: 'gray'
		});
	}
	handleDerivedCreated(derived2) {
		const existingHandleChange = derived2.handleChange;
		this.changedObservablesSets.set(derived2, new Set());
		derived2.handleChange = (observable, change) => {
			this.changedObservablesSets.get(derived2).add(observable);
			return existingHandleChange.apply(derived2, [observable, change]);
		};
	}
	handleDerivedRecomputed(derived2, info) {
		const changedObservables = this.changedObservablesSets.get(derived2);
		console.log(
			...this.textToConsoleArgs([
				formatKind('derived recomputed'),
				styled(derived2.debugName, { color: 'BlueViolet' }),
				...this.formatInfo(info),
				this.formatChanges(changedObservables),
				{ data: [{ fn: derived2._computeFn }] }
			])
		);
		changedObservables.clear();
	}
	handleFromEventObservableTriggered(observable, info) {
		console.log(
			...this.textToConsoleArgs([
				formatKind('observable from event triggered'),
				styled(observable.debugName, { color: 'BlueViolet' }),
				...this.formatInfo(info),
				{ data: [{ fn: observable._getValue }] }
			])
		);
	}
	handleAutorunCreated(autorun2) {
		const existingHandleChange = autorun2.handleChange;
		this.changedObservablesSets.set(autorun2, new Set());
		autorun2.handleChange = (observable, change) => {
			this.changedObservablesSets.get(autorun2).add(observable);
			return existingHandleChange.apply(autorun2, [observable, change]);
		};
	}
	handleAutorunTriggered(autorun2) {
		const changedObservables = this.changedObservablesSets.get(autorun2);
		console.log(
			...this.textToConsoleArgs([
				formatKind('autorun'),
				styled(autorun2.debugName, { color: 'BlueViolet' }),
				this.formatChanges(changedObservables),
				{ data: [{ fn: autorun2._runFn }] }
			])
		);
		changedObservables.clear();
		this.indentation++;
	}
	handleAutorunFinished(autorun2) {
		this.indentation--;
	}
	handleBeginTransaction(transaction2) {
		let transactionName = transaction2.getDebugName();
		if (transactionName === undefined) {
			transactionName = '';
		}
		console.log(
			...this.textToConsoleArgs([
				formatKind('transaction'),
				styled(transactionName, { color: 'BlueViolet' }),
				{ data: [{ fn: transaction2._fn }] }
			])
		);
		this.indentation++;
	}
	handleEndTransaction() {
		this.indentation--;
	}
}




function waitForState(observable, predicate, isError, cancellationToken) {
	if (!predicate) {
		predicate = state => state !== null && state !== undefined;
	}
	return new Promise((resolve2, reject) => {
		let isImmediateRun = true;
		let shouldDispose = false;
		const stateObs = observable.map(state => {
			return {
				isFinished: predicate(state),
				error: isError ? isError(state) : false,
				state
			};
		});
		const d = autorun(reader => {
			const { isFinished, error, state } = stateObs.read(reader);
			if (isFinished || error) {
				if (isImmediateRun) {
					shouldDispose = true;
				} else {
					d.dispose();
				}
				if (error) {
					reject(error === true ? state : error);
				} else {
					resolve2(state);
				}
			}
		});
		if (cancellationToken) {
			const dc = cancellationToken.onCancellationRequested(() => {
				d.dispose();
				dc.dispose();
				reject(new CancellationError());
			});
			if (cancellationToken.isCancellationRequested) {
				d.dispose();
				dc.dispose();
				reject(new CancellationError());
				return;
			}
		}
		isImmediateRun = false;
		if (shouldDispose) {
			d.dispose();
		}
	});
}




let enableLogging = false;
if (enableLogging) {
	setLogger(new ConsoleObservableLogger());
}