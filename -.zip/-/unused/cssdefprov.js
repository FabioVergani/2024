	class DefinitionAdapter {
	constructor(_worker) {
		this._worker = _worker;
	}
	provideDefinition(model, position, token) {
		const resource = model.uri;
		return this._worker(resource)
			.then(worker => {
				return worker.findDefinition(resource.toString(), fromPosition0(position));
			})
			.then(e => {
				if (e) {
					return [
						{
							uri: Uri.parse(e.uri),
							range: toRange0(e.range) //
						}
					];
				}
			});
	}
}



if (modeConfiguration.definitions) {
		const registerDefinitionProvider = (languageSelector, provider) => {
			return getService_LanguageFeatures().definitionProvider.register(languageSelector, provider);
		};
		providers.push(registerDefinitionProvider(languageId, new DefinitionAdapter(wk)));
	}