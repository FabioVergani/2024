class CountBadge {
	constructor(container, options2, styles) {
		this.options = options2;
		this.styles = styles;
		this.count = 0;
		this.element = append(container, createDomElement('.monaco-count-badge'));
		this.countFormat = this.options.countFormat || '{0}';
		this.titleFormat = this.options.titleFormat || '';
		this.setCount(this.options.count || 0);
	}
	setCount(count) {
		this.count = count;
		this.render();
	}
	setTitleFormat(titleFormat) {
		this.titleFormat = titleFormat;
		this.render();
	}
	render() {
		this.element.textContent = interpolateDigitsPlaceholders(this.countFormat, this.count);
		this.element.title = interpolateDigitsPlaceholders(this.titleFormat, this.count);
		this.element.style.backgroundColor = this.styles.badgeBackground || '';
		this.element.style.color = this.styles.badgeForeground || '';
		if (this.styles.badgeBorder) {
			this.element.style.border = `1px solid ${this.styles.badgeBorder}`;
		}
	}
}
