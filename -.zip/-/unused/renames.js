







// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


class StandaloneBulkEditService {
	constructor(_modelService) {
		this._modelService = _modelService;
	}
	hasPreviewHandler() {
		return false;
	}
	async apply(editsIn, _options) {
		const edits = isArray(editsIn) ? editsIn : ResourceEdit.convert(editsIn);
		const textEdits = new Map();
		for (const edit of edits) {
			if (!(edit instanceof ResourceTextEdit)) {
				throw new Error('bad edit - only text edits are supported');
			}
			const model = this._modelService.getModel(edit.resource);
			if (!model) {
				throw new Error('bad edit - model not found');
			}
			if (typeof edit.versionId === 'number' && model.getVersionId() !== edit.versionId) {
				throw new Error('bad state - model changed in the meantime');
			}
			let array2 = textEdits.get(model);
			if (!array2) {
				array2 = [];
				textEdits.set(model, array2);
			}
			array2.push(EditOperation.replaceMove(Range.lift(edit.textEdit.range), edit.textEdit.text));
		}
		let totalEdits = 0;
		let totalFiles = 0;
		for (const [model, edits2] of textEdits) {
			model.pushStackElement();
			model.pushEditOperations([], edits2, () => []);
			model.pushStackElement();
			totalFiles += 1;
			totalEdits += edits2.length;
		}
		return {
			isApplied: totalEdits > 0
		};
	}
}
__decorate([__param(0, IModelService)], StandaloneBulkEditService);
registerSingleton(
	IBulkEditService,
	StandaloneBulkEditService,
	0 //Eager
);






	renameOnType: registerEditorOption(
		new EditorBooleanOption(93, 'renameOnType', false, {
			markdownDeprecationMessage: localize('Deprecated, use `editor.linkedEditing` instead.')
		})
	),

	registerColor(
		'editor.linkedEditingBackground',
		{
			dark: Color.fromHex('#f00').transparent(0.3),
			light: Color.fromHex('#f00').transparent(0.3),
			hcDark: Color.fromHex('#f00').transparent(0.3),
			hcLight: colorWhite
		},
		localize('Background color when the editor auto renames on type.')
	);

const ck_editorHasProvider_rename = new RawContextKey(
	'editorHasRenameProvider',
	false,
	localize('Whether the editor has a rename provider')
);

	this._register(_languageFeaturesService.renameProvider.onDidChange(update));

this._hasRenameProvider.set(this._languageFeaturesService.renameProvider.has(model));

this.renameProvider = new LanguageFeatureRegistry(this._score.bind(this));

const registerRenameProvider = (languageSelector, provider) => {
	return getService_LanguageFeatures().renameProvider.register(languageSelector, provider);
};

class RenameAdapter {
	constructor(_worker) {
		this._worker = _worker;
	}
	provideRenameEdits(model, position, newName, token) {
		const resource = model.uri;
		return this._worker(resource)
			.then(worker2 => {
				return worker2.doRename(resource.toString(), fromPosition0(position), newName);
			})
			.then(edit => {
				if (!edit || !edit.changes) {
					return;
				}
				let resourceEdits = [];
				for (let uri in edit.changes) {
					const _uri = Uri.parse(uri);
					for (let e of edit.changes[uri]) {
						resourceEdits.push({
							resource: _uri,
							versionId: undefined,
							textEdit: { range: toRange0(e.range), text: e.newText }
						});
					}
				}
				return { edits: resourceEdits };
			});
	}
}



class RenameAdapterJS extends AdapterJS {
	constructor(worker2) {
		super(worker2);
	}
	async provideRenameEdits(model, position, newName, token) {
		const resource = model.uri;
		const fileName = resource.toString();
		const offset = model.getOffsetAt(position);
		const worker2 = await this._worker(resource);
		if (model.isDisposed()) {
			return;
		}
		const renameInfo = await worker2.getRenameInfo(fileName, offset, {
			allowRenameOfImportPath: false
		});
		if (renameInfo.canRename === false) {
			return {
				edits: [],
				rejectReason: renameInfo.localizedErrorMessage
			};
		}
		if (renameInfo.fileToRename !== undefined) {
			throw new Error('Renaming files is not supported.');
		}
		const renameLocations = await worker2.findRenameLocations(
			fileName,
			offset,
			false, //strings
			false, //comments
			false //prefixAndSuffix
		);
		if (!renameLocations || model.isDisposed()) {
			return;
		}
		const edits = [];

		return { edits };
	}
}


	if (modeConfiguration.rename) {
		providers.push(registerRenameProvider(languageId, new RenameAdapter(wk)));
	}


const ck_renameInputVisible = new RawContextKey('renameInputVisible', false);

class RenameCandidateView {
	constructor(parent, fontInfo) {
		this._domNode = document.createElement('div');
		this._domNode.className = 'rename-box rename-candidate';
		this._domNode.style.display = `flex`;
		this._domNode.style.columnGap = `5px`;
		this._domNode.style.alignItems = `center`;
		this._domNode.style.height = `${fontInfo.lineHeight}px`;
		this._domNode.style.padding = `2px`;
		const iconContainer = document.createElement('div');
		iconContainer.style.display = `flex`;
		iconContainer.style.alignItems = `center`;
		iconContainer.style.width = iconContainer.style.height = `${fontInfo.lineHeight * 0.8}px`;
		this._domNode.appendChild(iconContainer);
		this._icon = renderIcon(codicon_sparkle);
		this._icon.style.display = `none`;
		iconContainer.appendChild(this._icon);
		this._label = document.createElement('div');
		applyFontInfo(this._label, fontInfo);
		this._domNode.appendChild(this._label);
		parent.appendChild(this._domNode);
	}
	populate(value) {
		this._updateIcon(value);
		this._updateLabel(value);
	}
	_updateIcon(value) {
		this._icon.style.display = value.tags?.includes(
			1 //AIGenerated
		)
			? 'inherit'
			: 'none';
	}
	_updateLabel(value) {
		this._label.innerText = value.newSymbolName;
	}
	static getLayoutInfo({ lineHeight }) {
		const totalHeight = lineHeight + 4;
		return { totalHeight };
	}
	dispose() {}
}

class CandidateRenderer {
	constructor() {
		this.templateId = 'candidate';
	}
	renderTemplate(container2) {
		return new RenameCandidateView(container2, fontInfo);
	}
	renderElement(candidate, index, templateData) {
		templateData.populate(candidate);
	}
	disposeTemplate(templateData) {
		templateData.dispose();
	}
}

class RenameCandidateListView {
	constructor(parent, opts) {
		this._disposables = new DisposableStore();
		this._availableHeight = 0;
		this._minimumWidth = 0;
		this._lineHeight = opts.fontInfo.lineHeight;
		this._typicalHalfwidthCharacterWidth = opts.fontInfo.typicalHalfwidthCharacterWidth;
		this._listContainer = document.createElement('div');
		this._listContainer.className = 'rename-box rename-candidate-list-container';
		parent.appendChild(this._listContainer);
		this._listWidget = RenameCandidateListView._createListWidget(this._listContainer, this._candidateViewHeight, opts.fontInfo);
		this._listWidget.onDidChangeFocus(e => {
			if (e.elements.length === 1) {
				opts.onFocusChange(e.elements[0].newSymbolName);
			}
		}, this._disposables);
		this._listWidget.onDidChangeSelection(e => {
			if (e.elements.length === 1) {
				opts.onSelectionChange();
			}
		}, this._disposables);
		this._disposables.add(
			this._listWidget.onDidBlur(() => {
				this._listWidget.setFocus([]);
			})
		);
		this._listWidget.style(
			getListStyles({
				listInactiveFocusForeground: colorId_quickInputListFocus_foreground,
				listInactiveFocusBackground: colorId_quickInputListFocus_background
			})
		);
	}
	dispose() {
		this._listWidget.dispose();
		this._disposables.dispose();
	}
	// height - max height allowed by parent element
	layout({ height, width: width2 }) {
		this._availableHeight = height;
		this._minimumWidth = width2;
	}
	setCandidates(candidates) {
		this._listWidget.splice(0, 0, candidates);
		const height = this._pickListHeight(this._listWidget.length);
		const width2 = this._pickListWidth(candidates);
		this._listWidget.layout(height, width2);
		this._listContainer.style.height = `${height}px`;
		this._listContainer.style.width = `${width2}px`;
	}
	clearCandidates() {
		this._listContainer.style.height = '0px';
		this._listContainer.style.width = '0px';
		this._listWidget.splice(0, this._listWidget.length, []);
	}
	get nCandidates() {
		return this._listWidget.length;
	}
	get focusedCandidate() {
		if (this._listWidget.length === 0) {
			return;
		}
		const selectedElement = this._listWidget.getSelectedElements()[0];
		if (selectedElement !== undefined) {
			return selectedElement.newSymbolName;
		}
		const focusedElement = this._listWidget.getFocusedElements()[0];
		if (focusedElement !== undefined) {
			return focusedElement.newSymbolName;
		}
	}
	focusNext() {
		if (this._listWidget.length === 0) {
			return false;
		}
		const focusedIxs = this._listWidget.getFocus();
		if (focusedIxs.length === 0) {
			this._listWidget.focusFirst();
			this._listWidget.reveal(0);
			return true;
		} else {
			if (focusedIxs[0] === this._listWidget.length - 1) {
				this._listWidget.setFocus([]);
				this._listWidget.reveal(0);
				return false;
			} else {
				this._listWidget.focusNext();
				const focused = this._listWidget.getFocus()[0];
				this._listWidget.reveal(focused);
				return true;
			}
		}
	}
	focusPrevious() {
		if (this._listWidget.length === 0) {
			return false;
		}
		const focusedIxs = this._listWidget.getFocus();
		if (focusedIxs.length === 0) {
			this._listWidget.focusLast();
			const focused = this._listWidget.getFocus()[0];
			this._listWidget.reveal(focused);
			return true;
		} else {
			if (focusedIxs[0] === 0) {
				this._listWidget.setFocus([]);
				return false;
			} else {
				this._listWidget.focusPrevious();
				const focused = this._listWidget.getFocus()[0];
				this._listWidget.reveal(focused);
				return true;
			}
		}
	}
	clearFocus() {
		this._listWidget.setFocus([]);
	}
	get _candidateViewHeight() {
		const { totalHeight } = RenameCandidateView.getLayoutInfo({
			lineHeight: this._lineHeight
		});
		return totalHeight;
	}
	_pickListHeight(nCandidates) {
		const heightToFitAllCandidates = this._candidateViewHeight * nCandidates;
		const MAX_N_CANDIDATES = 7;
		return Math.min(heightToFitAllCandidates, this._availableHeight, this._candidateViewHeight * MAX_N_CANDIDATES);
	}
	_pickListWidth(candidates) {
		const longestCandidateWidth = Math.ceil(
			Math.max(...candidates.map(c => c.newSymbolName.length)) * this._typicalHalfwidthCharacterWidth
		);
		return Math.max(
			this._minimumWidth,
			4 + 16 + 5 + longestCandidateWidth + 10 //(possibly visible) scrollbar width
		);
	}
	static _createListWidget(container, candidateViewHeight, fontInfo) {
		class VirtualDelegate {
			getTemplateId() {
				return 'candidate';
			}
			getHeight() {
				return candidateViewHeight;
			}
		}
		const virtualDelegate = new VirtualDelegate();
		const renderer = new CandidateRenderer();
		return new List('NewSymbolNameCandidates', container, virtualDelegate, [renderer], {
			keyboardSupport: false,
			// @ulugbekna: because we handle keyboard events through proper commands & keybinding service, see `rename.ts`
			mouseSupport: true,
			multipleSelectionSupport: false
		});
	}
}

class InputWithButton {
	constructor() {
		this._onDidInputChange = new Emitter();
		this.onDidInputChange = this._onDidInputChange.event;
		this._disposables = new DisposableStore();
	}
	get domNode() {
		if (!this._domNode) {
			this._domNode = document.createElement('div');
			this._domNode.className = 'rename-input-with-button';
			this._domNode.style.display = 'flex';
			this._domNode.style.flexDirection = 'row';
			this._domNode.style.alignItems = 'center';
			this._inputNode = document.createElement('input');
			this._inputNode.className = 'rename-input';
			this._inputNode.type = 'text';
			this._inputNode.style.border = 'none';
			this._domNode.appendChild(this._inputNode);
			this._buttonNode = document.createElement('div');
			this._buttonNode.className = 'rename-suggestions-button';
			this._buttonNode.setAttribute('tabindex', '0');
			this._buttonGenHoverText = localize('Generate new name suggestions');
			this._buttonCancelHoverText = localize('Cancel');
			this._buttonHover = getBaseLayerHoverDelegate().setupUpdatableHover(
				getDefaultHoverDelegate('element'),
				this._buttonNode,
				this._buttonGenHoverText
			);
			this._disposables.add(this._buttonHover);
			this._domNode.appendChild(this._buttonNode);
			this._disposables.add(addDisposableListener(this.input, EventType.INPUT, () => this._onDidInputChange.fire()));
			this._disposables.add(
				addDisposableListener(this.input, EventType.KEY_DOWN, e => {
					const keyEvent = new StandardKeyboardEvent(e);
					if (keyEvent.keyCode === 15 || keyEvent.keyCode === 17) {
						this._onDidInputChange.fire();
					}
				})
			);
			this._disposables.add(addDisposableListener(this.input, EventType.CLICK, () => this._onDidInputChange.fire()));
			this._disposables.add(
				addDisposableListener(this.input, EventType.FOCUS, () => {
					this.domNode.style.outlineWidth = '1px';
					this.domNode.style.outlineStyle = 'solid';
					this.domNode.style.outlineOffset = '-1px';
					this.domNode.style.outlineColor = 'var(--vscode-focusBorder)';
				})
			);
			this._disposables.add(
				addDisposableListener(this.input, EventType.BLUR, () => {
					this.domNode.style.outline = 'none';
				})
			);
		}
		return this._domNode;
	}
	get input() {
		return this._inputNode;
	}
	get button() {
		return this._buttonNode;
	}
	get buttonState() {
		return this._buttonState;
	}
	setSparkleButton() {
		this._buttonState = 'sparkle';
		this._sparkleIcon ||= renderIcon(codicon_sparkle);
		clearNode(this.button);
		this.button.appendChild(this._sparkleIcon);
		this._buttonHover?.update(this._buttonGenHoverText);
		this.input.focus();
	}
	setStopButton() {
		this._buttonState = 'stop';
		this._stopIcon ||= renderIcon(codicon_primitiveSquare);
		clearNode(this.button);
		this.button.appendChild(this._stopIcon);
		this._buttonHover?.update(this._buttonCancelHoverText);
		this.input.focus();
	}
	dispose() {
		this._disposables.dispose();
	}
}

class RenameWidget {
	constructor(_editor, _acceptKeybindings, _themeService, _keybindingService, contextKeyService) {
		this._editor = _editor;
		this._acceptKeybindings = _acceptKeybindings;
		this._themeService = _themeService;
		this._keybindingService = _keybindingService;
		this.allowEditorOverflow = true;
		this._disposables = new DisposableStore();
		this._visibleContextKey = ck_renameInputVisible.bindTo(contextKeyService);
		this._isEditingRenameCandidate = false;
		this._nRenameSuggestionsInvocations = 0;
		this._hadAutomaticRenameSuggestionsInvocation = false;
		this._candidates = new Set();
		this._beforeFirstInputFieldEditSW = new StopWatch();
		this._inputWithButton = new InputWithButton();
		this._disposables.add(this._inputWithButton);
		this._editor.addContentWidget(this);
		this._disposables.add(
			this._editor.onDidChangeConfiguration(e => {
				if (
					e.hasChanged(
						50 // fontInfo
					)
				) {
					this._updateFont();
				}
			})
		);
		this._disposables.add(_themeService.onDidColorThemeChange(this._updateStyles, this));
	}
	dispose() {
		this._disposables.dispose();
		this._editor.removeContentWidget(this);
	}
	getId() {
		return '__renameInputWidget';
	}
	getDomNode() {
		if (!this._domNode) {
			this._domNode = document.createElement('div');
			this._domNode.className = 'monaco-editor rename-box';
			this._domNode.appendChild(this._inputWithButton.domNode);
			this._renameCandidateListView = this._disposables.add(
				new RenameCandidateListView(this._domNode, {
					fontInfo: this._editor.getOption(
						50 // fontInfo
					),
					onFocusChange: newSymbolName => {
						this._inputWithButton.input.value = newSymbolName;
						this._isEditingRenameCandidate = false;
					},
					onSelectionChange: () => {
						this._isEditingRenameCandidate = false;
						this.acceptInput(false);
					}
				})
			);
			this._disposables.add(
				this._inputWithButton.onDidInputChange(() => {
					if (this._renameCandidateListView?.focusedCandidate !== undefined) {
						this._isEditingRenameCandidate = true;
					}
					this._timeBeforeFirstInputFieldEdit ||= this._beforeFirstInputFieldEditSW.elapsed();
					if (this._renameCandidateProvidersCts?.token.isCancellationRequested === false) {
						this._renameCandidateProvidersCts.cancel();
					}
					this._renameCandidateListView?.clearFocus();
				})
			);
			this._label = document.createElement('div');
			this._label.className = 'rename-label';
			this._domNode.appendChild(this._label);
			this._updateFont();
			this._updateStyles(this._themeService.getColorTheme());
		}
		return this._domNode;
	}
	_updateStyles(theme) {
		if (this._domNode) {
			const widgetShadowColor = theme.getColor(colorId_widget_shadow);
			const widgetBorderColor = theme.getColor(colorId_widget_border);
			this._domNode.style.backgroundColor = String(theme.getColor(colorId_widget_background) || '');
			this._domNode.style.boxShadow = widgetShadowColor ? ` 0 0 8px 2px ${widgetShadowColor}` : '';
			this._domNode.style.border = widgetBorderColor ? `1px solid ${widgetBorderColor}` : '';
			this._domNode.style.color = String(theme.getColor(colorId_input_foreground) || '');
			const border = theme.getColor(colorId_input_border);
			this._inputWithButton.domNode.style.backgroundColor = String(theme.getColor(colorId_input_background) || '');
			this._inputWithButton.input.style.backgroundColor = String(theme.getColor(colorId_input_background) || '');
			this._inputWithButton.domNode.style.borderWidth = border ? '1px' : '0px';
			this._inputWithButton.domNode.style.borderStyle = border ? 'solid' : 'none';
			this._inputWithButton.domNode.style.borderColor = border?.toString() ?? 'none';
		}
	}
	_updateFont() {
		if (this._domNode && this._label) {
			this._editor.applyFontInfo(this._inputWithButton.input);
			const fontInfo = this._editor.getOption(
				50 // fontInfo
			);
			this._label.style.fontSize = `${this._computeLabelFontSize(fontInfo.fontSize)}px`;
		}
	}
	_computeLabelFontSize(editorFontSize) {
		return editorFontSize * 0.8;
	}
	getPosition() {
		if (!this._visible) {
			return null;
		}
		if (
			!this._editor.hasModel() || // @ulugbekna: shouldn't happen
			!this._editor.getDomNode()
		) {
			return null;
		}
		const bodyBox = getClientArea(this.getDomNode().ownerDocument.body);
		const editorBox = getDomNodePagePosition(this._editor.getDomNode());
		const cursorBoxTop = this._getTopForPosition();
		this._nPxAvailableAbove = cursorBoxTop + editorBox.top;
		this._nPxAvailableBelow = bodyBox.height - this._nPxAvailableAbove;
		const lineHeight = this._editor.getOption(
			67 // lineHeight
		);
		const { totalHeight: candidateViewHeight } = RenameCandidateView.getLayoutInfo({ lineHeight });
		const positionPreference =
			this._nPxAvailableBelow > candidateViewHeight * 6
				? [
						2,
						1 // ABOVE
					]
				: [
						1,
						2 // BELOW
					];
		return { position: this._position, preference: positionPreference };
	}
	beforeRender() {
		const [accept, preview] = this._acceptKeybindings;
		this._label.innerText = localize(
			this._keybindingService.lookupKeybinding(accept)?.getLabel(),
			this._keybindingService.lookupKeybinding(preview)?.getLabel()
		);
		this._domNode.style.minWidth = `200px`;
		return null;
	}
	afterRender(position) {
		if (position === null) {
			this.cancelInput(true, 'afterRender (because position is null)');
			return;
		}
		if (
			!this._editor.hasModel() || // shouldn't happen
			!this._editor.getDomNode()
		) {
			return;
		}
		if (this._renameCandidateListView && this._nPxAvailableAbove !== undefined && this._nPxAvailableBelow !== undefined) {
			const inputBoxHeight = getTotalHeight(this._inputWithButton.domNode);
			const labelHeight = getTotalHeight(this._label);
			this._renameCandidateListView.layout({
				height: (2 === position ? this._nPxAvailableBelow : this._nPxAvailableAbove) - labelHeight - inputBoxHeight,
				width: getTotalWidth(this._inputWithButton.domNode)
			});
		}
	}
	acceptInput(wantsPreview) {
		this._currentAcceptInput?.call(this, wantsPreview);
	}
	cancelInput(focusEditor, caller) {
		this._currentCancelInput?.call(this, focusEditor);
	}
	focusNextRenameSuggestion() {
		if (!this._renameCandidateListView?.focusNext()) {
			this._inputWithButton.input.value = this._currentName;
		}
	}
	focusPreviousRenameSuggestion() {
		if (!this._renameCandidateListView?.focusPrevious()) {
			this._inputWithButton.input.value = this._currentName;
		}
	}
	getInput(where, currentName, supportPreview, requestRenameCandidates, cts) {
		const { start: selectionStart, end: selectionEnd } = this._getSelection(where, currentName);
		this._renameCts = cts;
		const disposeOnDone = new DisposableStore();
		this._nRenameSuggestionsInvocations = 0;
		this._hadAutomaticRenameSuggestionsInvocation = false;
		if (requestRenameCandidates === undefined) {
			this._inputWithButton.button.style.display = 'none';
		} else {
			this._inputWithButton.button.style.display = 'flex';
			this._requestRenameCandidatesOnce = requestRenameCandidates;
			this._requestRenameCandidates(currentName, false);
			disposeOnDone.add(
				addDisposableListener(this._inputWithButton.button, 'click', () => this._requestRenameCandidates(currentName, true))
			);
			disposeOnDone.add(
				addDisposableListener(this._inputWithButton.button, EventType.KEY_DOWN, e => {
					const keyEvent = new StandardKeyboardEvent(e);
					if (
						keyEvent.equals(
							3 // Enter
						) ||
						keyEvent.equals(
							10 // Space
						)
					) {
						keyEvent.stopPropagation();
						keyEvent.preventDefault();
						this._requestRenameCandidates(currentName, true);
					}
				})
			);
		}
		this._isEditingRenameCandidate = false;
		this._domNode.classList.toggle('preview', supportPreview);
		this._position = new Position(where.startLineNumber, where.startColumn);
		this._currentName = currentName;
		this._inputWithButton.input.value = currentName;
		this._inputWithButton.input.setAttribute('selectionStart', selectionStart.toString());
		this._inputWithButton.input.setAttribute('selectionEnd', selectionEnd.toString());
		this._inputWithButton.input.size = Math.max((where.endColumn - where.startColumn) * 1.1, 20);
		this._beforeFirstInputFieldEditSW.reset();
		disposeOnDone.add(
			toDisposable(() => {
				this._renameCts = undefined;
				cts.dispose(true);
			})
		);
		disposeOnDone.add(
			toDisposable(() => {
				if (this._renameCandidateProvidersCts !== undefined) {
					this._renameCandidateProvidersCts.dispose(true);
					this._renameCandidateProvidersCts = undefined;
				}
			})
		);
		disposeOnDone.add(toDisposable(() => this._candidates.clear()));
		const inputResult = new DeferredPromise();
		inputResult.p.finally(() => {
			disposeOnDone.dispose();
			this._hide();
		});
		this._currentCancelInput = focusEditor => {
			this._currentAcceptInput = undefined;
			this._currentCancelInput = undefined;
			this._renameCandidateListView?.clearCandidates();
			inputResult.complete(focusEditor);
			return true;
		};
		this._currentAcceptInput = wantsPreview => {
			if (this._renameCandidateListView) {
				const nRenameSuggestions = this._renameCandidateListView.nCandidates;
				let newName;
				let source;
				const focusedCandidate = this._renameCandidateListView.focusedCandidate;
				if (focusedCandidate !== undefined) {
					newName = focusedCandidate;
					source = { k: 'renameSuggestion' };
				} else {
					newName = this._inputWithButton.input.value;
					source = this._isEditingRenameCandidate ? { k: 'userEditedRenameSuggestion' } : { k: 'inputField' };
				}
				if (newName === currentName || newName.trim().length === 0) {
					this.cancelInput(true, '_currentAcceptInput (because newName === value || newName.trim().length === 0)');
					return;
				}
				this._currentAcceptInput = undefined;
				this._currentCancelInput = undefined;
				this._renameCandidateListView.clearCandidates();
				inputResult.complete({
					newName,
					wantsPreview: supportPreview && wantsPreview,
					stats: {
						source,
						nRenameSuggestions,
						timeBeforeFirstInputFieldEdit: this._timeBeforeFirstInputFieldEdit,
						nRenameSuggestionsInvocations: this._nRenameSuggestionsInvocations,
						hadAutomaticRenameSuggestionsInvocation: this._hadAutomaticRenameSuggestionsInvocation
					}
				});
			}
		};
		disposeOnDone.add(cts.token.onCancellationRequested(() => this.cancelInput(true, 'cts.token.onCancellationRequested')));
		disposeOnDone.add(
			this._editor.onDidBlurEditorWidget(() => {
				return this.cancelInput(!this._domNode?.ownerDocument.hasFocus(), 'editor.onDidBlurEditorWidget');
			})
		);
		this._show();
		return inputResult.p;
	}
	_requestRenameCandidates(currentName, isManuallyTriggered) {
		if (this._requestRenameCandidatesOnce === undefined) {
			return;
		}
		if (this._renameCandidateProvidersCts !== undefined) {
			this._renameCandidateProvidersCts.dispose(true);
		}
		if (this._renameCts) {
			if (this._inputWithButton.buttonState !== 'stop') {
				this._renameCandidateProvidersCts = new CancellationTokenSource();
				const triggerKind = isManuallyTriggered
					? 0 //Invoke
					: 1; //Automatic;
				const candidates = this._requestRenameCandidatesOnce(triggerKind, this._renameCandidateProvidersCts.token);
				if (candidates.length === 0) {
					this._inputWithButton.setSparkleButton();
					return;
				}
				if (!isManuallyTriggered) {
					this._hadAutomaticRenameSuggestionsInvocation = true;
				}
				this._nRenameSuggestionsInvocations += 1;
				this._inputWithButton.setStopButton();
				this._updateRenameCandidates(candidates, currentName, this._renameCts.token);
			}
		}
	}
	_getSelection(where, currentName) {
		if (this._editor.hasModel()) {
			const selection = this._editor.getSelection();
			let start = 0;
			let end = currentName.length;
			if (!Range.isEmpty(selection) && !Range.spansMultipleLines(selection) && Range.containsRange(where, selection)) {
				start = Math.max(0, selection.startColumn - where.startColumn);
				end = Math.min(where.endColumn, selection.endColumn) - where.startColumn;
			}
			return { start, end };
		}
	}
	_show() {
		this._editor.revealLineInCenterIfOutsideViewport(
			this._position.lineNumber,
			0 // Smooth
		);
		this._visible = true;
		this._visibleContextKey.set(true);
		this._editor.layoutContentWidget(this);
		setTimeout(() => {
			this._inputWithButton.input.focus();
			this._inputWithButton.input.setSelectionRange(
				parseInt(this._inputWithButton.input.getAttribute('selectionStart')),
				parseInt(this._inputWithButton.input.getAttribute('selectionEnd'))
			);
		}, 100);
	}
	async _updateRenameCandidates(candidates, currentName, token) {
		const namesListResults = await raceCancellation(Promise.allSettled(candidates), token);
		this._inputWithButton.setSparkleButton();
		if (namesListResults === undefined) {
			return;
		}
		const newNames = namesListResults.flatMap(namesListResult =>
			namesListResult.status === 'fulfilled' && notIsNullOrUndefined(namesListResult.value) ? namesListResult.value : []
		);
		const distinctNames = distinct(newNames, v => v.newSymbolName);
		const validDistinctNames = distinctNames.filter(
			({ newSymbolName }) =>
				newSymbolName.trim().length > 0 &&
				newSymbolName !== this._inputWithButton.input.value &&
				newSymbolName !== currentName &&
				!this._candidates.has(newSymbolName)
		);
		validDistinctNames.forEach(n => this._candidates.add(n.newSymbolName));
		if (validDistinctNames.length) {
			this._renameCandidateListView.setCandidates(validDistinctNames);
			this._editor.layoutContentWidget(this);
		}
	}
	_hide() {
		this._visible = false;
		this._visibleContextKey.reset();
		this._editor.layoutContentWidget(this);
	}
	_getTopForPosition() {
		const visibleRanges = this._editor.getVisibleRanges();
		let firstLineInViewport;
		if (visibleRanges.length > 0) {
			firstLineInViewport = visibleRanges[0].startLineNumber;
		} else {
			firstLineInViewport = Math.max(1, this._position.lineNumber - 5);
		}
		return this._editor.getTopForLineNumber(this._position.lineNumber) - this._editor.getTopForLineNumber(firstLineInViewport);
	}
}
__decorate(
	[
		__param(2, IThemeService),
		__param(3, IKeybindingService),
		__param(4, IContextKeyService)
		//...
	],
	RenameWidget
);

const renameController_id = 'editor.contrib.renameController';
class RenameController {
	static get(editor2) {
		return editor2.getContribution(renameController_id);
	}
	constructor(
		editor2,
		_instaService,
		_notificationService,
		_bulkEditService,
		_progressService,
		_configService,
		_languageFeaturesService
	) {
		this.editor = editor2;
		this._instaService = _instaService;
		this._notificationService = _notificationService;
		this._bulkEditService = _bulkEditService;
		this._progressService = _progressService;
		this._configService = _configService;
		this._languageFeaturesService = _languageFeaturesService;
		this._disposableStore = new DisposableStore();
		this._cts = new CancellationTokenSource();
		this._renameWidget = this._disposableStore.add(
			this._instaService.createInstance(RenameWidget, this.editor, ['acceptRenameInput', 'acceptRenameInputWithPreview'])
		);
	}
	dispose() {
		this._disposableStore.dispose();
		this._cts.dispose(true);
	}
	async run() {
		this._cts.dispose(true);
		this._cts = new CancellationTokenSource();
		if (this.editor.hasModel()) {
			const position = this.editor.getPosition();
			const skeleton = new RenameSkeleton(this.editor.getModel(), position, this._languageFeaturesService.renameProvider);
			if (skeleton.hasProvider()) {
				const cts1 = new EditorStateCancellationTokenSource(this.editor, 4 | 1, undefined, this._cts.token);
				let loc;
				try {
					const resolveLocationOperation = skeleton.resolveRenameLocation(cts1.token);
					this._progressService.showWhile(resolveLocationOperation, 250);
					loc = await resolveLocationOperation;
				} catch (exception) {
					if (exception instanceof CancellationError) {
						console.debug('resolve rename location cancelled', JSON.stringify(exception, null, '	'));
					} else {
						console.debug(
							'resolve rename location failed',
							exception instanceof Error ? exception : JSON.stringify(exception, null, '	')
						);
					}
					return;
				} finally {
					cts1.dispose();
				}
				if (loc && !loc.rejectReason) {
					if (cts1.token.isCancellationRequested) {
						return;
					}
					const cts2 = new EditorStateCancellationTokenSource(this.editor, 4 | 1, loc.range, this._cts.token);
					const model = this.editor.getModel();
					const newSymbolNamesProviders = this._languageFeaturesService.newSymbolNamesProvider.all(model);
					const resolvedNewSymbolnamesProviders = await Promise.all(
						newSymbolNamesProviders.map(async p => {
							return [p, (await p.supportsAutomaticNewSymbolNamesTriggerKind) ?? false];
						})
					);
					const requestRenameSuggestions = (triggerKind, cts) => {
						let providers = resolvedNewSymbolnamesProviders.slice();
						if (
							triggerKind === 1 //Automatic
						) {
							providers = providers.filter(([_, supportsAutomatic]) => supportsAutomatic);
						}
						return providers.map(([p]) => p.provideNewSymbolNames(model, loc.range, triggerKind, cts));
					};
					const supportPreview =
						this._bulkEditService.hasPreviewHandler() &&
						this._configService.getValue(this.editor.getModel().uri, 'editor.rename.enablePreview');
					const inputFieldResult = await this._renameWidget.getInput(
						loc.range,
						loc.text,
						supportPreview,
						newSymbolNamesProviders.length > 0 ? requestRenameSuggestions : undefined,
						cts2
					);
					if (typeof inputFieldResult === 'boolean') {
						if (inputFieldResult) {
							this.editor.focus();
						}
						cts2.dispose();
						return;
					}
					this.editor.focus();

					const renameOperation = raceCancellation(skeleton.provideRenameEdits(inputFieldResult.newName, cts2.token), cts2.token)
						.then(
							async renameResult => {
								if (!renameResult) {
									return;
								}
								if (!this.editor.hasModel()) {
									return;
								}
								if (renameResult.rejectReason) {
									this._notificationService.info(renameResult.rejectReason);
									return;
								}
								this.editor.setSelection(Range.fromPositions(this.editor.getSelection().getPosition()));
								this._bulkEditService
									.apply(renameResult, {
										editor: this.editor,
										showPreview: inputFieldResult.wantsPreview,
										label: localize("Renaming '{0}' to '{1}'", loc?.text, inputFieldResult.newName),
										code: 'undoredo.rename',
										quotableLabel: localize('Renaming {0} to {1}', loc?.text, inputFieldResult.newName),
										respectAutoSaveConfig: true
									})
									.catch(err => {
										console.debug(`error when applying edits ${JSON.stringify(err, null, '	')}`);
										this._notificationService.error(localize('Rename failed to apply edits'));
									});
							},
							err => {
								console.debug('error when providing rename edits', JSON.stringify(err, null, '	'));
								this._notificationService.error(localize('Rename failed to compute edits'));
							}
						)
						.finally(() => {
							cts2.dispose();
						});
					this._progressService.showWhile(renameOperation, 250);
					return renameOperation;
				}
			}
		}
	}
	acceptRenameInput(wantsPreview) {
		this._renameWidget.acceptInput(wantsPreview);
	}
	cancelRenameInput() {
		this._renameWidget.cancelInput(true, 'cancelRenameInput command');
	}
	focusNextRenameSuggestion() {
		this._renameWidget.focusNextRenameSuggestion();
	}
	focusPreviousRenameSuggestion() {
		this._renameWidget.focusPreviousRenameSuggestion();
	}
}
__decorate(
	[
		__param(1, IInstantiationService),
		__param(2, INotificationService),
		__param(3, IBulkEditService),
		__param(4, IEditorProgressService),
		__param(5, ITextResourceConfigurationService),
		__param(6, ILanguageFeaturesService)
	],
	RenameController
);

class RenameAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.rename',
			label: localize('Rename Symbol'),
			alias: 'Rename Symbol',
			precondition: ContextKeyExpr.and(ck_writable, ck_editorHasProvider_rename),
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 60,
				weight: 100 //editorContrib
			},
			contextMenuOpts: {
				group: '1_modification',
				order: 1.1
			}
		});
	}
	runCommand(accessor, args) {
		const editorService = accessor.get(ICodeEditorService);
		const [uri, pos] = (isArray(args) && args) || [undefined, undefined];
		if (URI.isUri(uri) && Position.isIPosition(pos)) {
			return editorService.openCodeEditor({ resource: uri }, editorService.getActiveCodeEditor()).then(editor2 => {
				if (!editor2) {
					return;
				}
				editor2.setPosition(pos);
				editor2.invokeWithinContext(accessor2 => {
					return this.run(accessor2, editor2);
				});
			}, onUnexpectedError);
		}
		return super.runCommand(accessor, args);
	}
	run(accessor, editor2) {
		const controller = RenameController.get(editor2);
		return controller ? controller.run() : Promise.resolve();
	}
}
registerEditorContribution(
	renameController_id,
	RenameController,
	4 // Lazy
);
registerEditorAction(RenameAction);

const RenameCommand = EditorCommand.bindToContribution(RenameController.get);

registerEditorCommand(
	new RenameCommand({
		id: 'acceptRenameInput',
		precondition: ck_renameInputVisible,
		handler: x => x.acceptRenameInput(false),
		kbOpts: {
			weight: 100 + 99,
			kbExpr: ContextKeyExpr.and(ck_editorFocus, ContextKeyExpr.not('isComposing')),
			primary: 3 // Enter
		}
	})
);

registerEditorCommand(
	new RenameCommand({
		id: 'acceptRenameInputWithPreview',
		precondition: ContextKeyExpr.and(ck_renameInputVisible, ContextKeyExpr.has('config.editor.rename.enablePreview')),
		handler: x => x.acceptRenameInput(true),
		kbOpts: {
			weight: 100 + 99,
			kbExpr: ContextKeyExpr.and(ck_editorFocus, ContextKeyExpr.not('isComposing')),
			primary: 2048 + 3 // Enter
		}
	})
);

registerEditorCommand(
	new RenameCommand({
		id: 'cancelRenameInput',
		precondition: ck_renameInputVisible,
		handler: x => x.cancelRenameInput(),
		kbOpts: {
			weight: 100 + 99,
			kbExpr: ck_editorFocus,
			primary: 9,
			secondary: [
				1024 | 9 // Escape
			]
		}
	})
);

registerEditorAction2(
	class FocusNextRenameSuggestion extends Action2 {
		constructor() {
			super({
				id: 'focusNextRenameSuggestion',
				title: {
					...localize('Focus Next Rename Suggestion')
				},
				precondition: ck_renameInputVisible,
				keybinding: [
					{
						primary: 18,
						weight: 199
					}
				]
			});
		}
		run(accessor) {
			const currentEditor = accessor.get(ICodeEditorService).getFocusedCodeEditor();
			if (!currentEditor) {
				return;
			}
			const controller = RenameController.get(currentEditor);
			if (!controller) {
				return;
			}
			controller.focusNextRenameSuggestion();
		}
	}
);

registerEditorAction2(
	class FocusPreviousRenameSuggestion extends Action2 {
		constructor() {
			super({
				id: 'focusPreviousRenameSuggestion',
				title: {
					...localize('Focus Previous Rename Suggestion')
				},
				precondition: ck_renameInputVisible,
				keybinding: [
					{
						primary: 16,
						weight: 199
					}
				]
			});
		}
		run(accessor) {
			const currentEditor = accessor.get(ICodeEditorService).getFocusedCodeEditor();
			if (!currentEditor) {
				return;
			}
			const controller = RenameController.get(currentEditor);
			if (!controller) {
				return;
			}
			controller.focusPreviousRenameSuggestion();
		}
	}
);

class RenameSkeleton {
	constructor(model, position, registry) {
		this.model = model;
		this.position = position;
		this._providerRenameIdx = 0;
		this._providers = registry.ordered(model);
	}
	hasProvider() {
		return this._providers.length > 0;
	}
	async resolveRenameLocation(token) {
		const rejects = [];
		for (this._providerRenameIdx = 0; this._providerRenameIdx < this._providers.length; this._providerRenameIdx++) {
			const provider = this._providers[this._providerRenameIdx];
			if (!provider.resolveRenameLocation) {
				break;
			}
			const res = await provider.resolveRenameLocation(this.model, this.position, token);
			if (!res) {
				continue;
			}
			if (res.rejectReason) {
				rejects.push(res.rejectReason);
				continue;
			}
			return res;
		}
		this._providerRenameIdx = 0;
		const word = this.model.getWordAtPosition(this.position);
		if (!word) {
			return {
				range: Range.fromPositions(this.position),
				text: '',
				rejectReason: rejects.length > 0 ? rejects.join('\n') : undefined
			};
		}
		return {
			range: new Range(this.position.lineNumber, word.startColumn, this.position.lineNumber, word.endColumn),
			text: word.word,
			rejectReason: rejects.length > 0 ? rejects.join('\n') : undefined
		};
	}
	async provideRenameEdits(newName, token) {
		return this._provideRenameEdits(newName, this._providerRenameIdx, [], token);
	}
	async _provideRenameEdits(newName, i, rejects, token) {
		const provider = this._providers[i];
		if (!provider) {
			return { edits: [], rejectReason: rejects.join('\n') };
		}
		const result = await provider.provideRenameEdits(this.model, this.position, newName, token);
		if (!result) {
			return this._provideRenameEdits(newName, i + 1, rejects.concat(localize('No result.')), token);
		} else if (result.rejectReason) {
			return this._provideRenameEdits(newName, i + 1, rejects.concat(result.rejectReason), token);
		}
		return result;
	}
}

async function rename(registry, model, position, newName) {
	const skeleton = new RenameSkeleton(model, position, registry);
	const loc = await skeleton.resolveRenameLocation(cancellationToken_none);
	if (loc?.rejectReason) {
		return { edits: [], rejectReason: loc.rejectReason };
	}
	return skeleton.provideRenameEdits(newName, cancellationToken_none);
}

registerModelAndPositionCommand('_executeDocumentRenameProvider', function (accessor, model, position, newName) {
	if (typeof newName === 'string') {
		const { renameProvider } = accessor.get(ILanguageFeaturesService);
		return rename(renameProvider, model, position, newName);
	}
});

registerModelAndPositionCommand('_executePrepareRename', async function (accessor, model, position) {
	const { renameProvider } = accessor.get(ILanguageFeaturesService);
	const skeleton = new RenameSkeleton(model, position, renameProvider);
	const loc = await skeleton.resolveRenameLocation(cancellationToken_none);
	if (loc?.rejectReason) {
		throw new Error(loc.rejectReason);
	}
	return loc;
});

registry.as(baseContributionId_Configuration).registerConfiguration({
	id: 'editor',
	properties: {
		'editor.rename.enablePreview': {
			scope: 5,
			default: true,
			type: 'boolean'
		}
	}
});



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


class StandaloneUriLabelService {
	getUriLabel(resource, options2) {
		if (resource.scheme === 'file') {
			return resource.fsPath;
		}
		return resource.path;
	}
	getUriBasenameLabel(resource) {
		return basename2(resource);
	}
}
registerSingleton(
	ILabelService,
	StandaloneUriLabelService,
	0 //Eager
);




