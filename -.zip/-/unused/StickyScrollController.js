class DefaultStickyScrollDelegate {
	constrainStickyScrollNodes(stickyNodes, stickyScrollMaxItemCount, maxWidgetHeight) {
		for (let i = 0; i < stickyNodes.length; i++) {
			const stickyNode = stickyNodes[i];
			const stickyNodeBottom = stickyNode.position + stickyNode.height;
			if (stickyNodeBottom > maxWidgetHeight || i >= stickyScrollMaxItemCount) {
				return stickyNodes.slice(0, i);
			}
		}
		return stickyNodes;
	}
}

const stickyScrollNodeEquals = (a, b) => {
	return a.node.element === b.node.element && a.startIndex === b.startIndex && a.height === b.height && a.endIndex === b.endIndex;
};

class StickyScrollState {
	constructor(stickyNodes = []) {
		this.stickyNodes = stickyNodes;
	}
	get count() {
		return this.stickyNodes.length;
	}
	equal(state) {
		return equals(this.stickyNodes, state.stickyNodes, (a, b) => a.position === b.position && stickyScrollNodeEquals(a, b));
	}
	lastNodePartiallyVisible() {
		if (this.count === 0) {
			return false;
		}
		const lastStickyNode = this.stickyNodes[this.count - 1];
		if (this.count === 1) {
			return lastStickyNode.position !== 0;
		}
		const secondLastStickyNode = this.stickyNodes[this.count - 2];
		return secondLastStickyNode.position + secondLastStickyNode.height !== lastStickyNode.position;
	}
	animationStateChanged(previousState) {
		if (!equals(this.stickyNodes, previousState.stickyNodes, stickyScrollNodeEquals)) {
			return false;
		}
		if (this.count === 0) {
			return false;
		}
		const lastStickyNode = this.stickyNodes[this.count - 1];
		const previousLastStickyNode = previousState.stickyNodes[previousState.count - 1];
		return lastStickyNode.position !== previousLastStickyNode.position;
	}
}
class StickyScrollFocus extends Disposable {
	get domHasFocus() {
		return this._domHasFocus;
	}
	set domHasFocus(hasFocus) {
		if (hasFocus !== this._domHasFocus) {
			this._onDidChangeHasFocus.fire(hasFocus);
			this._domHasFocus = hasFocus;
		}
	}
	constructor(container, view) {
		super();
		this.container = container;
		this.view = view;
		this.focusedIndex = -1;
		this.elements = [];
		this._onDidChangeHasFocus = new Emitter();
		this.onDidChangeHasFocus = this._onDidChangeHasFocus.event;
		this._onContextMenu = new Emitter();
		this.onContextMenu = this._onContextMenu.event;
		this._domHasFocus = false;
		this.container.addEventListener('focus', () => this.onFocus());
		this.container.addEventListener('blur', () => this.onBlur());
		this._register(this.view.onDidFocus(() => this.toggleStickyScrollFocused(false)));
		this._register(this.view.onKeyDown(e => this.onKeyDown(e)));
		this._register(this.view.onMouseDown(e => this.onMouseDown(e)));
		this._register(this.view.onContextMenu(e => this.handleContextMenu(e)));
	}
	handleContextMenu(e) {
		const target = e.browserEvent.target;
		if (!isStickyScrollContainer(target) && !isStickyScrollElement(target)) {
			if (this.focusedLast()) {
				this.view.domFocus();
			}
			return;
		}
		if (!isKeyboardEvent(e.browserEvent)) {
			if (!this.state) {
				throw new Error('Context menu should not be triggered when state is undefined');
			}
			const stickyIndex = this.state.stickyNodes.findIndex(stickyNode2 => {
				return stickyNode2.node.element === e.element?.element;
			});
			if (stickyIndex === -1) {
				throw new Error('Context menu should not be triggered when element is not in sticky scroll widget');
			}
			this.container.focus();
			this.setFocus(stickyIndex);
			return;
		}
		if (!this.state || this.focusedIndex < 0) {
			throw new Error('Context menu key should not be triggered when focus is not in sticky scroll widget');
		}
		const stickyNode = this.state.stickyNodes[this.focusedIndex];
		const element = stickyNode.node.element;
		const anchor = this.elements[this.focusedIndex];
		this._onContextMenu.fire({
			element,
			anchor,
			browserEvent: e.browserEvent,
			isStickyScroll: true
		});
	}
	onKeyDown(e) {
		if (this.domHasFocus && this.state) {
			if (e.key === 'ArrowUp') {
				this.setFocusedElement(Math.max(0, this.focusedIndex - 1));
				e.preventDefault();
				e.stopPropagation();
			} else if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
				if (this.focusedIndex >= this.state.count - 1) {
					const nodeIndexToFocus = this.state.stickyNodes[this.state.count - 1].startIndex + 1;
					this.view.domFocus();
					this.view.setFocus([nodeIndexToFocus]);
					this.scrollNodeUnderWidget(nodeIndexToFocus, this.state);
				} else {
					this.setFocusedElement(this.focusedIndex + 1);
				}
				e.preventDefault();
				e.stopPropagation();
			}
		}
	}
	onMouseDown(e) {
		const target = e.browserEvent.target;
		if (!isStickyScrollContainer(target) && !isStickyScrollElement(target)) {
			return;
		}
		e.browserEvent.preventDefault();
		e.browserEvent.stopPropagation();
	}
	updateElements(elements, state) {
		if (state && state.count === 0) {
			throw new Error('Sticky scroll state must be undefined when there are no sticky nodes');
		}
		if (state && state.count !== elements.length) {
			throw new Error('Sticky scroll focus received illigel state');
		}
		const previousIndex = this.focusedIndex;
		this.removeFocus();
		this.elements = elements;
		this.state = state;
		if (state) {
			const newFocusedIndex = clamp(previousIndex, 0, state.count - 1);
			this.setFocus(newFocusedIndex);
		} else {
			if (this.domHasFocus) {
				this.view.domFocus();
			}
		}
		this.container.tabIndex = state ? 0 : -1;
	}
	setFocusedElement(stickyIndex) {
		const state = this.state;
		if (!state) {
			throw new Error('Cannot set focus when state is undefined');
		}
		this.setFocus(stickyIndex);
		if (stickyIndex < state.count - 1) {
			return;
		}
		if (state.lastNodePartiallyVisible()) {
			const lastStickyNode = state.stickyNodes[stickyIndex];
			this.scrollNodeUnderWidget(lastStickyNode.endIndex + 1, state);
		}
	}
	scrollNodeUnderWidget(nodeIndex, state) {
		const lastStickyNode = state.stickyNodes[state.count - 1];
		const secondLastStickyNode = state.count > 1 ? state.stickyNodes[state.count - 2] : undefined;
		const elementScrollTop = this.view.getElementTop(nodeIndex);
		const elementTargetViewTop = secondLastStickyNode
			? secondLastStickyNode.position + secondLastStickyNode.height + lastStickyNode.height
			: lastStickyNode.height;
		this.view.scrollTop = elementScrollTop - elementTargetViewTop;
	}
	domFocus() {
		if (!this.state) {
			throw new Error('Cannot focus when state is undefined');
		}
		this.container.focus();
	}
	focusedLast() {
		if (!this.state) {
			return false;
		}
		return this.view.getHTMLElement().classList.contains('sticky-scroll-focused');
	}
	removeFocus() {
		if (this.focusedIndex === -1) {
			return;
		}
		this.toggleElementFocus(this.elements[this.focusedIndex], false);
		this.focusedIndex = -1;
	}
	setFocus(newFocusIndex) {
		if (0 > newFocusIndex) {
			throw new Error('addFocus() can not remove focus');
		}
		if (!this.state && newFocusIndex >= 0) {
			throw new Error('Cannot set focus index when state is undefined');
		}
		if (this.state && newFocusIndex >= this.state.count) {
			throw new Error('Cannot set focus index to an index that does not exist');
		}
		const oldIndex = this.focusedIndex;
		if (oldIndex >= 0) {
			this.toggleElementFocus(this.elements[oldIndex], false);
		}
		if (newFocusIndex >= 0) {
			this.toggleElementFocus(this.elements[newFocusIndex], true);
		}
		this.focusedIndex = newFocusIndex;
	}
	toggleElementFocus(element, focused) {
		this.toggleElementActiveFocus(element, focused && this.domHasFocus);
		this.toggleElementPassiveFocus(element, focused);
	}
	toggleCurrentElementActiveFocus(focused) {
		if (this.focusedIndex === -1) {
			return;
		}
		this.toggleElementActiveFocus(this.elements[this.focusedIndex], focused);
	}
	toggleElementActiveFocus(element, focused) {
		element.classList.toggle('focused', focused);
	}
	toggleElementPassiveFocus(element, focused) {
		element.classList.toggle('passive-focused', focused);
	}
	toggleStickyScrollFocused(focused) {
		this.view.getHTMLElement().classList.toggle('sticky-scroll-focused', focused);
	}
	onFocus() {
		if (!this.state || this.elements.length === 0) {
			throw new Error('Cannot focus when state is undefined or elements are empty');
		}
		this.domHasFocus = true;
		this.toggleStickyScrollFocused(true);
		this.toggleCurrentElementActiveFocus(true);
		if (this.focusedIndex === -1) {
			this.setFocus(0);
		}
	}
	onBlur() {
		this.domHasFocus = false;
		this.toggleCurrentElementActiveFocus(false);
	}
	dispose() {
		this.toggleStickyScrollFocused(false);
		this._onDidChangeHasFocus.fire(false);
		super.dispose();
	}
}
class StickyScrollWidget {
	constructor(container, view, tree, treeRenderers, treeDelegate) {
		this.view = view;
		this.tree = tree;
		this.treeRenderers = treeRenderers;
		this.treeDelegate = treeDelegate;
		this._previousElements = [];
		this._previousStateDisposables = new DisposableStore();
		this._rootDomNode = createDomElement('.monaco-tree-sticky-container.empty');
		container.appendChild(this._rootDomNode);
		const shadow = createDomElement('.monaco-tree-sticky-container-shadow');
		this._rootDomNode.appendChild(shadow);
		this.stickyScrollFocus = new StickyScrollFocus(this._rootDomNode, view);
		this.onDidChangeHasFocus = this.stickyScrollFocus.onDidChangeHasFocus;
		this.onContextMenu = this.stickyScrollFocus.onContextMenu;
	}
	get height() {
		if (!this._previousState) {
			return 0;
		}
		const lastElement = this._previousState.stickyNodes[this._previousState.count - 1];
		return lastElement.position + lastElement.height;
	}
	setState(state) {
		const wasVisible = !!this._previousState && this._previousState.count > 0;
		const isVisible = !!state && state.count > 0;
		if ((!wasVisible && !isVisible) || (wasVisible && isVisible && this._previousState.equal(state))) {
			return;
		}
		if (wasVisible !== isVisible) {
			this.setVisible(isVisible);
		}
		if (!isVisible) {
			this._previousState = undefined;
			this._previousElements = [];
			this._previousStateDisposables.clear();
			return;
		}
		const lastStickyNode = state.stickyNodes[state.count - 1];
		if (this._previousState && state.animationStateChanged(this._previousState)) {
			this._previousElements[this._previousState.count - 1].style.top = `${lastStickyNode.position}px`;
		} else {
			this._previousStateDisposables.clear();
			const elements = Array(state.count);
			for (let stickyIndex = state.count - 1; stickyIndex >= 0; stickyIndex--) {
				const stickyNode = state.stickyNodes[stickyIndex];
				const { element, disposable } = this.createElement(stickyNode, stickyIndex, state.count);
				elements[stickyIndex] = element;
				this._rootDomNode.appendChild(element);
				this._previousStateDisposables.add(disposable);
			}
			this.stickyScrollFocus.updateElements(elements, state);
			this._previousElements = elements;
		}
		this._previousState = state;
		this._rootDomNode.style.height = `${lastStickyNode.position + lastStickyNode.height}px`;
	}
	createElement(stickyNode, stickyIndex, stickyNodesTotal) {
		const nodeIndex = stickyNode.startIndex;
		const stickyElement = document.createElement('div');
		stickyElement.style.top = `${stickyNode.position}px`;
		if (this.tree.options.setRowHeight !== false) {
			stickyElement.style.height = `${stickyNode.height}px`;
		}
		if (this.tree.options.setRowLineHeight !== false) {
			stickyElement.style.lineHeight = `${stickyNode.height}px`;
		}
		stickyElement.classList.add('monaco-tree-sticky-row');
		stickyElement.classList.add('monaco-list-row');
		stickyElement.setAttribute('data-index', `${nodeIndex}`);
		stickyElement.setAttribute('data-parity', nodeIndex % 2 === 0 ? 'even' : 'odd');
		stickyElement.setAttribute('id', this.view.getElementID(nodeIndex));
		const nodeTemplateId = this.treeDelegate.getTemplateId(stickyNode.node);
		const renderer = this.treeRenderers.find(renderer2 => renderer2.templateId === nodeTemplateId);
		if (!renderer) {
			throw new Error(`No renderer found for template id ${nodeTemplateId}`);
		}
		let nodeCopy = stickyNode.node;
		if (nodeCopy === this.tree.getNode(this.tree.getNodeLocation(stickyNode.node))) {
			nodeCopy = new Proxy(stickyNode.node, {});
		}
		const templateData = renderer.renderTemplate(stickyElement);
		renderer.renderElement(nodeCopy, stickyNode.startIndex, templateData, stickyNode.height);
		const disposable = toDisposable(() => {
			renderer.disposeElement(nodeCopy, stickyNode.startIndex, templateData, stickyNode.height);
			renderer.disposeTemplate(templateData);
			stickyElement.remove();
		});
		return { element: stickyElement, disposable };
	}
	setVisible(visible) {
		this._rootDomNode.classList.toggle('empty', !visible);
		if (!visible) {
			this.stickyScrollFocus.updateElements([], undefined);
		}
	}
	domFocus() {
		this.stickyScrollFocus.domFocus();
	}
	focusedLast() {
		return this.stickyScrollFocus.focusedLast();
	}
	dispose() {
		this.stickyScrollFocus.dispose();
		this._previousStateDisposables.dispose();
		this._rootDomNode.remove();
	}
}
class StickyScrollController extends Disposable {
	constructor(tree, model, view, renderers, treeDelegate, options2 = {}) {
		super();
		this.tree = tree;
		this.model = model;
		this.view = view;
		this.treeDelegate = treeDelegate;
		this.maxWidgetViewRatio = 0.4;
		const stickyScrollOptions = this.validateStickySettings(options2);
		this.stickyScrollMaxItemCount = stickyScrollOptions.stickyScrollMaxItemCount;
		this.stickyScrollDelegate = options2.stickyScrollDelegate ?? new DefaultStickyScrollDelegate();
		this._widget = this._register(new StickyScrollWidget(view.getScrollableElement(), view, tree, renderers, treeDelegate));
		this.onDidChangeHasFocus = this._widget.onDidChangeHasFocus;
		this.onContextMenu = this._widget.onContextMenu;
		this._register(view.onDidScroll(() => this.update()));
		this._register(view.onDidChangeContentHeight(() => this.update()));
		this._register(tree.onDidChangeCollapseState(() => this.update()));
		this.update();
	}
	get height() {
		return this._widget.height;
	}
	getNodeAtHeight(height) {
		let index;
		if (height === 0) {
			index = this.view.firstVisibleIndex;
		} else {
			index = this.view.indexAt(height + this.view.scrollTop);
		}
		if (index < 0 || index >= this.view.length) {
			return;
		}
		return this.view.element(index);
	}
	update() {
		const firstVisibleNode = this.getNodeAtHeight(0);
		if (!firstVisibleNode || this.tree.scrollTop === 0) {
			this._widget.setState(undefined);
			return;
		}
		const stickyState = this.findStickyState(firstVisibleNode);
		this._widget.setState(stickyState);
	}
	findStickyState(firstVisibleNode) {
		const stickyNodes = [];
		let firstVisibleNodeUnderWidget = firstVisibleNode;
		let stickyNodesHeight = 0;
		let nextStickyNode = this.getNextStickyNode(firstVisibleNodeUnderWidget, undefined, stickyNodesHeight);
		while (nextStickyNode) {
			stickyNodes.push(nextStickyNode);
			stickyNodesHeight += nextStickyNode.height;
			if (stickyNodes.length <= this.stickyScrollMaxItemCount) {
				firstVisibleNodeUnderWidget = this.getNextVisibleNode(nextStickyNode);
				if (!firstVisibleNodeUnderWidget) {
					break;
				}
			}
			nextStickyNode = this.getNextStickyNode(firstVisibleNodeUnderWidget, nextStickyNode.node, stickyNodesHeight);
		}
		const contrainedStickyNodes = this.constrainStickyNodes(stickyNodes);
		return contrainedStickyNodes.length ? new StickyScrollState(contrainedStickyNodes) : undefined;
	}
	getNextVisibleNode(previousStickyNode) {
		return this.getNodeAtHeight(previousStickyNode.position + previousStickyNode.height);
	}
	getNextStickyNode(firstVisibleNodeUnderWidget, previousStickyNode, stickyNodesHeight) {
		const nextStickyNode = this.getAncestorUnderPrevious(firstVisibleNodeUnderWidget, previousStickyNode);
		if (!nextStickyNode) {
			return;
		}
		if (nextStickyNode === firstVisibleNodeUnderWidget) {
			if (!this.nodeIsUncollapsedParent(firstVisibleNodeUnderWidget)) {
				return;
			}
			if (this.nodeTopAlignsWithStickyNodesBottom(firstVisibleNodeUnderWidget, stickyNodesHeight)) {
				return;
			}
		}
		return this.createStickyScrollNode(nextStickyNode, stickyNodesHeight);
	}
	nodeTopAlignsWithStickyNodesBottom(node, stickyNodesHeight) {
		const nodeIndex = this.getNodeIndex(node);
		const elementTop = this.view.getElementTop(nodeIndex);
		const stickyPosition = stickyNodesHeight;
		return this.view.scrollTop === elementTop - stickyPosition;
	}
	createStickyScrollNode(node, currentStickyNodesHeight) {
		const height = this.treeDelegate.getHeight(node);
		const { startIndex, endIndex } = this.getNodeRange(node);
		const position = this.calculateStickyNodePosition(endIndex, currentStickyNodesHeight, height);
		return { node, position, height, startIndex, endIndex };
	}
	getAncestorUnderPrevious(node, previousAncestor = undefined) {
		let currentAncestor = node;
		let parentOfcurrentAncestor = this.getParentNode(currentAncestor);
		while (parentOfcurrentAncestor) {
			if (parentOfcurrentAncestor === previousAncestor) {
				return currentAncestor;
			}
			currentAncestor = parentOfcurrentAncestor;
			parentOfcurrentAncestor = this.getParentNode(currentAncestor);
		}
		if (previousAncestor === undefined) {
			return currentAncestor;
		}
		return;
	}
	calculateStickyNodePosition(lastDescendantIndex, stickyRowPositionTop, stickyNodeHeight) {
		let lastChildRelativeTop = this.view.getRelativeTop(lastDescendantIndex);
		if (
			lastChildRelativeTop === null &&
			this.view.firstVisibleIndex === lastDescendantIndex &&
			lastDescendantIndex + 1 < this.view.length
		) {
			const nodeHeight = this.treeDelegate.getHeight(this.view.element(lastDescendantIndex));
			const nextNodeRelativeTop = this.view.getRelativeTop(lastDescendantIndex + 1);
			lastChildRelativeTop = nextNodeRelativeTop ? nextNodeRelativeTop - nodeHeight / this.view.renderHeight : null;
		}
		if (lastChildRelativeTop === null) {
			return stickyRowPositionTop;
		}
		const lastChildNode = this.view.element(lastDescendantIndex);
		const lastChildHeight = this.treeDelegate.getHeight(lastChildNode);
		const topOfLastChild = lastChildRelativeTop * this.view.renderHeight;
		const bottomOfLastChild = topOfLastChild + lastChildHeight;
		if (stickyRowPositionTop + stickyNodeHeight > bottomOfLastChild && stickyRowPositionTop <= bottomOfLastChild) {
			return bottomOfLastChild - stickyNodeHeight;
		}
		return stickyRowPositionTop;
	}
	constrainStickyNodes(stickyNodes) {
		if (stickyNodes.length === 0) {
			return [];
		}
		const maximumStickyWidgetHeight = this.view.renderHeight * this.maxWidgetViewRatio;
		const lastStickyNode = stickyNodes[stickyNodes.length - 1];
		if (
			stickyNodes.length <= this.stickyScrollMaxItemCount &&
			lastStickyNode.position + lastStickyNode.height <= maximumStickyWidgetHeight
		) {
			return stickyNodes;
		}
		const constrainedStickyNodes = this.stickyScrollDelegate.constrainStickyScrollNodes(
			stickyNodes,
			this.stickyScrollMaxItemCount,
			maximumStickyWidgetHeight
		);
		if (!constrainedStickyNodes.length) {
			return [];
		}
		const lastConstrainedStickyNode = constrainedStickyNodes[constrainedStickyNodes.length - 1];
		if (
			constrainedStickyNodes.length > this.stickyScrollMaxItemCount ||
			lastConstrainedStickyNode.position + lastConstrainedStickyNode.height > maximumStickyWidgetHeight
		) {
			throw new Error('stickyScrollDelegate violates constraints');
		}
		return constrainedStickyNodes;
	}
	getParentNode(node) {
		const nodeLocation = this.model.getNodeLocation(node);
		const parentLocation = this.model.getParentNodeLocation(nodeLocation);
		return parentLocation ? this.model.getNode(parentLocation) : undefined;
	}
	nodeIsUncollapsedParent(node) {
		const nodeLocation = this.model.getNodeLocation(node);
		return this.model.getListRenderCount(nodeLocation) > 1;
	}
	getNodeIndex(node) {
		const nodeLocation = this.model.getNodeLocation(node);
		const nodeIndex = this.model.getListIndex(nodeLocation);
		return nodeIndex;
	}
	getNodeRange(node) {
		const nodeLocation = this.model.getNodeLocation(node);
		const startIndex = this.model.getListIndex(nodeLocation);
		if (startIndex < 0) {
			throw new Error('Node not found in tree');
		}
		const renderCount = this.model.getListRenderCount(nodeLocation);
		const endIndex = startIndex + renderCount - 1;
		return { startIndex, endIndex };
	}
	nodePositionTopBelowWidget(node) {
		const ancestors = [];
		let currentAncestor = this.getParentNode(node);
		while (currentAncestor) {
			ancestors.push(currentAncestor);
			currentAncestor = this.getParentNode(currentAncestor);
		}
		let widgetHeight = 0;
		for (let i = 0; i < ancestors.length && i < this.stickyScrollMaxItemCount; i++) {
			widgetHeight += this.treeDelegate.getHeight(ancestors[i]);
		}
		return widgetHeight;
	}
	domFocus() {
		this._widget.domFocus();
	}
	// Whether sticky scroll was the last focused part in the tree or not
	focusedLast() {
		return this._widget.focusedLast();
	}
	updateOptions(optionsUpdate = {}) {
		if (!optionsUpdate.stickyScrollMaxItemCount) {
			return;
		}
		const validatedOptions = this.validateStickySettings(optionsUpdate);
		if (this.stickyScrollMaxItemCount !== validatedOptions.stickyScrollMaxItemCount) {
			this.stickyScrollMaxItemCount = validatedOptions.stickyScrollMaxItemCount;
			this.update();
		}
	}
	validateStickySettings(options2) {
		let stickyScrollMaxItemCount = 7;
		if (typeof options2.stickyScrollMaxItemCount === 'number') {
			stickyScrollMaxItemCount = Math.max(options2.stickyScrollMaxItemCount, 1);
		}
		return { stickyScrollMaxItemCount };
	}
}