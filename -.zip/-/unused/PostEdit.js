class PostEditWidgetManager extends Disposable {
	constructor(_id, _editor, _visibleContext, _showCommand, _instantiationService, _bulkEditService) {
		super();
		this._id = _id;
		this._editor = _editor;
		this._visibleContext = _visibleContext;
		this._showCommand = _showCommand;
		this._instantiationService = _instantiationService;
		this._bulkEditService = _bulkEditService;
		this._currentWidget = this._register(new MutableDisposable());
		this._register(editorEventAny(_editor.onDidChangeModel, _editor.onDidChangeModelContent)(() => this.clear()));
	}
	async applyEditAndShowIfNeeded(ranges, edits, canShowWidget, resolve2, token) {
		const model = this._editor.getModel();
		if (!model || !ranges.length) {
			return;
		}
		const edit = edits.allEdits.at(edits.activeEditIndex);
		if (!edit) {
			return;
		}
		const resolvedEdit = await resolve2(edit, token);
		if (token.isCancellationRequested) {
			return;
		}
		const combinedWorkspaceEdit = createCombinedWorkspaceEdit(model.uri, ranges, resolvedEdit);
		const primaryRange = ranges[0];
		const editTrackingDecoration = model.deltaDecorations(
			[],
			[
				{
					range: primaryRange,
					options: {
						description: 'paste-line-suffix',
						stickiness: 0 // AlwaysGrowsWhenTypingAtEdges
					}
				}
			]
		);
		this._editor.focus();
		let editResult;
		let editRange;
		try {
			editResult = await this._bulkEditService.apply(combinedWorkspaceEdit, { editor: this._editor, token });
			editRange = model.getDecorationRange(editTrackingDecoration[0]);
		} finally {
			model.deltaDecorations(editTrackingDecoration, []);
		}
		if (token.isCancellationRequested) {
			return;
		}
		if (canShowWidget && editResult.isApplied && edits.allEdits.length > 1) {
			this.show(editRange !== null && editRange !== undefined ? editRange : primaryRange, edits, async newEditIndex => {
				const model2 = this._editor.getModel();
				if (!model2) {
					return;
				}
				await model2.undo();
				await this.applyEditAndShowIfNeeded(
					ranges,
					{
						activeEditIndex: newEditIndex,
						allEdits: edits.allEdits
					},
					canShowWidget,
					resolve2,
					token
				);
			});
		}
	}
	show(range2, edits, onDidSelectEdit) {
		this.clear();
		if (this._editor.hasModel()) {
			this._currentWidget.value = this._instantiationService.createInstance(
				PostEditWidget,
				this._id,
				this._editor,
				this._visibleContext,
				this._showCommand,
				range2,
				edits,
				onDidSelectEdit
			);
		}
	}
	clear() {
		this._currentWidget.clear();
	}
	tryShowSelector() {
		this._currentWidget.value?.showSelector();
	}
}
__decorate(
	[
		__param(4, IInstantiationService),
		__param(5, IBulkEditService)
		//...
	],
	PostEditWidgetManager
);


		this._postPasteWidgetManager = this._register(
			instantiationService.createInstance(PostEditWidgetManager, 'pasteIntoEditor', editor2, ck_pasteWidgetVisible, {
				id: changePasteTypeCommand_id,
				label: localize('Show paste options...')
			})
		);


		const changePasteTypeCommand_id = 'editor.changePasteType';
			changePasteType() {
		this._postPasteWidgetManager.tryShowSelector();
	}

		clearWidgets() {
		this._postPasteWidgetManager.clear();
	}


				if (providerEdits.length) {
					const canShowWidget =
						editor2.getOption(
							85 // pasteAs
						).showPasteSelector === 'afterPaste';
					return this._postPasteWidgetManager.applyEditAndShowIfNeeded(
						selections,
						{ activeEditIndex: 0, allEdits: providerEdits },
						canShowWidget,
						async (edit, token2) => {
							const resolved = await edit.provider?.resolveDocumentPasteEdit.call(edit.provider, edit, token2);
							if (resolved) {
								edit.additionalEdit = resolved.additionalEdit;
							}
							return edit;
						},
						tokenSource.token
					);
				}