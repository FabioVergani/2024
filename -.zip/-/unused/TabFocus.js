

class TabFocus {
	constructor() {
		this._tabFocus = false;
		this._onDidChangeTabFocus = new Emitter();
		this.onDidChangeTabFocus = this._onDidChangeTabFocus.event;
	}
	getTabFocusMode() {
		return this._tabFocus;
	}
	setTabFocusMode(tabFocusMode) {
		this._tabFocus = tabFocusMode;
		this._onDidChangeTabFocus.fire(this._tabFocus);
	}
}
const tabFocus = new TabFocus();

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



tabFocusMode: tabFocus.getTabFocusMode(),
	tabFocusMode: registerEditorOption(new EditorBooleanOption(144, 'tabFocusMode', false)),
this._register(tabFocus.onDidChangeTabFocus(() => this._recomputeOptions()));

this._register(tabFocus.onDidChangeTabFocus(tabFocusMode => this._tabMovesFocus.set(tabFocusMode)));


this._tabMovesFocus.set(tabFocus.getTabFocusMode());