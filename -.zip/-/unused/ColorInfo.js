



const createColor0 = (r, g, b, a) => {
	return {
		red: r,
		green: g,
		blue: b,
		alpha: a
	};
};

const isValidColor0 = e => {
	return (
		isNumberInRange(e.red, 0, 1) && isNumberInRange(e.green, 0, 1) && isNumberInRange(e.blue, 0, 1) && isNumberInRange(e.alpha, 0, 1)
	);
};

const createColorInformation = (range, color) => ({ range: range, color: color });

const isValidColorInformation = e => isValidRange0(e.range) && isValidColor0(e.color);

