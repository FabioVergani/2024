class InPlaceReplaceCommand {
	constructor(editRange, originalSelection, text2) {
		this._editRange = editRange;
		this._originalSelection = originalSelection;
		this._text = text2;
	}
	getEditOperations(model, builder) {
		builder.addTrackedEditOperation(this._editRange, this._text);
	}
	computeCursorState(model, helper) {
		const inverseEditOperations = helper.getInverseEditOperations();
		const srcRange = inverseEditOperations[0].range;
		if (!this._originalSelection.isEmpty()) {
			return new EditorSelection(
				srcRange.endLineNumber,
				srcRange.endColumn - this._text.length,
				srcRange.endLineNumber,
				srcRange.endColumn
			);
		}
		return new EditorSelection(
			srcRange.endLineNumber,
			Math.min(this._originalSelection.positionColumn, srcRange.endColumn),
			srcRange.endLineNumber,
			Math.min(this._originalSelection.positionColumn, srcRange.endColumn)
		);
	}
}
