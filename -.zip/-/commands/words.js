class MoveWordCommand extends EditorCommand {
	constructor(opts) {
		super(opts);
		this._inSelectionMode = opts.inSelectionMode;
		this._wordNavigationType = opts.wordNavigationType;
	}
	runEditorCommand(accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const wordSeparators2 = getMapForWordSeparators(
			editor2.getOption(
				131 // wordSeparators
			),
			editor2.getOption(
				130 // wordSegmenterLocales
			)
		);
		const model = editor2.getModel();
		const selections = editor2.getSelections();
		const result = selections.map(sel => {
			const inPosition = new Position(sel.positionLineNumber, sel.positionColumn);
			const outPosition = this._move(wordSeparators2, model, inPosition, this._wordNavigationType);
			return this._moveTo(sel, outPosition, this._inSelectionMode);
		});
		model.pushStackElement();
		editor2._getViewModel().setCursorStates(
			'moveWordCommand',
			3,
			result.map(r => CursorState.fromModelSelection(r))
		);
		if (result.length === 1) {
			const pos = new Position(result[0].positionLineNumber, result[0].positionColumn);
			editor2.revealPosition(
				pos,
				0 // Smooth
			);
		}
	}
	_moveTo(from, to, inSelectionMode) {
		if (inSelectionMode) {
			return new EditorSelection(from.selectionStartLineNumber, from.selectionStartColumn, to.lineNumber, to.column);
		} else {
			return new EditorSelection(to.lineNumber, to.column, to.lineNumber, to.column);
		}
	}
}

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class WordLeftCommand extends MoveWordCommand {
	_move(wordSeparators2, model, position, wordNavigationType) {
		return WordOperations.moveWordLeft(wordSeparators2, model, position, wordNavigationType);
	}
}
class WordRightCommand extends MoveWordCommand {
	_move(wordSeparators2, model, position, wordNavigationType) {
		return WordOperations.moveWordRight(wordSeparators2, model, position, wordNavigationType);
	}
}

class CursorWordLeft extends WordLeftCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 1,
			id: 'cursorWordLeft',
			kbOpts: {
				kbExpr: ContextKeyExpr.and(ctxKeys_inputFocus_text, ContextKeyExpr.and(IsWindowsContext)?.negate()),
				primary: 2048 | 15,
				mac: {
					primary: 512 | 15 //KeyCode.LeftArrow
				},
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorCommand(new CursorWordLeft());
class CursorWordLeftSelect extends WordLeftCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 1,
			id: 'cursorWordLeftSelect',
			kbOpts: {
				kbExpr: ContextKeyExpr.and(ctxKeys_inputFocus_text, ContextKeyExpr.and(IsWindowsContext)?.negate()),
				primary: 2048 | 1024 | 15,
				mac: {
					primary: 512 | 1024 | 15 // KeyCode.LeftArrow
				},
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorCommand(new CursorWordLeftSelect());

class CursorWordStartLeft extends WordLeftCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 0,
			id: 'cursorWordStartLeft'
		});
	}
}
registerEditorCommand(new CursorWordStartLeft());
class CursorWordStartLeftSelect extends WordLeftCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 0,
			id: 'cursorWordStartLeftSelect'
		});
	}
}
registerEditorCommand(new CursorWordStartLeftSelect());

class CursorWordEndLeft extends WordLeftCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 2,
			id: 'cursorWordEndLeft'
		});
	}
}
registerEditorCommand(new CursorWordEndLeft());
class CursorWordEndLeftSelect extends WordLeftCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 2,
			id: 'cursorWordEndLeftSelect'
		});
	}
}
registerEditorCommand(new CursorWordEndLeftSelect());

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class CursorWordRight extends WordRightCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 2,
			id: 'cursorWordRight'
		});
	}
}
registerEditorCommand(new CursorWordRight());
class CursorWordRightSelect extends WordRightCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 2,
			id: 'cursorWordRightSelect'
		});
	}
}
registerEditorCommand(new CursorWordRightSelect());

class CursorWordStartRight extends WordRightCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 0,
			id: 'cursorWordStartRight'
		});
	}
}
registerEditorCommand(new CursorWordStartRight());
class CursorWordStartRightSelect extends WordRightCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 0,
			id: 'cursorWordStartRightSelect'
		});
	}
}
registerEditorCommand(new CursorWordStartRightSelect());

class CursorWordEndRight extends WordRightCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 2,
			id: 'cursorWordEndRight',
			kbOpts: {
				kbExpr: ContextKeyExpr.and(ctxKeys_inputFocus_text, ContextKeyExpr.and(IsWindowsContext)?.negate()),
				primary: 2048 | 17,
				mac: {
					primary: 512 | 17 //KeyCode.RightArrow
				},
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorCommand(new CursorWordEndRight());
class CursorWordEndRightSelect extends WordRightCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 2,
			id: 'cursorWordEndRightSelect',
			kbOpts: {
				kbExpr: ContextKeyExpr.and(ctxKeys_inputFocus_text, ContextKeyExpr.and(IsWindowsContext)?.negate()),
				primary: 2048 | 1024 | 17,
				mac: {
					primary: 512 | 1024 | 17 //KeyCode.RightArrow
				},
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorCommand(new CursorWordEndRightSelect());

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class DeleteWordCommand extends EditorCommand {
	constructor(opts) {
		super(opts);
		this._whitespaceHeuristics = opts.whitespaceHeuristics;
		this._wordNavigationType = opts.wordNavigationType;
	}
	runEditorCommand(accessor, editor2) {
		const languageConfigurationService = accessor.get(ILanguageConfigurationService);
		if (!editor2.hasModel()) {
			return;
		}
		const wordSeparators2 = getMapForWordSeparators(
			editor2.getOption(
				131 // wordSeparators
			),
			editor2.getOption(
				130 // wordSegmenterLocales
			)
		);
		const model = editor2.getModel();
		const selections = editor2.getSelections();
		const autoClosingBrackets = editor2.getOption(
			6 // autoClosingBrackets
		);
		const autoClosingQuotes = editor2.getOption(
			11 // autoClosingQuotes
		);
		const autoClosingPairs = languageConfigurationService.getLanguageConfiguration(model.getLanguageId()).getAutoClosingPairs();
		const viewModel = editor2._getViewModel();
		const commands = selections.map(sel => {
			const deleteRange = this._delete(
				{
					wordSeparators: wordSeparators2,
					model,
					selection: sel,
					whitespaceHeuristics: this._whitespaceHeuristics,
					autoClosingDelete: editor2.getOption(
						9 // autoClosingDelete
					),
					autoClosingBrackets,
					autoClosingQuotes,
					autoClosingPairs,
					autoClosedCharacters: viewModel.getCursorAutoClosedCharacters()
				},
				this._wordNavigationType
			);
			return new ReplaceCommand(deleteRange, '');
		});
		editor2.pushUndoStop();
		editor2.executeCommands(this.id, commands);
		editor2.pushUndoStop();
	}
}

class DeleteWordLeftCommand extends DeleteWordCommand {
	_delete(ctx, wordNavigationType) {
		const r = WordOperations.deleteWordLeft(ctx, wordNavigationType);
		if (r) {
			return r;
		}
		return new Range(1, 1, 1, 1);
	}
}
class DeleteWordRightCommand extends DeleteWordCommand {
	_delete(ctx, wordNavigationType) {
		const r = WordOperations.deleteWordRight(ctx, wordNavigationType);
		if (r) {
			return r;
		}
		const lineCount = ctx.model.getLineCount();
		const maxColumn = ctx.model.getLineMaxColumn(lineCount);
		return new Range(lineCount, maxColumn, lineCount, maxColumn);
	}
}

class DeleteWordStartLeft extends DeleteWordLeftCommand {
	constructor() {
		super({
			whitespaceHeuristics: false,
			wordNavigationType: 0,
			id: 'deleteWordStartLeft',
			precondition: ctxKeys_writable
		});
	}
}
registerEditorCommand(new DeleteWordStartLeft());
class DeleteWordStartRight extends DeleteWordRightCommand {
	constructor() {
		super({
			whitespaceHeuristics: false,
			wordNavigationType: 0,
			id: 'deleteWordStartRight',
			precondition: ctxKeys_writable
		});
	}
}
registerEditorCommand(new DeleteWordStartRight());

class DeleteWordEndLeft extends DeleteWordLeftCommand {
	constructor() {
		super({
			whitespaceHeuristics: false,
			wordNavigationType: 2,
			id: 'deleteWordEndLeft',
			precondition: ctxKeys_writable
		});
	}
}
registerEditorCommand(new DeleteWordEndLeft());
class DeleteWordEndRight extends DeleteWordRightCommand {
	constructor() {
		super({
			whitespaceHeuristics: false,
			wordNavigationType: 2,
			id: 'deleteWordEndRight',
			precondition: ctxKeys_writable
		});
	}
}
registerEditorCommand(new DeleteWordEndRight());

class DeleteWordLeft extends DeleteWordLeftCommand {
	constructor() {
		super({
			whitespaceHeuristics: true,
			wordNavigationType: 0,
			id: 'deleteWordLeft',
			precondition: ctxKeys_writable,
			kbOpts: {
				kbExpr: ctxKeys_inputFocus_text,
				primary: 2048 | 1,
				mac: {
					primary: 512 | 1 //KeyCode.Backspace
				},
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorCommand(new DeleteWordLeft());
class DeleteWordRight extends DeleteWordRightCommand {
	constructor() {
		super({
			whitespaceHeuristics: true,
			wordNavigationType: 2,
			id: 'deleteWordRight',
			precondition: ctxKeys_writable,
			kbOpts: {
				kbExpr: ctxKeys_inputFocus_text,
				primary: 2048 | 20,
				mac: {
					primary: 512 | 20 //KeyCode.Delete
				},
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorCommand(new DeleteWordRight());

class DeleteInsideWord extends EditorAction {
	constructor() {
		super({
			id: 'deleteInsideWord',
			precondition: ctxKeys_writable,
			label: localize('Delete Word'),
			alias: 'Delete Word'
		});
	}
	run(accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const wordSeparators2 = getMapForWordSeparators(
			editor2.getOption(
				131 // wordSeparators
			),
			editor2.getOption(
				130 // wordSegmenterLocales
			)
		);
		const model = editor2.getModel();
		const selections = editor2.getSelections();
		const commands = selections.map(sel => {
			const deleteRange = WordOperations.deleteInsideWord(wordSeparators2, model, sel);
			return new ReplaceCommand(deleteRange, '');
		});
		editor2.pushUndoStop();
		editor2.executeCommands(this.id, commands);
		editor2.pushUndoStop();
	}
}
registerEditorAction(DeleteInsideWord);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class DeleteWordPartLeft extends DeleteWordCommand {
	constructor() {
		super({
			whitespaceHeuristics: true,
			wordNavigationType: 0,
			id: 'deleteWordPartLeft',
			precondition: ctxKeys_writable,
			kbOpts: {
				kbExpr: ctxKeys_inputFocus_text,
				primary: 0,
				mac: {
					primary: 256 | 512 | 1 //KeyCode.Backspace
				},
				weight: 100 //editorContrib
			}
		});
	}
	_delete(ctx) {
		const r = WordPartOperations.deleteWordPartLeft(ctx);
		if (r) {
			return r;
		}
		return new Range(1, 1, 1, 1);
	}
}
registerEditorCommand(new DeleteWordPartLeft());

class DeleteWordPartRight extends DeleteWordCommand {
	constructor() {
		super({
			whitespaceHeuristics: true,
			wordNavigationType: 2,
			id: 'deleteWordPartRight',
			precondition: ctxKeys_writable,
			kbOpts: {
				kbExpr: ctxKeys_inputFocus_text,
				primary: 0,
				mac: {
					primary: 256 | 512 | 20 // KeyCode.Delete
				},
				weight: 100 //editorContrib
			}
		});
	}
	_delete(ctx) {
		const r = WordPartOperations.deleteWordPartRight(ctx);
		if (r) {
			return r;
		}
		const lineCount = ctx.model.getLineCount();
		const maxColumn = ctx.model.getLineMaxColumn(lineCount);
		return new Range(lineCount, maxColumn, lineCount, maxColumn);
	}
}
registerEditorCommand(new DeleteWordPartRight());

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class WordPartLeftCommand extends MoveWordCommand {
	_move(wordSeparators, model, position) {
		return WordPartOperations.moveWordPartLeft(wordSeparators, model, position);
	}
}

class CursorWordPartLeft extends WordPartLeftCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 0,
			id: 'cursorWordPartLeft',
			kbOpts: {
				kbExpr: ctxKeys_inputFocus_text,
				primary: 0,
				mac: {
					primary: 256 | 512 | 15 // KeyCode.LeftArrow
				},
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorCommand(new CursorWordPartLeft());

class CursorWordPartLeftSelect extends WordPartLeftCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 0,
			id: 'cursorWordPartLeftSelect',
			kbOpts: {
				kbExpr: ctxKeys_inputFocus_text,
				primary: 0,
				mac: {
					primary: 256 | 512 | 1024 | 15 // LeftArrow
				},
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorCommand(new CursorWordPartLeftSelect());

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -


class WordPartRightCommand extends MoveWordCommand {
	_move(wordSeparators, model, position) {
		return WordPartOperations.moveWordPartRight(wordSeparators, model, position);
	}
}

class CursorWordPartRight extends WordPartRightCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 2,
			id: 'cursorWordPartRight',
			kbOpts: {
				kbExpr: ctxKeys_inputFocus_text,
				primary: 0,
				mac: {
					primary: 785 // RightArrow 256 | 512 | 17
				},
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorCommand(new CursorWordPartRight());

class CursorWordPartRightSelect extends WordPartRightCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 2,
			id: 'cursorWordPartRightSelect',
			kbOpts: {
				kbExpr: ctxKeys_inputFocus_text,
				primary: 0,
				mac: {
					primary: 1809 // RightArrow 256 | 512 | 1024 | 17
				},
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorCommand(new CursorWordPartRightSelect());