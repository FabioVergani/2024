const IEditorCancellationTokens = createEditorServiceDecorator('IEditorCancelService');

const ctxCancellableOperation = new RawContextKey(
	'cancellableOperation',
	false,
	localize("Whether the editor runs a cancellable operation, e.g. like 'Peek References'")
);

registerSingleton(
	IEditorCancellationTokens,
	class {
		constructor() {
			this._tokens = new WeakMap();
		}
		add(editor2, cts) {
			let data = this._tokens.get(editor2);
			if (!data) {
				data = editor2.invokeWithinContext(accessor => {
					const key = ctxCancellableOperation.bindTo(accessor.get(IContextKeyService));
					const tokens = new LinkedList();
					return { key, tokens };
				});
				this._tokens.set(editor2, data);
			}
			let removeFn;
			data.key.set(true);
			removeFn = data.tokens.push(cts);
			return () => {
				if (removeFn) {
					removeFn();
					data.key.set(!data.tokens.isEmpty());
					removeFn = undefined;
				}
			};
		}
		cancel(editor2) {
			const data = this._tokens.get(editor2);
			if (!data) {
				return;
			}
			const cts = data.tokens.pop();
			if (cts) {
				cts.cancel();
				data.key.set(!data.tokens.isEmpty());
			}
		}
	},
	1 //InstantiationType.Delayed
);

class CancelOperationCmd extends EditorCommand {
	constructor() {
		super({
			id: 'editor.cancelOperation',
			kbOpts: {
				weight: 100,
				primary: 9 //Escape
			},
			precondition: ctxCancellableOperation
		});
	}
	runEditorCommand(accessor, editor2) {
		accessor.get(IEditorCancellationTokens).cancel(editor2);
	}
}
const cancelOperationCmd = new CancelOperationCmd();
registerEditorCommand(cancelOperationCmd);