













// node_modules/monaco-editor/esm/vs/editor/contrib/gotoSymbol/browser/goToSymbol.js
async function getLocationLinks(model, position, registry, provide) {
	const provider = registry.ordered(model);
	const promises = provider.map(provider2 => {
		return Promise.resolve(provide(provider2, model, position)).then(undefined, err => {
			onUnexpectedExternalError(err);
			return;
		});
	});
	const values = await Promise.all(promises);
	return values.flat().filter(e => !!e);
}
function getDefinitionsAtPosition(registry, model, position, token) {
	return getLocationLinks(model, position, registry, (provider, model2, position2) => {
		return provider.provideDefinition(model2, position2, token);
	});
}
function getDeclarationsAtPosition(registry, model, position, token) {
	return getLocationLinks(model, position, registry, (provider, model2, position2) => {
		return provider.provideDeclaration(model2, position2, token);
	});
}
function getImplementationsAtPosition(registry, model, position, token) {
	return getLocationLinks(model, position, registry, (provider, model2, position2) => {
		return provider.provideImplementation(model2, position2, token);
	});
}
function getTypeDefinitionsAtPosition(registry, model, position, token) {
	return getLocationLinks(model, position, registry, (provider, model2, position2) => {
		return provider.provideTypeDefinition(model2, position2, token);
	});
}
function getReferencesAtPosition(registry, model, position, compact, token) {
	return getLocationLinks(model, position, registry, async (provider, model2, position2) => {
		const result = await provider.provideReferences(model2, position2, { includeDeclaration: true }, token);
		if (!compact || !result || result.length !== 2) {
			return result;
		}
		const resultWithoutDeclaration = await provider.provideReferences(model2, position2, { includeDeclaration: false }, token);
		if (resultWithoutDeclaration && resultWithoutDeclaration.length === 1) {
			return resultWithoutDeclaration;
		}
		return result;
	});
}
async function _sortedAndDeduped(callback) {
	const rawLinks = await callback();
	const model = new ReferencesModel(rawLinks, '');
	const modelLinks = model.references.map(ref => ref.link);
	model.dispose();
	return modelLinks;
}
registerModelAndPositionCommand('_executeDefinitionProvider', (accessor, model, position) => {
	const languageFeaturesService = accessor.get(ILanguageFeaturesService);
	const promise = getDefinitionsAtPosition(languageFeaturesService.definitionProvider, model, position, cancellationToken_none);
	return _sortedAndDeduped(() => promise);
});
registerModelAndPositionCommand('_executeTypeDefinitionProvider', (accessor, model, position) => {
	const languageFeaturesService = accessor.get(ILanguageFeaturesService);
	const promise = getTypeDefinitionsAtPosition(languageFeaturesService.typeDefinitionProvider, model, position, cancellationToken_none);
	return _sortedAndDeduped(() => promise);
});
registerModelAndPositionCommand('_executeDeclarationProvider', (accessor, model, position) => {
	const languageFeaturesService = accessor.get(ILanguageFeaturesService);
	const promise = getDeclarationsAtPosition(languageFeaturesService.declarationProvider, model, position, cancellationToken_none);
	return _sortedAndDeduped(() => promise);
});
registerModelAndPositionCommand('_executeReferenceProvider', (accessor, model, position) => {
	const languageFeaturesService = accessor.get(ILanguageFeaturesService);
	const promise = getReferencesAtPosition(languageFeaturesService.referenceProvider, model, position, false, cancellationToken_none);
	return _sortedAndDeduped(() => promise);
});
registerModelAndPositionCommand('_executeImplementationProvider', (accessor, model, position) => {
	const languageFeaturesService = accessor.get(ILanguageFeaturesService);
	const promise = getImplementationsAtPosition(languageFeaturesService.implementationProvider, model, position, cancellationToken_none);
	return _sortedAndDeduped(() => promise);
});











menuRegistry.appendMenuItem(editorContext_menuId, {
	submenu: editorContextPeek_menuId,
	title: localize('Peek'),
	group: 'navigation',
	order: 100
});

class SymbolNavigationAnchor {
	static is(thing) {
		if (!thing || typeof thing !== 'object') {
			return false;
		}
		if (thing instanceof SymbolNavigationAnchor) {
			return true;
		}
		if (Position.isIPosition(thing.position) && thing.model) {
			return true;
		}
		return false;
	}
	constructor(model, position) {
		this.model = model;
		this.position = position;
	}
}

class SymbolNavigationAction extends EditorAction2 {
	static all() {
		return SymbolNavigationAction._allSymbolNavigationCommands.values();
	}
	static _patchConfig(opts) {
		const result = { ...opts, f1: true };
		if (result.menu) {
			const resultMenu = result.menu;
			function* iterableSingle(e) {
				yield e;
			}
			for (const item of isIterable(resultMenu) ? resultMenu : iterableSingle(resultMenu)) {
				if (item.id === editorContext_menuId || item.id === editorContextPeek_menuId) {
					item.when = ContextKeyExpr.and(opts.precondition, item.when);
				}
			}
		}
		return result;
	}
	constructor(configuration, opts) {
		super(SymbolNavigationAction._patchConfig(opts));
		this.configuration = configuration;
		SymbolNavigationAction._allSymbolNavigationCommands.set(opts.id, this);
	}
	runEditorCommand(accessor, editor2, arg, range2) {
		if (!editor2.hasModel()) {
			return Promise.resolve(undefined);
		}
		const notificationService = accessor.get(INotificationService);
		const editorService = accessor.get(ICodeEditorService);
		const progressService = accessor.get(IEditorProgressService);
		const symbolNavService = accessor.get(ISymbolNavigationService);
		const languageFeaturesService = accessor.get(ILanguageFeaturesService);
		const instaService = accessor.get(IInstantiationService);
		const model = editor2.getModel();
		const position = editor2.getPosition();
		const anchor = SymbolNavigationAnchor.is(arg) ? arg : new SymbolNavigationAnchor(model, position);
		const cts = new EditorStateCancellationTokenSource(
			editor2,
			1 | 4 //CodeEditorStateFlag.Position */
		);
		const promise = raceCancellation(
			this._getLocationModel(languageFeaturesService, anchor.model, anchor.position, cts.token),
			cts.token
		)
			.then(
				async references => {
					var _j;
					if (!references || cts.token.isCancellationRequested) {
						return;
					}
					let altAction;
					if (references.referenceAt(model.uri, position)) {
						const altActionId = this._getAlternativeCommand(editor2);
						if (
							!SymbolNavigationAction._activeAlternativeCommands.has(altActionId) &&
							SymbolNavigationAction._allSymbolNavigationCommands.has(altActionId)
						) {
							altAction = SymbolNavigationAction._allSymbolNavigationCommands.get(altActionId);
						}
					}
					const referenceCount = references.references.length;
					if (referenceCount === 0) {
						if (!this.configuration.muteMessage) {
							const info = model.getWordAtPosition(position);
							(_j = MessageController.get(editor2)) === null || _j === undefined
								? undefined
								: _j.showMessage(this._getNoResultFoundMessage(info), position);
						}
					} else if (referenceCount === 1 && altAction) {
						SymbolNavigationAction._activeAlternativeCommands.add(this.desc.id);
						instaService.invokeFunction(accessor2 =>
							altAction.runEditorCommand(accessor2, editor2, arg, range2).finally(() => {
								SymbolNavigationAction._activeAlternativeCommands.delete(this.desc.id);
							})
						);
					} else {
						return this._onResult(editorService, symbolNavService, editor2, references, range2);
					}
				},
				err => {
					notificationService.error(err);
				}
			)
			.finally(() => {
				cts.dispose();
			});
		progressService.showWhile(promise, 250);
		return promise;
	}
	async _onResult(editorService, symbolNavService, editor2, model, range2) {
		const gotoLocation = this._getGoToPreference(editor2);
		if (
			!(editor2 instanceof EmbeddedCodeEditorWidget) &&
			(this.configuration.openInPeek || (gotoLocation === 'peek' && model.references.length > 1))
		) {
			this._openInPeek(editor2, model, range2);
		} else {
			const next = model.firstReference();
			const peek = model.references.length > 1 && gotoLocation === 'gotoAndPeek';
			const targetEditor = await this._openReference(editor2, editorService, next, this.configuration.openToSide, !peek);
			if (peek && targetEditor) {
				this._openInPeek(targetEditor, model, range2);
			} else {
				model.dispose();
			}
			if (gotoLocation === 'goto') {
				symbolNavService.put(next);
			}
		}
	}
	async _openReference(editor2, editorService, reference, sideBySide, highlight) {
		let range2;
		if (
			reference &&
			URI.isUri(reference.uri) &&
			Range.isIRange(reference.range) &&
			(Range.isIRange(reference.originSelectionRange) || Range.isIRange(reference.targetSelectionRange))
		) {
			range2 = reference.targetSelectionRange;
		}
		if (!range2) {
			range2 = reference.range;
		}
		if (!range2) {
			return;
		}
		const targetEditor = await editorService.openCodeEditor(
			{
				resource: reference.uri,
				options: {
					selection: Range.collapseToStart(range2),
					selectionRevealType: 3,
					selectionSource: 'code.jump' // TextEditorSelectionSource.JUMP */
				}
			},
			editor2,
			sideBySide
		);
		if (!targetEditor) {
			return;
		}
		if (highlight) {
			const modelNow = targetEditor.getModel();
			const decorations = targetEditor.createDecorationsCollection([
				{
					range: range2,
					options: {
						description: 'symbol-navigate-action-highlight',
						className: 'symbolHighlight'
					}
				}
			]);
			setTimeout(() => {
				if (targetEditor.getModel() === modelNow) {
					decorations.clear();
				}
			}, 350);
		}
		return targetEditor;
	}
	_openInPeek(target, model, range2) {
		const controller = getReferencesControllerOf(target);
		if (controller && target.hasModel()) {
			controller.toggleWidget(
				range2 !== null && range2 !== undefined ? range2 : target.getSelection(),
				createCancelablePromise(_ => Promise.resolve(model)),
				this.configuration.openInPeek
			);
		} else {
			model.dispose();
		}
	}
}
SymbolNavigationAction._allSymbolNavigationCommands = new Map();
SymbolNavigationAction._activeAlternativeCommands = new Set();

class DefinitionAction extends SymbolNavigationAction {
	async _getLocationModel(languageFeaturesService, model, position, token) {
		return new ReferencesModel(
			await getDefinitionsAtPosition(languageFeaturesService.definitionProvider, model, position, token),
			localize('Definitions')
		);
	}
	_getNoResultFoundMessage(info) {
		return info && info.word ? localize("No definition found for '{0}'", info.word) : localize('No definition found');
	}
	_getAlternativeCommand(editor2) {
		return editor2.getOption(
			58 // gotoLocation
		).alternativeDefinitionCommand;
	}
	_getGoToPreference(editor2) {
		return editor2.getOption(
			58 // gotoLocation
		).multipleDefinitions;
	}
}

class GoToDefinitionAction extends DefinitionAction {
	constructor() {
		super(
			{ openToSide: false, openInPeek: false, muteMessage: false },
			{
				id: GoToDefinitionAction.id,
				title: localize('Go to Definition'),
				precondition: ck_editorHasProvider_definition,
				keybinding: [
					{
						when: ck_editorFocus_text,
						primary: 70,
						weight: 100 /* KeybindingWeight.EditorContrib */
					},
					{
						when: ContextKeyExpr.and(ck_editorFocus_text, IsWebContext),
						primary: 2048 | 70,
						weight: 100 /* KeybindingWeight.EditorContrib */
					}
				],
				menu: [
					{
						id: editorContext_menuId,
						group: 'navigation',
						order: 1.1
					},
					{
						id: menubarGoMenu_menuId,
						precondition: null,
						group: '4_symbol_nav',
						order: 2
					}
				]
			}
		);
		commandsRegistry.registerCommandAlias('editor.action.goToDeclaration', GoToDefinitionAction.id);
	}
}
GoToDefinitionAction.id = 'editor.action.revealDefinition';
registerEditorAction2(GoToDefinitionAction);

const ck_isInEmbeddedEditor = new RawContextKey('isInEmbeddedEditor', false, true);
class OpenDefinitionToSideAction extends DefinitionAction {
	constructor() {
		super(
			{ openToSide: true, openInPeek: false, muteMessage: false },
			{
				id: OpenDefinitionToSideAction.id,
				title: localize('Open Definition to the Side'),
				precondition: ContextKeyExpr.and(ck_editorHasProvider_definition, ck_isInEmbeddedEditor.toNegated()),
				keybinding: [
					{
						when: ck_editorFocus_text,
						primary: KeyChord(
							2048 | 41,
							70 // F12
						),
						weight: 100 /* KeybindingWeight.EditorContrib */
					},
					{
						when: ContextKeyExpr.and(ck_editorFocus_text, IsWebContext),
						primary: KeyChord(
							2048 | 41,
							2048 | 70 // F12
						),
						weight: 100 /* KeybindingWeight.EditorContrib */
					}
				]
			}
		);
		commandsRegistry.registerCommandAlias('editor.action.openDeclarationToTheSide', OpenDefinitionToSideAction.id);
	}
}
OpenDefinitionToSideAction.id = 'editor.action.revealDefinitionAside';
registerEditorAction2(OpenDefinitionToSideAction);

class PeekDefinitionAction extends DefinitionAction {
	constructor() {
		super(
			{ openToSide: false, openInPeek: true, muteMessage: false },
			{
				id: PeekDefinitionAction.id,
				title: localize('Peek Definition'),
				precondition: ContextKeyExpr.and(ck_editorHasProvider_definition, ck_notInPeekEditor, ck_isInEmbeddedEditor.toNegated()),
				keybinding: {
					when: ck_editorFocus_text,
					primary: 512 | 70,
					linux: {
						primary: 2048 | 1024 | 68 // F10
					},
					weight: 100 /* KeybindingWeight.EditorContrib */
				},
				menu: { id: editorContextPeek_menuId, group: 'peek', order: 2 }
			}
		);
		commandsRegistry.registerCommandAlias('editor.action.previewDeclaration', PeekDefinitionAction.id);
	}
}
PeekDefinitionAction.id = 'editor.action.peekDefinition';
registerEditorAction2(PeekDefinitionAction);

class DeclarationAction extends SymbolNavigationAction {
	async _getLocationModel(languageFeaturesService, model, position, token) {
		return new ReferencesModel(
			await getDeclarationsAtPosition(languageFeaturesService.declarationProvider, model, position, token),
			localize('Declarations')
		);
	}
	_getNoResultFoundMessage(info) {
		return info && info.word ? localize("No declaration found for '{0}'", info.word) : localize('No declaration found');
	}
	_getAlternativeCommand(editor2) {
		return editor2.getOption(
			58 // gotoLocation
		).alternativeDeclarationCommand;
	}
	_getGoToPreference(editor2) {
		return editor2.getOption(
			58 // gotoLocation
		).multipleDeclarations;
	}
}
class GoToDeclarationAction extends DeclarationAction {
	constructor() {
		super(
			{ openToSide: false, openInPeek: false, muteMessage: false },
			{
				id: GoToDeclarationAction.id,
				title: localize('Go to Declaration'),
				precondition: ContextKeyExpr.and(ck_editorHasProvider_declaration, ck_isInEmbeddedEditor.toNegated()),
				menu: [
					{
						id: editorContext_menuId,
						group: 'navigation',
						order: 1.3
					},
					{
						id: menubarGoMenu_menuId,
						precondition: null,
						group: '4_symbol_nav',
						order: 3
					}
				]
			}
		);
	}
	_getNoResultFoundMessage(info) {
		return info && info.word ? localize("No declaration found for '{0}'", info.word) : localize('No declaration found');
	}
}
GoToDeclarationAction.id = 'editor.action.revealDeclaration';
registerEditorAction2(GoToDeclarationAction);

class PeekDeclarationAction extends DeclarationAction {
	constructor() {
		super(
			{ openToSide: false, openInPeek: true, muteMessage: false },
			{
				id: 'editor.action.peekDeclaration',
				title: localize('Peek Declaration'),
				precondition: ContextKeyExpr.and(ck_editorHasProvider_declaration, ck_notInPeekEditor, ck_isInEmbeddedEditor.toNegated()),
				menu: { id: editorContextPeek_menuId, group: 'peek', order: 3 }
			}
		);
	}
}
registerEditorAction2(PeekDeclarationAction);

class TypeDefinitionAction extends SymbolNavigationAction {
	async _getLocationModel(languageFeaturesService, model, position, token) {
		return new ReferencesModel(
			await getTypeDefinitionsAtPosition(languageFeaturesService.typeDefinitionProvider, model, position, token),
			localize('Type Definitions')
		);
	}
	_getNoResultFoundMessage(info) {
		return info && info.word ? localize("No type definition found for '{0}'", info.word) : localize('No type definition found');
	}
	_getAlternativeCommand(editor2) {
		return editor2.getOption(
			58 // gotoLocation
		).alternativeTypeDefinitionCommand;
	}
	_getGoToPreference(editor2) {
		return editor2.getOption(
			58 // gotoLocation
		).multipleTypeDefinitions;
	}
}
class GoToTypeDefinitionAction extends TypeDefinitionAction {
	constructor() {
		super(
			{ openToSide: false, openInPeek: false, muteMessage: false },
			{
				id: GoToTypeDefinitionAction.ID,
				title: localize('Go to Type Definition'),
				precondition: ck_editorHasProvider_typeDefinition,
				keybinding: {
					when: ck_editorFocus_text,
					primary: 0,
					weight: 100 /* KeybindingWeight.EditorContrib */
				},
				menu: [
					{
						id: editorContext_menuId,
						group: 'navigation',
						order: 1.4
					},
					{
						id: menubarGoMenu_menuId,
						precondition: null,
						group: '4_symbol_nav',
						order: 3
					}
				]
			}
		);
	}
}
GoToTypeDefinitionAction.ID = 'editor.action.goToTypeDefinition';
registerEditorAction2(GoToTypeDefinitionAction);

class PeekTypeDefinitionAction extends TypeDefinitionAction {
	constructor() {
		super(
			{ openToSide: false, openInPeek: true, muteMessage: false },
			{
				id: PeekTypeDefinitionAction.ID,
				title: localize('Peek Type Definition'),
				precondition: ContextKeyExpr.and(
					ck_editorHasProvider_typeDefinition,
					ck_notInPeekEditor,
					ck_isInEmbeddedEditor.toNegated()
				),
				menu: { id: editorContextPeek_menuId, group: 'peek', order: 4 }
			}
		);
	}
}
PeekTypeDefinitionAction.ID = 'editor.action.peekTypeDefinition';
registerEditorAction2(PeekTypeDefinitionAction);

class ImplementationAction extends SymbolNavigationAction {
	async _getLocationModel(languageFeaturesService, model, position, token) {
		return new ReferencesModel(
			await getImplementationsAtPosition(languageFeaturesService.implementationProvider, model, position, token),
			localize('Implementations')
		);
	}
	_getNoResultFoundMessage(info) {
		return info && info.word ? localize("No implementation found for '{0}'", info.word) : localize('No implementation found');
	}
	_getAlternativeCommand(editor2) {
		return editor2.getOption(
			58 // gotoLocation
		).alternativeImplementationCommand;
	}
	_getGoToPreference(editor2) {
		return editor2.getOption(
			58 // gotoLocation
		).multipleImplementations;
	}
}
class GoToImplementationAction extends ImplementationAction {
	constructor() {
		super(
			{ openToSide: false, openInPeek: false, muteMessage: false },
			{
				id: GoToImplementationAction.ID,
				title: localize('Go to Implementations'),
				precondition: ck_editorHasProvider_implementation,
				keybinding: {
					when: ck_editorFocus_text,
					primary: 2048 | 70,
					weight: 100 /* KeybindingWeight.EditorContrib */
				},
				menu: [
					{
						id: editorContext_menuId,
						group: 'navigation',
						order: 1.45
					},
					{
						id: menubarGoMenu_menuId,
						precondition: null,
						group: '4_symbol_nav',
						order: 4
					}
				]
			}
		);
	}
}
GoToImplementationAction.ID = 'editor.action.goToImplementation';
registerEditorAction2(GoToImplementationAction);

class PeekImplementationAction extends ImplementationAction {
	constructor() {
		super(
			{ openToSide: false, openInPeek: true, muteMessage: false },
			{
				id: PeekImplementationAction.ID,
				title: localize('Peek Implementations'),
				precondition: ContextKeyExpr.and(
					ck_editorHasProvider_implementation,
					ck_notInPeekEditor,
					ck_isInEmbeddedEditor.toNegated()
				),
				keybinding: {
					when: ck_editorFocus_text,
					primary: 2048 | 1024 | 70,
					weight: 100 /* KeybindingWeight.EditorContrib */
				},
				menu: { id: editorContextPeek_menuId, group: 'peek', order: 5 }
			}
		);
	}
}
PeekImplementationAction.ID = 'editor.action.peekImplementation';
registerEditorAction2(PeekImplementationAction);

class ReferencesAction extends SymbolNavigationAction {
	_getNoResultFoundMessage(info) {
		return info ? localize("No references found for '{0}'", info.word) : localize('No references found');
	}
	_getAlternativeCommand(editor2) {
		return editor2.getOption(
			58 // gotoLocation
		).alternativeReferenceCommand;
	}
	_getGoToPreference(editor2) {
		return editor2.getOption(
			58 // gotoLocation
		).multipleReferences;
	}
}
class GoToReferencesAction extends ReferencesAction {
	constructor() {
		super(
			{ openToSide: false, openInPeek: false, muteMessage: false },
			{
				id: 'editor.action.goToReferences',
				title: localize('Go to References'),
				precondition: ContextKeyExpr.and(ck_editorHasProvider_reference, ck_notInPeekEditor, ck_isInEmbeddedEditor.toNegated()),
				keybinding: {
					when: ck_editorFocus_text,
					primary: 1024 | 70,
					weight: 100 /* KeybindingWeight.EditorContrib */
				},
				menu: [
					{
						id: editorContext_menuId,
						group: 'navigation',
						order: 1.45
					},
					{
						id: menubarGoMenu_menuId,
						precondition: null,
						group: '4_symbol_nav',
						order: 5
					}
				]
			}
		);
	}
	async _getLocationModel(languageFeaturesService, model, position, token) {
		return new ReferencesModel(
			await getReferencesAtPosition(languageFeaturesService.referenceProvider, model, position, true, token),
			localize('References')
		);
	}
}
registerEditorAction2(GoToReferencesAction);

class PeekReferencesAction extends ReferencesAction {
	constructor() {
		super(
			{ openToSide: false, openInPeek: true, muteMessage: false },
			{
				id: 'editor.action.referenceSearch.trigger',
				title: localize('Peek References'),
				precondition: ContextKeyExpr.and(ck_editorHasProvider_reference, ck_notInPeekEditor, ck_isInEmbeddedEditor.toNegated()),
				menu: { id: editorContextPeek_menuId, group: 'peek', order: 6 }
			}
		);
	}
	async _getLocationModel(languageFeaturesService, model, position, token) {
		return new ReferencesModel(
			await getReferencesAtPosition(languageFeaturesService.referenceProvider, model, position, false, token),
			localize('References')
		);
	}
}
registerEditorAction2(PeekReferencesAction);

class GenericGoToLocationAction extends SymbolNavigationAction {
	constructor(config, _references, _gotoMultipleBehaviour) {
		super(config, {
			id: 'editor.action.goToLocation',
			title: localize('Go to Any Symbol'),
			precondition: ContextKeyExpr.and(ck_notInPeekEditor, ck_isInEmbeddedEditor.toNegated())
		});
		this._references = _references;
		this._gotoMultipleBehaviour = _gotoMultipleBehaviour;
	}
	async _getLocationModel(languageFeaturesService, _model, _position, _token) {
		return new ReferencesModel(this._references, localize('Locations'));
	}
	_getNoResultFoundMessage(info) {
		return (info && localize("No results for '{0}'", info.word)) || '';
	}
	_getGoToPreference(editor2) {
		var _j;
		return (_j = this._gotoMultipleBehaviour) !== null && _j !== undefined
			? _j
			: editor2.getOption(
					58 // gotoLocation
				).multipleReferences;
	}
	_getAlternativeCommand() {
		return '';
	}
}

class GoToLocationAction2 extends GenericGoToLocationAction {
	_getNoResultFoundMessage(info) {
		return noResultsMessage || super._getNoResultFoundMessage(info);
	}
}

commandsRegistry.registerCommand({
	id: 'editor.action.goToLocations',
	metadata: {
		description: 'Go to locations from a position in a file',
		args: [
			{
				name: 'uri',
				description: 'The text document in which to start',
				constraint: URI
			},
			{
				name: 'position',
				description: 'The position at which to start',
				constraint: Position.isIPosition
			},
			{
				name: 'locations',
				description: 'An array of locations.',
				constraint: Array
			},
			{
				name: 'multiple',
				description: 'Define what to do when having multiple results, either `peek`, `gotoAndPeek`, or `goto`'
			},
			{
				name: 'noResultsMessage',
				description: 'Human readable message that shows when locations is empty.'
			}
		]
	},
	handler: async (accessor, resource, position, references, multiple, noResultsMessage, openInPeek) => {
		if (
			(typeof multiple === 'undefined' || typeof multiple === 'string') &&
			(typeof openInPeek === 'undefined' || typeof openInPeek === 'boolean') &&
			isArray(references) &&
			URI.isUri(resource) &&
			Position.isIPosition(position)
		) {
			const editor = await accessor.get(ICodeEditorService).openCodeEditor({ resource }, editorService.getFocusedCodeEditor());
			if (isCodeEditor(editor)) {
				editor.setPosition(position);
				editor.revealPositionInCenterIfOutsideViewport(
					position,
					0 // Smooth
				);
				return editor.invokeWithinContext(accessor2 => {
					const command = new GoToLocationAction2(
						{
							muteMessage: !Boolean(noResultsMessage),
							openInPeek: Boolean(openInPeek),
							openToSide: false
						},
						references,
						multiple
					);
					accessor2.get(IInstantiationService).invokeFunction(command.run.bind(command), editor);
				});
			}
		}
	}
});
commandsRegistry.registerCommand({
	id: 'editor.action.peekLocations',
	metadata: {
		description: 'Peek locations from a position in a file',
		args: [
			{
				name: 'uri',
				description: 'The text document in which to start',
				constraint: URI
			},
			{
				name: 'position',
				description: 'The position at which to start',
				constraint: Position.isIPosition
			},
			{
				name: 'locations',
				description: 'An array of locations.',
				constraint: Array
			},
			{
				name: 'multiple',
				description: 'Define what to do when having multiple results, either `peek`, `gotoAndPeek`, or `goto`'
			}
		]
	},
	handler: async (accessor, resource, position, references, multiple) => {
		accessor
			.get(ICommandService)
			.executeCommand('editor.action.goToLocations', resource, position, references, multiple, undefined, true);
	}
});
commandsRegistry.registerCommand({
	id: 'editor.action.findReferences',
	handler: (accessor, resource, position) => {
		if (URI.isUri(resource) && Position.isIPosition(position)) {
			const languageFeaturesService = accessor.get(ILanguageFeaturesService);
			const codeEditorService = accessor.get(ICodeEditorService);
			return codeEditorService.openCodeEditor({ resource }, codeEditorService.getFocusedCodeEditor()).then(control => {
				if (!isCodeEditor(control) || !control.hasModel()) {
					return;
				}
				const controller = getReferencesControllerOf(control);
				if (controller) {
					const references = createCancelablePromise(token =>
						getReferencesAtPosition(
							languageFeaturesService.referenceProvider,
							control.getModel(),
							Position.lift(position),
							false,
							token
						).then(references2 => new ReferencesModel(references2, localize('References')))
					);
					return Promise.resolve(
						controller.toggleWidget(
							new Range(position.lineNumber, position.column, position.lineNumber, position.column),
							references,
							false
						)
					);
				}
			});
		}
	}
});