if (document.queryCommandSupported('cut')) {
	const cmdCut = new MultiCommand({
		id: 'editor.action.clipboardCutAction',
		kbOpts: undefined,
		menuOpts: [
			{
				menuId: menubarEditMenu_menuId,
				group: '2_ccp',
				title: localize('Cu&&t'),
				order: 1
			},
			{
				menuId: editorContext_menuId,
				group: CLIPBOARD_CONTEXT_MENU_GROUP,
				title: localize('Cut'),
				when: ck_writable,
				order: 1
			},
			{
				menuId: simpleEditorContext_menuId,
				group: CLIPBOARD_CONTEXT_MENU_GROUP,
				title: localize('Cut'),
				when: ck_writable,
				order: 1
			}
		]
	});
	cmdCut.register();
	registerExecCommandImpl(cmdCut, 'cut');
}