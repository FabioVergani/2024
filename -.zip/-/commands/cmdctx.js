



commandsRegistry.registerCommand('_setContext', function (accessor, contextKey, contextValue) {
	const ctxKeyService = accessor.get(IContextKeyService);
	ctxKeyService.createKey(
		String(contextKey),
		_cloneAndChange(contextValue, e => {
			if (typeof e === 'object' && e.$mid === 1) {
				return URI.revive(e).toString();
			}
			if (e instanceof URI) {
				return e.toString();
			}
		})
	);
});

commandsRegistry.registerCommand({
	id: 'getContextKeyInfo',
	handler() {
		return [...RawContextKey.all()].sort((a, b) => a.key.localeCompare(b.key));
	},
	metadata: {
		args: []
	}
});

commandsRegistry.registerCommand('_generateContextKeyInfo', function () {
	const result = [];
	const seen = new Set();
	for (const info of RawContextKey.all()) {
		if (!seen.has(info.key)) {
			seen.add(info.key);
			result.push(info);
		}
	}
	result.sort((a, b) => a.key.localeCompare(b.key));
});
