commandsRegistry.registerCommand('_executeDocumentSymbolProvider', async function (accessor, resource) {
	if (URI.isUri(resource)) {
		const outlineService = accessor.get(IOutlineModelService);
		const modelService = accessor.get(ITextModelService);
		const reference = await modelService.createModelReference(resource);
		try {
			return (await outlineService.getOrCreate(reference.object.textEditorModel, cancellationToken_none)).getTopLevelSymbols();
		} finally {
			reference.dispose();
		}
	}
});


