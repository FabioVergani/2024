
class ParameterHintPending {
	constructor(request, previouslyActiveHints) {
		this.request = request;
		this.previouslyActiveHints = previouslyActiveHints;
		this.type = 2;
	}
}
class ParameterHintActive {
	constructor(hints) {
		this.hints = hints;
		this.type = 1;
	}
}

class ParameterHintsModel extends Disposable {
	constructor(editor2, providers, delay = ParameterHintsModel.DEFAULT_DELAY) {
		super();
		this._onChangedHints = this._register(new Emitter());
		this.onChangedHints = this._onChangedHints.event;
		this.triggerOnType = false;
		this._state = {
			type: 0 //Default
		};
		this._pendingTriggers = [];
		this._lastSignatureHelpResult = this._register(new MutableDisposable());
		this.triggerChars = new CharacterSet();
		this.retriggerChars = new CharacterSet();
		this.triggerId = 0;
		this.editor = editor2;
		this.providers = providers;
		this.throttledDelayer = new Delayer(delay);
		this._register(this.editor.onDidBlurEditorWidget(() => this.cancel()));
		this._register(this.editor.onDidChangeConfiguration(() => this.onEditorConfigurationChange()));
		this._register(this.editor.onDidChangeModel(() => this.onModelChanged()));
		this._register(this.editor.onDidChangeModelLanguage(_ => this.onModelChanged()));
		this._register(this.editor.onDidChangeCursorSelection(e => this.onCursorChange(e)));
		this._register(this.editor.onDidChangeModelContent(() => this.onModelContentChange()));
		this._register(this.providers.onDidChange(this.onModelChanged, this));
		this._register(this.editor.onDidType(text2 => this.onDidType(text2)));
		this.onEditorConfigurationChange();
		this.onModelChanged();
	}
	get state() {
		return this._state;
	}
	set state(value) {
		if (this._state.type === 2) {
			this._state.request.cancel();
		}
		this._state = value;
	}
	cancel(silent = false) {
		this.state = {
			type: 0 //Default
		};
		this.throttledDelayer.cancel();
		if (!silent) {
			this._onChangedHints.fire(undefined);
		}
	}
	trigger(context, delay) {
		const model = this.editor.getModel();
		if (!model || !this.providers.has(model)) {
			return;
		}
		const triggerId = ++this.triggerId;
		this._pendingTriggers.push(context);
		this.throttledDelayer
			.trigger(() => {
				return this.doTrigger(triggerId);
			}, delay)
			.catch(onUnexpectedError);
	}
	next() {
		if (this.state.type !== 1) {
			return;
		}
		const length = this.state.hints.signatures.length;
		const activeSignature = this.state.hints.activeSignature;
		const last = activeSignature % length === length - 1;
		const cycle = this.editor.getOption(
			86
			// parameterHints
		).cycle;
		if ((length < 2 || last) && !cycle) {
			this.cancel();
			return;
		}
		this.updateActiveSignature(last && cycle ? 0 : activeSignature + 1);
	}
	previous() {
		if (this.state.type !== 1) {
			return;
		}
		const length = this.state.hints.signatures.length;
		const activeSignature = this.state.hints.activeSignature;
		const first2 = activeSignature === 0;
		const cycle = this.editor.getOption(
			86
			// parameterHints
		).cycle;
		if ((length < 2 || first2) && !cycle) {
			this.cancel();
			return;
		}
		this.updateActiveSignature(first2 && cycle ? length - 1 : activeSignature - 1);
	}
	updateActiveSignature(activeSignature) {
		if (this.state.type !== 1) {
			return;
		}
		this.state = new ParameterHintActive({ ...this.state.hints, activeSignature });
		this._onChangedHints.fire(this.state.hints);
	}
	async doTrigger(triggerId) {
		const isRetrigger = this.state.type === 1 || this.state.type === 2;
		const activeSignatureHelp = this.getLastActiveHints();
		this.cancel(true);
		if (this._pendingTriggers.length === 0) {
			return false;
		}
		const context = this._pendingTriggers.reduce(mergeTriggerContexts);
		this._pendingTriggers = [];
		const triggerContext = {
			triggerKind: context.triggerKind,
			triggerCharacter: context.triggerCharacter,
			isRetrigger,
			activeSignatureHelp
		};
		if (!this.editor.hasModel()) {
			return false;
		}
		const model = this.editor.getModel();
		const position = this.editor.getPosition();
		this.state = new ParameterHintPending(
			createCancelablePromise(token => provideSignatureHelp(this.providers, model, position, triggerContext, token)),
			activeSignatureHelp
		);
		try {
			const result = await this.state.request;
			if (triggerId !== this.triggerId) {
				result?.dispose();
				return false;
			}
			if (!result || !result.value.signatures || result.value.signatures.length === 0) {
				result?.dispose();
				this._lastSignatureHelpResult.clear();
				this.cancel();
				return false;
			} else {
				this.state = new ParameterHintActive(result.value);
				this._lastSignatureHelpResult.value = result;
				this._onChangedHints.fire(this.state.hints);
				return true;
			}
		} catch (error) {
			if (triggerId === this.triggerId) {
				this.state = {
					type: 0 //Default
				};
			}
			onUnexpectedError(error);
			return false;
		}
	}
	getLastActiveHints() {
		switch (this.state.type) {
			case 1:
				return this.state.hints;
			case 2:
				return this.state.previouslyActiveHints;
			default:
				return;
		}
	}
	get isTriggered() {
		return this.state.type === 1 || this.state.type === 2 || this.throttledDelayer.isTriggered();
	}
	onModelChanged() {
		this.cancel();
		this.triggerChars.clear();
		this.retriggerChars.clear();
		const model = this.editor.getModel();
		if (!model) {
			return;
		}
		for (const support of this.providers.ordered(model)) {
			for (const ch of support.signatureHelpTriggerCharacters || []) {
				if (ch.length) {
					const charCode = ch.charCodeAt(0);
					this.triggerChars.add(charCode);
					this.retriggerChars.add(charCode);
				}
			}
			for (const ch of support.signatureHelpRetriggerCharacters || []) {
				if (ch.length) {
					this.retriggerChars.add(ch.charCodeAt(0));
				}
			}
		}
	}
	onDidType(text2) {
		if (!this.triggerOnType) {
			return;
		}
		const lastCharIndex = text2.length - 1;
		const triggerCharCode = text2.charCodeAt(lastCharIndex);
		if (this.triggerChars.has(triggerCharCode) || (this.isTriggered && this.retriggerChars.has(triggerCharCode))) {
			this.trigger({
				triggerKind: 2, //TriggerCharacter
				triggerCharacter: text2.charAt(lastCharIndex)
			});
		}
	}
	onCursorChange(e) {
		if (e.source === 'mouse') {
			this.cancel();
		} else if (this.isTriggered) {
			this.trigger({
				triggerKind: 3 // ContentChange
			});
		}
	}
	onModelContentChange() {
		if (this.isTriggered) {
			this.trigger({
				triggerKind: 3 //ContentChange
			});
		}
	}
	onEditorConfigurationChange() {
		this.triggerOnType = this.editor.getOption(
			86
			// parameterHints
		).enabled;
		if (!this.triggerOnType) {
			this.cancel();
		}
	}
	dispose() {
		this.cancel(true);
		super.dispose();
	}
}
ParameterHintsModel.DEFAULT_DELAY = 120;

function mergeTriggerContexts(previous, current) {
	switch (current.triggerKind) {
		case 1: //Invoke
			return current;
		case 3: //ContentChange
			return previous;
		case 2: //TriggerCharacter
		default:
			return current;
	}
}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

var parameterHintsNextIcon = iconRegistry.registerIcon(
	'parameter-hints-next',
	codicon_chevronDown,
	localize('Icon for show next parameter hint.')
);
var parameterHintsPreviousIcon = iconRegistry.registerIcon(
	'parameter-hints-previous',
	codicon_chevronUp,
	localize('Icon for show previous parameter hint.')
);

class ParameterHintsWidget extends Disposable {
	constructor(editor2, model, contextKeyService, openerService, languageService) {
		super();
		this.editor = editor2;
		this.model = model;
		this.renderDisposeables = this._register(new DisposableStore());
		this.visible = false;
		this.announcedLabel = null;
		this.allowEditorOverflow = true;
		this.markdownRenderer = this._register(new MarkdownRenderer({ editor: editor2 }, languageService, openerService));
		this.keyVisible = Context3.Visible.bindTo(contextKeyService);
		this.keyMultipleSignatures = Context3.MultipleSignatures.bindTo(contextKeyService);
	}
	createParameterHintDOMNodes() {
		const element = $('.editor-widget.parameter-hints-widget');
		const wrapper = append(element, $('.phwrapper'));
		wrapper.tabIndex = -1;
		const controls = append(wrapper, $('.controls'));
		const previous = append(controls, $('.button' + asThemeIconCSSSelector(parameterHintsPreviousIcon)));
		const overloads = append(controls, $('.overloads'));
		const next = append(controls, $('.button' + asThemeIconCSSSelector(parameterHintsNextIcon)));
		this._register(
			addDisposableListener(previous, 'click', e => {
				EventHelper.stop(e);
				this.previous();
			})
		);
		this._register(
			addDisposableListener(next, 'click', e => {
				EventHelper.stop(e);
				this.next();
			})
		);
		const body = $('.body');
		const scrollbar = new DomScrollableElement(body, {
			alwaysConsumeMouseWheel: true
		});
		this._register(scrollbar);
		wrapper.appendChild(scrollbar.getDomNode());
		const signature = append(body, $('.signature'));
		const docs = append(body, $('.docs'));
		element.style.userSelect = 'text';
		this.domNodes = {
			element,
			signature,
			overloads,
			docs,
			scrollbar
		};
		this.editor.addContentWidget(this);
		this.hide();
		this._register(
			this.editor.onDidChangeCursorSelection(() => {
				if (this.visible) {
					this.editor.layoutContentWidget(this);
				}
			})
		);
		const updateFont = () => {
			if (!this.domNodes) {
				return;
			}
			const fontInfo = this.editor.getOption(
				50
				// fontInfo
			);
			this.domNodes.element.style.fontSize = `${fontInfo.fontSize}px`;
			this.domNodes.element.style.lineHeight = `${fontInfo.lineHeight / fontInfo.fontSize}`;
		};
		updateFont();
		this._register(
			editorEventChain(this.editor.onDidChangeConfiguration.bind(this.editor), $16 =>
				$16.filter(e =>
					e.hasChanged(
						50
						// fontInfo
					)
				)
			)(updateFont)
		);
		this._register(this.editor.onDidLayoutChange(e => this.updateMaxHeight()));
		this.updateMaxHeight();
	}
	show() {
		if (this.visible) {
			return;
		}
		if (!this.domNodes) {
			this.createParameterHintDOMNodes();
		}
		this.keyVisible.set(true);
		this.visible = true;
		setTimeout(() => {
			this.domNodes?.element.classList.add('visible');
		}, 100);
		this.editor.layoutContentWidget(this);
	}
	hide() {
		this.renderDisposeables.clear();
		if (!this.visible) {
			return;
		}
		this.keyVisible.reset();
		this.visible = false;
		this.announcedLabel = null;
		this.domNodes?.element.classList.remove('visible');
		this.editor.layoutContentWidget(this);
	}
	getPosition() {
		if (this.visible) {
			return {
				position: this.editor.getPosition(),
				preference: [
					1, 2
					// BELOW
				]
			};
		}
		return null;
	}
	render(hints) {
		this.renderDisposeables.clear();
		if (this.domNodes) {
			const multiple = hints.signatures.length > 1;
			this.domNodes.element.classList.toggle('multiple', multiple);
			this.keyMultipleSignatures.set(multiple);
			this.domNodes.signature.innerText = '';
			this.domNodes.docs.innerText = '';
			const signature = hints.signatures[hints.activeSignature];
			if (!signature) {
				return;
			}
			const code = append(this.domNodes.signature, $('.code'));
			const fontInfo = this.editor.getOption(
				50
				// fontInfo
			);
			code.style.fontSize = `${fontInfo.fontSize}px`;
			code.style.fontFamily = fontInfo.fontFamily;
			const hasParameters = signature.parameters.length > 0;
			const activeParameterIndex = signature.activeParameter ?? hints.activeParameter;
			if (!hasParameters) {
				const label = append(code, $('span'));
				label.textContent = signature.label;
			} else {
				this.renderParameters(code, signature, activeParameterIndex);
			}
			const activeParameter = signature.parameters[activeParameterIndex];
			if (activeParameter?.documentation) {
				const documentation = $('span.documentation');
				if (typeof activeParameter.documentation === 'string') {
					documentation.textContent = activeParameter.documentation;
				} else {
					const renderedContents = this.renderMarkdownDocs(activeParameter.documentation);
					documentation.appendChild(renderedContents.element);
				}
				append(this.domNodes.docs, $('p', {}, documentation));
			}
			if (signature.documentation === undefined) {
			} else if (typeof signature.documentation === 'string') {
				append(this.domNodes.docs, $('p', {}, signature.documentation));
			} else {
				const renderedContents = this.renderMarkdownDocs(signature.documentation);
				append(this.domNodes.docs, renderedContents.element);
			}
			const hasDocs = this.hasDocs(signature, activeParameter);
			this.domNodes.signature.classList.toggle('has-docs', hasDocs);
			this.domNodes.docs.classList.toggle('empty', !hasDocs);
			this.domNodes.overloads.textContent =
				String(hints.activeSignature + 1).padStart(hints.signatures.length.toString().length, '0') + '/' + hints.signatures.length;
			if (activeParameter) {
				let labelToAnnounce = '';
				const param = signature.parameters[activeParameterIndex];
				if (isArray(param.label)) {
					labelToAnnounce = signature.label.substring(param.label[0], param.label[1]);
				} else {
					labelToAnnounce = param.label;
				}
				if (param.documentation) {
					labelToAnnounce +=
						typeof param.documentation === 'string' ? `, ${param.documentation}` : `, ${param.documentation.value}`;
				}
				if (signature.documentation) {
					labelToAnnounce +=
						typeof signature.documentation === 'string' ? `, ${signature.documentation}` : `, ${signature.documentation.value}`;
				}
				if (this.announcedLabel !== labelToAnnounce) {
					alert(localize(labelToAnnounce));
					this.announcedLabel = labelToAnnounce;
				}
			}
			this.editor.layoutContentWidget(this);
			this.domNodes.scrollbar.scanDomNode();
		}
	}
	renderMarkdownDocs(markdown) {
		const renderedContents = this.renderDisposeables.add(
			this.markdownRenderer.render(markdown, {
				asyncRenderCallback: () => {
					this.domNodes?.scrollbar.scanDomNode();
				}
			})
		);
		renderedContents.element.classList.add('markdown-docs');
		return renderedContents;
	}
	hasDocs(signature, activeParameter) {
		if (activeParameter && typeof activeParameter.documentation === 'string' && activeParameter.documentation?.length > 0) {
			return true;
		}
		if (activeParameter && typeof activeParameter.documentation === 'object' && activeParameter.documentation?.value.length > 0) {
			return true;
		}
		if (signature.documentation && typeof signature.documentation === 'string' && signature.documentation?.length > 0) {
			return true;
		}
		if (signature.documentation && typeof signature.documentation === 'object' && signature.documentation.value?.length > 0) {
			return true;
		}
		return false;
	}
	renderParameters(parent, signature, activeParameterIndex) {
		const [start, end] = this.getParameterLabelOffsets(signature, activeParameterIndex);
		const beforeSpan = document.createElement('span');
		beforeSpan.textContent = signature.label.substring(0, start);
		const paramSpan = document.createElement('span');
		paramSpan.textContent = signature.label.substring(start, end);
		paramSpan.className = 'parameter active';
		const afterSpan = document.createElement('span');
		afterSpan.textContent = signature.label.substring(end);
		append(parent, beforeSpan, paramSpan, afterSpan);
	}
	getParameterLabelOffsets(signature, paramIdx) {
		const param = signature.parameters[paramIdx];
		if (!param) {
			return [0, 0];
		} else if (isArray(param.label)) {
			return param.label;
		} else if (!param.label.length) {
			return [0, 0];
		} else {
			const regex = new RegExp(`(\\W|^)${escapeRegexChars(param.label)}(?=\\W|$)`, 'g');
			regex.test(signature.label);
			const idx = regex.lastIndex - param.label.length;
			return idx >= 0 ? [idx, regex.lastIndex] : [0, 0];
		}
	}
	next() {
		this.editor.focus();
		this.model.next();
	}
	previous() {
		this.editor.focus();
		this.model.previous();
	}
	getDomNode() {
		if (!this.domNodes) {
			this.createParameterHintDOMNodes();
		}
		return this.domNodes.element;
	}
	getId() {
		return ParameterHintsWidget.ID;
	}
	updateMaxHeight() {
		if (!this.domNodes) {
			return;
		}
		const height = Math.max(this.editor.getLayoutInfo().height / 4, 250);
		const maxHeight = `${height}px`;
		this.domNodes.element.style.maxHeight = maxHeight;
		const wrapper = this.domNodes.element.getElementsByClassName('phwrapper');
		if (wrapper.length) {
			wrapper[0].style.maxHeight = maxHeight;
		}
	}
}
ParameterHintsWidget.ID = 'editor.widget.parameterHintsWidget';
__decorate([__param(2, IContextKeyService), __param(3, IOpenerService), __param(4, ILanguageService)], ParameterHintsWidget);

// node_modules/monaco-editor/esm/vs/editor/contrib/parameterHints/browser/parameterHints.js
class ParameterHintsController extends Disposable {
	static get(editor2) {
		return editor2.getContribution(ParameterHintsController.ID);
	}
	constructor(editor2, instantiationService, languageFeaturesService) {
		super();
		this.editor = editor2;
		this.model = this._register(new ParameterHintsModel(editor2, languageFeaturesService.signatureHelpProvider));
		this._register(
			this.model.onChangedHints(newParameterHints => {
				if (newParameterHints) {
					this.widget.value.show();
					this.widget.value.render(newParameterHints);
				} else {
					this.widget.rawValue?.hide();
				}
			})
		);
		this.widget = new Lazy(() => this._register(instantiationService.createInstance(ParameterHintsWidget, this.editor, this.model)));
	}
	cancel() {
		this.model.cancel();
	}
	previous() {
		this.widget.rawValue?.previous();
	}
	next() {
		this.widget.rawValue?.next();
	}
	trigger(context) {
		this.model.trigger(context, 0);
	}
}
ParameterHintsController.ID = 'editor.controller.parameterHints';
__decorate([__param(1, IInstantiationService), __param(2, ILanguageFeaturesService)], ParameterHintsController);

class TriggerParameterHintsAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.triggerParameterHints',
			label: localize('Trigger Parameter Hints'),
			alias: 'Trigger Parameter Hints',
			precondition: ctxKeys_editorHasProvider_signatureHelp,
			kbOpts: {
				kbExpr: ctxKeys_editorFocus_text,
				primary: 2048 | 1024 | 10,
				weight: 100 //editorContrib
			}
		});
	}
	run(accessor, editor2) {
		const controller = ParameterHintsController.get(editor2);
		controller === null || controller === undefined
			? undefined
			: controller.trigger({
					triggerKind: 1 //Invoke
				});
	}
}
registerEditorContribution(
	ParameterHintsController.ID,
	ParameterHintsController,
	2 // EditorContributionInstantiation.BeforeFirstInteraction
);
registerEditorAction(TriggerParameterHintsAction);

var ParameterHintsCommand = EditorCommand.bindToContribution(ParameterHintsController.get);
registerEditorCommand(
	new ParameterHintsCommand({
		id: 'closeParameterHints',
		precondition: Context3.Visible,
		handler: x => x.cancel(),
		kbOpts: {
			weight: 175,
			kbExpr: ctxKeys_editorFocus,
			primary: 9,
			secondary: [
				1024 | 9 // Escape
			]
		}
	})
);
registerEditorCommand(
	new ParameterHintsCommand({
		id: 'showPrevParameterHint',
		precondition: ContextKeyExpr.and(Context3.Visible, Context3.MultipleSignatures),
		handler: x => x.previous(),
		kbOpts: {
			weight: 175,
			kbExpr: ctxKeys_editorFocus,
			primary: 16,
			secondary: [
				512 | 16 // UpArrow
			],
			mac: {
				primary: 16,
				secondary: [
					512 | 16,
					256 | 46 // KeyCode.KeyP
				]
			}
		}
	})
);
registerEditorCommand(
	new ParameterHintsCommand({
		id: 'showNextParameterHint',
		precondition: ContextKeyExpr.and(Context3.Visible, Context3.MultipleSignatures),
		handler: x => x.next(),
		kbOpts: {
			weight: 175,
			kbExpr: ctxKeys_editorFocus,
			primary: 18,
			secondary: [
				512 | 18
				// DownArrow
			],
			mac: {
				primary: 18,
				secondary: [
					512 | 18,
					256 | 44 // KeyCode.KeyN
				]
			}
		}
	})
);