commandsRegistry.registerCommand('_executeCodeLensProvider', (accessor, uri, itemResolveCount) => {
	if (URI.isUri(uri) && (typeof itemResolveCount === 'number' || !itemResolveCount)) {
		const { codeLensProvider } = accessor.get(ILanguageFeaturesService);
		const model = accessor.get(IModelService).getModel(uri);
		if (model) {
			const result = [];
			const disposables = new DisposableStore();
			return getCodeLensModel(codeLensProvider, model, cancellationToken_none)
				.then(value => {
					disposables.add(value);
					const resolve2 = [];
					for (const item of value.lenses) {
						if (isNullOrUndefined(itemResolveCount) || !!item.symbol.command) {
							result.push(item.symbol);
						} else if (itemResolveCount-- > 0 && item.provider.resolveCodeLens) {
							resolve2.push(
								Promise.resolve(item.provider.resolveCodeLens(model, item.symbol, cancellationToken_none)).then(symbol => result.push(symbol || item.symbol))
							);
						}
					}
					return Promise.all(resolve2);
				})
				.then(() => {
					return result;
				})
				.finally(() => {
					setTimeout(() => disposables.dispose(), 100);
				});
		}
	}
});