class WordSelectionRangeProvider {
	constructor(selectSubwords = true) {
		this.selectSubwords = selectSubwords;
	}
	provideSelectionRanges(model, positions) {
		const result = [];
		for (const position of positions) {
			const bucket = [];
			result.push(bucket);
			if (this.selectSubwords) {
				this._addInWordRanges(bucket, model, position);
			}
			this._addWordRanges(bucket, model, position);
			this._addWhitespaceLine(bucket, model, position);
			bucket.push({ range: model.getFullModelRange() });
		}
		return result;
	}
	_addInWordRanges(bucket, model, pos) {
		const obj = model.getWordAtPosition(pos);
		if (!obj) {
			return;
		}
		const { word, startColumn } = obj;
		const offset = pos.column - startColumn;
		let start = offset;
		let end = offset;
		let lastCh = 0;
		for (; start >= 0; start--) {
			const ch = word.charCodeAt(start);
			if (start !== offset && (ch === 95 || ch === 45)) {
				break;
			} else if (isLowerAsciiLetter(ch) && isUpperAsciiLetter(lastCh)) {
				break;
			}
			lastCh = ch;
		}
		start += 1;
		for (; end < word.length; end++) {
			const ch = word.charCodeAt(end);
			if (isUpperAsciiLetter(ch) && isLowerAsciiLetter(lastCh)) {
				break;
			} else if (ch === 95 || ch === 45) {
				break;
			}
			lastCh = ch;
		}
		if (start < end) {
			bucket.push({
				range: new Range(pos.lineNumber, startColumn + start, pos.lineNumber, startColumn + end)
			});
		}
	}
	_addWordRanges(bucket, model, pos) {
		const word = model.getWordAtPosition(pos);
		if (word) {
			bucket.push({
				range: new Range(pos.lineNumber, word.startColumn, pos.lineNumber, word.endColumn)
			});
		}
	}
	_addWhitespaceLine(bucket, model, pos) {
		if (
			model.getLineLength(pos.lineNumber) > 0 &&
			model.getLineFirstNonWhitespaceColumn(pos.lineNumber) === 0 &&
			model.getLineLastNonWhitespaceColumn(pos.lineNumber) === 0
		) {
			bucket.push({
				range: new Range(pos.lineNumber, 1, pos.lineNumber, model.getLineMaxColumn(pos.lineNumber))
			});
		}
	}
}
async function provideSelectionRanges(registry, model, positions, options2, token) {
	const providers = registry.all(model).concat(new WordSelectionRangeProvider(options2.selectSubwords));
	if (providers.length === 1) {
		providers.unshift(new BracketSelectionRangeProvider());
	}
	const work = [];
	const allRawRanges = [];
	for (const provider of providers) {
		work.push(
			Promise.resolve(provider.provideSelectionRanges(model, positions, token)).then(allProviderRanges => {
				if (isArrayAndHasLength(allProviderRanges) && allProviderRanges.length === positions.length) {
					for (let i = 0; i < positions.length; i++) {
						if (!allRawRanges[i]) {
							allRawRanges[i] = [];
						}
						for (const oneProviderRanges of allProviderRanges[i]) {
							if (Range.isIRange(oneProviderRanges.range) && Range.containsPosition(oneProviderRanges.range, positions[i])) {
								allRawRanges[i].push(Range.lift(oneProviderRanges.range));
							}
						}
					}
				}
			}, onUnexpectedExternalError)
		);
	}
	await Promise.all(work);
	return allRawRanges.map(oneRawRanges => {
		if (oneRawRanges.length === 0) {
			return [];
		}
		oneRawRanges.sort((a, b) => {
			if (Position.isBefore(a.getStartPosition(), b.getStartPosition())) {
				return 1;
			} else if (Position.isBefore(b.getStartPosition(), a.getStartPosition())) {
				return -1;
			} else if (Position.isBefore(a.getEndPosition(), b.getEndPosition())) {
				return -1;
			} else if (Position.isBefore(b.getEndPosition(), a.getEndPosition())) {
				return 1;
			} else {
				return 0;
			}
		});
		const oneRanges = [];
		let last;
		for (const range2 of oneRawRanges) {
			if (!last || (Range.containsRange(range2, last) && !Range.equalsRange(range2, last))) {
				oneRanges.push(range2);
				last = range2;
			}
		}
		if (!options2.selectLeadingAndTrailingWhitespace) {
			return oneRanges;
		}
		const oneRangesWithTrivia = [oneRanges[0]];
		for (let i = 1; i < oneRanges.length; i++) {
			const prev = oneRanges[i - 1];
			const cur = oneRanges[i];
			if (cur.startLineNumber !== prev.startLineNumber || cur.endLineNumber !== prev.endLineNumber) {
				const rangeNoWhitespace = new Range(
					prev.startLineNumber,
					model.getLineFirstNonWhitespaceColumn(prev.startLineNumber),
					prev.endLineNumber,
					model.getLineLastNonWhitespaceColumn(prev.endLineNumber)
				);
				if (
					rangeNoWhitespace.containsRange(prev) &&
					!rangeNoWhitespace.equalsRange(prev) &&
					cur.containsRange(rangeNoWhitespace) &&
					!cur.equalsRange(rangeNoWhitespace)
				) {
					oneRangesWithTrivia.push(rangeNoWhitespace);
				}
				const rangeFull = new Range(prev.startLineNumber, 1, prev.endLineNumber, model.getLineMaxColumn(prev.endLineNumber));
				if (
					rangeFull.containsRange(prev) &&
					!rangeFull.equalsRange(rangeNoWhitespace) &&
					cur.containsRange(rangeFull) &&
					!cur.equalsRange(rangeFull)
				) {
					oneRangesWithTrivia.push(rangeFull);
				}
			}
			oneRangesWithTrivia.push(cur);
		}
		return oneRangesWithTrivia;
	});
}
commandsRegistry.registerCommand('_executeSelectionRangeProvider', async function (accessor, resource, positions) {
	if (URI.isUri(resource)) {
		const registry = accessor.get(ILanguageFeaturesService).selectionRangeProvider;
		const reference = await accessor.get(ITextModelService).createModelReference(resource);
		try {
			return provideSelectionRanges(
				registry,
				reference.object.textEditorModel,
				positions,
				{
					selectLeadingAndTrailingWhitespace: true,
					selectSubwords: true
				},
				cancellationToken_none
			);
		} finally {
			reference.dispose();
		}
	}
});