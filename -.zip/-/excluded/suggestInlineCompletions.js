// node_modules/monaco-editor/esm/vs/editor/contrib/suggest/browser/suggestInlineCompletions.js

class SuggestInlineCompletion {
	constructor(range2, insertText, filterText, additionalTextEdits, command, completion) {
		this.range = range2;
		this.insertText = insertText;
		this.filterText = filterText;
		this.additionalTextEdits = additionalTextEdits;
		this.command = command;
		this.completion = completion;
	}
}

class InlineCompletionResults {
	constructor(model, line, word, completionModel, completions, _suggestMemoryService) {
		const _disposable = completions.disposable;
		this._disposable = _disposable;
		this._counter = 1;
		this.model = model;
		this.line = line;
		this.word = word;
		this.completionModel = completionModel;
		this._suggestMemoryService = _suggestMemoryService;
	}
	acquire() {
		++this._counter;
		return this;
	}
	release() {
		if (--this._counter === 0) {
			this._disposable.dispose();
		}
		return this;
	}
	canBeReused(model, line, word) {
		return (
			this.model === model &&
			this.line === line &&
			this.word.word.length > 0 &&
			this.word.startColumn === word.startColumn &&
			this.word.endColumn < word.endColumn &&
			this.completionModel.getIncompleteProvider().size === 0
		);
	}
	get items() {
		const result = [];
		const { items } = this.completionModel;
		const selectedIndex = this._suggestMemoryService.select(
			this.model,
			{
				lineNumber: this.line,
				column: this.word.endColumn + this.completionModel.lineContext.characterCountDelta
			},
			items
		);
		const first2 = iterableSlice(items, selectedIndex);
		const second = iterableSlice(items, 0, selectedIndex);
		let resolveCount = 5;
		for (const item of iterableConcat(first2, second)) {
			if (item.score === fuzzyScoreDefault) {
				continue;
			}
			const range2 = new Range(
				item.editStart.lineNumber,
				item.editStart.column,
				item.editInsertEnd.lineNumber,
				item.editInsertEnd.column + this.completionModel.lineContext.characterCountDelta
				// end PLUS character delta
			);
			const insertText =
				item.completion.insertTextRules && item.completion.insertTextRules & 4
					? { snippet: item.completion.insertText }
					: item.completion.insertText;
			result.push(
				new SuggestInlineCompletion(
					range2,
					insertText,
					item.filterTextLow ?? item.labelLow,
					item.completion.additionalTextEdits,
					item.completion.command,
					item
				)
			);
			if (resolveCount-- >= 0) {
				item.resolve(cancellationToken_none);
			}
		}
		return result;
	}
}
__decorate([__param(5, ISuggestMemoryService)], InlineCompletionResults);

class SuggestInlineCompletions extends Disposable {
	constructor(_languageFeatureService, _clipboardService, _suggestMemoryService, _editorService) {
		super();
		this._languageFeatureService = _languageFeatureService;
		this._clipboardService = _clipboardService;
		this._suggestMemoryService = _suggestMemoryService;
		this._editorService = _editorService;
		this._store.add(_languageFeatureService.inlineCompletionsProvider.register('*', this));
	}
	async provideInlineCompletions(model, position, context, token) {
		if (!context.selectedSuggestionInfo) {
			let editor2;
			for (const candidate of this._editorService.listCodeEditors()) {
				if (candidate.getModel() === model) {
					editor2 = candidate;
					break;
				}
			}
			if (!editor2) {
				return;
			}
			const config = editor2.getOption(
				89
				// quickSuggestions
			);
			if (QuickSuggestionsOptions.isAllOff(config)) {
				return;
			}
			model.tokenization.tokenizeIfCheap(position.lineNumber);
			const lineTokens = model.tokenization.getLineTokens(position.lineNumber);
			const tokenType = lineTokens.getStandardTokenType(lineTokens.findTokenIndexAtOffset(Math.max(position.column - 1 - 1, 0)));
			if (QuickSuggestionsOptions.valueFor(config, tokenType) !== 'inline') {
				return;
			}
			let wordInfo = model.getWordAtPosition(position);
			let triggerCharacterInfo;
			if (!wordInfo?.word) {
				triggerCharacterInfo = this._getTriggerCharacterInfo(model, position);
			}
			if (!wordInfo?.word && !triggerCharacterInfo) {
				return;
			}
			if (!wordInfo) {
				wordInfo = model.getWordUntilPosition(position);
			}
			if (wordInfo.endColumn !== position.column) {
				return;
			}
			let result;
			const leadingLineContents = model.getValueInRange(new Range(position.lineNumber, 1, position.lineNumber, position.column));
			if (!triggerCharacterInfo && this._lastResult?.canBeReused(model, position.lineNumber, wordInfo)) {
				this._lastResult.completionModel.lineContext = new LineContext(
					leadingLineContents,
					position.column - this._lastResult.word.endColumn
				);
				this._lastResult.acquire();
				result = this._lastResult;
			} else {
				const completions = await provideSuggestionItems(
					this._languageFeatureService.completionProvider,
					model,
					position,
					new CompletionOptions(undefined, SuggestModel.createSuggestFilter(editor2).itemKind, triggerCharacterInfo?.providers),
					triggerCharacterInfo && { triggerKind: 1, triggerCharacter: triggerCharacterInfo.ch },
					token
				);
				let clipboardText;
				if (completions.needsClipboard) {
					clipboardText = await this._clipboardService.readText();
				}
				const completionModel = new CompletionModel(
					completions.items,
					position.column,
					new LineContext(leadingLineContents, 0),
					WordDistance.None,
					editor2.getOption(
						118
						// suggest
					),
					editor2.getOption(
						112
						// snippetSuggestions
					),
					{ boostFullMatch: false, firstMatchCanBeWeak: false },
					clipboardText
				);
				result = new InlineCompletionResults(
					model,
					position.lineNumber,
					wordInfo,
					completionModel,
					completions,
					this._suggestMemoryService
				);
			}
			this._lastResult = result;
			return result;
		}
	}
	handleItemDidShow(_completions, item) {
		item.completion.resolve(cancellationToken_none);
	}
	freeInlineCompletions(result) {
		result.release();
	}
	_getTriggerCharacterInfo(model, position) {
		const ch = model.getValueInRange(Range.fromPositions({ lineNumber: position.lineNumber, column: position.column - 1 }, position));
		const providers = new Set();
		for (const provider of this._languageFeatureService.completionProvider.all(model)) {
			if (provider.triggerCharacters?.includes(ch)) {
				providers.add(provider);
			}
		}
		if (providers.size === 0) {
			return;
		}
		return { providers, ch };
	}
}
__decorate(
	[
		__param(0, ILanguageFeaturesService),
		__param(1, IClipboardService),
		__param(2, ISuggestMemoryService),
		__param(3, ICodeEditorService)
	],
	SuggestInlineCompletions
);
registerEditorFeature(SuggestInlineCompletions);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


class ForceRetokenizeAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.forceRetokenize',
			label: localize('Developer: Force Retokenize'),
			alias: 'Developer: Force Retokenize'
		});
	}
	run(accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const model = editor2.getModel();
		model.tokenization.resetTokenization();
		const sw = new StopWatch();
		model.tokenization.forceTokenization(model.getLineCount());
		sw.stop();
		console.log(`tokenization took ${sw.elapsed()}`);
	}
}
//registerEditorAction(ForceRetokenizeAction);