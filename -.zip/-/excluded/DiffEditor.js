

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function computeViewElementGroups(diffs, originalLineCount, modifiedLineCount) {
	const result = [];
	for (const g of groupAdjacentBy(
		diffs,
		(a, b) => b.modified.startLineNumber - a.modified.endLineNumberExclusive < 2 * viewElementGroupLineMargin
	)) {
		const viewElements = [];
		viewElements.push({ type: 0 });
		const origFullRange = new LineRange(
			Math.max(1, g[0].original.startLineNumber - viewElementGroupLineMargin),
			Math.min(g[g.length - 1].original.endLineNumberExclusive + viewElementGroupLineMargin, originalLineCount + 1)
		);
		const modifiedFullRange = new LineRange(
			Math.max(1, g[0].modified.startLineNumber - viewElementGroupLineMargin),
			Math.min(g[g.length - 1].modified.endLineNumberExclusive + viewElementGroupLineMargin, modifiedLineCount + 1)
		);
		forEachAdjacent(g, (a, b) => {
			const origRange = new LineRange(
				a ? a.original.endLineNumberExclusive : origFullRange.startLineNumber,
				b ? b.original.startLineNumber : origFullRange.endLineNumberExclusive
			);
			const modifiedRange2 = new LineRange(
				a ? a.modified.endLineNumberExclusive : modifiedFullRange.startLineNumber,
				b ? b.modified.startLineNumber : modifiedFullRange.endLineNumberExclusive
			);
			origRange.forEach(origLineNumber => {
				viewElements.push({
					originalLineNumber: origLineNumber,
					modifiedLineNumber: modifiedRange2.startLineNumber + (origLineNumber - origRange.startLineNumber),
					type: 1
				});
			});
			if (b) {
				b.original.forEach(origLineNumber => {
					viewElements.push({
						diff: b,
						originalLineNumber: origLineNumber,
						type: 2
					});
				});
				b.modified.forEach(modifiedLineNumber => {
					viewElements.push({
						diff: b,
						modifiedLineNumber: modifiedLineNumber,
						type: 3
					});
				});
			}
		});
		const modifiedRange = g[0].modified.join(g[g.length - 1].modified);
		const originalRange = g[0].original.join(g[g.length - 1].original);

		result.push({
			range: new LineRangeMapping(modifiedRange, originalRange),
			lines: viewElements
		});
	}
	return result;
}
/*
const accessibleDiffViewerInsertIcon = iconRegistry.registerIcon(
	'diff-review-insert',
	codicon_add,
	localize("Icon for 'Insert' in accessible diff viewer.")
);
const accessibleDiffViewerRemoveIcon = iconRegistry.registerIcon(
	'diff-review-remove',
	codicon_remove,
	localize("Icon for 'Remove' in accessible diff viewer.")
);
const accessibleDiffViewerCloseIcon = iconRegistry.registerIcon(
	'diff-review-close',
	codicon_close,
	localize("Icon for 'Close' in accessible diff viewer.")
);

class AccessibleDiffViewer extends Disposable {
	constructor(_parentNode, _visible, _setVisible, _canClose, _width, _height, _diffs, _models, _instantiationService) {
		super();
		this._parentNode = _parentNode;
		this._visible = _visible;
		this._setVisible = _setVisible;
		this._canClose = _canClose;
		this._width = _width;
		this._height = _height;
		this._diffs = _diffs;
		this._models = _models;
		this._instantiationService = _instantiationService;
		this._state = derivedWithStore(this, (reader, store) => {
			const visible = this._visible.read(reader);
			this._parentNode.style.visibility = visible ? 'visible' : 'hidden';
			if (!visible) {
				return null;
			}
			const model = store.add(
				this._instantiationService.createInstance(ViewModel2, this._diffs, this._models, this._setVisible, this._canClose)
			);
			const view = store.add(
				this._instantiationService.createInstance(View3, this._parentNode, model, this._width, this._height, this._models)
			);
			return { model, view };
		}).recomputeInitiallyAndOnChange(this._store);
	}
	next() {
		transaction(tx => {
			const isVisible = this._visible.get();
			this._setVisible(true, tx);
			if (isVisible) {
				this._state.get().model.nextGroup(tx);
			}
		});
	}
	prev() {
		transaction(tx => {
			this._setVisible(true, tx);
			this._state.get().model.previousGroup(tx);
		});
	}
	close() {
		transaction(tx => {
			this._setVisible(false, tx);
		});
	}
}
__decorate([__param(8, IInstantiationService)], AccessibleDiffViewer);
*/

class ViewModel2 extends Disposable {
	constructor(_diffs, _models, _setVisible, canClose) {
		super();
		this._diffs = _diffs;
		this._models = _models;
		this._setVisible = _setVisible;
		this.canClose = canClose;
		this._groups = observableValue(this, []);
		this._currentGroupIdx = observableValue(this, 0);
		this._currentElementIdx = observableValue(this, 0);
		this.groups = this._groups;
		this.currentGroup = this._currentGroupIdx.map((idx, r) => this._groups.read(r)[idx]);
		this.currentGroupIndex = this._currentGroupIdx;
		this.currentElement = this._currentElementIdx.map((idx, r) => {
			return this.currentGroup.read(r)?.lines[idx];
		});
		this._register(
			autorun(reader => {
				const diffs = this._diffs.read(reader);
				if (!diffs) {
					this._groups.set([], undefined);
					return;
				}
				const groups = computeViewElementGroups(
					diffs,
					this._models.getOriginalModel().getLineCount(),
					this._models.getModifiedModel().getLineCount()
				);
				transaction(tx => {
					const p = this._models.getModifiedPosition();
					if (p) {
						const nextGroup = groups.findIndex(g => p?.lineNumber < g.range.modified.endLineNumberExclusive);
						if (nextGroup !== -1) {
							this._currentGroupIdx.set(nextGroup, tx);
						}
					}
					this._groups.set(groups, tx);
				});
			})
		);
		this._register(
			autorun(reader => {
				const currentViewItem = this.currentElement.read(reader);
				if (currentViewItem && currentViewItem.type !== 0) {
					const lineNumber = currentViewItem.modifiedLineNumber ?? currentViewItem.diff.modified.startLineNumber;
					this._models.modifiedSetSelection(Range.fromPositions(new Position(lineNumber, 1)));
				}
			})
		);
	}
	_goToGroupDelta(delta, tx) {
		const groups = this.groups.get();
		if (!groups || groups.length <= 1) {
			return;
		}
		subtransaction(tx, tx2 => {
			this._currentGroupIdx.set(OffsetRange.ofLength(groups.length).clipCyclic(this._currentGroupIdx.get() + delta), tx2);
			this._currentElementIdx.set(0, tx2);
		});
	}
	nextGroup(tx) {
		this._goToGroupDelta(1, tx);
	}
	previousGroup(tx) {
		this._goToGroupDelta(-1, tx);
	}
	_goToLineDelta(delta) {
		const group = this.currentGroup.get();
		if (!group || group.lines.length <= 1) {
			return;
		}
		transaction(tx => {
			this._currentElementIdx.set(OffsetRange.ofLength(group.lines.length).clip(this._currentElementIdx.get() + delta), tx);
		});
	}
	goToNextLine() {
		this._goToLineDelta(1);
	}
	goToPreviousLine() {
		this._goToLineDelta(-1);
	}
	goToLine(line) {
		const group = this.currentGroup.get();
		if (!group) {
			return;
		}
		const idx = group.lines.indexOf(line);
		if (idx === -1) {
			return;
		}
		transaction(tx => {
			this._currentElementIdx.set(idx, tx);
		});
	}
	revealCurrentElementInEditor() {
		if (!this.canClose.get()) {
			return;
		}
		this._setVisible(false, undefined);
		const curElem = this.currentElement.get();
		if (curElem) {
			if (curElem.type === 2) {
				this._models.originalReveal(Range.fromPositions(new Position(curElem.originalLineNumber, 1)));
			} else {
				this._models.modifiedReveal(
					curElem.type !== 0 ? Range.fromPositions(new Position(curElem.modifiedLineNumber, 1)) : undefined
				);
			}
		}
	}
	close() {
		if (!this.canClose.get()) {
			return;
		}
		this._setVisible(false, undefined);
		this._models.modifiedFocus();
	}
}

let viewElementGroupLineMargin = 3;

class View3 extends Disposable {
	constructor(_element, _model, _width, _height, _models, _languageService) {
		super();
		this._element = _element;
		this._model = _model;
		this._width = _width;
		this._height = _height;
		this._models = _models;
		this._languageService = _languageService;
		this.domNode = this._element;
		this.domNode.className = 'monaco-component diff-review monaco-editor-background';
		const actionBarContainer = document.createElement('div');
		actionBarContainer.className = 'diff-review-actions';
		this._actionBar = this._register(new ActionBar(actionBarContainer));
		this._register(
			autorun(reader => {
				this._actionBar.clear();
				if (this._model.canClose.read(reader)) {
					this._actionBar.push(
						new Action(
							'diffreview.close',
							localize('Close'),
							'close-diff-review ' + asThemeIconClassNameString(accessibleDiffViewerCloseIcon),
							true,
							async () => _model.close()
						),
						{ label: false, icon: true }
					);
				}
			})
		);
		this._content = document.createElement('div');
		this._content.className = 'diff-review-content';
		this._content.setAttribute('role', 'code');
		this._scrollbar = this._register(new DomScrollableElement(this._content, {}));
		reset(this.domNode, this._scrollbar.getDomNode(), actionBarContainer);
		this._register(
			autorun(r => {
				this._height.read(r);
				this._width.read(r);
				this._scrollbar.scanDomNode();
			})
		);
		this._register(
			toDisposable(() => {
				reset(this.domNode);
			})
		);
		this._register(
			applyStyle(this.domNode, {
				width: this._width,
				height: this._height
			})
		);
		this._register(
			applyStyle(this._content, {
				width: this._width,
				height: this._height
			})
		);
		this._register(
			autorunWithStore((reader, store) => {
				this._model.currentGroup.read(reader);
				this._render(store);
			})
		);
		this._register(
			addStandardDisposableListener(this.domNode, 'keydown', e => {
				if (
					e.equals(
						18 // DownArrow
					) ||
					e.equals(
						2048 | 18 // DownArrow
					) ||
					e.equals(
						512 | 18 // DownArrow
					)
				) {
					e.preventDefault();
					this._model.goToNextLine();
				}
				if (
					e.equals(
						16 // UpArrow
					) ||
					e.equals(
						2048 | 16 // UpArrow
					) ||
					e.equals(
						512 | 16 // UpArrow
					)
				) {
					e.preventDefault();
					this._model.goToPreviousLine();
				}
				if (
					e.equals(
						9 // Escape
					) ||
					e.equals(
						2048 | 9 // Escape
					) ||
					e.equals(
						512 | 9 // Escape
					) ||
					e.equals(
						1024 | 9 // Escape
					)
				) {
					e.preventDefault();
					this._model.close();
				}
				if (
					e.equals(
						10 // Space
					) ||
					e.equals(
						3 // Enter
					)
				) {
					e.preventDefault();
					this._model.revealCurrentElementInEditor();
				}
			})
		);
	}
	_render(store) {
		const originalOptions = this._models.getOriginalOptions();
		const modifiedOptions = this._models.getModifiedOptions();
		const container = document.createElement('div');
		container.className = 'diff-review-table';
		container.setAttribute('role', 'list');
		applyFontInfo(
			container,
			modifiedOptions.get(
				50 // fontInfo
			)
		);
		reset(this._content, container);
		const originalModel = this._models.getOriginalModel();
		const modifiedModel = this._models.getModifiedModel();
		if (!originalModel || !modifiedModel) {
			return;
		}
		const originalModelOpts = originalModel.getOptions();
		const modifiedModelOpts = modifiedModel.getOptions();
		const lineHeight = modifiedOptions.get(
			67 // lineHeight
		);
		const group = this._model.currentGroup.get();
		for (const viewItem of group?.lines || []) {
			if (!group) {
				break;
			}
			let row;
			if (viewItem.type === 0) {
				const header = document.createElement('div');
				header.className = 'diff-review-row';
				header.setAttribute('role', 'listitem');
				const r = group.range;
				const diffIndex = this._model.currentGroupIndex.get();
				const diffsLength = this._model.groups.get().length;
				const cell = document.createElement('div');
				cell.className = 'diff-review-cell diff-review-summary';
				cell.appendChild(
					document.createTextNode(
						`${diffIndex + 1}/${diffsLength}: @@ -${r.original.startLineNumber},${r.original.length} +${r.modified.startLineNumber},${r.modified.length} @@`
					)
				);
				header.appendChild(cell);
				row = header;
			} else {
				row = this._createRow(
					viewItem,
					lineHeight,
					this._width.get(),
					originalOptions,
					originalModel,
					originalModelOpts,
					modifiedOptions,
					modifiedModel,
					modifiedModelOpts
				);
			}
			container.appendChild(row);
			const isSelectedObs = derived(reader => this._model.currentElement.read(reader) === viewItem);
			store.add(
				autorun(reader => {
					const isSelected = isSelectedObs.read(reader);
					row.tabIndex = isSelected ? 0 : -1;
					if (isSelected) {
						row.focus();
					}
				})
			);
			store.add(
				addDisposableListener(row, 'focus', () => {
					this._model.goToLine(viewItem);
				})
			);
		}
		this._scrollbar.scanDomNode();
	}
	_createRow(
		item,
		lineHeight,
		width2,
		originalOptions,
		originalModel,
		originalModelOpts,
		modifiedOptions,
		modifiedModel,
		modifiedModelOpts
	) {
		const originalLayoutInfo = originalOptions.get(
			145 // layoutInfo
		);
		const originalLineNumbersWidth = originalLayoutInfo.glyphMarginWidth + originalLayoutInfo.lineNumbersWidth;
		const modifiedLayoutInfo = modifiedOptions.get(
			145 // layoutInfo
		);
		const modifiedLineNumbersWidth = 10 + modifiedLayoutInfo.glyphMarginWidth + modifiedLayoutInfo.lineNumbersWidth;
		let rowClassName = 'diff-review-row';
		let lineNumbersExtraClassName = '';
		const spacerClassName = 'diff-review-spacer';
		let spacerIcon = null;
		switch (item.type) {
			case 3:
				rowClassName = 'diff-review-row line-insert';
				lineNumbersExtraClassName = ' char-insert';
				spacerIcon = accessibleDiffViewerInsertIcon;
				break;
			case 2:
				rowClassName = 'diff-review-row line-delete';
				lineNumbersExtraClassName = ' char-delete';
				spacerIcon = accessibleDiffViewerRemoveIcon;
				break;
		}
		const row = document.createElement('div');
		row.style.minWidth = width2 + 'px';
		row.className = rowClassName;
		row.setAttribute('role', 'listitem');

		const cell = document.createElement('div');
		cell.className = 'diff-review-cell';
		cell.style.height = `${lineHeight}px`;
		row.appendChild(cell);
		const originalLineNumber = document.createElement('span');
		originalLineNumber.style.width = originalLineNumbersWidth + 'px';
		originalLineNumber.style.minWidth = originalLineNumbersWidth + 'px';
		originalLineNumber.className = 'diff-review-line-number' + lineNumbersExtraClassName;
		if (item.originalLineNumber !== undefined) {
			originalLineNumber.appendChild(document.createTextNode(String(item.originalLineNumber)));
		} else {
			originalLineNumber.innerText = '\xA0';
		}
		cell.appendChild(originalLineNumber);
		const modifiedLineNumber = document.createElement('span');
		modifiedLineNumber.style.width = modifiedLineNumbersWidth + 'px';
		modifiedLineNumber.style.minWidth = modifiedLineNumbersWidth + 'px';
		modifiedLineNumber.style.paddingRight = '10px';
		modifiedLineNumber.className = 'diff-review-line-number' + lineNumbersExtraClassName;
		if (item.modifiedLineNumber !== undefined) {
			modifiedLineNumber.appendChild(document.createTextNode(String(item.modifiedLineNumber)));
		} else {
			modifiedLineNumber.innerText = '\xA0';
		}
		cell.appendChild(modifiedLineNumber);
		const spacer = document.createElement('span');
		spacer.className = spacerClassName;
		if (spacerIcon) {
			const spacerCodicon = document.createElement('span');
			spacerCodicon.className = asThemeIconClassNameString(spacerIcon);
			spacerCodicon.innerText = '\xA0\xA0';
			spacer.appendChild(spacerCodicon);
		} else {
			spacer.innerText = '\xA0\xA0';
		}
		cell.appendChild(spacer);
		let lineContent;
		if (item.modifiedLineNumber !== undefined) {
			let html2 = this._getLineHtml(
				modifiedModel,
				modifiedOptions,
				modifiedModelOpts.tabSize,
				item.modifiedLineNumber,
				this._languageService.languageIdCodec
			);
			cell.insertAdjacentHTML('beforeend', html2);
			lineContent = modifiedModel.getLineContent(item.modifiedLineNumber);
		} else {
			let html2 = this._getLineHtml(
				originalModel,
				originalOptions,
				originalModelOpts.tabSize,
				item.originalLineNumber,
				this._languageService.languageIdCodec
			);
			cell.insertAdjacentHTML('beforeend', html2);
			lineContent = originalModel.getLineContent(item.originalLineNumber);
		}
		if (lineContent.length === 0) {
			lineContent = localize('blank');
		}
		return row;
	}
	_getLineHtml(model, options2, tabSize, lineNumber, languageIdCodec) {
		const lineContent = model.getLineContent(lineNumber);
		const fontInfo = options2.get(
			50 // fontInfo
		);
		const lineTokens = LineTokens.createEmpty(lineContent, languageIdCodec);
		const isBasicASCII2 = ViewLineRenderingData.isBasicASCII(lineContent, model.mightContainNonBasicASCII());
		const containsRTL2 = ViewLineRenderingData.containsRTL(lineContent, isBasicASCII2, model.mightContainRTL());
		const r = renderViewLine2(
			new RenderLineInput(
				fontInfo.isMonospace &&
					!options2.get(
						33 // disableMonospaceOptimizations
					),
				fontInfo.canUseHalfwidthRightwardsArrow,
				lineContent,
				false,
				isBasicASCII2,
				containsRTL2,
				0,
				lineTokens,
				[],
				tabSize,
				0,
				fontInfo.spaceWidth,
				fontInfo.middotWidth,
				fontInfo.wsmiddotWidth,
				options2.get(
					117 // stopRenderingLineAfter
				),
				options2.get(
					99 // renderWhitespace
				),
				options2.get(
					94 // renderControlCharacters
				),
				options2.get(
					51 // fontLigatures
				) !== EditorFontLigatures.OFF,
				null
			)
		);
		return r.html;
	}
}
__decorate([__param(5, ILanguageService)], View3);

class AccessibleDiffViewerModelFromEditors {
	constructor(editors) {
		this.editors = editors;
	}
	getOriginalModel() {
		return this.editors.original.getModel();
	}
	getOriginalOptions() {
		return this.editors.original.getOptions();
	}
	originalReveal(range2) {
		this.editors.original.revealRange(range2);
		this.editors.original.setSelection(range2);
		this.editors.original.focus();
	}
	getModifiedModel() {
		return this.editors.modified.getModel();
	}
	getModifiedOptions() {
		return this.editors.modified.getOptions();
	}
	modifiedReveal(range2) {
		if (range2) {
			this.editors.modified.revealRange(range2);
			this.editors.modified.setSelection(range2);
		}
		this.editors.modified.focus();
	}
	modifiedSetSelection(range2) {
		this.editors.modified.setSelection(range2);
	}
	modifiedFocus() {
		this.editors.modified.focus();
	}
	getModifiedPosition() {
		return this.editors.modified.getPosition();
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const IDiffProviderFactoryService = createEditorServiceDecorator('diffProviderFactoryService');
class WorkerBasedDiffProviderFactoryService {
	constructor(instantiationService) {
		this.instantiationService = instantiationService;
	}
	createDiffProvider(options2) {
		return this.instantiationService.createInstance(WorkerBasedDocumentDiffProvider, options2);
	}
}
__decorate([__param(0, IInstantiationService)], WorkerBasedDiffProviderFactoryService);
registerSingleton(
	IDiffProviderFactoryService,
	WorkerBasedDiffProviderFactoryService,
	1 // Delayed
);

class WorkerBasedDocumentDiffProvider {
	constructor(options2, editorWorkerService) {
		this.editorWorkerService = editorWorkerService;
		this.onDidChangeEventEmitter = new Emitter();
		this.onDidChange = this.onDidChangeEventEmitter.event;
		this.diffAlgorithm = 'advanced';
		this.diffAlgorithmOnDidChangeSubscription = undefined;
		this.setOptions(options2);
	}
	dispose() {
		this.diffAlgorithmOnDidChangeSubscription?.dispose();
	}
	async computeDiff(original, modified, options2, cancellationToken) {
		if (typeof this.diffAlgorithm !== 'string') {
			return this.diffAlgorithm.computeDiff(original, modified, options2, cancellationToken);
		}
		if (original.isDisposed() || modified.isDisposed()) {
			return {
				changes: [],
				identical: true,
				quitEarly: false,
				moves: []
			};
		}
		if (original.getLineCount() === 1 && original.getLineMaxColumn(1) === 1) {
			if (modified.getLineCount() === 1 && modified.getLineMaxColumn(1) === 1) {
				return {
					changes: [],
					identical: true,
					quitEarly: false,
					moves: []
				};
			}
			return {
				changes: [
					new DetailedLineRangeMapping(new LineRange(1, 2), new LineRange(1, modified.getLineCount() + 1), [
						new RangeMapping(original.getFullModelRange(), modified.getFullModelRange())
					])
				],
				identical: false,
				quitEarly: false,
				moves: []
			};
		}
		const uriKey = JSON.stringify([original.uri.toString(), modified.uri.toString()]);
		const context = JSON.stringify([
			original.id,
			modified.id,
			original.getAlternativeVersionId(),
			modified.getAlternativeVersionId(),
			JSON.stringify(options2)
		]);
		const c = WorkerBasedDocumentDiffProvider.diffCache.get(uriKey);
		if (c && c.context === context) {
			return c.result;
		}
		const sw = StopWatch.create();
		const result = await this.editorWorkerService.computeDiff(original.uri, modified.uri, options2, this.diffAlgorithm);
		const timeMs = sw.elapsed();
		if (cancellationToken.isCancellationRequested) {
			return {
				changes: [],
				identical: false,
				quitEarly: true,
				moves: []
			};
		}
		if (!result) {
			throw new Error('no diff result available');
		}
		if (WorkerBasedDocumentDiffProvider.diffCache.size > 10) {
			WorkerBasedDocumentDiffProvider.diffCache.delete(WorkerBasedDocumentDiffProvider.diffCache.keys().next().value);
		}
		WorkerBasedDocumentDiffProvider.diffCache.set(uriKey, {
			result,
			context
		});
		return result;
	}
	setOptions(newOptions) {
		let didChange = false;
		if (newOptions.diffAlgorithm) {
			if (this.diffAlgorithm !== newOptions.diffAlgorithm) {
				this.diffAlgorithmOnDidChangeSubscription?.dispose();
				this.diffAlgorithmOnDidChangeSubscription = undefined;
				this.diffAlgorithm = newOptions.diffAlgorithm;
				if (typeof newOptions.diffAlgorithm !== 'string') {
					this.diffAlgorithmOnDidChangeSubscription = newOptions.diffAlgorithm.onDidChange(() =>
						this.onDidChangeEventEmitter.fire()
					);
				}
				didChange = true;
			}
		}
		if (didChange) {
			this.onDidChangeEventEmitter.fire();
		}
	}
}
WorkerBasedDocumentDiffProvider.diffCache = new Map();
__decorate([__param(1, IEditorWorkerService)], WorkerBasedDocumentDiffProvider);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


class DiffChange {
	constructor(originalStart, originalLength, modifiedStart, modifiedLength) {
		this.originalStart = originalStart;
		this.originalLength = originalLength;
		this.modifiedStart = modifiedStart;
		this.modifiedLength = modifiedLength;
	}
	getOriginalEnd() {
		return this.originalStart + this.originalLength;
	}
	getModifiedEnd() {
		return this.modifiedStart + this.modifiedLength;
	}
}

function stringDiff(original, modified, pretty) {
	return new LcsDiff(new StringDiffSequence(original), new StringDiffSequence(modified)).ComputeDiff(pretty).changes;
}

class StringDiffSequence {
	constructor(source) {
		this.source = source;
	}
	getElements() {
		const source = this.source;
		const characters = new Int32Array(source.length);
		for (let i = 0, len = source.length; i < len; i++) {
			characters[i] = source.charCodeAt(i);
		}
		return characters;
	}
}
class Debug {
	static Assert(condition, message) {
		if (!condition) {
			throw new Error(message);
		}
	}
}
class MyArray {
	static Copy(sourceArray, sourceIndex, destinationArray, destinationIndex, length) {
		for (let i = 0; i < length; i++) {
			destinationArray[destinationIndex + i] = sourceArray[sourceIndex + i];
		}
	}
	static Copy2(sourceArray, sourceIndex, destinationArray, destinationIndex, length) {
		for (let i = 0; i < length; i++) {
			destinationArray[destinationIndex + i] = sourceArray[sourceIndex + i];
		}
	}
}
class DiffChangeHelper {
	constructor() {
		this.m_changes = [];
		this.m_originalStart = 1073741824;
		this.m_modifiedStart = 1073741824;
		this.m_originalCount = 0;
		this.m_modifiedCount = 0;
	}

	MarkNextChange() {
		if (this.m_originalCount > 0 || this.m_modifiedCount > 0) {
			this.m_changes.push(new DiffChange(this.m_originalStart, this.m_originalCount, this.m_modifiedStart, this.m_modifiedCount));
		}
		this.m_originalCount = 0;
		this.m_modifiedCount = 0;
		this.m_originalStart = 1073741824;
		this.m_modifiedStart = 1073741824;
	}

	AddOriginalElement(originalIndex, modifiedIndex) {
		this.m_originalStart = Math.min(this.m_originalStart, originalIndex);
		this.m_modifiedStart = Math.min(this.m_modifiedStart, modifiedIndex);
		this.m_originalCount++;
	}

	AddModifiedElement(originalIndex, modifiedIndex) {
		this.m_originalStart = Math.min(this.m_originalStart, originalIndex);
		this.m_modifiedStart = Math.min(this.m_modifiedStart, modifiedIndex);
		this.m_modifiedCount++;
	}

	getChanges() {
		if (this.m_originalCount > 0 || this.m_modifiedCount > 0) {
			this.MarkNextChange();
		}
		return this.m_changes;
	}

	getReverseChanges() {
		if (this.m_originalCount > 0 || this.m_modifiedCount > 0) {
			this.MarkNextChange();
		}
		this.m_changes.reverse();
		return this.m_changes;
	}
}
class LcsDiff {
	constructor(originalSequence, modifiedSequence, continueProcessingPredicate = null) {
		this.ContinueProcessingPredicate = continueProcessingPredicate;
		this._originalSequence = originalSequence;
		this._modifiedSequence = modifiedSequence;
		const [originalStringElements, originalElementsOrHash, originalHasStrings] = LcsDiff._getElements(originalSequence);
		const [modifiedStringElements, modifiedElementsOrHash, modifiedHasStrings] = LcsDiff._getElements(modifiedSequence);
		this._hasStrings = originalHasStrings && modifiedHasStrings;
		this._originalStringElements = originalStringElements;
		this._originalElementsOrHash = originalElementsOrHash;
		this._modifiedStringElements = modifiedStringElements;
		this._modifiedElementsOrHash = modifiedElementsOrHash;
		this.m_forwardHistory = [];
		this.m_reverseHistory = [];
	}
	static _isStringArray(arr) {
		return arr.length > 0 && typeof arr[0] === 'string';
	}
	static _getElements(sequence) {
		const elements = sequence.getElements();
		if (LcsDiff._isStringArray(elements)) {
			const hashes = new Int32Array(elements.length);
			for (let i = 0, len = elements.length; i < len; i++) {
				hashes[i] = stringHash(elements[i], 0);
			}
			return [elements, hashes, true];
		}
		if (elements instanceof Int32Array) {
			return [[], elements, false];
		}
		return [[], new Int32Array(elements), false];
	}
	ElementsAreEqual(originalIndex, newIndex) {
		if (this._originalElementsOrHash[originalIndex] !== this._modifiedElementsOrHash[newIndex]) {
			return false;
		}
		return this._hasStrings ? this._originalStringElements[originalIndex] === this._modifiedStringElements[newIndex] : true;
	}
	ElementsAreStrictEqual(originalIndex, newIndex) {
		if (!this.ElementsAreEqual(originalIndex, newIndex)) {
			return false;
		}
		const originalElement = LcsDiff._getStrictElement(this._originalSequence, originalIndex);
		const modifiedElement = LcsDiff._getStrictElement(this._modifiedSequence, newIndex);
		return originalElement === modifiedElement;
	}
	static _getStrictElement(sequence, index) {
		if (typeof sequence.getStrictElement === 'function') {
			return sequence.getStrictElement(index);
		}
		return null;
	}
	OriginalElementsAreEqual(index1, index2) {
		if (this._originalElementsOrHash[index1] !== this._originalElementsOrHash[index2]) {
			return false;
		}
		return this._hasStrings ? this._originalStringElements[index1] === this._originalStringElements[index2] : true;
	}
	ModifiedElementsAreEqual(index1, index2) {
		if (this._modifiedElementsOrHash[index1] !== this._modifiedElementsOrHash[index2]) {
			return false;
		}
		return this._hasStrings ? this._modifiedStringElements[index1] === this._modifiedStringElements[index2] : true;
	}
	ComputeDiff(pretty) {
		return this._ComputeDiff(0, this._originalElementsOrHash.length - 1, 0, this._modifiedElementsOrHash.length - 1, pretty);
	}

	_ComputeDiff(originalStart, originalEnd, modifiedStart, modifiedEnd, pretty) {
		const quitEarlyArr = [false];
		let changes = this.ComputeDiffRecursive(originalStart, originalEnd, modifiedStart, modifiedEnd, quitEarlyArr);
		if (pretty) {
			changes = this.PrettifyChanges(changes);
		}
		return {
			quitEarly: quitEarlyArr[0],
			changes
		};
	}

	ComputeDiffRecursive(originalStart, originalEnd, modifiedStart, modifiedEnd, quitEarlyArr) {
		quitEarlyArr[0] = false;
		while (originalStart <= originalEnd && modifiedStart <= modifiedEnd && this.ElementsAreEqual(originalStart, modifiedStart)) {
			originalStart++;
			modifiedStart++;
		}
		while (originalEnd >= originalStart && modifiedEnd >= modifiedStart && this.ElementsAreEqual(originalEnd, modifiedEnd)) {
			originalEnd--;
			modifiedEnd--;
		}
		if (originalStart > originalEnd || modifiedStart > modifiedEnd) {
			let changes;
			if (modifiedStart <= modifiedEnd) {
				Debug.Assert(originalStart === originalEnd + 1, 'originalStart should only be one more than originalEnd');
				changes = [new DiffChange(originalStart, 0, modifiedStart, modifiedEnd - modifiedStart + 1)];
			} else if (originalStart <= originalEnd) {
				Debug.Assert(modifiedStart === modifiedEnd + 1, 'modifiedStart should only be one more than modifiedEnd');
				changes = [new DiffChange(originalStart, originalEnd - originalStart + 1, modifiedStart, 0)];
			} else {
				Debug.Assert(originalStart === originalEnd + 1, 'originalStart should only be one more than originalEnd');
				Debug.Assert(modifiedStart === modifiedEnd + 1, 'modifiedStart should only be one more than modifiedEnd');
				changes = [];
			}
			return changes;
		}
		const midOriginalArr = [0];
		const midModifiedArr = [0];
		const result = this.ComputeRecursionPoint(
			originalStart,
			originalEnd,
			modifiedStart,
			modifiedEnd,
			midOriginalArr,
			midModifiedArr,
			quitEarlyArr
		);
		const midOriginal = midOriginalArr[0];
		const midModified = midModifiedArr[0];
		if (result !== null) {
			return result;
		} else if (!quitEarlyArr[0]) {
			const leftChanges = this.ComputeDiffRecursive(originalStart, midOriginal, modifiedStart, midModified, quitEarlyArr);
			let rightChanges = [];
			if (!quitEarlyArr[0]) {
				rightChanges = this.ComputeDiffRecursive(midOriginal + 1, originalEnd, midModified + 1, modifiedEnd, quitEarlyArr);
			} else {
				rightChanges = [
					new DiffChange(
						midOriginal + 1,
						originalEnd - (midOriginal + 1) + 1,
						midModified + 1,
						modifiedEnd - (midModified + 1) + 1
					)
				];
			}
			return this.ConcatenateChanges(leftChanges, rightChanges);
		}
		return [new DiffChange(originalStart, originalEnd - originalStart + 1, modifiedStart, modifiedEnd - modifiedStart + 1)];
	}
	WALKTRACE(
		diagonalForwardBase,
		diagonalForwardStart,
		diagonalForwardEnd,
		diagonalForwardOffset,
		diagonalReverseBase,
		diagonalReverseStart,
		diagonalReverseEnd,
		diagonalReverseOffset,
		forwardPoints,
		reversePoints,
		originalIndex,
		originalEnd,
		midOriginalArr,
		modifiedIndex,
		modifiedEnd,
		midModifiedArr,
		deltaIsEven,
		quitEarlyArr
	) {
		let forwardChanges = null;
		let reverseChanges = null;
		let changeHelper = new DiffChangeHelper();
		let diagonalMin = diagonalForwardStart;
		let diagonalMax = diagonalForwardEnd;
		let diagonalRelative = midOriginalArr[0] - midModifiedArr[0] - diagonalForwardOffset;
		let lastOriginalIndex = -1073741824;
		let historyIndex = this.m_forwardHistory.length - 1;
		do {
			const diagonal = diagonalRelative + diagonalForwardBase;
			if (diagonal === diagonalMin || (diagonal < diagonalMax && forwardPoints[diagonal - 1] < forwardPoints[diagonal + 1])) {
				originalIndex = forwardPoints[diagonal + 1];
				modifiedIndex = originalIndex - diagonalRelative - diagonalForwardOffset;
				if (originalIndex < lastOriginalIndex) {
					changeHelper.MarkNextChange();
				}
				lastOriginalIndex = originalIndex;
				changeHelper.AddModifiedElement(originalIndex + 1, modifiedIndex);
				diagonalRelative = diagonal + 1 - diagonalForwardBase;
			} else {
				originalIndex = forwardPoints[diagonal - 1] + 1;
				modifiedIndex = originalIndex - diagonalRelative - diagonalForwardOffset;
				if (originalIndex < lastOriginalIndex) {
					changeHelper.MarkNextChange();
				}
				lastOriginalIndex = originalIndex - 1;
				changeHelper.AddOriginalElement(originalIndex, modifiedIndex + 1);
				diagonalRelative = diagonal - 1 - diagonalForwardBase;
			}
			if (historyIndex >= 0) {
				forwardPoints = this.m_forwardHistory[historyIndex];
				diagonalForwardBase = forwardPoints[0];
				diagonalMin = 1;
				diagonalMax = forwardPoints.length - 1;
			}
		} while (--historyIndex >= -1);
		forwardChanges = changeHelper.getReverseChanges();
		if (quitEarlyArr[0]) {
			let originalStartPoint = midOriginalArr[0] + 1;
			let modifiedStartPoint = midModifiedArr[0] + 1;
			if (forwardChanges !== null && forwardChanges.length > 0) {
				const lastForwardChange = forwardChanges[forwardChanges.length - 1];
				originalStartPoint = Math.max(originalStartPoint, lastForwardChange.getOriginalEnd());
				modifiedStartPoint = Math.max(modifiedStartPoint, lastForwardChange.getModifiedEnd());
			}
			reverseChanges = [
				new DiffChange(
					originalStartPoint,
					originalEnd - originalStartPoint + 1,
					modifiedStartPoint,
					modifiedEnd - modifiedStartPoint + 1
				)
			];
		} else {
			changeHelper = new DiffChangeHelper();
			diagonalMin = diagonalReverseStart;
			diagonalMax = diagonalReverseEnd;
			diagonalRelative = midOriginalArr[0] - midModifiedArr[0] - diagonalReverseOffset;
			lastOriginalIndex = 1073741824;
			historyIndex = deltaIsEven ? this.m_reverseHistory.length - 1 : this.m_reverseHistory.length - 2;
			do {
				const diagonal = diagonalRelative + diagonalReverseBase;
				if (diagonal === diagonalMin || (diagonal < diagonalMax && reversePoints[diagonal - 1] >= reversePoints[diagonal + 1])) {
					originalIndex = reversePoints[diagonal + 1] - 1;
					modifiedIndex = originalIndex - diagonalRelative - diagonalReverseOffset;
					if (originalIndex > lastOriginalIndex) {
						changeHelper.MarkNextChange();
					}
					lastOriginalIndex = originalIndex + 1;
					changeHelper.AddOriginalElement(originalIndex + 1, modifiedIndex + 1);
					diagonalRelative = diagonal + 1 - diagonalReverseBase;
				} else {
					originalIndex = reversePoints[diagonal - 1];
					modifiedIndex = originalIndex - diagonalRelative - diagonalReverseOffset;
					if (originalIndex > lastOriginalIndex) {
						changeHelper.MarkNextChange();
					}
					lastOriginalIndex = originalIndex;
					changeHelper.AddModifiedElement(originalIndex + 1, modifiedIndex + 1);
					diagonalRelative = diagonal - 1 - diagonalReverseBase;
				}
				if (historyIndex >= 0) {
					reversePoints = this.m_reverseHistory[historyIndex];
					diagonalReverseBase = reversePoints[0];
					diagonalMin = 1;
					diagonalMax = reversePoints.length - 1;
				}
			} while (--historyIndex >= -1);
			reverseChanges = changeHelper.getChanges();
		}
		return this.ConcatenateChanges(forwardChanges, reverseChanges);
	}

	ComputeRecursionPoint(originalStart, originalEnd, modifiedStart, modifiedEnd, midOriginalArr, midModifiedArr, quitEarlyArr) {
		let originalIndex = 0,
			modifiedIndex = 0;
		let diagonalForwardStart = 0,
			diagonalForwardEnd = 0;
		let diagonalReverseStart = 0,
			diagonalReverseEnd = 0;
		originalStart--;
		modifiedStart--;
		midOriginalArr[0] = 0;
		midModifiedArr[0] = 0;
		this.m_forwardHistory = [];
		this.m_reverseHistory = [];
		const maxDifferences = originalEnd - originalStart + (modifiedEnd - modifiedStart);
		const numDiagonals = maxDifferences + 1;
		const forwardPoints = new Int32Array(numDiagonals);
		const reversePoints = new Int32Array(numDiagonals);
		const diagonalForwardBase = modifiedEnd - modifiedStart;
		const diagonalReverseBase = originalEnd - originalStart;
		const diagonalForwardOffset = originalStart - modifiedStart;
		const diagonalReverseOffset = originalEnd - modifiedEnd;
		const delta = diagonalReverseBase - diagonalForwardBase;
		const deltaIsEven = delta % 2 === 0;
		forwardPoints[diagonalForwardBase] = originalStart;
		reversePoints[diagonalReverseBase] = originalEnd;
		quitEarlyArr[0] = false;
		for (let numDifferences = 1; numDifferences <= maxDifferences / 2 + 1; numDifferences++) {
			let furthestOriginalIndex = 0;
			let furthestModifiedIndex = 0;
			diagonalForwardStart = this.ClipDiagonalBound(
				diagonalForwardBase - numDifferences,
				numDifferences,
				diagonalForwardBase,
				numDiagonals
			);
			diagonalForwardEnd = this.ClipDiagonalBound(
				diagonalForwardBase + numDifferences,
				numDifferences,
				diagonalForwardBase,
				numDiagonals
			);
			for (let diagonal = diagonalForwardStart; diagonal <= diagonalForwardEnd; diagonal += 2) {
				if (
					diagonal === diagonalForwardStart ||
					(diagonal < diagonalForwardEnd && forwardPoints[diagonal - 1] < forwardPoints[diagonal + 1])
				) {
					originalIndex = forwardPoints[diagonal + 1];
				} else {
					originalIndex = forwardPoints[diagonal - 1] + 1;
				}
				modifiedIndex = originalIndex - (diagonal - diagonalForwardBase) - diagonalForwardOffset;
				const tempOriginalIndex = originalIndex;
				while (
					originalIndex < originalEnd &&
					modifiedIndex < modifiedEnd &&
					this.ElementsAreEqual(originalIndex + 1, modifiedIndex + 1)
				) {
					originalIndex++;
					modifiedIndex++;
				}
				forwardPoints[diagonal] = originalIndex;
				if (originalIndex + modifiedIndex > furthestOriginalIndex + furthestModifiedIndex) {
					furthestOriginalIndex = originalIndex;
					furthestModifiedIndex = modifiedIndex;
				}
				if (!deltaIsEven && Math.abs(diagonal - diagonalReverseBase) <= numDifferences - 1) {
					if (originalIndex >= reversePoints[diagonal]) {
						midOriginalArr[0] = originalIndex;
						midModifiedArr[0] = modifiedIndex;
						if (tempOriginalIndex <= reversePoints[diagonal] && 1447 > 0 && numDifferences <= 1447 + 1) {
							return this.WALKTRACE(
								diagonalForwardBase,
								diagonalForwardStart,
								diagonalForwardEnd,
								diagonalForwardOffset,
								diagonalReverseBase,
								diagonalReverseStart,
								diagonalReverseEnd,
								diagonalReverseOffset,
								forwardPoints,
								reversePoints,
								originalIndex,
								originalEnd,
								midOriginalArr,
								modifiedIndex,
								modifiedEnd,
								midModifiedArr,
								deltaIsEven,
								quitEarlyArr
							);
						} else {
							return null;
						}
					}
				}
			}
			const matchLengthOfLongest =
				(furthestOriginalIndex - originalStart + (furthestModifiedIndex - modifiedStart) - numDifferences) / 2;
			if (
				this.ContinueProcessingPredicate !== null &&
				!this.ContinueProcessingPredicate(furthestOriginalIndex, matchLengthOfLongest)
			) {
				quitEarlyArr[0] = true;
				midOriginalArr[0] = furthestOriginalIndex;
				midModifiedArr[0] = furthestModifiedIndex;
				if (matchLengthOfLongest > 0 && 1447 > 0 && numDifferences <= 1447 + 1) {
					return this.WALKTRACE(
						diagonalForwardBase,
						diagonalForwardStart,
						diagonalForwardEnd,
						diagonalForwardOffset,
						diagonalReverseBase,
						diagonalReverseStart,
						diagonalReverseEnd,
						diagonalReverseOffset,
						forwardPoints,
						reversePoints,
						originalIndex,
						originalEnd,
						midOriginalArr,
						modifiedIndex,
						modifiedEnd,
						midModifiedArr,
						deltaIsEven,
						quitEarlyArr
					);
				} else {
					originalStart++;
					modifiedStart++;
					return [new DiffChange(originalStart, originalEnd - originalStart + 1, modifiedStart, modifiedEnd - modifiedStart + 1)];
				}
			}
			diagonalReverseStart = this.ClipDiagonalBound(
				diagonalReverseBase - numDifferences,
				numDifferences,
				diagonalReverseBase,
				numDiagonals
			);
			diagonalReverseEnd = this.ClipDiagonalBound(
				diagonalReverseBase + numDifferences,
				numDifferences,
				diagonalReverseBase,
				numDiagonals
			);
			for (let diagonal = diagonalReverseStart; diagonal <= diagonalReverseEnd; diagonal += 2) {
				if (
					diagonal === diagonalReverseStart ||
					(diagonal < diagonalReverseEnd && reversePoints[diagonal - 1] >= reversePoints[diagonal + 1])
				) {
					originalIndex = reversePoints[diagonal + 1] - 1;
				} else {
					originalIndex = reversePoints[diagonal - 1];
				}
				modifiedIndex = originalIndex - (diagonal - diagonalReverseBase) - diagonalReverseOffset;
				const tempOriginalIndex = originalIndex;
				while (
					originalIndex > originalStart &&
					modifiedIndex > modifiedStart &&
					this.ElementsAreEqual(originalIndex, modifiedIndex)
				) {
					originalIndex--;
					modifiedIndex--;
				}
				reversePoints[diagonal] = originalIndex;
				if (deltaIsEven && Math.abs(diagonal - diagonalForwardBase) <= numDifferences) {
					if (originalIndex <= forwardPoints[diagonal]) {
						midOriginalArr[0] = originalIndex;
						midModifiedArr[0] = modifiedIndex;
						if (tempOriginalIndex >= forwardPoints[diagonal] && 1447 > 0 && numDifferences <= 1447 + 1) {
							return this.WALKTRACE(
								diagonalForwardBase,
								diagonalForwardStart,
								diagonalForwardEnd,
								diagonalForwardOffset,
								diagonalReverseBase,
								diagonalReverseStart,
								diagonalReverseEnd,
								diagonalReverseOffset,
								forwardPoints,
								reversePoints,
								originalIndex,
								originalEnd,
								midOriginalArr,
								modifiedIndex,
								modifiedEnd,
								midModifiedArr,
								deltaIsEven,
								quitEarlyArr
							);
						} else {
							return null;
						}
					}
				}
			}
			if (numDifferences <= 1447) {
				let temp = new Int32Array(diagonalForwardEnd - diagonalForwardStart + 2);
				temp[0] = diagonalForwardBase - diagonalForwardStart + 1;
				MyArray.Copy2(forwardPoints, diagonalForwardStart, temp, 1, diagonalForwardEnd - diagonalForwardStart + 1);
				this.m_forwardHistory.push(temp);
				temp = new Int32Array(diagonalReverseEnd - diagonalReverseStart + 2);
				temp[0] = diagonalReverseBase - diagonalReverseStart + 1;
				MyArray.Copy2(reversePoints, diagonalReverseStart, temp, 1, diagonalReverseEnd - diagonalReverseStart + 1);
				this.m_reverseHistory.push(temp);
			}
		}
		return this.WALKTRACE(
			diagonalForwardBase,
			diagonalForwardStart,
			diagonalForwardEnd,
			diagonalForwardOffset,
			diagonalReverseBase,
			diagonalReverseStart,
			diagonalReverseEnd,
			diagonalReverseOffset,
			forwardPoints,
			reversePoints,
			originalIndex,
			originalEnd,
			midOriginalArr,
			modifiedIndex,
			modifiedEnd,
			midModifiedArr,
			deltaIsEven,
			quitEarlyArr
		);
	}

	PrettifyChanges(changes) {
		for (let i = 0; i < changes.length; i++) {
			const change = changes[i];
			const originalStop = i < changes.length - 1 ? changes[i + 1].originalStart : this._originalElementsOrHash.length;
			const modifiedStop = i < changes.length - 1 ? changes[i + 1].modifiedStart : this._modifiedElementsOrHash.length;
			const checkOriginal = change.originalLength > 0;
			const checkModified = change.modifiedLength > 0;
			while (
				change.originalStart + change.originalLength < originalStop &&
				change.modifiedStart + change.modifiedLength < modifiedStop &&
				(!checkOriginal || this.OriginalElementsAreEqual(change.originalStart, change.originalStart + change.originalLength)) &&
				(!checkModified || this.ModifiedElementsAreEqual(change.modifiedStart, change.modifiedStart + change.modifiedLength))
			) {
				const startStrictEqual = this.ElementsAreStrictEqual(change.originalStart, change.modifiedStart);
				const endStrictEqual = this.ElementsAreStrictEqual(
					change.originalStart + change.originalLength,
					change.modifiedStart + change.modifiedLength
				);
				if (endStrictEqual && !startStrictEqual) {
					break;
				}
				change.originalStart++;
				change.modifiedStart++;
			}
			const mergedChangeArr = [null];
			if (i < changes.length - 1 && this.ChangesOverlap(changes[i], changes[i + 1], mergedChangeArr)) {
				changes[i] = mergedChangeArr[0];
				changes.splice(i + 1, 1);
				i--;
				continue;
			}
		}
		for (let i = changes.length - 1; i >= 0; i--) {
			const change = changes[i];
			let originalStop = 0;
			let modifiedStop = 0;
			if (i > 0) {
				const prevChange = changes[i - 1];
				originalStop = prevChange.originalStart + prevChange.originalLength;
				modifiedStop = prevChange.modifiedStart + prevChange.modifiedLength;
			}
			const checkOriginal = change.originalLength > 0;
			const checkModified = change.modifiedLength > 0;
			let bestDelta = 0;
			let bestScore = this._boundaryScore(change.originalStart, change.originalLength, change.modifiedStart, change.modifiedLength);
			for (let delta = 1; ; delta++) {
				const originalStart = change.originalStart - delta;
				const modifiedStart = change.modifiedStart - delta;
				if (originalStart < originalStop || modifiedStart < modifiedStop) {
					break;
				}
				if (checkOriginal && !this.OriginalElementsAreEqual(originalStart, originalStart + change.originalLength)) {
					break;
				}
				if (checkModified && !this.ModifiedElementsAreEqual(modifiedStart, modifiedStart + change.modifiedLength)) {
					break;
				}
				const touchingPreviousChange = originalStart === originalStop && modifiedStart === modifiedStop;
				const score3 =
					(touchingPreviousChange ? 5 : 0) +
					this._boundaryScore(originalStart, change.originalLength, modifiedStart, change.modifiedLength);
				if (score3 > bestScore) {
					bestScore = score3;
					bestDelta = delta;
				}
			}
			change.originalStart -= bestDelta;
			change.modifiedStart -= bestDelta;
			const mergedChangeArr = [null];
			if (i > 0 && this.ChangesOverlap(changes[i - 1], changes[i], mergedChangeArr)) {
				changes[i - 1] = mergedChangeArr[0];
				changes.splice(i, 1);
				i++;
				continue;
			}
		}
		if (this._hasStrings) {
			for (let i = 1, len = changes.length; i < len; i++) {
				const aChange = changes[i - 1];
				const bChange = changes[i];
				const matchedLength = bChange.originalStart - aChange.originalStart - aChange.originalLength;
				const aOriginalStart = aChange.originalStart;
				const bOriginalEnd = bChange.originalStart + bChange.originalLength;
				const abOriginalLength = bOriginalEnd - aOriginalStart;
				const aModifiedStart = aChange.modifiedStart;
				const bModifiedEnd = bChange.modifiedStart + bChange.modifiedLength;
				const abModifiedLength = bModifiedEnd - aModifiedStart;
				if (matchedLength < 5 && abOriginalLength < 20 && abModifiedLength < 20) {
					const t = this._findBetterContiguousSequence(
						aOriginalStart,
						abOriginalLength,
						aModifiedStart,
						abModifiedLength,
						matchedLength
					);
					if (t) {
						const [originalMatchStart, modifiedMatchStart] = t;
						if (
							originalMatchStart !== aChange.originalStart + aChange.originalLength ||
							modifiedMatchStart !== aChange.modifiedStart + aChange.modifiedLength
						) {
							aChange.originalLength = originalMatchStart - aChange.originalStart;
							aChange.modifiedLength = modifiedMatchStart - aChange.modifiedStart;
							bChange.originalStart = originalMatchStart + matchedLength;
							bChange.modifiedStart = modifiedMatchStart + matchedLength;
							bChange.originalLength = bOriginalEnd - bChange.originalStart;
							bChange.modifiedLength = bModifiedEnd - bChange.modifiedStart;
						}
					}
				}
			}
		}
		return changes;
	}
	_findBetterContiguousSequence(originalStart, originalLength, modifiedStart, modifiedLength, desiredLength) {
		if (originalLength < desiredLength || modifiedLength < desiredLength) {
			return null;
		}
		const originalMax = originalStart + originalLength - desiredLength + 1;
		const modifiedMax = modifiedStart + modifiedLength - desiredLength + 1;
		let bestScore = 0;
		let bestOriginalStart = 0;
		let bestModifiedStart = 0;
		for (let i = originalStart; i < originalMax; i++) {
			for (let j = modifiedStart; j < modifiedMax; j++) {
				const score3 = this._contiguousSequenceScore(i, j, desiredLength);
				if (score3 > 0 && score3 > bestScore) {
					bestScore = score3;
					bestOriginalStart = i;
					bestModifiedStart = j;
				}
			}
		}
		if (bestScore > 0) {
			return [bestOriginalStart, bestModifiedStart];
		}
		return null;
	}
	_contiguousSequenceScore(originalStart, modifiedStart, length) {
		let score3 = 0;
		for (let l = 0; l < length; l++) {
			if (!this.ElementsAreEqual(originalStart + l, modifiedStart + l)) {
				return 0;
			}
			score3 += this._originalStringElements[originalStart + l].length;
		}
		return score3;
	}
	_OriginalIsBoundary(index) {
		if (index <= 0 || index >= this._originalElementsOrHash.length - 1) {
			return true;
		}
		return this._hasStrings && /^\s*$/.test(this._originalStringElements[index]);
	}
	_OriginalRegionIsBoundary(originalStart, originalLength) {
		if (this._OriginalIsBoundary(originalStart) || this._OriginalIsBoundary(originalStart - 1)) {
			return true;
		}
		if (originalLength > 0) {
			const originalEnd = originalStart + originalLength;
			if (this._OriginalIsBoundary(originalEnd - 1) || this._OriginalIsBoundary(originalEnd)) {
				return true;
			}
		}
		return false;
	}
	_ModifiedIsBoundary(index) {
		if (index <= 0 || index >= this._modifiedElementsOrHash.length - 1) {
			return true;
		}
		return this._hasStrings && /^\s*$/.test(this._modifiedStringElements[index]);
	}
	_ModifiedRegionIsBoundary(modifiedStart, modifiedLength) {
		if (this._ModifiedIsBoundary(modifiedStart) || this._ModifiedIsBoundary(modifiedStart - 1)) {
			return true;
		}
		if (modifiedLength > 0) {
			const modifiedEnd = modifiedStart + modifiedLength;
			if (this._ModifiedIsBoundary(modifiedEnd - 1) || this._ModifiedIsBoundary(modifiedEnd)) {
				return true;
			}
		}
		return false;
	}
	_boundaryScore(originalStart, originalLength, modifiedStart, modifiedLength) {
		const originalScore = this._OriginalRegionIsBoundary(originalStart, originalLength) ? 1 : 0;
		const modifiedScore = this._ModifiedRegionIsBoundary(modifiedStart, modifiedLength) ? 1 : 0;
		return originalScore + modifiedScore;
	}

	ConcatenateChanges(left, right) {
		const mergedChangeArr = [];
		if (left.length === 0 || right.length === 0) {
			return right.length > 0 ? right : left;
		} else if (this.ChangesOverlap(left[left.length - 1], right[0], mergedChangeArr)) {
			const result = new Array(left.length + right.length - 1);
			MyArray.Copy(left, 0, result, 0, left.length - 1);
			result[left.length - 1] = mergedChangeArr[0];
			MyArray.Copy(right, 1, result, left.length, right.length - 1);
			return result;
		} else {
			const result = new Array(left.length + right.length);
			MyArray.Copy(left, 0, result, 0, left.length);
			MyArray.Copy(right, 0, result, left.length, right.length);
			return result;
		}
	}

	ChangesOverlap(left, right, mergedChangeArr) {
		Debug.Assert(left.originalStart <= right.originalStart, 'Left change is not less than or equal to right change');
		Debug.Assert(left.modifiedStart <= right.modifiedStart, 'Left change is not less than or equal to right change');
		if (
			left.originalStart + left.originalLength >= right.originalStart ||
			left.modifiedStart + left.modifiedLength >= right.modifiedStart
		) {
			const originalStart = left.originalStart;
			let originalLength = left.originalLength;
			const modifiedStart = left.modifiedStart;
			let modifiedLength = left.modifiedLength;
			if (left.originalStart + left.originalLength >= right.originalStart) {
				originalLength = right.originalStart + right.originalLength - left.originalStart;
			}
			if (left.modifiedStart + left.modifiedLength >= right.modifiedStart) {
				modifiedLength = right.modifiedStart + right.modifiedLength - left.modifiedStart;
			}
			mergedChangeArr[0] = new DiffChange(originalStart, originalLength, modifiedStart, modifiedLength);
			return true;
		} else {
			mergedChangeArr[0] = null;
			return false;
		}
	}

	ClipDiagonalBound(diagonal, numDifferences, diagonalBaseIndex, numDiagonals) {
		if (diagonal >= 0 && diagonal < numDiagonals) {
			return diagonal;
		}
		const diagonalsBelow = diagonalBaseIndex;
		const diagonalsAbove = numDiagonals - diagonalBaseIndex - 1;
		const diffEven = numDifferences % 2 === 0;
		if (diagonal < 0) {
			const lowerBoundEven = diagonalsBelow % 2 === 0;
			return diffEven === lowerBoundEven ? 0 : 1;
		} else {
			const upperBoundEven = diagonalsAbove % 2 === 0;
			return diffEven === upperBoundEven ? numDiagonals - 1 : numDiagonals - 2;
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


const colorId_overviewInserted_foreground = 'diffEditorOverview.insertedForeground';


	registerColor(
		colorId_overviewInserted_foreground,
		{ dark: null, light: null, hcDark: null, hcLight: null },
		localize('Diff overview ruler foreground for inserted content.')
	);
class OverviewRulerFeature extends Disposable {
	constructor(_editors, _rootElement, _diffModel, _rootWidth, _rootHeight, _modifiedEditorLayoutInfo, _themeService) {
		super();
		this._editors = _editors;
		this._rootElement = _rootElement;
		this._diffModel = _diffModel;
		this._rootWidth = _rootWidth;
		this._rootHeight = _rootHeight;
		this._modifiedEditorLayoutInfo = _modifiedEditorLayoutInfo;
		this._themeService = _themeService;
		this.width = OverviewRulerFeature.ENTIRE_DIFF_OVERVIEW_WIDTH;
		const currentColorTheme = observableFromEvent(this._themeService.onDidColorThemeChange, () => this._themeService.getColorTheme());
		const currentColors = derived(reader => {
			const theme = currentColorTheme.read(reader);
			const insertColor =
				theme.getColor(colorId_overviewInserted_foreground) ||
				(theme.getColor(colorId_insertedText_background) || color_defaultInsert).transparent(2);
			const removeColor =
				theme.getColor(colorId_overviewRemoved_foreground) ||
				(theme.getColor(colorId_removedText_background) || color_defaultRemove).transparent(2);
			return { insertColor, removeColor };
		});
		const viewportDomElement = createFastDomNode(document.createElement('div'));
		viewportDomElement.setClassName('diffViewport');
		viewportDomElement.setPosition('absolute');
		const diffOverviewRoot = h('div.diffOverview', {
			style: {
				position: 'absolute',
				top: '0px',
				width: OverviewRulerFeature.ENTIRE_DIFF_OVERVIEW_WIDTH + 'px'
			}
		}).root;
		this._register(appendRemoveOnDispose(diffOverviewRoot, viewportDomElement.domNode));
		this._register(
			addStandardDisposableListener(diffOverviewRoot, EventType.POINTER_DOWN, e => {
				this._editors.modified.delegateVerticalScrollbarPointerDown(e);
			})
		);
		this._register(
			addDisposableListener(
				diffOverviewRoot,
				EventType.MOUSE_WHEEL,
				e => {
					this._editors.modified.delegateScrollFromMouseWheelEvent(e);
				},
				{ passive: false }
			)
		);
		this._register(appendRemoveOnDispose(this._rootElement, diffOverviewRoot));
		this._register(
			autorunWithStore((reader, store) => {
				const m = this._diffModel.read(reader);
				const originalOverviewRuler = this._editors.original.createOverviewRuler('original diffOverviewRuler');
				if (originalOverviewRuler) {
					store.add(originalOverviewRuler);
					store.add(appendRemoveOnDispose(diffOverviewRoot, originalOverviewRuler.getDomNode()));
				}
				const modifiedOverviewRuler = this._editors.modified.createOverviewRuler('modified diffOverviewRuler');
				if (modifiedOverviewRuler) {
					store.add(modifiedOverviewRuler);
					store.add(appendRemoveOnDispose(diffOverviewRoot, modifiedOverviewRuler.getDomNode()));
				}
				if (!originalOverviewRuler || !modifiedOverviewRuler) {
					return;
				}
				const origViewZonesChanged = observableSignalFromEvent('viewZoneChanged', this._editors.original.onDidChangeViewZones);
				const modViewZonesChanged = observableSignalFromEvent('viewZoneChanged', this._editors.modified.onDidChangeViewZones);
				const origHiddenRangesChanged = observableSignalFromEvent(
					'hiddenRangesChanged',
					this._editors.original.onDidChangeHiddenAreas
				);
				const modHiddenRangesChanged = observableSignalFromEvent(
					'hiddenRangesChanged',
					this._editors.modified.onDidChangeHiddenAreas
				);
				store.add(
					autorun(reader2 => {
						origViewZonesChanged.read(reader2);
						modViewZonesChanged.read(reader2);
						origHiddenRangesChanged.read(reader2);
						modHiddenRangesChanged.read(reader2);
						const colors = currentColors.read(reader2);
						const diff = m?.diff?.read(reader2)?.mappings;
						function createZones(ranges, color, editor2) {
							const vm = editor2._getViewModel();
							if (!vm) {
								return [];
							}
							return ranges
								.filter(d => d.length > 0)
								.map(r => {
									const start = vm.coordinatesConverter.convertModelPositionToViewPosition(
										new Position(r.startLineNumber, 1)
									);
									const end = vm.coordinatesConverter.convertModelPositionToViewPosition(
										new Position(r.endLineNumberExclusive, 1)
									);
									const lineCount = end.lineNumber - start.lineNumber;
									return new OverviewRulerZone(start.lineNumber, end.lineNumber, lineCount, color.toString());
								});
						}
						const originalZones = createZones(
							(diff || []).map(d => d.lineRangeMapping.original),
							colors.removeColor,
							this._editors.original
						);
						const modifiedZones = createZones(
							(diff || []).map(d => d.lineRangeMapping.modified),
							colors.insertColor,
							this._editors.modified
						);
						originalOverviewRuler === null || originalOverviewRuler === undefined
							? undefined
							: originalOverviewRuler.setZones(originalZones);
						modifiedOverviewRuler === null || modifiedOverviewRuler === undefined
							? undefined
							: modifiedOverviewRuler.setZones(modifiedZones);
					})
				);
				store.add(
					autorun(reader2 => {
						const height = this._rootHeight.read(reader2);
						const width2 = this._rootWidth.read(reader2);
						const layoutInfo = this._modifiedEditorLayoutInfo.read(reader2);
						if (layoutInfo) {
							const freeSpace = OverviewRulerFeature.ENTIRE_DIFF_OVERVIEW_WIDTH - 2 * OverviewRulerFeature.ONE_OVERVIEW_WIDTH;
							originalOverviewRuler.setLayout({
								top: 0,
								height,
								right: freeSpace + OverviewRulerFeature.ONE_OVERVIEW_WIDTH,
								width: OverviewRulerFeature.ONE_OVERVIEW_WIDTH
							});
							modifiedOverviewRuler.setLayout({
								top: 0,
								height,
								right: 0,
								width: OverviewRulerFeature.ONE_OVERVIEW_WIDTH
							});
							const scrollTop = this._editors.modifiedScrollTop.read(reader2);
							const scrollHeight = this._editors.modifiedScrollHeight.read(reader2);
							const scrollBarOptions = this._editors.modified.getOption(
								103
								// scrollbar
							);
							const state = new ScrollbarState(
								scrollBarOptions.verticalHasArrows ? scrollBarOptions.arrowSize : 0,
								scrollBarOptions.verticalScrollbarSize,
								0,
								layoutInfo.height,
								scrollHeight,
								scrollTop
							);
							viewportDomElement.setTop(state.getSliderPosition());
							viewportDomElement.setHeight(state.getSliderSize());
						} else {
							viewportDomElement.setTop(0);
							viewportDomElement.setHeight(0);
						}
						diffOverviewRoot.style.height = height + 'px';
						diffOverviewRoot.style.left = width2 - OverviewRulerFeature.ENTIRE_DIFF_OVERVIEW_WIDTH + 'px';
						viewportDomElement.setWidth(OverviewRulerFeature.ENTIRE_DIFF_OVERVIEW_WIDTH);
					})
				);
			})
		);
	}
}
OverviewRulerFeature.ONE_OVERVIEW_WIDTH = 15;
OverviewRulerFeature.ENTIRE_DIFF_OVERVIEW_WIDTH = OverviewRulerFeature.ONE_OVERVIEW_WIDTH * 2;
__decorate([__param(6, IThemeService)], OverviewRulerFeature);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


class DiffEditorEditors extends Disposable {
	get onDidContentSizeChange() {
		return this._onDidContentSizeChange.event;
	}
	constructor(
		originalEditorElement,
		modifiedEditorElement,
		_options,
		_argCodeEditorWidgetOptions,
		_createInnerEditor,
		_instantiationService,
		_keybindingService
	) {
		super();
		this.originalEditorElement = originalEditorElement;
		this.modifiedEditorElement = modifiedEditorElement;
		this._options = _options;
		this._argCodeEditorWidgetOptions = _argCodeEditorWidgetOptions;
		this._createInnerEditor = _createInnerEditor;
		this._instantiationService = _instantiationService;
		this._keybindingService = _keybindingService;
		this.original = this._register(
			this._createLeftHandSideEditor(this._options.editorOptions.get(), this._argCodeEditorWidgetOptions.originalEditor || {})
		);
		this.modified = this._register(
			this._createRightHandSideEditor(this._options.editorOptions.get(), this._argCodeEditorWidgetOptions.modifiedEditor || {})
		);
		this._onDidContentSizeChange = this._register(new Emitter());
		this.modifiedScrollTop = observableFromEvent(this.modified.onDidScrollChange, () => this.modified.getScrollTop());
		this.modifiedScrollHeight = observableFromEvent(this.modified.onDidScrollChange, () => this.modified.getScrollHeight());
		this.modifiedModel = obsCodeEditor(this.modified).model;
		this.modifiedSelections = observableFromEvent(this.modified.onDidChangeCursorSelection, () => {
			return this.modified.getSelections() || [];
		});
		this.modifiedCursor = derivedOpts({ owner: this, equalsFn: Position.equals }, reader => {
			return this.modifiedSelections.read(reader)[0]?.getPosition() ?? new Position(1, 1);
		});
		this.originalCursor = observableFromEvent(this.original.onDidChangeCursorPosition, () => {
			return this.original.getPosition() ?? new Position(1, 1);
		});
		this._argCodeEditorWidgetOptions = null;
		this._register(
			autorunHandleChanges(
				{
					createEmptyChangeSummary: () => ({}),
					handleChange: (ctx, changeSummary) => {
						if (ctx.didChange(_options.editorOptions)) {
							Object.assign(changeSummary, ctx.change.changedOptions);
						}
						return true;
					}
				},
				(reader, changeSummary) => {
					_options.editorOptions.read(reader);
					this._options.renderSideBySide.read(reader);
					this.modified.updateOptions(this._adjustOptionsForRightHandSide(reader, changeSummary));
					this.original.updateOptions(this._adjustOptionsForLeftHandSide(reader, changeSummary));
				}
			)
		);
	}
	_createLeftHandSideEditor(options2, codeEditorWidgetOptions) {
		const leftHandSideOptions = this._adjustOptionsForLeftHandSide(undefined, options2);
		const editor2 = this._constructInnerEditor(
			this._instantiationService,
			this.originalEditorElement,
			leftHandSideOptions,
			codeEditorWidgetOptions
		);
		editor2.setContextValue('isInDiffLeftEditor', true);
		return editor2;
	}
	_createRightHandSideEditor(options2, codeEditorWidgetOptions) {
		const rightHandSideOptions = this._adjustOptionsForRightHandSide(undefined, options2);
		const editor2 = this._constructInnerEditor(
			this._instantiationService,
			this.modifiedEditorElement,
			rightHandSideOptions,
			codeEditorWidgetOptions
		);
		editor2.setContextValue('isInDiffRightEditor', true);
		return editor2;
	}
	_constructInnerEditor(instantiationService, container, options2, editorWidgetOptions) {
		const editor2 = this._createInnerEditor(instantiationService, container, options2, editorWidgetOptions);
		this._register(
			editor2.onDidContentSizeChange(e => {
				const width2 =
					this.original.getContentWidth() + this.modified.getContentWidth() + OverviewRulerFeature.ENTIRE_DIFF_OVERVIEW_WIDTH;
				const height = Math.max(this.modified.getContentHeight(), this.original.getContentHeight());
				this._onDidContentSizeChange.fire({
					contentHeight: height,
					contentWidth: width2,
					contentHeightChanged: e.contentHeightChanged,
					contentWidthChanged: e.contentWidthChanged
				});
			})
		);
		return editor2;
	}
	_adjustOptionsForLeftHandSide(_reader, changedOptions) {
		const result = this._adjustOptionsForSubEditor(changedOptions);
		if (!this._options.renderSideBySide.get()) {
			result.wordWrapOverride1 = 'off';
			result.wordWrapOverride2 = 'off';
			result.stickyScroll = { enabled: false };
			result.unicodeHighlight = {
				nonBasicASCII: false,
				ambiguousCharacters: false,
				invisibleCharacters: false
			};
		} else {
			result.unicodeHighlight = this._options.editorOptions.get().unicodeHighlight || {};
			result.wordWrapOverride1 = this._options.diffWordWrap.get();
		}
		result.glyphMargin = this._options.renderSideBySide.get();
		if (changedOptions.originalAriaLabel) {
			result.ariaLabel = changedOptions.originalAriaLabel;
		}
		result.ariaLabel = this._updateAriaLabel(result.ariaLabel);
		result.readOnly = !this._options.originalEditable.get();
		result.dropIntoEditor = { enabled: !result.readOnly };
		result.extraEditorClassName = 'original-in-monaco-diff-editor';
		return result;
	}
	_adjustOptionsForRightHandSide(reader, changedOptions) {
		const result = this._adjustOptionsForSubEditor(changedOptions);
		if (changedOptions.modifiedAriaLabel) {
			result.ariaLabel = changedOptions.modifiedAriaLabel;
		}
		result.ariaLabel = this._updateAriaLabel(result.ariaLabel);
		result.wordWrapOverride1 = this._options.diffWordWrap.get();
		result.revealHorizontalRightPadding =
			editorOptions.revealHorizontalRightPadding.defaultValue + OverviewRulerFeature.ENTIRE_DIFF_OVERVIEW_WIDTH;
		result.scrollbar.verticalHasArrows = false;
		result.extraEditorClassName = 'modified-in-monaco-diff-editor';
		return result;
	}
	_adjustOptionsForSubEditor(options2) {
		const clonedOptions = {
			...options2,
			dimension: {
				height: 0,
				width: 0
			}
		};
		clonedOptions.inDiffEditor = true;
		clonedOptions.automaticLayout = false;
		clonedOptions.scrollbar = { ...(clonedOptions.scrollbar || {}) };
		clonedOptions.folding = false;
		clonedOptions.codeLens = this._options.diffCodeLens.get();
		clonedOptions.fixedOverflowWidgets = true;
		clonedOptions.minimap = { ...(clonedOptions.minimap || {}) };
		clonedOptions.minimap.enabled = false;
		if (this._options.hideUnchangedRegions.get()) {
			clonedOptions.stickyScroll = { enabled: false };
		} else {
			clonedOptions.stickyScroll = this._options.editorOptions.get().stickyScroll;
		}
		return clonedOptions;
	}
	_updateAriaLabel(ariaLabel) {
		if (!ariaLabel) {
			ariaLabel = '';
		}
		const ariaNavigationTip = localize(
			' use {0} to open the accessibility help.',
			this._keybindingService.lookupKeybinding('editor.action.accessibilityHelp')?.getAriaLabel()
		);
		if (this._options.accessibilityVerbose.get()) {
			return ariaLabel + ariaNavigationTip;
		} else if (ariaLabel) {
			return ariaLabel.replaceAll(ariaNavigationTip, '');
		}
		return '';
	}
}
__decorate([__param(5, IInstantiationService), __param(6, IKeybindingService)], DiffEditorEditors);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -






function isDiffEditor(thing) {
	if (thing && typeof thing.getEditorType === 'function') {
		return thing.getEditorType() === 2;
	} else {
		return false;
	}
}

class StandaloneDiffEditor extends DiffEditorWidget {
	constructor(
		domElement,
		_options,
		instantiationService,
		contextKeyService,
		codeEditorService,
		themeService,
		notificationService,
		configurationService,
		contextMenuService,
		editorProgressService,
		clipboardService,
		accessibilitySignalService
	) {
		const options2 = { ..._options };
		updateConfigurationService(configurationService, options2, true);
		const themeDomRegistration = themeService.registerEditorContainer(domElement);
		if (typeof options2.theme === 'string') {
			themeService.setTheme(options2.theme);
		}
		if (typeof options2.autoDetectHighContrast !== 'undefined') {
			themeService.setAutoDetectHighContrast(Boolean(options2.autoDetectHighContrast));
		}
		super(
			domElement,
			options2,
			{},
			contextKeyService,
			instantiationService,
			codeEditorService,
			accessibilitySignalService,
			editorProgressService
		);
		this._configurationService = configurationService;
		this._standaloneThemeService = themeService;
		this._register(themeDomRegistration);
	}
	dispose() {
		super.dispose();
	}
	updateOptions(newOptions) {
		updateConfigurationService(this._configurationService, newOptions, true);
		if (typeof newOptions.theme === 'string') {
			this._standaloneThemeService.setTheme(newOptions.theme);
		}
		if (typeof newOptions.autoDetectHighContrast !== 'undefined') {
			this._standaloneThemeService.setAutoDetectHighContrast(Boolean(newOptions.autoDetectHighContrast));
		}
		super.updateOptions(newOptions);
	}
	_createInnerEditor(instantiationService, container, options2) {
		return instantiationService.createInstance(StandaloneCodeEditor, container, options2);
	}
	getOriginalEditor() {
		return super.getOriginalEditor();
	}
	getModifiedEditor() {
		return super.getModifiedEditor();
	}
	addCommand(keybinding, handler, context) {
		return this.getModifiedEditor().addCommand(keybinding, handler, context);
	}
	createContextKey(key, defaultValue) {
		return this.getModifiedEditor().createContextKey(key, defaultValue);
	}
	addAction(descriptor) {
		return this.getModifiedEditor().addAction(descriptor);
	}
}
__decorate(
	[
		__param(2, IInstantiationService),
		__param(3, IContextKeyService),
		__param(4, ICodeEditorService),
		__param(5, IStandaloneThemeService),
		__param(6, INotificationService),
		__param(7, IConfigurationService),
		__param(8, IContextMenuService),
		__param(9, IEditorProgressService),
		__param(10, IClipboardService),
		__param(11, IAccessibilitySignalService)
	],
	StandaloneDiffEditor
);


const createDiffEditor = (domElement, options, override) => {
	return initializeStandaloneServices(override || {}).createInstance(StandaloneDiffEditor2, domElement, options);
};


// node_modules/monaco-editor/esm/vs/editor/editor.all.js
class DiffEditorBreadcrumbsSource extends Disposable {
	constructor(_textModel, _languageFeaturesService, _outlineModelService) {
		super();
		this._textModel = _textModel;
		this._languageFeaturesService = _languageFeaturesService;
		this._outlineModelService = _outlineModelService;
		this._currentModel = observableValue(this, undefined);
		const documentSymbolProviderChanged = observableSignalFromEvent(
			'documentSymbolProvider.onDidChange',
			this._languageFeaturesService.documentSymbolProvider.onDidChange
		);
		const textModelChanged = observableSignalFromEvent(
			'_textModel.onDidChangeContent',
			editorEventDebounce(
				e => this._textModel.onDidChangeContent(e),
				() => undefined,
				100
			)
		);
		this._register(
			autorunWithStore(async (reader, store) => {
				documentSymbolProviderChanged.read(reader);
				textModelChanged.read(reader);
				const src = store.add(new DisposableCancellationTokenSource());
				const model = await this._outlineModelService.getOrCreate(this._textModel, src.token);
				if (store.isDisposed) {
					return;
				}
				this._currentModel.set(model, undefined);
			})
		);
	}
	getBreadcrumbItems(startRange, reader) {
		const m = this._currentModel.read(reader);
		if (!m) {
			return [];
		}
		const symbols = m
			.asListOfDocumentSymbols()
			.filter(s => startRange.contains(s.range.startLineNumber) && !startRange.contains(s.range.endLineNumber));

		symbols.sort((a, b) => {
			const f = x => x.range.endLineNumber - x.range.startLineNumber;
			return -(f(a) - f(b));
		});
		return symbols.map(s => ({ name: s.name, kind: s.kind, startLineNumber: s.range.startLineNumber }));
	}
}
__decorate([__param(1, ILanguageFeaturesService), __param(2, IOutlineModelService)], DiffEditorBreadcrumbsSource);
HideUnchangedRegionsFeature.setBreadcrumbsSourceFactory((textModel, instantiationService) => {
	return instantiationService.createInstance(DiffEditorBreadcrumbsSource, textModel);
});

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function validateDiffEditorOptions(options2, defaults) {
	return {
		enableSplitViewResizing: boolean(options2.enableSplitViewResizing, defaults.enableSplitViewResizing),
		splitViewDefaultRatio: clampedFloat(options2.splitViewDefaultRatio, 0.5, 0.1, 0.9),
		renderSideBySide: boolean(options2.renderSideBySide, defaults.renderSideBySide),
		renderMarginRevertIcon: boolean(options2.renderMarginRevertIcon, defaults.renderMarginRevertIcon),
		maxComputationTime: clampedInt(
			options2.maxComputationTime,
			defaults.maxComputationTime,
			0,
			1073741824
			/* Constants.MAX_SAFE_SMALL_INTEGER */
		),
		maxFileSize: clampedInt(
			options2.maxFileSize,
			defaults.maxFileSize,
			0,
			1073741824
			/* Constants.MAX_SAFE_SMALL_INTEGER */
		),
		ignoreTrimWhitespace: boolean(options2.ignoreTrimWhitespace, defaults.ignoreTrimWhitespace),
		renderIndicators: boolean(options2.renderIndicators, defaults.renderIndicators),
		originalEditable: boolean(options2.originalEditable, defaults.originalEditable),
		diffCodeLens: boolean(options2.diffCodeLens, defaults.diffCodeLens),
		renderOverviewRuler: boolean(options2.renderOverviewRuler, defaults.renderOverviewRuler),
		diffWordWrap: stringSet(options2.diffWordWrap, defaults.diffWordWrap, ['off', 'on', 'inherit']),
		diffAlgorithm: stringSet(options2.diffAlgorithm, defaults.diffAlgorithm, ['legacy', 'advanced'], {
			smart: 'legacy',
			experimental: 'advanced'
		}),
		accessibilityVerbose: boolean(options2.accessibilityVerbose, defaults.accessibilityVerbose),
		experimental: {
			showMoves: boolean(options2.experimental?.showMoves, defaults.experimental.showMoves),
			showEmptyDecorations: boolean(options2.experimental?.showEmptyDecorations, defaults.experimental.showEmptyDecorations)
		},
		hideUnchangedRegions: {
			enabled: boolean(
				options2.hideUnchangedRegions?.enabled ?? options2.experimental?.collapseUnchangedRegions,
				defaults.hideUnchangedRegions.enabled
			),
			contextLineCount: clampedInt(
				options2.hideUnchangedRegions?.contextLineCount,
				defaults.hideUnchangedRegions.contextLineCount,
				0,
				1073741824
				/* Constants.MAX_SAFE_SMALL_INTEGER */
			),
			minimumLineCount: clampedInt(
				options2.hideUnchangedRegions?.minimumLineCount,
				defaults.hideUnchangedRegions.minimumLineCount,
				0,
				1073741824
				/* Constants.MAX_SAFE_SMALL_INTEGER */
			),
			revealLineCount: clampedInt(
				options2.hideUnchangedRegions?.revealLineCount,
				defaults.hideUnchangedRegions.revealLineCount,
				0,
				1073741824
				/* Constants.MAX_SAFE_SMALL_INTEGER */
			)
		},
		isInEmbeddedEditor: boolean(options2.isInEmbeddedEditor, defaults.isInEmbeddedEditor),
		onlyShowAccessibleDiffViewer: boolean(options2.onlyShowAccessibleDiffViewer, defaults.onlyShowAccessibleDiffViewer),
		renderSideBySideInlineBreakpoint: clampedInt(
			options2.renderSideBySideInlineBreakpoint,
			defaults.renderSideBySideInlineBreakpoint,
			0,
			1073741824
			/* Constants.MAX_SAFE_SMALL_INTEGER */
		),
		useInlineViewWhenSpaceIsLimited: boolean(options2.useInlineViewWhenSpaceIsLimited, defaults.useInlineViewWhenSpaceIsLimited),
		renderGutterMenu: boolean(options2.renderGutterMenu, defaults.renderGutterMenu)
	};
}

class DiffEditorOptions {
	get editorOptions() {
		return this._options;
	}
	constructor(options2, _accessibilityService) {
		this._accessibilityService = _accessibilityService;
		this._diffEditorWidth = observableValue(this, 0);
		this._screenReaderMode = observableFromEvent(this._accessibilityService.onDidChangeScreenReaderOptimized, () =>
			this._accessibilityService.isScreenReaderOptimized()
		);
		this.couldShowInlineViewBecauseOfSize = derived(
			this,
			reader =>
				this._options.read(reader).renderSideBySide &&
				this._diffEditorWidth.read(reader) <= this._options.read(reader).renderSideBySideInlineBreakpoint
		);
		this.renderOverviewRuler = derived(this, reader => this._options.read(reader).renderOverviewRuler);
		this.renderSideBySide = derived(
			this,
			reader =>
				this._options.read(reader).renderSideBySide &&
				!(
					this._options.read(reader).useInlineViewWhenSpaceIsLimited &&
					this.couldShowInlineViewBecauseOfSize.read(reader) &&
					!this._screenReaderMode.read(reader)
				)
		);
		this.readOnly = derived(this, reader => this._options.read(reader).readOnly);
		this.shouldRenderOldRevertArrows = derived(this, reader => {
			if (!this._options.read(reader).renderMarginRevertIcon) {
				return false;
			}
			if (!this.renderSideBySide.read(reader)) {
				return false;
			}
			if (this.readOnly.read(reader)) {
				return false;
			}
			if (this.shouldRenderGutterMenu.read(reader)) {
				return false;
			}
			return true;
		});
		this.shouldRenderGutterMenu = derived(this, reader => this._options.read(reader).renderGutterMenu);
		this.renderIndicators = derived(this, reader => this._options.read(reader).renderIndicators);
		this.enableSplitViewResizing = derived(this, reader => this._options.read(reader).enableSplitViewResizing);
		this.splitViewDefaultRatio = derived(this, reader => this._options.read(reader).splitViewDefaultRatio);
		this.ignoreTrimWhitespace = derived(this, reader => this._options.read(reader).ignoreTrimWhitespace);
		this.maxComputationTimeMs = derived(this, reader => this._options.read(reader).maxComputationTime);
		this.showMoves = derived(this, reader => this._options.read(reader).experimental.showMoves && this.renderSideBySide.read(reader));
		this.isInEmbeddedEditor = derived(this, reader => this._options.read(reader).isInEmbeddedEditor);
		this.diffWordWrap = derived(this, reader => this._options.read(reader).diffWordWrap);
		this.originalEditable = derived(this, reader => this._options.read(reader).originalEditable);
		this.diffCodeLens = derived(this, reader => this._options.read(reader).diffCodeLens);
		this.accessibilityVerbose = derived(this, reader => this._options.read(reader).accessibilityVerbose);
		this.diffAlgorithm = derived(this, reader => this._options.read(reader).diffAlgorithm);
		this.showEmptyDecorations = derived(this, reader => this._options.read(reader).experimental.showEmptyDecorations);
		this.onlyShowAccessibleDiffViewer = derived(this, reader => this._options.read(reader).onlyShowAccessibleDiffViewer);
		this.hideUnchangedRegions = derived(this, reader => this._options.read(reader).hideUnchangedRegions.enabled);
		this.hideUnchangedRegionsRevealLineCount = derived(this, reader => this._options.read(reader).hideUnchangedRegions.revealLineCount);
		this.hideUnchangedRegionsContextLineCount = derived(
			this,
			reader => this._options.read(reader).hideUnchangedRegions.contextLineCount
		);
		this.hideUnchangedRegionsMinimumLineCount = derived(
			this,
			reader => this._options.read(reader).hideUnchangedRegions.minimumLineCount
		);
		const optionsCopy = { ...options2, ...validateDiffEditorOptions(options2, diffEditorDefaultOptions) };
		this._options = observableValue(this, optionsCopy);
	}
	updateOptions(changedOptions) {
		const newDiffEditorOptions = validateDiffEditorOptions(changedOptions, this._options.get());
		const newOptions = { ...this._options.get(), ...changedOptions, ...newDiffEditorOptions };
		this._options.set(newOptions, undefined, { changedOptions });
	}
	setWidth(width2) {
		this._diffEditorWidth.set(width2, undefined);
	}
}
__decorate([__param(1, IAccessibilityService)], DiffEditorOptions);
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


function toLineChanges(state) {
	return state.mappings.map(x => {
		const m = x.lineRangeMapping;
		let originalStartLineNumber;
		let originalEndLineNumber;
		let modifiedStartLineNumber;
		let modifiedEndLineNumber;
		let innerChanges = m.innerChanges;
		if (m.original.isEmpty) {
			originalStartLineNumber = m.original.startLineNumber - 1;
			originalEndLineNumber = 0;
			innerChanges = undefined;
		} else {
			originalStartLineNumber = m.original.startLineNumber;
			originalEndLineNumber = m.original.endLineNumberExclusive - 1;
		}
		if (m.modified.isEmpty) {
			modifiedStartLineNumber = m.modified.startLineNumber - 1;
			modifiedEndLineNumber = 0;
			innerChanges = undefined;
		} else {
			modifiedStartLineNumber = m.modified.startLineNumber;
			modifiedEndLineNumber = m.modified.endLineNumberExclusive - 1;
		}
		return {
			originalStartLineNumber,
			originalEndLineNumber,
			modifiedStartLineNumber,
			modifiedEndLineNumber,
			charChanges:
				innerChanges === null || innerChanges === undefined
					? undefined
					: innerChanges.map(m2 => ({
							originalStartLineNumber: m2.originalRange.startLineNumber,
							originalStartColumn: m2.originalRange.startColumn,
							originalEndLineNumber: m2.originalRange.endLineNumber,
							originalEndColumn: m2.originalRange.endColumn,
							modifiedStartLineNumber: m2.modifiedRange.startLineNumber,
							modifiedStartColumn: m2.modifiedRange.startColumn,
							modifiedEndLineNumber: m2.modifiedRange.endLineNumber,
							modifiedEndColumn: m2.modifiedRange.endColumn
						}))
		};
	});
}

class DiffEditorWidget extends DelegatingEditor {
	get onDidContentSizeChange() {
		return this._editors.onDidContentSizeChange;
	}
	constructor(
		_domElement,
		options2,
		codeEditorWidgetOptions,
		_parentContextKeyService,
		_parentInstantiationService,
		codeEditorService,
		_accessibilitySignalService,
		_editorProgressService
	) {
		super();
		this._domElement = _domElement;
		this._parentContextKeyService = _parentContextKeyService;
		this._parentInstantiationService = _parentInstantiationService;
		this._accessibilitySignalService = _accessibilitySignalService;
		this._editorProgressService = _editorProgressService;
		this.elements = h('div.monaco-diff-editor.side-by-side', { style: { position: 'relative', height: '100%' } }, [
			h('div.editor.original@original', { style: { position: 'absolute', height: '100%' } }),
			h('div.editor.modified@modified', { style: { position: 'absolute', height: '100%' } }),
			h('div.accessibleDiffViewer@accessibleDiffViewer', {
				style: { position: 'absolute', height: '100%' }
			})
		]);
		this._diffModel = observableValue(this, undefined);
		this._shouldDisposeDiffModel = false;
		this.onDidChangeModel = editorEventFromObservableLight(this._diffModel);
		this._contextKeyService = this._register(this._parentContextKeyService.createScoped(this._domElement));
		this._instantiationService = this._parentInstantiationService.createChild(
			new ServiceCollection([IContextKeyService, this._contextKeyService])
		);
		this._boundarySashes = observableValue(this, undefined);
		this._accessibleDiffViewerShouldBeVisible = observableValue(this, false);
		this._accessibleDiffViewerVisible = derived(this, reader =>
			this._options.onlyShowAccessibleDiffViewer.read(reader) ? true : this._accessibleDiffViewerShouldBeVisible.read(reader)
		);
		this._movedBlocksLinesPart = observableValue(this, undefined);
		this._layoutInfo = derived(this, reader => {
			const fullWidth = this._rootSizeObserver.width.read(reader);
			const fullHeight = this._rootSizeObserver.height.read(reader);
			const sash = this._sash.read(reader);
			const gutter = this._gutter.read(reader);
			const gutterWidth = gutter?.width?.read(reader) ?? 0;
			const overviewRulerPartWidth = this._overviewRulerPart.read(reader)?.width ?? 0;
			let originalLeft, originalWidth, modifiedLeft, modifiedWidth, gutterLeft;
			const sideBySide = !!sash;
			if (sideBySide) {
				const sashLeft = sash.sashLeft.read(reader);
				const movedBlocksLinesWidth = this._movedBlocksLinesPart.read(reader)?.width.read(reader) ?? 0;
				originalLeft = 0;
				originalWidth = sashLeft - gutterWidth - movedBlocksLinesWidth;
				gutterLeft = sashLeft - gutterWidth;
				modifiedLeft = sashLeft;
				modifiedWidth = fullWidth - modifiedLeft - overviewRulerPartWidth;
			} else {
				gutterLeft = 0;
				originalLeft = gutterWidth;
				originalWidth = Math.max(5, this._editors.original.getLayoutInfo().decorationsLeft);
				modifiedLeft = gutterWidth + originalWidth;
				modifiedWidth = fullWidth - modifiedLeft - overviewRulerPartWidth;
			}
			this.elements.original.style.left = originalLeft + 'px';
			this.elements.original.style.width = originalWidth + 'px';
			this._editors.original.layout({ width: originalWidth, height: fullHeight }, true);
			gutter?.layout(gutterLeft);
			this.elements.modified.style.left = modifiedLeft + 'px';
			this.elements.modified.style.width = modifiedWidth + 'px';
			this._editors.modified.layout({ width: modifiedWidth, height: fullHeight }, true);
			return {
				modifiedEditor: this._editors.modified.getLayoutInfo(),
				originalEditor: this._editors.original.getLayoutInfo()
			};
		});
		this._diffValue = this._diffModel.map((m, r) => m.diff?.read(r));
		this.onDidUpdateDiff = editorEventFromObservableLight(this._diffValue);
		codeEditorService.willCreateDiffEditor();
		this._contextKeyService.createKey('isInDiffEditor', true);
		this._domElement.appendChild(this.elements.root);
		this._register(toDisposable(() => this._domElement.removeChild(this.elements.root)));
		this._rootSizeObserver = this._register(new ObservableElementSizeObserver(this.elements.root, options2.dimension));
		this._rootSizeObserver.setAutomaticLayout(options2.automaticLayout ?? false);
		this._options = this._instantiationService.createInstance(DiffEditorOptions, options2);
		this._register(
			autorun(reader => {
				this._options.setWidth(this._rootSizeObserver.width.read(reader));
			})
		);
		this._contextKeyService.createKey(ctxKeys_isEmbeddedDiffEditor.key, false);
		this._register(
			bindContextKey(ctxKeys_isEmbeddedDiffEditor, this._contextKeyService, reader => this._options.isInEmbeddedEditor.read(reader))
		);
		this._register(
			bindContextKey(ctxKeys_comparingMovedCode, this._contextKeyService, reader => {
				return !!this._diffModel.read(reader)?.movedTextToCompare.read(reader);
			})
		);
		this._register(
			bindContextKey(ctxKeys_diffEditor_renderSideBySideInlineBreakpointReached, this._contextKeyService, reader =>
				this._options.couldShowInlineViewBecauseOfSize.read(reader)
			)
		);
		this._register(
			bindContextKey(ctxKeys_diffEditor_inlineMode, this._contextKeyService, reader => !this._options.renderSideBySide.read(reader))
		);
		this._register(
			bindContextKey(ctxKeys_diffEditor_hasChanges, this._contextKeyService, reader => {
				return (this._diffModel.read(reader)?.diff.read(reader)?.mappings.length ?? 0) > 0;
			})
		);
		this._editors = this._register(
			this._instantiationService.createInstance(
				DiffEditorEditors,
				this.elements.original,
				this.elements.modified,
				this._options,
				codeEditorWidgetOptions,
				(i, c, o, o2) => this._createInnerEditor(i, c, o, o2)
			)
		);
		this._register(
			bindContextKey(ctxKeys_diffEditor_writableOriginal, this._contextKeyService, reader =>
				this._options.originalEditable.read(reader)
			)
		);
		this._register(
			bindContextKey(ctxKeys_diffEditor_writableModified, this._contextKeyService, reader => !this._options.readOnly.read(reader))
		);
		this._register(
			bindContextKey(ctxKeys_diffEditor_uriOriginal, this._contextKeyService, reader => {
				return this._diffModel.read(reader)?.model.original.uri.toString() || '';
			})
		);
		this._register(
			bindContextKey(ctxKeys_diffEditor_uriModified, this._contextKeyService, reader => {
				return this._diffModel.read(reader)?.model.modified.uri.toString() || '';
			})
		);
		this._overviewRulerPart = derivedDisposable(this, reader =>
			!this._options.renderOverviewRuler.read(reader)
				? undefined
				: this._instantiationService.createInstance(
						() => {},
						this._editors,
						this.elements.root,
						this._diffModel,
						this._rootSizeObserver.width,
						this._rootSizeObserver.height,
						this._layoutInfo.map(i => i.modifiedEditor)
					)
		).recomputeInitiallyAndOnChange(this._store);
		this._sash = derivedDisposable(this, reader => {
			const showSash = this._options.renderSideBySide.read(reader);
			this.elements.root.classList.toggle('side-by-side', showSash);
			return !showSash
				? undefined
				: new DiffEditorSash(
						this._options,
						this.elements.root,
						{
							height: this._rootSizeObserver.height,
							width: this._rootSizeObserver.width.map((w, reader2) => {
								return w - (this._overviewRulerPart.read(reader2)?.width ?? 0);
							})
						},
						this._boundarySashes
					);
		}).recomputeInitiallyAndOnChange(this._store);
		const unchangedRangesFeature = derivedDisposable(this, reader =>
			this._instantiationService.createInstance(() => {}, this._editors, this._diffModel, this._options)
		).recomputeInitiallyAndOnChange(this._store);
		derivedDisposable(this, reader =>
			this._instantiationService.createInstance(() => {}, this._editors, this._diffModel, this._options, this)
		).recomputeInitiallyAndOnChange(this._store);
		const origViewZoneIdsToIgnore = new Set();
		const modViewZoneIdsToIgnore = new Set();
		let isUpdatingViewZones = false;
		const viewZoneManager = derivedDisposable(this, reader =>
			this._instantiationService.createInstance(
				() => {},
				getWindow(this._domElement),
				this._editors,
				this._diffModel,
				this._options,
				this,
				() => isUpdatingViewZones || unchangedRangesFeature.get().isUpdatingHiddenAreas,
				origViewZoneIdsToIgnore,
				modViewZoneIdsToIgnore
			)
		).recomputeInitiallyAndOnChange(this._store);
		const originalViewZones = derived(this, reader => {
			const orig = viewZoneManager.read(reader).viewZones.read(reader).orig;
			const orig2 = unchangedRangesFeature.read(reader).viewZones.read(reader).origViewZones;
			return orig.concat(orig2);
		});
		const modifiedViewZones = derived(this, reader => {
			const mod = viewZoneManager.read(reader).viewZones.read(reader).mod;
			const mod2 = unchangedRangesFeature.read(reader).viewZones.read(reader).modViewZones;
			return mod.concat(mod2);
		});
		this._register(
			applyViewZones(
				this._editors.original,
				originalViewZones,
				isUpdatingOrigViewZones => {
					isUpdatingViewZones = isUpdatingOrigViewZones;
				},
				origViewZoneIdsToIgnore
			)
		);
		let scrollState;
		this._register(
			applyViewZones(
				this._editors.modified,
				modifiedViewZones,
				isUpdatingModViewZones => {
					isUpdatingViewZones = isUpdatingModViewZones;
					if (isUpdatingViewZones) {
						scrollState = StableEditorScrollState.capture(this._editors.modified);
					} else {
						scrollState?.restore(this._editors.modified);
						scrollState = undefined;
					}
				},
				modViewZoneIdsToIgnore
			)
		);
		this._accessibleDiffViewer = derivedDisposable(this, reader =>
			this._instantiationService.createInstance(
				() => {},
				this.elements.accessibleDiffViewer,
				this._accessibleDiffViewerVisible,
				(visible, tx) => this._accessibleDiffViewerShouldBeVisible.set(visible, tx),
				this._options.onlyShowAccessibleDiffViewer.map(v => !v),
				this._rootSizeObserver.width,
				this._rootSizeObserver.height,
				this._diffModel.map((m, r) => {
					return m?.diff?.read?.(r).mappings.map(e => e.lineRangeMapping);
				}),
				new AccessibleDiffViewerModelFromEditors(this._editors)
			)
		).recomputeInitiallyAndOnChange(this._store);
		const visibility = this._accessibleDiffViewerVisible.map(v => (v ? 'hidden' : 'visible'));
		this._register(applyStyle(this.elements.modified, { visibility }));
		this._register(applyStyle(this.elements.original, { visibility }));
		this._createDiffEditorContributions();
		codeEditorService.addDiffEditor(this);
		this._gutter = derivedDisposable(this, reader => {
			return this._options.shouldRenderGutterMenu.read(reader)
				? this._instantiationService.createInstance(() => {}, this.elements.root, this._diffModel, this._editors)
				: undefined;
		});
		this._register(recomputeInitiallyAndOnChange(this._layoutInfo));
		derivedDisposable(this, () => {}).recomputeInitiallyAndOnChange(this._store, value => {
			this._movedBlocksLinesPart.set(value, undefined);
		});
		this._register(
			editorEventRunAndSubscribe(this._editors.modified.onDidChangeCursorPosition, e => this._handleCursorPositionChange(e, true))
		);
		this._register(
			editorEventRunAndSubscribe(this._editors.original.onDidChangeCursorPosition, e => this._handleCursorPositionChange(e, false))
		);
		const isInitializingDiff = this._diffModel.map(this, (m, reader) => {
			if (!m) {
				return;
			}
			return m.diff.read(reader) === undefined && !m.isDiffUpToDate.read(reader);
		});
		this._register(
			autorunWithStore((reader, store) => {
				if (isInitializingDiff.read(reader) === true) {
					const r = this._editorProgressService.show(true, 1e3);
					store.add(toDisposable(() => r.done()));
				}
			})
		);
		this._register(
			toDisposable(() => {
				if (this._shouldDisposeDiffModel) {
					this._diffModel.get()?.dispose();
				}
			})
		);
		this._register(autorunWithStore((reader, store) => {}));
	}
	_createInnerEditor(instantiationService, container, options2, editorWidgetOptions) {
		const editor2 = instantiationService.createInstance(CodeEditorWidget, container, options2, editorWidgetOptions);
		return editor2;
	}
	_createDiffEditorContributions() {
		const contributions = getDiffEditorExtensionsContributions();
		for (const desc of contributions) {
			try {
				this._register(this._instantiationService.createInstance(desc.ctor, this));
			} catch (err) {
				onUnexpectedError(err);
			}
		}
	}
	get _targetEditor() {
		return this._editors.modified;
	}
	getEditorType() {
		return 2; //IDiffEditor
	}
	layout(dimension) {
		this._rootSizeObserver.observe(dimension);
	}
	hasTextFocus() {
		return this._editors.original.hasTextFocus() || this._editors.modified.hasTextFocus();
	}
	saveViewState() {
		const originalViewState = this._editors.original.saveViewState();
		const modifiedViewState = this._editors.modified.saveViewState();
		return {
			original: originalViewState,
			modified: modifiedViewState,
			modelState: this._diffModel.get()?.serializeState()
		};
	}
	restoreViewState(s) {
		if (s && s.original && s.modified) {
			const diffEditorState = s;
			this._editors.original.restoreViewState(diffEditorState.original);
			this._editors.modified.restoreViewState(diffEditorState.modified);
			if (diffEditorState.modelState) {
				this._diffModel.get()?.restoreSerializedState(diffEditorState.modelState);
			}
		}
	}
	handleInitialized() {
		this._editors.original.handleInitialized();
		this._editors.modified.handleInitialized();
	}
	createViewModel(model) {
		return this._instantiationService.createInstance(DiffEditorViewModel, model, this._options);
	}
	getModel() {
		return this._diffModel.get()?.model ?? null;
	}
	setModel(model, tx) {
		if (!model && this._diffModel.get()) {
			this._accessibleDiffViewer.get().close();
		}
		const vm = model
			? 'model' in model
				? { model, shouldDispose: false }
				: { model: this.createViewModel(model), shouldDispose: true }
			: undefined;
		if (this._diffModel.get() !== vm?.model) {
			subtransaction(tx, tx2 => {
				batchObsEventsGlobally(tx2, () => {
					this._editors.original.setModel(vm ? vm.model.model.original : null);
					this._editors.modified.setModel(vm ? vm.model.model.modified : null);
				});
				const prevValue = this._diffModel.get();
				const shouldDispose = this._shouldDisposeDiffModel;
				this._shouldDisposeDiffModel = vm?.shouldDispose ?? false;
				this._diffModel.set(vm?.model, tx2);
				if (shouldDispose) {
					prevValue?.dispose();
				}
			});
		}
	}

	updateOptions(changedOptions) {
		this._options.updateOptions(changedOptions);
	}
	getContainerDomNode() {
		return this._domElement;
	}
	getOriginalEditor() {
		return this._editors.original;
	}
	getModifiedEditor() {
		return this._editors.modified;
	}

	getLineChanges() {
		const diffState = this._diffModel.get()?.diff.get();
		if (!diffState) {
			return null;
		}
		return toLineChanges(diffState);
	}
	revert(diff) {
		const model = this._diffModel.get();
		if (!model || !model.isDiffUpToDate.get()) {
			return;
		}
		this._editors.modified.executeEdits('diffEditor', [
			{
				range: diff.modified.toExclusiveRange(),
				text: model.model.original.getValueInRange(diff.original.toExclusiveRange())
			}
		]);
	}
	revertRangeMappings(diffs) {
		const model = this._diffModel.get();
		if (!model || !model.isDiffUpToDate.get()) {
			return;
		}
		const changes = diffs.map(c => ({
			range: c.modifiedRange,
			text: model.model.original.getValueInRange(c.originalRange)
		}));
		this._editors.modified.executeEdits('diffEditor', changes);
	}
	_goTo(diff) {
		this._editors.modified.setPosition(new Position(diff.lineRangeMapping.modified.startLineNumber, 1));
		this._editors.modified.revealRangeInCenter(diff.lineRangeMapping.modified.toExclusiveRange());
	}
	goToDiff(target) {
		const diffs = this._diffModel.get()?.diff.get()?.mappings;
		if (!diffs || diffs.length === 0) {
			return;
		}
		const curLineNumber = this._editors.modified.getPosition().lineNumber;
		let diff;
		if (target === 'next') {
			diff = diffs.find(d => d.lineRangeMapping.modified.startLineNumber > curLineNumber) ?? diffs[0];
		} else {
			diff = findLast(diffs, d => d.lineRangeMapping.modified.startLineNumber < curLineNumber) ?? diffs[diffs.length - 1];
		}
		this._goTo(diff);
		if (diff.lineRangeMapping.modified.isEmpty) {
			this._accessibilitySignalService.playSignal(AccessibilitySignal.diffLineDeleted, {
				source: 'diffEditor.goToDiff'
			});
		} else if (diff.lineRangeMapping.original.isEmpty) {
			this._accessibilitySignalService.playSignal(AccessibilitySignal.diffLineInserted, {
				source: 'diffEditor.goToDiff'
			});
		} else if (diff) {
			this._accessibilitySignalService.playSignal(AccessibilitySignal.diffLineModified, {
				source: 'diffEditor.goToDiff'
			});
		}
	}
	revealFirstDiff() {
		const diffModel = this._diffModel.get();
		if (!diffModel) {
			return;
		}
		this.waitForDiff().then(() => {
			const diffs = diffModel.diff.get()?.mappings;
			if (!diffs || diffs.length === 0) {
				return;
			}
			this._goTo(diffs[0]);
		});
	}
	accessibleDiffViewerNext() {
		this._accessibleDiffViewer.get().next();
	}
	accessibleDiffViewerPrev() {
		this._accessibleDiffViewer.get().prev();
	}
	async waitForDiff() {
		const diffModel = this._diffModel.get();
		if (!diffModel) {
			return;
		}
		await diffModel.waitForDiff();
	}
	mapToOtherSide() {
		const isModifiedFocus = this._editors.modified.hasWidgetFocus();
		const source = isModifiedFocus ? this._editors.modified : this._editors.original;
		const destination = isModifiedFocus ? this._editors.original : this._editors.modified;
		let destinationSelection;
		const sourceSelection = source.getSelection();
		if (sourceSelection) {
			const mappings = this._diffModel
				.get()
				?.diff.get()
				?.mappings.map(m => (isModifiedFocus ? m.lineRangeMapping.flip() : m.lineRangeMapping));
			if (mappings) {
				const newRange1 = translatePosition(sourceSelection.getStartPosition(), mappings);
				const newRange2 = translatePosition(sourceSelection.getEndPosition(), mappings);
				destinationSelection = Range.plusRange(newRange1, newRange2);
			}
		}
		return { destination, destinationSelection };
	}
	switchSide() {
		const { destination, destinationSelection } = this.mapToOtherSide();
		destination.focus();
		if (destinationSelection) {
			destination.setSelection(destinationSelection);
		}
	}
	exitCompareMove() {
		const model = this._diffModel.get();
		if (!model) {
			return;
		}
		model.movedTextToCompare.set(undefined, undefined);
	}
	collapseAllUnchangedRegions() {
		const unchangedRegions = this._diffModel.get()?.unchangedRegions.get();
		if (unchangedRegions) {
			transaction(tx => {
				for (const region of unchangedRegions) {
					region.collapseAll(tx);
				}
			});
		}
	}
	showAllUnchangedRegions() {
		const unchangedRegions = this._diffModel.get()?.unchangedRegions.get();
		if (unchangedRegions) {
			transaction(tx => {
				for (const region of unchangedRegions) {
					region.showAll(tx);
				}
			});
		}
	}
	_handleCursorPositionChange(e, isModifiedEditor) {
		if (e?.reason === 3) {
			const diff = this._diffModel
				.get()
				?.diff.get()
				?.mappings.find(m =>
					isModifiedEditor
						? m.lineRangeMapping.modified.contains(e.position.lineNumber)
						: m.lineRangeMapping.original.contains(e.position.lineNumber)
				);
			if (diff?.lineRangeMapping.modified.isEmpty) {
				this._accessibilitySignalService.playSignal(AccessibilitySignal.diffLineDeleted, {
					source: 'diffEditor.cursorPositionChanged'
				});
			} else if (diff?.lineRangeMapping.original.isEmpty) {
				this._accessibilitySignalService.playSignal(AccessibilitySignal.diffLineInserted, {
					source: 'diffEditor.cursorPositionChanged'
				});
			} else if (diff) {
				this._accessibilitySignalService.playSignal(AccessibilitySignal.diffLineModified, {
					source: 'diffEditor.cursorPositionChanged'
				});
			}
		}
	}
}
__decorate(
	[
		__param(3, IContextKeyService),
		__param(4, IInstantiationService),
		__param(5, ICodeEditorService),
		__param(6, IAccessibilitySignalService),
		__param(7, IEditorProgressService)
	],
	DiffEditorWidget
);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


const colorId_insertedText_background = 'diffEditor.insertedTextBackground';
const colorId_removedText_background = 'diffEditor.removedTextBackground';
const colorId_overviewRemoved_foreground = 'diffEditorOverview.removedForeground';


	registerColor(
		colorId_insertedText_background,
		{ dark: '#9ccc2c33', light: '#9ccc2c40', hcDark: null, hcLight: null },
		localize(
			'Background color for text that got inserted. The color must not be opaque so as not to hide underlying decorations.'
		),
		true
	);

	registerColor(
		colorId_removedText_background,
		{ dark: '#ff000033', light: '#ff000033', hcDark: null, hcLight: null },
		localize(
			'Background color for text that got removed. The color must not be opaque so as not to hide underlying decorations.'
		),
		true
	);

	registerColor(
		'diffEditor.insertedLineBackground',
		{ dark: color_defaultInsert, light: color_defaultInsert, hcDark: null, hcLight: null },
		localize(
			'Background color for lines that got inserted. The color must not be opaque so as not to hide underlying decorations.'
		),
		true
	);

	registerColor(
		'diffEditor.removedLineBackground',
		{ dark: color_defaultRemove, light: color_defaultRemove, hcDark: null, hcLight: null },
		localize(
			'Background color for lines that got removed. The color must not be opaque so as not to hide underlying decorations.'
		),
		true
	);

	registerColor(
		'diffEditorGutter.insertedLineBackground',
		{ dark: null, light: null, hcDark: null, hcLight: null },
		localize('Background color for the margin where lines got inserted.')
	);

	registerColor(
		'diffEditorGutter.removedLineBackground',
		{ dark: null, light: null, hcDark: null, hcLight: null },
		localize('Background color for the margin where lines got removed.')
	);



	registerColor(
		colorId_overviewRemoved_foreground,
		{ dark: null, light: null, hcDark: null, hcLight: null },
		localize('Diff overview ruler foreground for removed content.')
	);

	registerColor(
		'diffEditor.insertedTextBorder',
		{ dark: null, light: null, hcDark: '#33ff2eff', hcLight: '#374E06' },
		localize('Outline color for the text that got inserted.')
	);

	registerColor(
		'diffEditor.removedTextBorder',
		{ dark: null, light: null, hcDark: '#FF008F', hcLight: '#AD0707' },
		localize('Outline color for text that got removed.')
	);

	registerColor(
		'diffEditor.border',
		{ dark: null, light: null, hcDark: colorId_contrast_border, hcLight: colorId_contrast_border },
		localize('Border color between the two text editors.')
	);

	registerColor(
		'diffEditor.diagonalFill',
		{ dark: '#cccccc33', light: '#22222233', hcDark: null, hcLight: null },
		localize("Color of the diff editor's diagonal fill. The diagonal fill is used in side-by-side diff views.")
	);

	registerColor(
		'diffEditor.unchangedRegionBackground',
		{
			dark: 'sideBar.background',
			light: 'sideBar.background',
			hcDark: 'sideBar.background',
			hcLight: 'sideBar.background'
		},
		localize('The background color of unchanged blocks in the diff editor.')
	);

	registerColor(
		'diffEditor.unchangedRegionForeground',
		{ dark: 'foreground', light: 'foreground', hcDark: 'foreground', hcLight: 'foreground' },
		localize('The foreground color of unchanged blocks in the diff editor.')
	);

	registerColor(
		'diffEditor.unchangedCodeBackground',
		{ dark: '#74747429', light: '#b8b8b829', hcDark: null, hcLight: null },
		localize('The background color of unchanged code in the diff editor.')
	);



	registerColor(
		'diffEditor.move.border',
		{ dark: '#8b8b8b9c', light: '#8b8b8b9c', hcDark: '#8b8b8b9c', hcLight: '#8b8b8b9c' },
		localize('The border color for text that got moved in the diff editor.')
	);

	registerColor(
		'diffEditor.moveActive.border',
		{ dark: '#FFA500', light: '#FFA500', hcDark: '#FFA500', hcLight: '#FFA500' },
		localize('The active border color for text that got moved in the diff editor.')
	);

	registerColor(
		'diffEditor.unchangedRegionShadow',
		{ dark: '#000000', light: '#737373BF', hcDark: '#000000', hcLight: '#737373BF' },
		localize('The color of the shadow around unchanged region widgets.')
	);

	registerColor(
		'multiDiffEditor.headerBackground',
		{
			dark: '#262626',
			light: 'tab.inactiveBackground',
			hcDark: 'tab.inactiveBackground',
			hcLight: 'tab.inactiveBackground'
		},
		localize("The background color of the diff editor's header")
	);

	registerColor(
		'multiDiffEditor.background',
		{
			dark: 'editorBackground',
			light: 'editorBackground',
			hcDark: 'editorBackground',
			hcLight: 'editorBackground'
		},
		localize('The background color of the multi file diff editor')
	);

	registerColor(
		'multiDiffEditor.border',
		{
			dark: 'sideBarSectionHeader.border',
			light: '#cccccc',
			hcDark: 'sideBarSectionHeader.border',
			hcLight: '#cccccc'
		},
		localize('The border color of the multi file diff editor')
	);


function isDiffEditorConfigurationKey(key) {
	const editorConfigurationKeys = getEditorConfigurationKeys();
	return editorConfigurationKeys[`diffEditor.${key}`] || false;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class DiffEditorViewModel extends Disposable {
	setActiveMovedText(movedText) {
		this._activeMovedText.set(movedText, undefined);
	}
	constructor(model, _options, _diffProviderFactoryService) {
		super();
		this.model = model;
		this._options = _options;
		this._diffProviderFactoryService = _diffProviderFactoryService;
		this._isDiffUpToDate = observableValue(this, false);
		this.isDiffUpToDate = this._isDiffUpToDate;
		this._diff = observableValue(this, undefined);
		this.diff = this._diff;
		this._unchangedRegions = observableValue(this, undefined);
		this.unchangedRegions = derived(this, r => {
			if (this._options.hideUnchangedRegions.read(r)) {
				return this._unchangedRegions.read(r)?.regions ?? [];
			} else {
				transaction(tx => {
					for (const e of this._unchangedRegions.get() || []) {
						e.collapseAll(tx);
					}
				});
				return [];
			}
		});
		this.movedTextToCompare = observableValue(this, undefined);
		this._activeMovedText = observableValue(this, undefined);
		this._hoveredMovedText = observableValue(this, undefined);
		this.activeMovedText = derived(this, r => {
			return this.movedTextToCompare.read(r)?._hoveredMovedText.read(r) ?? this._activeMovedText.read(r);
		});
		this._cancellationTokenSource = new CancellationTokenSource();
		this._diffProvider = derived(this, reader => {
			const diffProvider = this._diffProviderFactoryService.createDiffProvider({
				diffAlgorithm: this._options.diffAlgorithm.read(reader)
			});
			const onChangeSignal = observableSignalFromEvent('onDidChange', diffProvider.onDidChange);
			return {
				diffProvider,
				onChangeSignal
			};
		});
		this._register(toDisposable(() => this._cancellationTokenSource.cancel()));
		const contentChangedSignal = observableSignal('contentChangedSignal');
		const debouncer = this._register(new RunOnceScheduler(() => contentChangedSignal.trigger(undefined), 200));
		this._register(
			autorun(reader => {
				const lastUnchangedRegions = this._unchangedRegions.read(reader);
				if (!lastUnchangedRegions || lastUnchangedRegions.regions.some(r => r.isDragged.read(reader))) {
					return;
				}
				const lastUnchangedRegionsOrigRanges = lastUnchangedRegions.originalDecorationIds
					.map(id => model.original.getDecorationRange(id))
					.map(r => (r ? LineRange.fromRangeInclusive(r) : undefined));
				const lastUnchangedRegionsModRanges = lastUnchangedRegions.modifiedDecorationIds
					.map(id => model.modified.getDecorationRange(id))
					.map(r => (r ? LineRange.fromRangeInclusive(r) : undefined));
				const updatedLastUnchangedRegions = lastUnchangedRegions.regions
					.map((r, idx) =>
						!lastUnchangedRegionsOrigRanges[idx] || !lastUnchangedRegionsModRanges[idx]
							? undefined
							: new UnchangedRegion(
									lastUnchangedRegionsOrigRanges[idx].startLineNumber,
									lastUnchangedRegionsModRanges[idx].startLineNumber,
									lastUnchangedRegionsOrigRanges[idx].length,
									r.visibleLineCountTop.read(reader),
									r.visibleLineCountBottom.read(reader)
								)
					)
					.filter(notIsNullOrUndefined);
				const newRanges = [];
				let didChange = false;
				for (const touching of groupAdjacentBy(
					updatedLastUnchangedRegions,
					(a, b) => a.getHiddenModifiedRange(reader).endLineNumberExclusive === b.getHiddenModifiedRange(reader).startLineNumber
				)) {
					if (touching.length > 1) {
						didChange = true;
						const sumLineCount = touching.reduce((sum, r2) => sum + r2.lineCount, 0);
						const r = new UnchangedRegion(
							touching[0].originalLineNumber,
							touching[0].modifiedLineNumber,
							sumLineCount,
							touching[0].visibleLineCountTop.get(),
							touching[touching.length - 1].visibleLineCountBottom.get()
						);
						newRanges.push(r);
					} else {
						newRanges.push(touching[0]);
					}
				}
				if (didChange) {
					const originalDecorationIds = model.original.deltaDecorations(
						lastUnchangedRegions.originalDecorationIds,
						newRanges.map(r => ({
							range: r.originalUnchangedRange.toInclusiveRange(),
							options: { description: 'unchanged' }
						}))
					);
					const modifiedDecorationIds = model.modified.deltaDecorations(
						lastUnchangedRegions.modifiedDecorationIds,
						newRanges.map(r => ({
							range: r.modifiedUnchangedRange.toInclusiveRange(),
							options: { description: 'unchanged' }
						}))
					);
					transaction(tx => {
						this._unchangedRegions.set(
							{
								regions: newRanges,
								originalDecorationIds,
								modifiedDecorationIds
							},
							tx
						);
					});
				}
			})
		);
		const updateUnchangedRegions = (result, tx, reader) => {
			const newUnchangedRegions = UnchangedRegion.fromDiffs(
				result.changes,
				model.original.getLineCount(),
				model.modified.getLineCount(),
				this._options.hideUnchangedRegionsMinimumLineCount.read(reader),
				this._options.hideUnchangedRegionsContextLineCount.read(reader)
			);
			let visibleRegions = undefined;
			const lastUnchangedRegions = this._unchangedRegions.get();
			if (lastUnchangedRegions) {
				const lastUnchangedRegionsOrigRanges = lastUnchangedRegions.originalDecorationIds
					.map(id => model.original.getDecorationRange(id))
					.map(r => (r ? LineRange.fromRangeInclusive(r) : undefined));
				const lastUnchangedRegionsModRanges = lastUnchangedRegions.modifiedDecorationIds
					.map(id => model.modified.getDecorationRange(id))
					.map(r => (r ? LineRange.fromRangeInclusive(r) : undefined));

				function filterWithPrevious(arr, filter) {
					let prev;
					return arr.filter(cur => {
						const result = filter(cur, prev);
						prev = cur;
						return result;
					});
				}

				const updatedLastUnchangedRegions = filterWithPrevious(
					lastUnchangedRegions.regions
						.map((r, idx) => {
							if (!lastUnchangedRegionsOrigRanges[idx] || !lastUnchangedRegionsModRanges[idx]) {
								return;
							}
							const length = lastUnchangedRegionsOrigRanges[idx].length;
							return new UnchangedRegion(
								lastUnchangedRegionsOrigRanges[idx].startLineNumber,
								lastUnchangedRegionsModRanges[idx].startLineNumber,
								length,
								// The visible area can shrink by edits -> we have to account for this
								Math.min(r.visibleLineCountTop.get(), length),
								Math.min(r.visibleLineCountBottom.get(), length - r.visibleLineCountTop.get())
							);
						})
						.filter(notIsNullOrUndefined),
					(cur, prev) =>
						!prev ||
						(cur.modifiedLineNumber >= prev.modifiedLineNumber + prev.lineCount &&
							cur.originalLineNumber >= prev.originalLineNumber + prev.lineCount)
				);
				let hiddenRegions = updatedLastUnchangedRegions.map(
					r => new LineRangeMapping(r.getHiddenOriginalRange(reader), r.getHiddenModifiedRange(reader))
				);
				hiddenRegions = LineRangeMapping.clip(
					hiddenRegions,
					LineRange.ofLength(1, model.original.getLineCount()),
					LineRange.ofLength(1, model.modified.getLineCount())
				);
				visibleRegions = LineRangeMapping.inverse(hiddenRegions, model.original.getLineCount(), model.modified.getLineCount());
			}
			const newUnchangedRegions2 = [];
			if (visibleRegions) {
				for (const r of newUnchangedRegions) {
					const intersecting = visibleRegions.filter(
						f => f.original.intersectsStrict(r.originalUnchangedRange) && f.modified.intersectsStrict(r.modifiedUnchangedRange)
					);
					newUnchangedRegions2.push(...r.setVisibleRanges(intersecting, tx));
				}
			} else {
				newUnchangedRegions2.push(...newUnchangedRegions);
			}
			const originalDecorationIds = model.original.deltaDecorations(
				(lastUnchangedRegions === null || lastUnchangedRegions === undefined
					? undefined
					: lastUnchangedRegions.originalDecorationIds) || [],
				newUnchangedRegions2.map(r => ({
					range: r.originalUnchangedRange.toInclusiveRange(),
					options: { description: 'unchanged' }
				}))
			);
			const modifiedDecorationIds = model.modified.deltaDecorations(
				(lastUnchangedRegions === null || lastUnchangedRegions === undefined
					? undefined
					: lastUnchangedRegions.modifiedDecorationIds) || [],
				newUnchangedRegions2.map(r => ({
					range: r.modifiedUnchangedRange.toInclusiveRange(),
					options: { description: 'unchanged' }
				}))
			);
			this._unchangedRegions.set(
				{
					regions: newUnchangedRegions2,
					originalDecorationIds,
					modifiedDecorationIds
				},
				tx
			);
		};
		this._register(
			model.modified.onDidChangeContent(e => {
				//const diff = this._diff.get();
				this._isDiffUpToDate.set(false, undefined);
				debouncer.schedule();
			})
		);
		this._register(
			model.original.onDidChangeContent(e => {
				//const diff = this._diff.get();
				this._isDiffUpToDate.set(false, undefined);
				debouncer.schedule();
			})
		);
		this._register(
			autorunWithStore(async (reader, store) => {
				this._options.hideUnchangedRegionsMinimumLineCount.read(reader);
				this._options.hideUnchangedRegionsContextLineCount.read(reader);
				debouncer.cancel();
				contentChangedSignal.read(reader);
				const documentDiffProvider = this._diffProvider.read(reader);
				documentDiffProvider.onChangeSignal.read(reader);

				this._isDiffUpToDate.set(false, undefined);
				let originalTextEditInfos = [];
				store.add(
					model.original.onDidChangeContent(e => {
						const edits = TextEditInfo.fromModelContentChanges(e.changes);
						originalTextEditInfos = combineTextEditInfos(originalTextEditInfos, edits);
					})
				);
				let modifiedTextEditInfos = [];
				store.add(
					model.modified.onDidChangeContent(e => {
						const edits = TextEditInfo.fromModelContentChanges(e.changes);
						modifiedTextEditInfos = combineTextEditInfos(modifiedTextEditInfos, edits);
					})
				);
				let result = await documentDiffProvider.diffProvider.computeDiff(
					model.original,
					model.modified,
					{
						ignoreTrimWhitespace: this._options.ignoreTrimWhitespace.read(reader),
						maxComputationTimeMs: this._options.maxComputationTimeMs.read(reader),
						computeMoves: this._options.showMoves.read(reader)
					},
					this._cancellationTokenSource.token
				);
				if (this._cancellationTokenSource.token.isCancellationRequested) {
					return;
				}
				if (model.original.isDisposed() || model.modified.isDisposed()) {
					return;
				}

				function _normalizeDocumentDiff(diff, original, modified) {
					function _normalizeRangeMapping(rangeMapping, original, modified) {
						let originalRange = rangeMapping.originalRange;
						let modifiedRange = rangeMapping.modifiedRange;
						if (
							(originalRange.endColumn !== 1 || modifiedRange.endColumn !== 1) &&
							originalRange.endColumn === original.getLineMaxColumn(originalRange.endLineNumber) &&
							modifiedRange.endColumn === modified.getLineMaxColumn(modifiedRange.endLineNumber) &&
							originalRange.endLineNumber < original.getLineCount() &&
							modifiedRange.endLineNumber < modified.getLineCount()
						) {
							originalRange = originalRange.setEndPosition(originalRange.endLineNumber + 1, 1);
							modifiedRange = modifiedRange.setEndPosition(modifiedRange.endLineNumber + 1, 1);
						}
						return new RangeMapping(originalRange, modifiedRange);
					}

					return {
						changes: diff.changes.map(
							c =>
								new DetailedLineRangeMapping(
									c.original,
									c.modified,
									c.innerChanges ? c.innerChanges.map(i => _normalizeRangeMapping(i, original, modified)) : undefined
								)
						),
						moves: diff.moves,
						identical: diff.identical,
						quitEarly: diff.quitEarly
					};
				}

				result = _normalizeDocumentDiff(result, model.original, model.modified);

				transaction(tx => {
					updateUnchangedRegions(result, tx);
					this._lastDiff = result;
					const state = DiffState.fromDiffResult(result);
					this._diff.set(state, tx);
					this._isDiffUpToDate.set(true, tx);
					const currentSyncedMovedText = this.movedTextToCompare.get();
					this.movedTextToCompare.set(
						currentSyncedMovedText
							? this._lastDiff.moves.find(m =>
									m.lineRangeMapping.modified.intersect(currentSyncedMovedText.lineRangeMapping.modified)
								)
							: undefined,
						tx
					);
				});
			})
		);
	}
	ensureModifiedLineIsVisible(lineNumber, preference, tx) {
		if (this.diff.get()?.mappings.length) {
			const unchangedRegions = this._unchangedRegions.get()?.regions || [];
			for (const r of unchangedRegions) {
				if (r.getHiddenModifiedRange(undefined).contains(lineNumber)) {
					r.showModifiedLine(lineNumber, preference, tx);
					return;
				}
			}
		}
	}
	ensureOriginalLineIsVisible(lineNumber, preference, tx) {
		if (this.diff.get()?.mappings.length) {
			const unchangedRegions = this._unchangedRegions.get()?.regions || [];
			for (const r of unchangedRegions) {
				if (r.getHiddenOriginalRange(undefined).contains(lineNumber)) {
					r.showOriginalLine(lineNumber, preference, tx);
					return;
				}
			}
		}
	}
	async waitForDiff() {
		await waitForState(this.isDiffUpToDate, s => s);
	}
	serializeState() {
		const regions = this._unchangedRegions.get();
		return {
			collapsedRegions:
				regions === null || regions === undefined
					? undefined
					: regions.regions.map(r => ({ range: r.getHiddenModifiedRange(undefined).serialize() }))
		};
	}
	restoreSerializedState(state) {
		const ranges = state.collapsedRegions?.map(r => LineRange.deserialize(r.range));
		const regions = this._unchangedRegions.get();
		if (!regions || !ranges) {
			return;
		}
		transaction(tx => {
			for (const r of regions.regions) {
				for (const range2 of ranges) {
					if (r.modifiedUnchangedRange.intersect(range2)) {
						r.setHiddenModifiedRange(range2, tx);
						break;
					}
				}
			}
		});
	}
}
__decorate([__param(2, IDiffProviderFactoryService)], DiffEditorViewModel);

class DiffState {
	static fromDiffResult(result) {
		return new DiffState(
			result.changes.map(c => new DiffMapping(c)),
			result.moves || [],
			result.identical,
			result.quitEarly
		);
	}
	constructor(mappings, movedTexts, identical, quitEarly) {
		this.mappings = mappings;
		this.movedTexts = movedTexts;
		this.identical = identical;
		this.quitEarly = quitEarly;
	}
}

class DiffMapping {
	constructor(lineRangeMapping) {
		this.lineRangeMapping = lineRangeMapping;
	}
}

class UnchangedRegion {
	static fromDiffs(changes, originalLineCount, modifiedLineCount, minHiddenLineCount, minContext) {
		const inversedMappings = DetailedLineRangeMapping.inverse(changes, originalLineCount, modifiedLineCount);
		const result = [];
		for (const mapping of inversedMappings) {
			let origStart = mapping.original.startLineNumber;
			let modStart = mapping.modified.startLineNumber;
			let length = mapping.original.length;
			const atStart = origStart === 1 && modStart === 1;
			const atEnd = origStart + length === originalLineCount + 1 && modStart + length === modifiedLineCount + 1;
			if ((atStart || atEnd) && length >= minContext + minHiddenLineCount) {
				if (atStart && !atEnd) {
					length -= minContext;
				}
				if (atEnd && !atStart) {
					origStart += minContext;
					modStart += minContext;
					length -= minContext;
				}
				result.push(new UnchangedRegion(origStart, modStart, length, 0, 0));
			} else if (length >= minContext * 2 + minHiddenLineCount) {
				origStart += minContext;
				modStart += minContext;
				length -= minContext * 2;
				result.push(new UnchangedRegion(origStart, modStart, length, 0, 0));
			}
		}
		return result;
	}
	get originalUnchangedRange() {
		return LineRange.ofLength(this.originalLineNumber, this.lineCount);
	}
	get modifiedUnchangedRange() {
		return LineRange.ofLength(this.modifiedLineNumber, this.lineCount);
	}
	constructor(originalLineNumber, modifiedLineNumber, lineCount, visibleLineCountTop, visibleLineCountBottom) {
		this.originalLineNumber = originalLineNumber;
		this.modifiedLineNumber = modifiedLineNumber;
		this.lineCount = lineCount;
		this._visibleLineCountTop = observableValue(this, 0);
		this.visibleLineCountTop = this._visibleLineCountTop;
		this._visibleLineCountBottom = observableValue(this, 0);
		this.visibleLineCountBottom = this._visibleLineCountBottom;
		this._shouldHideControls = derived(
			this,
			reader =>
				this.visibleLineCountTop.read(reader) + this.visibleLineCountBottom.read(reader) === this.lineCount &&
				!this.isDragged.read(reader)
		);
		this.isDragged = observableValue(this, undefined);
		const visibleLineCountTop2 = Math.max(Math.min(visibleLineCountTop, this.lineCount), 0);
		const visibleLineCountBottom2 = Math.max(Math.min(visibleLineCountBottom, this.lineCount - visibleLineCountTop), 0);

		if (visibleLineCountTop !== visibleLineCountTop2 || visibleLineCountBottom !== visibleLineCountBottom2) {
			onUnexpectedError(new Error('at visible line'));
		}

		this._visibleLineCountTop.set(visibleLineCountTop2, undefined);
		this._visibleLineCountBottom.set(visibleLineCountBottom2, undefined);
	}
	setVisibleRanges(visibleRanges, tx) {
		const result = [];
		const hiddenModified = new LineRangeSet(visibleRanges.map(r => r.modified)).subtractFrom(this.modifiedUnchangedRange);
		let originalStartLineNumber = this.originalLineNumber;
		let modifiedStartLineNumber = this.modifiedLineNumber;
		const modifiedEndLineNumberEx = this.modifiedLineNumber + this.lineCount;
		if (hiddenModified.ranges.length === 0) {
			this.showAll(tx);
			result.push(this);
		} else {
			let i = 0;
			for (const r of hiddenModified.ranges) {
				const isLast = i === hiddenModified.ranges.length - 1;
				i++;
				const length = (isLast ? modifiedEndLineNumberEx : r.endLineNumberExclusive) - modifiedStartLineNumber;
				const newR = new UnchangedRegion(originalStartLineNumber, modifiedStartLineNumber, length, 0, 0);
				newR.setHiddenModifiedRange(r, tx);
				result.push(newR);
				originalStartLineNumber = newR.originalUnchangedRange.endLineNumberExclusive;
				modifiedStartLineNumber = newR.modifiedUnchangedRange.endLineNumberExclusive;
			}
		}
		return result;
	}
	shouldHideControls(reader) {
		return this._shouldHideControls.read(reader);
	}
	getHiddenOriginalRange(reader) {
		return LineRange.ofLength(
			this.originalLineNumber + this._visibleLineCountTop.read(reader),
			this.lineCount - this._visibleLineCountTop.read(reader) - this._visibleLineCountBottom.read(reader)
		);
	}
	getHiddenModifiedRange(reader) {
		return LineRange.ofLength(
			this.modifiedLineNumber + this._visibleLineCountTop.read(reader),
			this.lineCount - this._visibleLineCountTop.read(reader) - this._visibleLineCountBottom.read(reader)
		);
	}
	setHiddenModifiedRange(range2, tx) {
		const visibleLineCountTop = range2.startLineNumber - this.modifiedLineNumber;
		const visibleLineCountBottom = this.modifiedLineNumber + this.lineCount - range2.endLineNumberExclusive;
		this.setState(visibleLineCountTop, visibleLineCountBottom, tx);
	}
	getMaxVisibleLineCountTop() {
		return this.lineCount - this._visibleLineCountBottom.get();
	}
	getMaxVisibleLineCountBottom() {
		return this.lineCount - this._visibleLineCountTop.get();
	}
	showMoreAbove(count = 10, tx) {
		const maxVisibleLineCountTop = this.getMaxVisibleLineCountTop();
		this._visibleLineCountTop.set(Math.min(this._visibleLineCountTop.get() + count, maxVisibleLineCountTop), tx);
	}
	showMoreBelow(count = 10, tx) {
		const maxVisibleLineCountBottom = this.lineCount - this._visibleLineCountTop.get();
		this._visibleLineCountBottom.set(Math.min(this._visibleLineCountBottom.get() + count, maxVisibleLineCountBottom), tx);
	}
	showAll(tx) {
		this._visibleLineCountBottom.set(this.lineCount - this._visibleLineCountTop.get(), tx);
	}
	showModifiedLine(lineNumber, preference, tx) {
		const top = lineNumber + 1 - (this.modifiedLineNumber + this._visibleLineCountTop.get());
		const bottom = this.modifiedLineNumber - this._visibleLineCountBottom.get() + this.lineCount - lineNumber;
		if ((preference === 0 && top < bottom) || preference === 1) {
			this._visibleLineCountTop.set(this._visibleLineCountTop.get() + top, tx);
		} else {
			this._visibleLineCountBottom.set(this._visibleLineCountBottom.get() + bottom, tx);
		}
	}
	showOriginalLine(lineNumber, preference, tx) {
		const top = lineNumber - this.originalLineNumber;
		const bottom = this.originalLineNumber + this.lineCount - lineNumber;
		if ((preference === 0 && top < bottom) || preference === 1) {
			this._visibleLineCountTop.set(Math.min(this._visibleLineCountTop.get() + bottom - top, this.getMaxVisibleLineCountTop()), tx);
		} else {
			this._visibleLineCountBottom.set(
				Math.min(this._visibleLineCountBottom.get() + top - bottom, this.getMaxVisibleLineCountBottom()),
				tx
			);
		}
	}
	collapseAll(tx) {
		this._visibleLineCountTop.set(0, tx);
		this._visibleLineCountBottom.set(0, tx);
	}
	setState(visibleLineCountTop, visibleLineCountBottom, tx) {
		visibleLineCountTop = Math.max(Math.min(visibleLineCountTop, this.lineCount), 0);
		visibleLineCountBottom = Math.max(Math.min(visibleLineCountBottom, this.lineCount - visibleLineCountTop), 0);
		this._visibleLineCountTop.set(visibleLineCountTop, tx);
		this._visibleLineCountBottom.set(visibleLineCountBottom, tx);
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class InlineDiffDeletedCodeMargin extends Disposable {
	get visibility() {
		return this._visibility;
	}
	set visibility(_visibility) {
		if (this._visibility !== _visibility) {
			this._visibility = _visibility;
			this._diffActions.style.visibility = _visibility ? 'visible' : 'hidden';
		}
	}
	constructor(
		_getViewZoneId,
		_marginDomNode,
		_modifiedEditor,
		_diff,
		_editor,
		_viewLineCounts,
		_originalTextModel,
		_contextMenuService,
		_clipboardService
	) {
		super();
		this._getViewZoneId = _getViewZoneId;
		this._marginDomNode = _marginDomNode;
		this._modifiedEditor = _modifiedEditor;
		this._diff = _diff;
		this._editor = _editor;
		this._viewLineCounts = _viewLineCounts;
		this._originalTextModel = _originalTextModel;
		this._contextMenuService = _contextMenuService;
		this._clipboardService = _clipboardService;
		this._visibility = false;
		this._marginDomNode.style.zIndex = '10';
		this._diffActions = document.createElement('div');
		this._diffActions.className = asThemeIconClassNameString(codicon_lightBulb) + ' lightbulb-glyph';
		this._diffActions.style.position = 'absolute';
		const lineHeight = this._modifiedEditor.getOption(
			67
			// lineHeight
		);
		this._diffActions.style.right = '0px';
		this._diffActions.style.visibility = 'hidden';
		this._diffActions.style.height = `${lineHeight}px`;
		this._diffActions.style.lineHeight = `${lineHeight}px`;
		this._marginDomNode.appendChild(this._diffActions);
		let currentLineNumberOffset = 0;
		const useShadowDOM =
			_modifiedEditor.getOption(
				127 // useShadowDOM
			) && !isIOS;
		const showContextMenu = (x, y) => {
			this._contextMenuService.showContextMenu({
				domForShadowRoot: useShadowDOM ? _modifiedEditor.getDomNode() : undefined,
				getAnchor: () => ({ x, y }),
				getActions: () => {
					const actions = [];
					const isDeletion = _diff.modified.isEmpty;
					actions.push(
						new Action(
							'diff.clipboard.copyDeletedContent',
							isDeletion
								? _diff.original.length > 1
									? localize('Copy deleted lines')
									: localize('Copy deleted line')
								: _diff.original.length > 1
									? localize('Copy changed lines')
									: localize('Copy changed line'),
							undefined,
							true,
							async () => {
								const originalText = this._originalTextModel.getValueInRange(_diff.original.toExclusiveRange());
								await this._clipboardService.writeText(originalText);
							}
						)
					);
					if (_diff.original.length > 1) {
						actions.push(
							new Action(
								'diff.clipboard.copyDeletedLineContent',
								isDeletion
									? localize('Copy deleted line ({0})', _diff.original.startLineNumber + currentLineNumberOffset)
									: localize('Copy changed line ({0})', _diff.original.startLineNumber + currentLineNumberOffset),
								undefined,
								true,
								async () => {
									let lineContent = this._originalTextModel.getLineContent(
										_diff.original.startLineNumber + currentLineNumberOffset
									);
									if (lineContent === '') {
										const eof = this._originalTextModel.getEndOfLineSequence();
										lineContent = eof === 0 ? '\n' : '\r\n';
									}
									await this._clipboardService.writeText(lineContent);
								}
							)
						);
					}
					const readOnly = _modifiedEditor.getOption(
						91
						// readOnly
					);
					if (!readOnly) {
						actions.push(
							new Action('diff.inline.revertChange', localize('Revert this change'), undefined, true, async () => {
								this._editor.revert(this._diff);
							})
						);
					}
					return actions;
				},
				autoSelectFirstItem: true
			});
		};
		this._register(
			addStandardDisposableListener(this._diffActions, 'mousedown', e => {
				if (!e.leftButton) {
					return;
				}
				const { top, height } = getDomNodePagePosition(this._diffActions);
				const pad = Math.floor(lineHeight / 3);
				e.preventDefault();
				showContextMenu(e.posx, top + height + pad);
			})
		);
		this._register(
			_modifiedEditor.onMouseMove(e => {
				if ((e.target.type === 8 || e.target.type === 5) && e.target.detail.viewZoneId === this._getViewZoneId()) {
					currentLineNumberOffset = this._updateLightBulbPosition(this._marginDomNode, e.event.browserEvent.y, lineHeight);
					this.visibility = true;
				} else {
					this.visibility = false;
				}
			})
		);
		this._register(
			_modifiedEditor.onMouseDown(e => {
				if (!e.event.leftButton) {
					return;
				}
				if (e.target.type === 8 || e.target.type === 5) {
					const viewZoneId = e.target.detail.viewZoneId;
					if (viewZoneId === this._getViewZoneId()) {
						e.event.preventDefault();
						currentLineNumberOffset = this._updateLightBulbPosition(this._marginDomNode, e.event.browserEvent.y, lineHeight);
						showContextMenu(e.event.posx, e.event.posy + lineHeight);
					}
				}
			})
		);
	}
	_updateLightBulbPosition(marginDomNode, y, lineHeight) {
		const { top } = getDomNodePagePosition(marginDomNode);
		const offset = y - top;
		const lineNumberOffset = Math.floor(offset / lineHeight);
		const newTop = lineNumberOffset * lineHeight;
		this._diffActions.style.top = `${newTop}px`;
		if (this._viewLineCounts) {
			let acc = 0;
			for (let i = 0; i < this._viewLineCounts.length; i++) {
				acc += this._viewLineCounts[i];
				if (lineNumberOffset < acc) {
					return i;
				}
			}
		}
		return lineNumberOffset;
	}
}




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function renderOriginalLine(
	viewLineIdx,
	lineTokens,
	decorations,
	hasCharChanges,
	mightContainNonBasicASCII,
	mightContainRTL,
	options2,
	sb
) {
	sb.appendString('<div class="view-line');
	if (!hasCharChanges) {
		sb.appendString(' char-delete');
	}
	sb.appendString('" style="top:');
	sb.appendString(String(viewLineIdx * options2.lineHeight));
	sb.appendString('px;width:1000000px;">');
	const lineContent = lineTokens.getLineContent();
	const isBasicASCII2 = ViewLineRenderingData.isBasicASCII(lineContent, mightContainNonBasicASCII);
	const containsRTL2 = ViewLineRenderingData.containsRTL(lineContent, isBasicASCII2, mightContainRTL);
	const output = renderViewLine(
		new RenderLineInput(
			options2.fontInfo.isMonospace && !options2.disableMonospaceOptimizations,
			options2.fontInfo.canUseHalfwidthRightwardsArrow,
			lineContent,
			false,
			isBasicASCII2,
			containsRTL2,
			0,
			lineTokens,
			decorations,
			options2.tabSize,
			0,
			options2.fontInfo.spaceWidth,
			options2.fontInfo.middotWidth,
			options2.fontInfo.wsmiddotWidth,
			options2.stopRenderingLineAfter,
			options2.renderWhitespace,
			options2.renderControlCharacters,
			options2.fontLigatures !== EditorFontLigatures.OFF,
			null
			// Send no selections, original line cannot be selected
		),
		sb
	);
	sb.appendString('</div>');
	return output.characterMapping.getHorizontalOffset(output.characterMapping.length);
}

class LineSource {
	constructor(lineTokens, lineBreakData, mightContainNonBasicASCII, mightContainRTL) {
		this.lineTokens = lineTokens;
		this.lineBreakData = lineBreakData;
		this.mightContainNonBasicASCII = mightContainNonBasicASCII;
		this.mightContainRTL = mightContainRTL;
	}
}

class RenderOptions {
	static fromEditor(editor2) {
		const modifiedEditorOptions = editor2.getOptions();
		const fontInfo = modifiedEditorOptions.get(
			50 // fontInfo
		);
		const layoutInfo = modifiedEditorOptions.get(
			145 // layoutInfo
		);
		return new RenderOptions(
			editor2.getModel()?.getOptions().tabSize || 0,
			fontInfo,
			modifiedEditorOptions.get(
				33 // disableMonospaceOptimizations
			),
			fontInfo.typicalHalfwidthCharacterWidth,
			modifiedEditorOptions.get(
				104 // scrollBeyondLastColumn
			),
			modifiedEditorOptions.get(
				67 // lineHeight
			),
			layoutInfo.decorationsWidth,
			modifiedEditorOptions.get(
				117 // stopRenderingLineAfter
			),
			modifiedEditorOptions.get(
				99 // renderWhitespace
			),
			modifiedEditorOptions.get(
				94 // renderControlCharacters
			),
			modifiedEditorOptions.get(
				51 // fontLigatures
			)
		);
	}
	constructor(
		tabSize,
		fontInfo,
		disableMonospaceOptimizations,
		typicalHalfwidthCharacterWidth,
		scrollBeyondLastColumn,
		lineHeight,
		lineDecorationsWidth,
		stopRenderingLineAfter,
		renderWhitespace,
		renderControlCharacters,
		fontLigatures
	) {
		this.tabSize = tabSize;
		this.fontInfo = fontInfo;
		this.disableMonospaceOptimizations = disableMonospaceOptimizations;
		this.typicalHalfwidthCharacterWidth = typicalHalfwidthCharacterWidth;
		this.scrollBeyondLastColumn = scrollBeyondLastColumn;
		this.lineHeight = lineHeight;
		this.lineDecorationsWidth = lineDecorationsWidth;
		this.stopRenderingLineAfter = stopRenderingLineAfter;
		this.renderWhitespace = renderWhitespace;
		this.renderControlCharacters = renderControlCharacters;
		this.fontLigatures = fontLigatures;
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function computeRangeAlignment(
	originalEditor,
	modifiedEditor,
	diffs,
	originalEditorAlignmentViewZones,
	modifiedEditorAlignmentViewZones,
	innerHunkAlignment
) {
	const originalLineHeightOverrides = new ArrayQueue(getAdditionalLineHeights(originalEditor, originalEditorAlignmentViewZones));
	const modifiedLineHeightOverrides = new ArrayQueue(getAdditionalLineHeights(modifiedEditor, modifiedEditorAlignmentViewZones));
	const origLineHeight = originalEditor.getOption(
		67
		// lineHeight
	);
	const modLineHeight = modifiedEditor.getOption(
		67
		// lineHeight
	);
	const result = [];
	let lastOriginalLineNumber = 0;
	let lastModifiedLineNumber = 0;
	function handleAlignmentsOutsideOfDiffs(untilOriginalLineNumberExclusive, untilModifiedLineNumberExclusive) {
		while (true) {
			let origNext = originalLineHeightOverrides.peek();
			let modNext = modifiedLineHeightOverrides.peek();
			if (origNext && origNext.lineNumber >= untilOriginalLineNumberExclusive) {
				origNext = undefined;
			}
			if (modNext && modNext.lineNumber >= untilModifiedLineNumberExclusive) {
				modNext = undefined;
			}
			if (!origNext && !modNext) {
				break;
			}
			const distOrig = origNext ? origNext.lineNumber - lastOriginalLineNumber : Number.MAX_VALUE;
			const distNext = modNext ? modNext.lineNumber - lastModifiedLineNumber : Number.MAX_VALUE;
			if (distOrig < distNext) {
				originalLineHeightOverrides.dequeue();
				modNext = {
					lineNumber: origNext.lineNumber - lastOriginalLineNumber + lastModifiedLineNumber,
					heightInPx: 0
				};
			} else if (distOrig > distNext) {
				modifiedLineHeightOverrides.dequeue();
				origNext = {
					lineNumber: modNext.lineNumber - lastModifiedLineNumber + lastOriginalLineNumber,
					heightInPx: 0
				};
			} else {
				originalLineHeightOverrides.dequeue();
				modifiedLineHeightOverrides.dequeue();
			}
			result.push({
				originalRange: LineRange.ofLength(origNext.lineNumber, 1),
				modifiedRange: LineRange.ofLength(modNext.lineNumber, 1),
				originalHeightInPx: origLineHeight + origNext.heightInPx,
				modifiedHeightInPx: modLineHeight + modNext.heightInPx,
				diff: undefined
			});
		}
	}
	for (const m of diffs) {
		let emitAlignment = function (origLineNumberExclusive, modLineNumberExclusive) {
			if (origLineNumberExclusive < lastOrigLineNumber || modLineNumberExclusive < lastModLineNumber) {
				return;
			}
			if (first2) {
				first2 = false;
			} else if (origLineNumberExclusive === lastOrigLineNumber || modLineNumberExclusive === lastModLineNumber) {
				return;
			}
			const originalRange = new LineRange(lastOrigLineNumber, origLineNumberExclusive);
			const modifiedRange = new LineRange(lastModLineNumber, modLineNumberExclusive);
			if (originalRange.isEmpty && modifiedRange.isEmpty) {
				return;
			}
			const originalAdditionalHeight =
				originalLineHeightOverrides.takeWhile(v => v.lineNumber < origLineNumberExclusive)?.reduce((p, o) => p + o.heightInPx, 0) ??
				0;
			const modifiedAdditionalHeight =
				modifiedLineHeightOverrides.takeWhile(v => v.lineNumber < modLineNumberExclusive)?.reduce((p, o) => p + o.heightInPx, 0) ??
				0;
			result.push({
				originalRange,
				modifiedRange,
				originalHeightInPx: originalRange.length * origLineHeight + originalAdditionalHeight,
				modifiedHeightInPx: modifiedRange.length * modLineHeight + modifiedAdditionalHeight,
				diff: m.lineRangeMapping
			});
			lastOrigLineNumber = origLineNumberExclusive;
			lastModLineNumber = modLineNumberExclusive;
		};
		const c = m.lineRangeMapping;
		handleAlignmentsOutsideOfDiffs(c.original.startLineNumber, c.modified.startLineNumber);
		let first2 = true;
		let lastModLineNumber = c.modified.startLineNumber;
		let lastOrigLineNumber = c.original.startLineNumber;
		if (innerHunkAlignment) {
			for (const i of c.innerChanges || []) {
				if (i.originalRange.startColumn > 1 && i.modifiedRange.startColumn > 1) {
					emitAlignment(i.originalRange.startLineNumber, i.modifiedRange.startLineNumber);
				}
				const originalModel = originalEditor.getModel();
				const maxColumn =
					i.originalRange.endLineNumber <= originalModel.getLineCount()
						? originalModel.getLineMaxColumn(i.originalRange.endLineNumber)
						: Number.MAX_SAFE_INTEGER;
				if (i.originalRange.endColumn < maxColumn) {
					emitAlignment(i.originalRange.endLineNumber, i.modifiedRange.endLineNumber);
				}
			}
		}
		emitAlignment(c.original.endLineNumberExclusive, c.modified.endLineNumberExclusive);
		lastOriginalLineNumber = c.original.endLineNumberExclusive;
		lastModifiedLineNumber = c.modified.endLineNumberExclusive;
	}
	handleAlignmentsOutsideOfDiffs(Number.MAX_VALUE, Number.MAX_VALUE);
	return result;
}

function getAdditionalLineHeights(editor2, viewZonesToIgnore) {
	const viewZoneHeights = [];
	const wrappingZoneHeights = [];
	const hasWrapping =
		editor2.getOption(
			146
			// wrappingInfo
		).wrappingColumn !== -1;
	const coordinatesConverter = editor2._getViewModel().coordinatesConverter;
	const editorLineHeight = editor2.getOption(
		67
		// lineHeight
	);
	if (hasWrapping) {
		for (let i = 1; i <= editor2.getModel().getLineCount(); i++) {
			const lineCount = coordinatesConverter.getModelLineViewLineCount(i);
			if (lineCount > 1) {
				wrappingZoneHeights.push({ lineNumber: i, heightInPx: editorLineHeight * (lineCount - 1) });
			}
		}
	}
	for (const w of editor2.getWhitespaces()) {
		if (viewZonesToIgnore.has(w.id)) {
			continue;
		}
		const modelLineNumber =
			w.afterLineNumber === 0
				? 0
				: coordinatesConverter.convertViewPositionToModelPosition(new Position(w.afterLineNumber, 1)).lineNumber;
		viewZoneHeights.push({ lineNumber: modelLineNumber, heightInPx: w.height });
	}
	function _joinCombine(arr1, arr2, keySelector, combine) {
		if (arr1.length === 0) {
			return arr2;
		}
		if (arr2.length === 0) {
			return arr1;
		}
		const result = [];
		let i = 0;
		let j = 0;
		while (i < arr1.length && j < arr2.length) {
			const val1 = arr1[i];
			const val2 = arr2[j];
			const key1 = keySelector(val1);
			const key2 = keySelector(val2);
			if (key1 < key2) {
				result.push(val1);
				i++;
			} else if (key1 > key2) {
				result.push(val2);
				j++;
			} else {
				result.push(combine(val1, val2));
				i++;
				j++;
			}
		}
		while (i < arr1.length) {
			result.push(arr1[i]);
			i++;
		}
		while (j < arr2.length) {
			result.push(arr2[j]);
			j++;
		}
		return result;
	}
	const result = _joinCombine(
		viewZoneHeights,
		wrappingZoneHeights,
		v => v.lineNumber,
		(v1, v2) => ({ lineNumber: v1.lineNumber, heightInPx: v1.heightInPx + v2.heightInPx })
	);
	return result;
}

class DiffEditorViewZones extends Disposable {
	constructor(
		_targetWindow,
		_editors,
		_diffModel,
		_options,
		_diffEditorWidget,
		_canIgnoreViewZoneUpdateEvent,
		_origViewZonesToIgnore,
		_modViewZonesToIgnore,
		_clipboardService,
		_contextMenuService
	) {
		super();
		this._targetWindow = _targetWindow;
		this._editors = _editors;
		this._diffModel = _diffModel;
		this._options = _options;
		this._diffEditorWidget = _diffEditorWidget;
		this._canIgnoreViewZoneUpdateEvent = _canIgnoreViewZoneUpdateEvent;
		this._origViewZonesToIgnore = _origViewZonesToIgnore;
		this._modViewZonesToIgnore = _modViewZonesToIgnore;
		this._clipboardService = _clipboardService;
		this._contextMenuService = _contextMenuService;
		this._originalTopPadding = observableValue(this, 0);
		this._originalScrollOffset = observableValue(this, 0);
		this._originalScrollOffsetAnimated = animatedObservable(this._targetWindow, this._originalScrollOffset, this._store);
		this._modifiedTopPadding = observableValue(this, 0);
		this._modifiedScrollOffset = observableValue(this, 0);
		this._modifiedScrollOffsetAnimated = animatedObservable(this._targetWindow, this._modifiedScrollOffset, this._store);
		const state = observableValue('invalidateAlignmentsState', 0);
		const updateImmediately = this._register(
			new RunOnceScheduler(() => {
				state.set(state.get() + 1, undefined);
			}, 0)
		);
		this._register(
			this._editors.original.onDidChangeViewZones(_args => {
				if (!this._canIgnoreViewZoneUpdateEvent()) {
					updateImmediately.schedule();
				}
			})
		);
		this._register(
			this._editors.modified.onDidChangeViewZones(_args => {
				if (!this._canIgnoreViewZoneUpdateEvent()) {
					updateImmediately.schedule();
				}
			})
		);
		this._register(
			this._editors.original.onDidChangeConfiguration(args => {
				if (
					args.hasChanged(
						146
						// wrappingInfo
					) ||
					args.hasChanged(
						67
						// lineHeight
					)
				) {
					updateImmediately.schedule();
				}
			})
		);
		this._register(
			this._editors.modified.onDidChangeConfiguration(args => {
				if (
					args.hasChanged(
						146
						// wrappingInfo
					) ||
					args.hasChanged(
						67
						// lineHeight
					)
				) {
					updateImmediately.schedule();
				}
			})
		);
		const originalModelTokenizationCompleted = this._diffModel
			.map(m =>
				m
					? observableFromEvent(
							m.model.original.onDidChangeTokens,
							() => m.model.original.tokenization.backgroundTokenizationState === 2
							/* BackgroundTokenizationState.Completed */
						)
					: undefined
			)
			.map((m, reader) => m?.read(reader));
		const alignments = derived(reader => {
			const diffModel = this._diffModel.read(reader);
			const diff = diffModel?.diff.read(reader);
			if (!diffModel || !diff) {
				return null;
			}
			state.read(reader);
			const renderSideBySide = this._options.renderSideBySide.read(reader);
			const innerHunkAlignment = renderSideBySide;
			return computeRangeAlignment(
				this._editors.original,
				this._editors.modified,
				diff.mappings,
				this._origViewZonesToIgnore,
				this._modViewZonesToIgnore,
				innerHunkAlignment
			);
		});
		const alignmentsSyncedMovedText = derived(reader => {
			const syncedMovedText = this._diffModel.read(reader)?.movedTextToCompare.read(reader);
			if (!syncedMovedText) {
				return null;
			}
			state.read(reader);
			const mappings = syncedMovedText.changes.map(c => new DiffMapping(c));
			return computeRangeAlignment(
				this._editors.original,
				this._editors.modified,
				mappings,
				this._origViewZonesToIgnore,
				this._modViewZonesToIgnore,
				true
			);
		});
		function createFakeLinesDiv() {
			const r = document.createElement('div');
			r.className = 'diagonal-fill';
			return r;
		}
		const alignmentViewZonesDisposables = this._register(new DisposableStore());
		this.viewZones = derivedWithStore(this, (reader, store) => {
			alignmentViewZonesDisposables.clear();
			const alignmentsVal = alignments.read(reader) || [];
			const origViewZones = [];
			const modViewZones = [];
			const modifiedTopPaddingVal = this._modifiedTopPadding.read(reader);
			if (modifiedTopPaddingVal > 0) {
				modViewZones.push({
					afterLineNumber: 0,
					domNode: document.createElement('div'),
					heightInPx: modifiedTopPaddingVal,
					showInHiddenAreas: true,
					suppressMouseDown: true
				});
			}
			const originalTopPaddingVal = this._originalTopPadding.read(reader);
			if (originalTopPaddingVal > 0) {
				origViewZones.push({
					afterLineNumber: 0,
					domNode: document.createElement('div'),
					heightInPx: originalTopPaddingVal,
					showInHiddenAreas: true,
					suppressMouseDown: true
				});
			}
			const renderSideBySide = this._options.renderSideBySide.read(reader);
			const deletedCodeLineBreaksComputer = !renderSideBySide
				? this._editors.modified._getViewModel()?.createLineBreaksComputer()
				: undefined;
			if (deletedCodeLineBreaksComputer) {
				const originalModel = this._editors.original.getModel();
				for (const a of alignmentsVal) {
					if (a.diff) {
						for (let i = a.originalRange.startLineNumber; i < a.originalRange.endLineNumberExclusive; i++) {
							if (i > originalModel.getLineCount()) {
								return { orig: origViewZones, mod: modViewZones };
							}
							deletedCodeLineBreaksComputer === null || deletedCodeLineBreaksComputer === undefined
								? undefined
								: deletedCodeLineBreaksComputer.addRequest(originalModel.getLineContent(i), null, null);
						}
					}
				}
			}
			const lineBreakData = deletedCodeLineBreaksComputer?.finalize() || [];
			let lineBreakDataIdx = 0;
			const modLineHeight = this._editors.modified.getOption(
				67
				// lineHeight
			);
			const syncedMovedText = this._diffModel.read(reader)?.movedTextToCompare.read(reader);
			const mightContainNonBasicASCII = this._editors.original.getModel()?.mightContainNonBasicASCII() ?? false;
			const mightContainRTL = this._editors.original.getModel().mightContainRTL() ?? false;
			const renderOptions = RenderOptions.fromEditor(this._editors.modified);
			for (const a of alignmentsVal) {
				if (a.diff && !renderSideBySide) {
					if (!a.originalRange.isEmpty) {
						originalModelTokenizationCompleted.read(reader);
						const deletedCodeDomNode = document.createElement('div');
						deletedCodeDomNode.classList.add('view-lines', 'line-delete', 'monaco-mouse-cursor-text');
						const originalModel = this._editors.original.getModel();
						if (a.originalRange.endLineNumberExclusive - 1 > originalModel.getLineCount()) {
							return { orig: origViewZones, mod: modViewZones };
						}
						const source = new LineSource(
							a.originalRange.mapToLineArray(l => originalModel.tokenization.getLineTokens(l)),
							a.originalRange.mapToLineArray(_ => lineBreakData[lineBreakDataIdx++]),
							mightContainNonBasicASCII,
							mightContainRTL
						);
						const decorations = [];
						for (const i of a.diff.innerChanges || []) {
							decorations.push(
								new InlineDecoration(
									i.originalRange.delta(-(a.diff.original.startLineNumber - 1)),
									diffDeleteDecoration.className,
									0
									/* InlineDecorationType.Regular */
								)
							);
						}

						function _renderLines(source, options2, decorations, domNode) {
							applyFontInfo(domNode, options2.fontInfo);
							const hasCharChanges = decorations.length > 0;
							const sb = new StringBuilder(1e4);
							let maxCharsPerLine = 0;
							let renderedLineCount = 0;
							const viewLineCounts = [];
							for (let lineIndex = 0; lineIndex < source.lineTokens.length; lineIndex++) {
								const lineNumber = lineIndex + 1;
								const lineTokens = source.lineTokens[lineIndex];
								const lineBreakData = source.lineBreakData[lineIndex];
								const actualDecorations = LineDecoration.filter(decorations, lineNumber, 1, Number.MAX_SAFE_INTEGER);
								if (lineBreakData) {
									let lastBreakOffset = 0;
									for (const breakOffset of lineBreakData.breakOffsets) {
										const viewLineTokens = lineTokens.sliceAndInflate(lastBreakOffset, breakOffset, 0);
										maxCharsPerLine = Math.max(
											maxCharsPerLine,
											renderOriginalLine(
												renderedLineCount,
												viewLineTokens,
												LineDecoration.extractWrapped(actualDecorations, lastBreakOffset, breakOffset),
												hasCharChanges,
												source.mightContainNonBasicASCII,
												source.mightContainRTL,
												options2,
												sb
											)
										);
										renderedLineCount++;
										lastBreakOffset = breakOffset;
									}
									viewLineCounts.push(lineBreakData.breakOffsets.length);
								} else {
									viewLineCounts.push(1);
									maxCharsPerLine = Math.max(
										maxCharsPerLine,
										renderOriginalLine(
											renderedLineCount,
											lineTokens,
											actualDecorations,
											hasCharChanges,
											source.mightContainNonBasicASCII,
											source.mightContainRTL,
											options2,
											sb
										)
									);
									renderedLineCount++;
								}
							}
							maxCharsPerLine += options2.scrollBeyondLastColumn;

							domNode.innerHTML = sb.build();
							const minWidthInPx = maxCharsPerLine * options2.typicalHalfwidthCharacterWidth;
							return {
								heightInLines: renderedLineCount,
								minWidthInPx,
								viewLineCounts
							};
						}

						const result = _renderLines(source, renderOptions, decorations, deletedCodeDomNode);

						const marginDomNode2 = document.createElement('div');
						marginDomNode2.className = 'inline-deleted-margin-view-zone';
						applyFontInfo(marginDomNode2, renderOptions.fontInfo);
						if (this._options.renderIndicators.read(reader)) {
							for (let i = 0; i < result.heightInLines; i++) {
								const marginElement = document.createElement('div');
								marginElement.className = `delete-sign ${asThemeIconClassNameString(registeredIcon_diffRemove)}`;
								marginElement.setAttribute(
									'style',
									`position:absolute;top:${i * modLineHeight}px;width:${renderOptions.lineDecorationsWidth}px;height:${modLineHeight}px;right:0;`
								);
								marginDomNode2.appendChild(marginElement);
							}
						}
						let zoneId = undefined;
						alignmentViewZonesDisposables.add(
							new InlineDiffDeletedCodeMargin(
								() => zoneId,
								marginDomNode2,
								this._editors.modified,
								a.diff,
								this._diffEditorWidget,
								result.viewLineCounts,
								this._editors.original.getModel(),
								this._contextMenuService,
								this._clipboardService
							)
						);
						for (let i = 0; i < result.viewLineCounts.length; i++) {
							const count = result.viewLineCounts[i];
							if (count > 1) {
								origViewZones.push({
									afterLineNumber: a.originalRange.startLineNumber + i,
									domNode: createFakeLinesDiv(),
									heightInPx: (count - 1) * modLineHeight,
									showInHiddenAreas: true,
									suppressMouseDown: true
								});
							}
						}
						modViewZones.push({
							afterLineNumber: a.modifiedRange.startLineNumber - 1,
							domNode: deletedCodeDomNode,
							heightInPx: result.heightInLines * modLineHeight,
							minWidthInPx: result.minWidthInPx,
							marginDomNode: marginDomNode2,
							setZoneId(id) {
								zoneId = id;
							},
							showInHiddenAreas: true,
							suppressMouseDown: true
						});
					}
					const marginDomNode = document.createElement('div');
					marginDomNode.className = 'gutter-delete';
					origViewZones.push({
						afterLineNumber: a.originalRange.endLineNumberExclusive - 1,
						domNode: createFakeLinesDiv(),
						heightInPx: a.modifiedHeightInPx,
						marginDomNode,
						showInHiddenAreas: true,
						suppressMouseDown: true
					});
				} else {
					const delta = a.modifiedHeightInPx - a.originalHeightInPx;
					if (delta > 0) {
						if (
							syncedMovedText === null || syncedMovedText === undefined
								? undefined
								: syncedMovedText.lineRangeMapping.original
										.delta(-1)
										.deltaLength(2)
										.contains(a.originalRange.endLineNumberExclusive - 1)
						) {
							continue;
						}
						origViewZones.push({
							afterLineNumber: a.originalRange.endLineNumberExclusive - 1,
							domNode: createFakeLinesDiv(),
							heightInPx: delta,
							showInHiddenAreas: true,
							suppressMouseDown: true
						});
					} else {
						let createViewZoneMarginArrow = function () {
							const arrow = document.createElement('div');
							arrow.className = 'arrow-revert-change ' + asThemeIconClassNameString(codicon_arrowRight);
							store.add(addDisposableListener(arrow, 'mousedown', e => e.stopPropagation()));
							store.add(
								addDisposableListener(arrow, 'click', e => {
									e.stopPropagation();
									_diffEditorWidget.revert(a.diff);
								})
							);
							return $('div', {}, arrow);
						};
						if (
							syncedMovedText === null || syncedMovedText === undefined
								? undefined
								: syncedMovedText.lineRangeMapping.modified
										.delta(-1)
										.deltaLength(2)
										.contains(a.modifiedRange.endLineNumberExclusive - 1)
						) {
							continue;
						}
						let marginDomNode = undefined;
						if (a.diff && a.diff.modified.isEmpty && this._options.shouldRenderOldRevertArrows.read(reader)) {
							marginDomNode = createViewZoneMarginArrow();
						}
						modViewZones.push({
							afterLineNumber: a.modifiedRange.endLineNumberExclusive - 1,
							domNode: createFakeLinesDiv(),
							heightInPx: -delta,
							marginDomNode,
							showInHiddenAreas: true,
							suppressMouseDown: true
						});
					}
				}
			}
			for (const a of alignmentsSyncedMovedText.read(reader) || []) {
				if (
					!(syncedMovedText === null || syncedMovedText === undefined
						? undefined
						: syncedMovedText.lineRangeMapping.original.intersect(a.originalRange)) ||
					!(syncedMovedText === null || syncedMovedText === undefined
						? undefined
						: syncedMovedText.lineRangeMapping.modified.intersect(a.modifiedRange))
				) {
					continue;
				}
				const delta = a.modifiedHeightInPx - a.originalHeightInPx;
				if (delta > 0) {
					origViewZones.push({
						afterLineNumber: a.originalRange.endLineNumberExclusive - 1,
						domNode: createFakeLinesDiv(),
						heightInPx: delta,
						showInHiddenAreas: true,
						suppressMouseDown: true
					});
				} else {
					modViewZones.push({
						afterLineNumber: a.modifiedRange.endLineNumberExclusive - 1,
						domNode: createFakeLinesDiv(),
						heightInPx: -delta,
						showInHiddenAreas: true,
						suppressMouseDown: true
					});
				}
			}
			return { orig: origViewZones, mod: modViewZones };
		});
		let ignoreChange = false;
		this._register(
			this._editors.original.onDidScrollChange(e => {
				if (e.scrollLeftChanged && !ignoreChange) {
					ignoreChange = true;
					this._editors.modified.setScrollLeft(e.scrollLeft);
					ignoreChange = false;
				}
			})
		);
		this._register(
			this._editors.modified.onDidScrollChange(e => {
				if (e.scrollLeftChanged && !ignoreChange) {
					ignoreChange = true;
					this._editors.original.setScrollLeft(e.scrollLeft);
					ignoreChange = false;
				}
			})
		);
		this._originalScrollTop = observableFromEvent(this._editors.original.onDidScrollChange, () =>
			this._editors.original.getScrollTop()
		);
		this._modifiedScrollTop = observableFromEvent(this._editors.modified.onDidScrollChange, () =>
			this._editors.modified.getScrollTop()
		);
		this._register(
			autorun(reader => {
				const newScrollTopModified =
					this._originalScrollTop.read(reader) -
					(this._originalScrollOffsetAnimated.get() - this._modifiedScrollOffsetAnimated.read(reader)) -
					(this._originalTopPadding.get() - this._modifiedTopPadding.read(reader));
				if (newScrollTopModified !== this._editors.modified.getScrollTop()) {
					this._editors.modified.setScrollTop(
						newScrollTopModified,
						1
						// Immediate
					);
				}
			})
		);
		this._register(
			autorun(reader => {
				const newScrollTopOriginal =
					this._modifiedScrollTop.read(reader) -
					(this._modifiedScrollOffsetAnimated.get() - this._originalScrollOffsetAnimated.read(reader)) -
					(this._modifiedTopPadding.get() - this._originalTopPadding.read(reader));
				if (newScrollTopOriginal !== this._editors.original.getScrollTop()) {
					this._editors.original.setScrollTop(
						newScrollTopOriginal,
						1
						// Immediate
					);
				}
			})
		);
		this._register(
			autorun(reader => {
				const m = this._diffModel.read(reader)?.movedTextToCompare.read(reader);
				let deltaOrigToMod = 0;
				if (m) {
					const trueTopOriginal =
						this._editors.original.getTopForLineNumber(m.lineRangeMapping.original.startLineNumber, true) -
						this._originalTopPadding.get();
					const trueTopModified =
						this._editors.modified.getTopForLineNumber(m.lineRangeMapping.modified.startLineNumber, true) -
						this._modifiedTopPadding.get();
					deltaOrigToMod = trueTopModified - trueTopOriginal;
				}
				if (deltaOrigToMod > 0) {
					this._modifiedTopPadding.set(0, undefined);
					this._originalTopPadding.set(deltaOrigToMod, undefined);
				} else if (deltaOrigToMod < 0) {
					this._modifiedTopPadding.set(-deltaOrigToMod, undefined);
					this._originalTopPadding.set(0, undefined);
				} else {
					setTimeout(() => {
						this._modifiedTopPadding.set(0, undefined);
						this._originalTopPadding.set(0, undefined);
					}, 400);
				}
				if (this._editors.modified.hasTextFocus()) {
					this._originalScrollOffset.set(this._modifiedScrollOffset.get() - deltaOrigToMod, undefined, true);
				} else {
					this._modifiedScrollOffset.set(this._originalScrollOffset.get() + deltaOrigToMod, undefined, true);
				}
			})
		);
	}
}
__decorate([__param(8, IClipboardService), __param(9, IContextMenuService)], DiffEditorViewZones);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

let emptyArr2 = [];
let gutterWidth = 35;

class DiffEditorGutter extends Disposable {
	constructor(diffEditorRoot, _diffModel, _editors, _instantiationService, _contextKeyService, _menuService) {
		super();
		this._diffModel = _diffModel;
		this._editors = _editors;
		this._instantiationService = _instantiationService;
		this._contextKeyService = _contextKeyService;
		this._menuService = _menuService;
		this._menu = this._register(this._menuService.createMenu(MenuId.DiffEditorHunkToolbar, this._contextKeyService));
		this._actions = observableFromEvent(this._menu.onDidChange, () => this._menu.getActions());
		this._hasActions = this._actions.map(a => a.length > 0);
		this.width = derived(this, reader => (this._hasActions.read(reader) ? gutterWidth : 0));
		this.elements = h('div.gutter@gutter', { style: { position: 'absolute', height: '100%', width: gutterWidth + 'px' } }, []);
		this._currentDiff = derived(this, reader => {
			const model = this._diffModel.read(reader);
			if (model) {
				const mappings = model.diff.read(reader)?.mappings;
				const cursorPosition = this._editors.modifiedCursor.read(reader);
				if (cursorPosition) {
					return mappings === null || mappings === undefined
						? undefined
						: mappings.find(m => m.lineRangeMapping.modified.contains(cursorPosition.lineNumber));
				}
			}
		});
		this._selectedDiffs = derived(this, reader => {
			const model = this._diffModel.read(reader);
			const diff = model?.diff.read(reader);
			if (!diff) {
				return emptyArr2;
			}
			const selections = this._editors.modifiedSelections.read(reader);
			if (selections.every(s => s.isEmpty())) {
				return emptyArr2;
			}
			const selectedLineNumbers = new LineRangeSet(selections.map(s => LineRange.fromRangeInclusive(s)));
			const selectedMappings = diff.mappings.filter(
				m => m.lineRangeMapping.innerChanges && selectedLineNumbers.intersects(m.lineRangeMapping.modified)
			);
			const result = selectedMappings.map(mapping => ({
				mapping,
				rangeMappings: mapping.lineRangeMapping.innerChanges.filter(c =>
					selections.some(s => Range.areIntersecting(c.modifiedRange, s))
				)
			}));
			if (result.length === 0 || result.every(r => r.rangeMappings.length === 0)) {
				return emptyArr2;
			}
			return result;
		});
		function _prependRemoveOnDispose(parent, child) {
			parent.prepend(child);
			return toDisposable(() => {
				parent.removeChild(child);
			});
		}
		this._register(_prependRemoveOnDispose(diffEditorRoot, this.elements.root));
		this._register(
			addDisposableListener(this.elements.root, 'click', () => {
				this._editors.modified.focus();
			})
		);
		this._register(applyStyle(this.elements.root, { display: this._hasActions.map(a => (a ? 'block' : 'none')) }));
		this._register(
			new EditorGutter(this._editors.modified, this.elements.root, {
				getIntersectingGutterItems: (range2, reader) => {
					const model = this._diffModel.read(reader);
					if (!model) {
						return [];
					}
					const diffs = model.diff.read(reader);
					if (!diffs) {
						return [];
					}
					const selection = this._selectedDiffs.read(reader);
					if (selection.length > 0) {
						const m = DetailedLineRangeMapping.fromRangeMappings(selection.flatMap(s => s.rangeMappings));
						return [
							new DiffGutterItem(
								m,
								true,
								MenuId.DiffEditorSelectionToolbar,
								undefined,
								model.model.original.uri,
								model.model.modified.uri
							)
						];
					}
					const currentDiff = this._currentDiff.read(reader);
					return diffs.mappings.map(
						m =>
							new DiffGutterItem(
								m.lineRangeMapping.withInnerChangesFromLineRanges(),
								m.lineRangeMapping === currentDiff?.lineRangeMapping,
								MenuId.DiffEditorHunkToolbar,
								undefined,
								model.model.original.uri,
								model.model.modified.uri
							)
					);
				},
				createView: (item, target) => {
					return this._instantiationService.createInstance(DiffToolBar, item, target, this);
				}
			})
		);
		this._register(
			addDisposableListener(
				this.elements.gutter,
				EventType.MOUSE_WHEEL,
				e => {
					if (
						this._editors.modified.getOption(
							103
							// scrollbar
						).handleMouseWheel
					) {
						this._editors.modified.delegateScrollFromMouseWheelEvent(e);
					}
				},
				{ passive: false }
			)
		);
	}
	computeStagedValue(mapping) {
		const c = mapping.innerChanges || [];
		const modified = new TextModelText(this._editors.modifiedModel.get());
		const original = new TextModelText(this._editors.original.getModel());
		const edit = new TextEdit(c.map(c2 => c2.toTextEdit(modified)));
		const value = edit.apply(original);
		return value;
	}
	layout(left) {
		this.elements.gutter.style.left = left + 'px';
	}
}
__decorate([__param(3, IInstantiationService), __param(4, IContextKeyService), __param(5, IMenuService)], DiffEditorGutter);

class DiffGutterItem {
	constructor(mapping, showAlways, menuId, rangeOverride, originalUri, modifiedUri) {
		this.mapping = mapping;
		this.showAlways = showAlways;
		this.menuId = menuId;
		this.rangeOverride = rangeOverride;
		this.originalUri = originalUri;
		this.modifiedUri = modifiedUri;
	}
	get id() {
		return this.mapping.modified.toString();
	}
	get range() {
		return this.rangeOverride ?? this.mapping.modified;
	}
}

class DiffToolBar extends Disposable {
	constructor(_item, target, gutter, instantiationService) {
		super();
		this._item = _item;
		this._elements = h('div.gutterItem', { style: { height: '20px', width: '34px' } }, [
			h('div.background@background', {}, []),
			h('div.buttons@buttons', {}, [])
		]);
		this._showAlways = this._item.map(this, item => item.showAlways);
		this._menuId = this._item.map(this, item => item.menuId);
		this._isSmall = observableValue(this, false);
		this._lastItemRange = undefined;
		this._lastViewRange = undefined;
		const hoverDelegate = this._register(
			instantiationService.createInstance(WorkbenchHoverDelegate, 'element', true, {
				position: {
					hoverPosition: 1
					/* HoverPosition.RIGHT */
				}
			})
		);
		this._register(appendRemoveOnDispose(target, this._elements.root));
		this._register(
			autorun(reader => {
				const showAlways = this._showAlways.read(reader);
				this._elements.root.classList.toggle('noTransition', true);
				this._elements.root.classList.toggle('showAlways', showAlways);
				setTimeout(() => {
					this._elements.root.classList.toggle('noTransition', false);
				}, 0);
			})
		);
		this._register(
			autorunWithStore((reader, store) => {
				this._elements.buttons.replaceChildren();
				const i = store.add(
					instantiationService.createInstance(MenuWorkbenchToolBar, this._elements.buttons, this._menuId.read(reader), {
						orientation: 1,
						hoverDelegate,
						toolbarOptions: {
							primaryGroup: g => g.startsWith('primary')
						},
						overflowBehavior: { maxItems: this._isSmall.read(reader) ? 1 : 3 },
						hiddenItemStrategy: 0,
						actionRunner: new ActionRunnerWithContext(() => {
							const item = this._item.get();
							const mapping = item.mapping;
							return {
								mapping,
								originalWithModifiedChanges: gutter.computeStagedValue(mapping),
								originalUri: item.originalUri,
								modifiedUri: item.modifiedUri
							};
						}),
						menuOptions: {
							shouldForwardArgs: true
						}
					})
				);
				store.add(
					i.onDidChangeMenuItems(() => {
						if (this._lastItemRange) {
							this.layout(this._lastItemRange, this._lastViewRange);
						}
					})
				);
			})
		);
	}
	layout(itemRange, viewRange) {
		this._lastItemRange = itemRange;
		this._lastViewRange = viewRange;
		let itemHeight = this._elements.buttons.clientHeight;
		this._isSmall.set(this._item.get().mapping.original.startLineNumber === 1 && itemRange.length < 30, undefined);
		itemHeight = this._elements.buttons.clientHeight;
		this._elements.root.style.top = itemRange.start + 'px';
		this._elements.root.style.height = itemRange.length + 'px';
		const middleHeight = itemRange.length / 2 - itemHeight / 2;
		const margin = itemHeight;
		let effectiveCheckboxTop = itemRange.start + middleHeight;
		const preferredViewPortRange = OffsetRange.tryCreate(margin, viewRange.endExclusive - margin - itemHeight);
		const preferredParentRange = OffsetRange.tryCreate(itemRange.start + margin, itemRange.endExclusive - itemHeight - margin);
		if (preferredParentRange && preferredViewPortRange && preferredParentRange.start < preferredParentRange.endExclusive) {
			effectiveCheckboxTop = preferredViewPortRange.clip(effectiveCheckboxTop);
			effectiveCheckboxTop = preferredParentRange.clip(effectiveCheckboxTop);
		}
		this._elements.buttons.style.top = `${effectiveCheckboxTop - itemRange.start}px`;
	}
}
__decorate([__param(3, IInstantiationService)], DiffToolBar);
//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -


const ctxKeys_isEmbeddedDiffEditor = new RawContextKey(
	'isEmbeddedDiffEditor',
	false,
	localize('Whether the context is an embedded diff editor')
);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const ctxKeys_inDiffEditor = new RawContextKey(
	'inDiffEditor',
	false,
	localize('Whether the context is a diff editor') //
);

const ctxKeys_inMultiDiffEditor = new RawContextKey('inMultiDiffEditor', false, localize('Whether the context is a multi diff editor'));

const ctxKeys_multiDiffEditor_allCollapsed = new RawContextKey(
	'multiDiffEditorAllCollapsed',
	undefined,
	localize('Whether all files in multi diff editor are collapsed')
);

//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const ctxKeys_diffEditor_hasChanges = new RawContextKey('diffEditorHasChanges', false, localize('Whether the diff editor has changes'));

const ctxKeys_diffEditor_renderSideBySideInlineBreakpointReached = new RawContextKey(
	'diffEditorRenderSideBySideInlineBreakpointReached',
	false,
	localize('Whether the diff editor render side by side inline breakpoint is reached')
);

const ctxKeys_diffEditor_inlineMode = new RawContextKey('diffEditorInlineMode', false, localize('Whether inline mode is active'));

const ctxKeys_diffEditor_writableOriginal = new RawContextKey(
	'diffEditorOriginalWritable',
	false,
	localize('Whether modified is writable in the diff editor')
);

const ctxKeys_diffEditor_writableModified = new RawContextKey(
	'diffEditorModifiedWritable',
	false,
	localize('Whether modified is writable in the diff editor')
);

const ctxKeys_diffEditor_uriOriginal = new RawContextKey('diffEditorOriginalUri', '', localize('The uri of the original document'));

const ctxKeys_diffEditor_uriModified = new RawContextKey('diffEditorModifiedUri', '', localize('The uri of the modified document'));
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const diffEditorDefaultOptions = {
	enableSplitViewResizing: true,
	splitViewDefaultRatio: 0.5,
	renderSideBySide: true,
	renderMarginRevertIcon: true,
	renderGutterMenu: true,
	maxComputationTime: 5e3,
	maxFileSize: 50,
	ignoreTrimWhitespace: true,
	renderIndicators: true,
	originalEditable: false,
	diffCodeLens: false,
	renderOverviewRuler: true,
	diffWordWrap: 'inherit',
	diffAlgorithm: 'advanced',
	accessibilityVerbose: false,
	experimental: {
		showMoves: false,
		showEmptyDecorations: true
	},
	hideUnchangedRegions: {
		enabled: false,
		contextLineCount: 3,
		minimumLineCount: 3,
		revealLineCount: 20
	},
	isInEmbeddedEditor: false,
	onlyShowAccessibleDiffViewer: false,
	renderSideBySideInlineBreakpoint: 900,
	useInlineViewWhenSpaceIsLimited: true
};

{
			'diffEditor.maxComputationTime': {
			type: 'number',
			default: diffEditorDefaultOptions.maxComputationTime,
			description: localize('Timeout in milliseconds after which diff computation is cancelled. Use 0 for no timeout.')
		},
		'diffEditor.maxFileSize': {
			type: 'number',
			default: diffEditorDefaultOptions.maxFileSize,
			description: localize('Maximum file size in MB for which to compute diffs. Use 0 for no limit.')
		},
		'diffEditor.renderSideBySide': {
			type: 'boolean',
			default: diffEditorDefaultOptions.renderSideBySide,
			description: localize('Controls whether the diff editor shows the diff side by side or inline.')
		},
		'diffEditor.renderSideBySideInlineBreakpoint': {
			type: 'number',
			default: diffEditorDefaultOptions.renderSideBySideInlineBreakpoint,
			description: localize('If the diff editor width is smaller than this value, the inline view is used.')
		},
		'diffEditor.useInlineViewWhenSpaceIsLimited': {
			type: 'boolean',
			default: diffEditorDefaultOptions.useInlineViewWhenSpaceIsLimited,
			description: localize('If enabled and the editor width is too small, the inline view is used.')
		},
		'diffEditor.renderMarginRevertIcon': {
			type: 'boolean',
			default: diffEditorDefaultOptions.renderMarginRevertIcon,
			description: localize('When enabled, the diff editor shows arrows in its glyph margin to revert changes.')
		},
		'diffEditor.renderGutterMenu': {
			type: 'boolean',
			default: diffEditorDefaultOptions.renderGutterMenu,
			description: localize('When enabled, the diff editor shows a special gutter for revert and stage actions.')
		},
		'diffEditor.ignoreTrimWhitespace': {
			type: 'boolean',
			default: diffEditorDefaultOptions.ignoreTrimWhitespace,
			description: localize('When enabled, the diff editor ignores changes in leading or trailing whitespace.')
		},
		'diffEditor.renderIndicators': {
			type: 'boolean',
			default: diffEditorDefaultOptions.renderIndicators,
			description: localize('Controls whether the diff editor shows +/- indicators for added/removed changes.')
		},
		'diffEditor.codeLens': {
			type: 'boolean',
			default: diffEditorDefaultOptions.diffCodeLens,
			description: localize('Controls whether the editor shows CodeLens.')
		},
		'diffEditor.wordWrap': {
			type: 'string',
			enum: ['off', 'on', 'inherit'],
			default: diffEditorDefaultOptions.diffWordWrap,
			markdownEnumDescriptions: [
				localize('Lines will never wrap.'),
				localize('Lines will wrap at the viewport width.'),
				localize('`#editor.wordWrap#`')
			]
		},
		'diffEditor.diffAlgorithm': {
			type: 'string',
			enum: ['legacy', 'advanced'],
			default: diffEditorDefaultOptions.diffAlgorithm,
			markdownEnumDescriptions: [localize('Uses the legacy diffing algorithm.'), localize('Uses the advanced diffing algorithm.')],
			tags: ['experimental']
		},
		'diffEditor.hideUnchangedRegions.enabled': {
			type: 'boolean',
			default: diffEditorDefaultOptions.hideUnchangedRegions.enabled,
			markdownDescription: localize('Controls whether the diff editor shows unchanged regions.')
		},
		'diffEditor.hideUnchangedRegions.revealLineCount': {
			type: 'integer',
			default: diffEditorDefaultOptions.hideUnchangedRegions.revealLineCount,
			markdownDescription: localize('Controls how many lines are used for unchanged regions.'),
			minimum: 1
		},
		'diffEditor.hideUnchangedRegions.minimumLineCount': {
			type: 'integer',
			default: diffEditorDefaultOptions.hideUnchangedRegions.minimumLineCount,
			markdownDescription: localize('Controls how many lines are used as a minimum for unchanged regions.'),
			minimum: 1
		},
		'diffEditor.hideUnchangedRegions.contextLineCount': {
			type: 'integer',
			default: diffEditorDefaultOptions.hideUnchangedRegions.contextLineCount,
			markdownDescription: localize('Controls how many lines are used as context when comparing unchanged regions.'),
			minimum: 1
		},
		'diffEditor.experimental.showMoves': {
			type: 'boolean',
			default: diffEditorDefaultOptions.experimental.showMoves,
			markdownDescription: localize('Controls whether the diff editor should show detected code moves.')
		},
		'diffEditor.experimental.showEmptyDecorations': {
			type: 'boolean',
			default: diffEditorDefaultOptions.experimental.showEmptyDecorations,
			description: localize(
				'Controls whether the diff editor shows empty decorations to see where characters got inserted or deleted.'
			)
		}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class DiffEditorDecorations extends Disposable {
	constructor(_editors, _diffModel, _options, widget) {
		super();
		this._editors = _editors;
		this._diffModel = _diffModel;
		this._options = _options;
		this._decorations = derived(this, reader => {
			const diff = this._diffModel.read(reader)?.diff.read(reader);
			if (!diff) {
				return null;
			}
			const movedTextToCompare = this._diffModel.read(reader).movedTextToCompare.read(reader);
			const renderIndicators = this._options.renderIndicators.read(reader);
			const showEmptyDecorations = this._options.showEmptyDecorations.read(reader);
			const originalDecorations = [];
			const modifiedDecorations = [];
			if (!movedTextToCompare) {
				for (const m of diff.mappings) {
					if (!m.lineRangeMapping.original.isEmpty) {
						originalDecorations.push({
							range: m.lineRangeMapping.original.toInclusiveRange(),
							options: renderIndicators ? diffLineDeleteDecorationBackgroundWithIndicator : diffLineDeleteDecorationBackground
						});
					}
					if (!m.lineRangeMapping.modified.isEmpty) {
						modifiedDecorations.push({
							range: m.lineRangeMapping.modified.toInclusiveRange(),
							options: renderIndicators ? diffLineAddDecorationBackgroundWithIndicator : diffLineAddDecorationBackground
						});
					}
					if (m.lineRangeMapping.modified.isEmpty || m.lineRangeMapping.original.isEmpty) {
						if (!m.lineRangeMapping.original.isEmpty) {
							originalDecorations.push({
								range: m.lineRangeMapping.original.toInclusiveRange(),
								options: diffWholeLineDeleteDecoration
							});
						}
						if (!m.lineRangeMapping.modified.isEmpty) {
							modifiedDecorations.push({
								range: m.lineRangeMapping.modified.toInclusiveRange(),
								options: diffWholeLineAddDecoration
							});
						}
					} else {
						for (const i of m.lineRangeMapping.innerChanges || []) {
							if (m.lineRangeMapping.original.contains(i.originalRange.startLineNumber)) {
								originalDecorations.push({
									range: i.originalRange,
									options:
										i.originalRange.isEmpty() && showEmptyDecorations ? diffDeleteDecorationEmpty : diffDeleteDecoration
								});
							}
							if (m.lineRangeMapping.modified.contains(i.modifiedRange.startLineNumber)) {
								modifiedDecorations.push({
									range: i.modifiedRange,
									options: i.modifiedRange.isEmpty() && showEmptyDecorations ? diffAddDecorationEmpty : diffAddDecoration
								});
							}
						}
					}
				}
			}
			if (movedTextToCompare) {
				for (const m of movedTextToCompare.changes) {
					const fullRangeOriginal = m.original.toInclusiveRange();
					if (fullRangeOriginal) {
						originalDecorations.push({
							range: fullRangeOriginal,
							options: renderIndicators ? diffLineDeleteDecorationBackgroundWithIndicator : diffLineDeleteDecorationBackground
						});
					}
					const fullRangeModified = m.modified.toInclusiveRange();
					if (fullRangeModified) {
						modifiedDecorations.push({
							range: fullRangeModified,
							options: renderIndicators ? diffLineAddDecorationBackgroundWithIndicator : diffLineAddDecorationBackground
						});
					}
					for (const i of m.innerChanges || []) {
						originalDecorations.push({ range: i.originalRange, options: diffDeleteDecoration });
						modifiedDecorations.push({ range: i.modifiedRange, options: diffAddDecoration });
					}
				}
			}
			const activeMovedText = this._diffModel.read(reader).activeMovedText.read(reader);
			for (const m of diff.movedTexts) {
				originalDecorations.push({
					range: m.lineRangeMapping.original.toInclusiveRange(),
					options: {
						description: 'moved',
						blockClassName: 'movedOriginal' + (m === activeMovedText ? ' currentMove' : ''),
						blockPadding: [
							MovedBlocksLinesFeature.movedCodeBlockPadding,
							0,
							MovedBlocksLinesFeature.movedCodeBlockPadding,
							MovedBlocksLinesFeature.movedCodeBlockPadding
						]
					}
				});
				modifiedDecorations.push({
					range: m.lineRangeMapping.modified.toInclusiveRange(),
					options: {
						description: 'moved',
						blockClassName: 'movedModified' + (m === activeMovedText ? ' currentMove' : ''),
						blockPadding: [4, 0, 4, 4]
					}
				});
			}
			return { originalDecorations, modifiedDecorations };
		});
		this._register(
			applyObservableDecorations(
				this._editors.original,
				this._decorations.map(d => d?.originalDecorations || [])
			)
		);
		this._register(
			applyObservableDecorations(
				this._editors.modified,
				this._decorations.map(d => d?.modifiedDecorations || [])
			)
		);
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class DiffEditorSash extends Disposable {
	constructor(_options, _domNode, _dimensions, _sashes) {
		super();
		this._options = _options;
		this._domNode = _domNode;
		this._dimensions = _dimensions;
		this._sashes = _sashes;
		this._sashRatio = observableValue(this, undefined);
		this.sashLeft = derived(this, reader => {
			const ratio = this._sashRatio.read(reader) ?? this._options.splitViewDefaultRatio.read(reader);
			return this._computeSashLeft(ratio, reader);
		});
		this._sash = this._register(
			new Sash(
				this._domNode,
				{
					getVerticalSashTop: _sash => 0,
					getVerticalSashLeft: _sash => this.sashLeft.get(),
					getVerticalSashHeight: _sash => this._dimensions.height.get()
				},
				{
					orientation: 0
					/* Orientation.VERTICAL */
				}
			)
		);
		this._startSashPosition = undefined;
		this._register(
			this._sash.onDidStart(() => {
				this._startSashPosition = this.sashLeft.get();
			})
		);
		this._register(
			this._sash.onDidChange(e => {
				const contentWidth = this._dimensions.width.get();
				const sashPosition = this._computeSashLeft((this._startSashPosition + (e.currentX - e.startX)) / contentWidth, undefined);
				this._sashRatio.set(sashPosition / contentWidth, undefined);
			})
		);
		this._register(this._sash.onDidEnd(() => this._sash.layout()));
		this._register(this._sash.onDidReset(() => this._sashRatio.set(undefined, undefined)));
		this._register(
			autorun(reader => {
				const sashes = this._sashes.read(reader);
				if (sashes) {
					this._sash.orthogonalEndSash = sashes.bottom;
				}
			})
		);
		this._register(
			autorun(reader => {
				const enabled = this._options.enableSplitViewResizing.read(reader);
				this._sash.state = enabled ? 3 : 0;
				this.sashLeft.read(reader);
				this._dimensions.height.read(reader);
				this._sash.layout();
			})
		);
	}
	_computeSashLeft(desiredRatio, reader) {
		const contentWidth = this._dimensions.width.read(reader);
		const midPoint = Math.floor(this._options.splitViewDefaultRatio.read(reader) * contentWidth);
		const sashLeft = this._options.enableSplitViewResizing.read(reader) ? Math.floor(desiredRatio * contentWidth) : midPoint;
		const MINIMUM_EDITOR_WIDTH = 100;
		if (contentWidth <= MINIMUM_EDITOR_WIDTH * 2) {
			return midPoint;
		}
		if (sashLeft < MINIMUM_EDITOR_WIDTH) {
			return MINIMUM_EDITOR_WIDTH;
		}
		if (sashLeft > contentWidth - MINIMUM_EDITOR_WIDTH) {
			return contentWidth - MINIMUM_EDITOR_WIDTH;
		}
		return sashLeft;
	}
}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


class DelegatingEditor extends Disposable {
	constructor() {
		super(...arguments);
		this._id = ++DelegatingEditor.idCounter;
		this._onDidDispose = this._register(new Emitter());
		this.onDidDispose = this._onDidDispose.event;
	}
	getId() {
		return this.getEditorType() + ':v2:' + this._id;
	}
	/*
	// #region editorBrowser.IDiffEditor: Delegating to modified Editor
	getVisibleColumnFromPosition(position) {
		return this._targetEditor.getVisibleColumnFromPosition(position);
	}
	getPosition() {
		return this._targetEditor.getPosition();
	}
	setPosition(position, source = 'api') {
		this._targetEditor.setPosition(position, source);
	}
	revealLine(lineNumber, scrollType = 0) {
		this._targetEditor.revealLine(lineNumber, scrollType);
	}
	revealLineInCenter(lineNumber, scrollType = 0) {
		this._targetEditor.revealLineInCenter(lineNumber, scrollType);
	}
	revealLineInCenterIfOutsideViewport(lineNumber, scrollType = 0) {
		this._targetEditor.revealLineInCenterIfOutsideViewport(lineNumber, scrollType);
	}
	revealLineNearTop(lineNumber, scrollType = 0) {
		this._targetEditor.revealLineNearTop(lineNumber, scrollType);
	}
	revealPosition(position, scrollType = 0) {
		this._targetEditor.revealPosition(position, scrollType);
	}
	revealPositionInCenter(position, scrollType = 0) {
		this._targetEditor.revealPositionInCenter(position, scrollType);
	}
	revealPositionInCenterIfOutsideViewport(position, scrollType = 0) {
		this._targetEditor.revealPositionInCenterIfOutsideViewport(position, scrollType);
	}
	revealPositionNearTop(position, scrollType = 0) {
		this._targetEditor.revealPositionNearTop(position, scrollType);
	}
	getSelection() {
		return this._targetEditor.getSelection();
	}
	getSelections() {
		return this._targetEditor.getSelections();
	}
	setSelection(something, source = 'api') {
		this._targetEditor.setSelection(something, source);
	}
	setSelections(ranges, source = 'api') {
		this._targetEditor.setSelections(ranges, source);
	}
	revealLines(startLineNumber, endLineNumber, scrollType = 0) {
		this._targetEditor.revealLines(startLineNumber, endLineNumber, scrollType);
	}
	revealLinesInCenter(startLineNumber, endLineNumber, scrollType = 0) {
		this._targetEditor.revealLinesInCenter(startLineNumber, endLineNumber, scrollType);
	}
	revealLinesInCenterIfOutsideViewport(startLineNumber, endLineNumber, scrollType = 0) {
		this._targetEditor.revealLinesInCenterIfOutsideViewport(startLineNumber, endLineNumber, scrollType);
	}
	revealLinesNearTop(startLineNumber, endLineNumber, scrollType = 0) {
		this._targetEditor.revealLinesNearTop(startLineNumber, endLineNumber, scrollType);
	}
	revealRange(range2, scrollType = 0, revealVerticalInCenter = false, revealHorizontal = true) {
		this._targetEditor.revealRange(range2, scrollType, revealVerticalInCenter, revealHorizontal);
	}
	revealRangeInCenter(range2, scrollType = 0) {
		this._targetEditor.revealRangeInCenter(range2, scrollType);
	}
	revealRangeInCenterIfOutsideViewport(range2, scrollType = 0) {
		this._targetEditor.revealRangeInCenterIfOutsideViewport(range2, scrollType);
	}
	revealRangeNearTop(range2, scrollType = 0) {
		this._targetEditor.revealRangeNearTop(range2, scrollType);
	}
	revealRangeNearTopIfOutsideViewport(range2, scrollType = 0) {
		this._targetEditor.revealRangeNearTopIfOutsideViewport(range2, scrollType);
	}
	revealRangeAtTop(range2, scrollType = 0) {
		this._targetEditor.revealRangeAtTop(range2, scrollType);
	}
	getSupportedActions() {
		return this._targetEditor.getSupportedActions();
	}
	focus() {
		this._targetEditor.focus();
	}
	trigger(source, handlerId, payload) {
		this._targetEditor.trigger(source, handlerId, payload);
	}
	createDecorationsCollection(decorations) {
		return this._targetEditor.createDecorationsCollection(decorations);
	}
	changeDecorations(callback) {
		return this._targetEditor.changeDecorations(callback);
	}
	*/
}
DelegatingEditor.idCounter = 0;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function computeViewElementGroups(diffs, originalLineCount, modifiedLineCount) {
	const result = [];
	for (const g of groupAdjacentBy(
		diffs,
		(a, b) => b.modified.startLineNumber - a.modified.endLineNumberExclusive < 2 * viewElementGroupLineMargin
	)) {
		const viewElements = [];

		viewElements.push({ type: 0 });

		const origFullRange = new LineRange(
			Math.max(1, g[0].original.startLineNumber - viewElementGroupLineMargin),
			Math.min(g[g.length - 1].original.endLineNumberExclusive + viewElementGroupLineMargin, originalLineCount + 1)
		);
		const modifiedFullRange = new LineRange(
			Math.max(1, g[0].modified.startLineNumber - viewElementGroupLineMargin),
			Math.min(g[g.length - 1].modified.endLineNumberExclusive + viewElementGroupLineMargin, modifiedLineCount + 1)
		);
		forEachAdjacent(g, (a, b) => {
			const origRange = new LineRange(
				a ? a.original.endLineNumberExclusive : origFullRange.startLineNumber,
				b ? b.original.startLineNumber : origFullRange.endLineNumberExclusive
			);
			const modifiedRange2 = new LineRange(
				a ? a.modified.endLineNumberExclusive : modifiedFullRange.startLineNumber,
				b ? b.modified.startLineNumber : modifiedFullRange.endLineNumberExclusive
			);
			origRange.forEach(origLineNumber => {
				viewElements.push({
					originalLineNumber: origLineNumber,
					modifiedLineNumber: modifiedRange2.startLineNumber + (origLineNumber - origRange.startLineNumber),
					type: 1
				});
			});
			if (b) {
				b.original.forEach(origLineNumber => {
					viewElements.push({
						diff: b,
						originalLineNumber: origLineNumber,
						type: 2
					});
				});
				b.modified.forEach(modifiedLineNumber => {
					viewElements.push({
						diff: b,
						modifiedLineNumber: modifiedLineNumber,
						type: 3
					});
				});
			}
		});
		const modifiedRange = g[0].modified.join(g[g.length - 1].modified);
		const originalRange = g[0].original.join(g[g.length - 1].original);

		result.push({
			range: new LineRangeMapping(modifiedRange, originalRange),
			lines: viewElements
		});
	}
	return result;
}

const accessibleDiffViewerInsertIcon = iconRegistry.registerIcon(
	'diff-review-insert',
	codicon_add,
	localize("Icon for 'Insert' in accessible diff viewer.")
);
const accessibleDiffViewerRemoveIcon = iconRegistry.registerIcon(
	'diff-review-remove',
	codicon_remove,
	localize("Icon for 'Remove' in accessible diff viewer.")
);
const accessibleDiffViewerCloseIcon = iconRegistry.registerIcon(
	'diff-review-close',
	codicon_close,
	localize("Icon for 'Close' in accessible diff viewer.")
);

class AccessibleDiffViewer extends Disposable {
	constructor(_parentNode, _visible, _setVisible, _canClose, _width, _height, _diffs, _models, _instantiationService) {
		super();
		this._parentNode = _parentNode;
		this._visible = _visible;
		this._setVisible = _setVisible;
		this._canClose = _canClose;
		this._width = _width;
		this._height = _height;
		this._diffs = _diffs;
		this._models = _models;
		this._instantiationService = _instantiationService;
		this._state = derivedWithStore(this, (reader, store) => {
			const visible = this._visible.read(reader);
			this._parentNode.style.visibility = visible ? 'visible' : 'hidden';
			if (!visible) {
				return null;
			}
			const model = store.add(
				this._instantiationService.createInstance(ViewModel2, this._diffs, this._models, this._setVisible, this._canClose)
			);
			const view = store.add(
				this._instantiationService.createInstance(View3, this._parentNode, model, this._width, this._height, this._models)
			);
			return { model, view };
		}).recomputeInitiallyAndOnChange(this._store);
	}
	next() {
		transaction(tx => {
			const isVisible = this._visible.get();
			this._setVisible(true, tx);
			if (isVisible) {
				this._state.get().model.nextGroup(tx);
			}
		});
	}
	prev() {
		transaction(tx => {
			this._setVisible(true, tx);
			this._state.get().model.previousGroup(tx);
		});
	}
	close() {
		transaction(tx => {
			this._setVisible(false, tx);
		});
	}
}
__decorate([__param(8, IInstantiationService)], AccessibleDiffViewer);

class ViewModel2 extends Disposable {
	constructor(_diffs, _models, _setVisible, canClose, _accessibilitySignalService) {
		super();
		this._diffs = _diffs;
		this._models = _models;
		this._setVisible = _setVisible;
		this.canClose = canClose;
		this._accessibilitySignalService = _accessibilitySignalService;
		this._groups = observableValue(this, []);
		this._currentGroupIdx = observableValue(this, 0);
		this._currentElementIdx = observableValue(this, 0);
		this.groups = this._groups;
		this.currentGroup = this._currentGroupIdx.map((idx, r) => this._groups.read(r)[idx]);
		this.currentGroupIndex = this._currentGroupIdx;
		this.currentElement = this._currentElementIdx.map((idx, r) => {
			return this.currentGroup.read(r)?.lines[idx];
		});
		this._register(
			autorun(reader => {
				const diffs = this._diffs.read(reader);
				if (!diffs) {
					this._groups.set([], undefined);
					return;
				}
				const groups = computeViewElementGroups(
					diffs,
					this._models.getOriginalModel().getLineCount(),
					this._models.getModifiedModel().getLineCount()
				);
				transaction(tx => {
					const p = this._models.getModifiedPosition();
					if (p) {
						const nextGroup = groups.findIndex(g => p?.lineNumber < g.range.modified.endLineNumberExclusive);
						if (nextGroup !== -1) {
							this._currentGroupIdx.set(nextGroup, tx);
						}
					}
					this._groups.set(groups, tx);
				});
			})
		);
		this._register(
			autorun(reader => {
				const currentViewItem = this.currentElement.read(reader);
				if (currentViewItem?.type === 2) {
					this._accessibilitySignalService.playSignal(AccessibilitySignal.diffLineDeleted, {
						source: 'accessibleDiffViewer.currentElementChanged'
					});
				} else if (currentViewItem?.type === 3) {
					this._accessibilitySignalService.playSignal(AccessibilitySignal.diffLineInserted, {
						source: 'accessibleDiffViewer.currentElementChanged'
					});
				}
			})
		);
		this._register(
			autorun(reader => {
				const currentViewItem = this.currentElement.read(reader);
				if (currentViewItem && currentViewItem.type !== 0) {
					const lineNumber = currentViewItem.modifiedLineNumber ?? currentViewItem.diff.modified.startLineNumber;
					this._models.modifiedSetSelection(Range.fromPositions(new Position(lineNumber, 1)));
				}
			})
		);
	}
	_goToGroupDelta(delta, tx) {
		const groups = this.groups.get();
		if (!groups || groups.length <= 1) {
			return;
		}
		subtransaction(tx, tx2 => {
			this._currentGroupIdx.set(OffsetRange.ofLength(groups.length).clipCyclic(this._currentGroupIdx.get() + delta), tx2);
			this._currentElementIdx.set(0, tx2);
		});
	}
	nextGroup(tx) {
		this._goToGroupDelta(1, tx);
	}
	previousGroup(tx) {
		this._goToGroupDelta(-1, tx);
	}
	_goToLineDelta(delta) {
		const group = this.currentGroup.get();
		if (!group || group.lines.length <= 1) {
			return;
		}
		transaction(tx => {
			this._currentElementIdx.set(OffsetRange.ofLength(group.lines.length).clip(this._currentElementIdx.get() + delta), tx);
		});
	}
	goToNextLine() {
		this._goToLineDelta(1);
	}
	goToPreviousLine() {
		this._goToLineDelta(-1);
	}
	goToLine(line) {
		const group = this.currentGroup.get();
		if (!group) {
			return;
		}
		const idx = group.lines.indexOf(line);
		if (idx === -1) {
			return;
		}
		transaction(tx => {
			this._currentElementIdx.set(idx, tx);
		});
	}
	revealCurrentElementInEditor() {
		if (!this.canClose.get()) {
			return;
		}
		this._setVisible(false, undefined);
		const curElem = this.currentElement.get();
		if (curElem) {
			if (curElem.type === 2) {
				this._models.originalReveal(Range.fromPositions(new Position(curElem.originalLineNumber, 1)));
			} else {
				this._models.modifiedReveal(
					curElem.type !== 0 ? Range.fromPositions(new Position(curElem.modifiedLineNumber, 1)) : undefined
				);
			}
		}
	}
	close() {
		if (!this.canClose.get()) {
			return;
		}
		this._setVisible(false, undefined);
		this._models.modifiedFocus();
	}
}
__decorate([__param(4, IAccessibilitySignalService)], ViewModel2);

let viewElementGroupLineMargin = 3;

class View3 extends Disposable {
	constructor(_element, _model, _width, _height, _models, _languageService) {
		super();
		this._element = _element;
		this._model = _model;
		this._width = _width;
		this._height = _height;
		this._models = _models;
		this._languageService = _languageService;
		this.domNode = this._element;
		this.domNode.className = 'monaco-component diff-review monaco-editor-background';
		const actionBarContainer = document.createElement('div');
		actionBarContainer.className = 'diff-review-actions';
		this._actionBar = this._register(new ActionBar(actionBarContainer));
		this._register(
			autorun(reader => {
				this._actionBar.clear();
				if (this._model.canClose.read(reader)) {
					this._actionBar.push(
						new Action(
							'diffreview.close',
							localize('Close'),
							'close-diff-review ' + asThemeIconClassNameString(accessibleDiffViewerCloseIcon),
							true,
							async () => _model.close()
						),
						{ label: false, icon: true }
					);
				}
			})
		);
		this._content = document.createElement('div');
		this._content.className = 'diff-review-content';
		this._content.setAttribute('role', 'code');
		this._scrollbar = this._register(new DomScrollableElement(this._content, {}));
		reset(this.domNode, this._scrollbar.getDomNode(), actionBarContainer);
		this._register(
			autorun(r => {
				this._height.read(r);
				this._width.read(r);
				this._scrollbar.scanDomNode();
			})
		);
		this._register(
			toDisposable(() => {
				reset(this.domNode);
			})
		);
		this._register(applyStyle(this.domNode, { width: this._width, height: this._height }));
		this._register(applyStyle(this._content, { width: this._width, height: this._height }));
		this._register(
			autorunWithStore((reader, store) => {
				this._model.currentGroup.read(reader);
				this._render(store);
			})
		);
		this._register(
			addStandardDisposableListener(this.domNode, 'keydown', e => {
				if (
					e.equals(
						18
						/* KeyCode.DownArrow */
					) ||
					e.equals(
						2048 | 18
						/* KeyCode.DownArrow */
					) ||
					e.equals(
						512 | 18
						/* KeyCode.DownArrow */
					)
				) {
					e.preventDefault();
					this._model.goToNextLine();
				}
				if (
					e.equals(
						16
						/* KeyCode.UpArrow */
					) ||
					e.equals(
						2048 | 16
						/* KeyCode.UpArrow */
					) ||
					e.equals(
						512 | 16
						/* KeyCode.UpArrow */
					)
				) {
					e.preventDefault();
					this._model.goToPreviousLine();
				}
				if (
					e.equals(
						9
						/* KeyCode.Escape */
					) ||
					e.equals(
						2048 | 9
						/* KeyCode.Escape */
					) ||
					e.equals(
						512 | 9
						/* KeyCode.Escape */
					) ||
					e.equals(
						1024 | 9
						/* KeyCode.Escape */
					)
				) {
					e.preventDefault();
					this._model.close();
				}
				if (
					e.equals(
						10
						/* KeyCode.Space */
					) ||
					e.equals(
						3
						/* KeyCode.Enter */
					)
				) {
					e.preventDefault();
					this._model.revealCurrentElementInEditor();
				}
			})
		);
	}
	_render(store) {
		const originalOptions = this._models.getOriginalOptions();
		const modifiedOptions = this._models.getModifiedOptions();
		const container = document.createElement('div');
		container.className = 'diff-review-table';
		container.setAttribute('role', 'list');
		container.setAttribute('aria-label', localize('Accessible Diff Viewer. Use arrow up and down to navigate.'));
		applyFontInfo(
			container,
			modifiedOptions.get(
				50
				// fontInfo
			)
		);
		reset(this._content, container);
		const originalModel = this._models.getOriginalModel();
		const modifiedModel = this._models.getModifiedModel();
		if (!originalModel || !modifiedModel) {
			return;
		}
		const originalModelOpts = originalModel.getOptions();
		const modifiedModelOpts = modifiedModel.getOptions();
		const lineHeight = modifiedOptions.get(
			67
			// lineHeight
		);
		const group = this._model.currentGroup.get();
		for (const viewItem of group?.lines || []) {
			if (!group) {
				break;
			}
			let row;
			if (viewItem.type === 0) {
				const header = document.createElement('div');
				header.className = 'diff-review-row';
				header.setAttribute('role', 'listitem');
				const r = group.range;
				const diffIndex = this._model.currentGroupIndex.get();
				const diffsLength = this._model.groups.get().length;
				const getAriaLines = lines =>
					lines === 0 ? localize('no lines changed') : lines === 1 ? localize('1 line changed') : localize(lines);
				const originalChangedLinesCntAria = getAriaLines(r.original.length);
				const modifiedChangedLinesCntAria = getAriaLines(r.modified.length);
				header.setAttribute(
					'aria-label',
					localize(
						diffIndex + 1,
						diffsLength,
						r.original.startLineNumber,
						originalChangedLinesCntAria,
						r.modified.startLineNumber,
						modifiedChangedLinesCntAria
					)
				);
				const cell = document.createElement('div');
				cell.className = 'diff-review-cell diff-review-summary';
				cell.appendChild(
					document.createTextNode(
						`${diffIndex + 1}/${diffsLength}: @@ -${r.original.startLineNumber},${r.original.length} +${r.modified.startLineNumber},${r.modified.length} @@`
					)
				);
				header.appendChild(cell);
				row = header;
			} else {
				row = this._createRow(
					viewItem,
					lineHeight,
					this._width.get(),
					originalOptions,
					originalModel,
					originalModelOpts,
					modifiedOptions,
					modifiedModel,
					modifiedModelOpts
				);
			}
			container.appendChild(row);
			const isSelectedObs = derived(reader => this._model.currentElement.read(reader) === viewItem);
			store.add(
				autorun(reader => {
					const isSelected = isSelectedObs.read(reader);
					row.tabIndex = isSelected ? 0 : -1;
					if (isSelected) {
						row.focus();
					}
				})
			);
			store.add(
				addDisposableListener(row, 'focus', () => {
					this._model.goToLine(viewItem);
				})
			);
		}
		this._scrollbar.scanDomNode();
	}
	_createRow(
		item,
		lineHeight,
		width2,
		originalOptions,
		originalModel,
		originalModelOpts,
		modifiedOptions,
		modifiedModel,
		modifiedModelOpts
	) {
		const originalLayoutInfo = originalOptions.get(
			145
			// layoutInfo
		);
		const originalLineNumbersWidth = originalLayoutInfo.glyphMarginWidth + originalLayoutInfo.lineNumbersWidth;
		const modifiedLayoutInfo = modifiedOptions.get(
			145
			// layoutInfo
		);
		const modifiedLineNumbersWidth = 10 + modifiedLayoutInfo.glyphMarginWidth + modifiedLayoutInfo.lineNumbersWidth;
		let rowClassName = 'diff-review-row';
		let lineNumbersExtraClassName = '';
		const spacerClassName = 'diff-review-spacer';
		let spacerIcon = null;
		switch (item.type) {
			case 3:
				rowClassName = 'diff-review-row line-insert';
				lineNumbersExtraClassName = ' char-insert';
				spacerIcon = accessibleDiffViewerInsertIcon;
				break;
			case 2:
				rowClassName = 'diff-review-row line-delete';
				lineNumbersExtraClassName = ' char-delete';
				spacerIcon = accessibleDiffViewerRemoveIcon;
				break;
		}
		const row = document.createElement('div');
		row.style.minWidth = width2 + 'px';
		row.className = rowClassName;
		row.setAttribute('role', 'listitem');
		row.ariaLevel = '';
		const cell = document.createElement('div');
		cell.className = 'diff-review-cell';
		cell.style.height = `${lineHeight}px`;
		row.appendChild(cell);
		const originalLineNumber = document.createElement('span');
		originalLineNumber.style.width = originalLineNumbersWidth + 'px';
		originalLineNumber.style.minWidth = originalLineNumbersWidth + 'px';
		originalLineNumber.className = 'diff-review-line-number' + lineNumbersExtraClassName;
		if (item.originalLineNumber !== undefined) {
			originalLineNumber.appendChild(document.createTextNode(String(item.originalLineNumber)));
		} else {
			originalLineNumber.innerText = '\xA0';
		}
		cell.appendChild(originalLineNumber);
		const modifiedLineNumber = document.createElement('span');
		modifiedLineNumber.style.width = modifiedLineNumbersWidth + 'px';
		modifiedLineNumber.style.minWidth = modifiedLineNumbersWidth + 'px';
		modifiedLineNumber.style.paddingRight = '10px';
		modifiedLineNumber.className = 'diff-review-line-number' + lineNumbersExtraClassName;
		if (item.modifiedLineNumber !== undefined) {
			modifiedLineNumber.appendChild(document.createTextNode(String(item.modifiedLineNumber)));
		} else {
			modifiedLineNumber.innerText = '\xA0';
		}
		cell.appendChild(modifiedLineNumber);
		const spacer = document.createElement('span');
		spacer.className = spacerClassName;
		if (spacerIcon) {
			const spacerCodicon = document.createElement('span');
			spacerCodicon.className = asThemeIconClassNameString(spacerIcon);
			spacerCodicon.innerText = '\xA0\xA0';
			spacer.appendChild(spacerCodicon);
		} else {
			spacer.innerText = '\xA0\xA0';
		}
		cell.appendChild(spacer);
		let lineContent;
		if (item.modifiedLineNumber !== undefined) {
			let html2 = this._getLineHtml(
				modifiedModel,
				modifiedOptions,
				modifiedModelOpts.tabSize,
				item.modifiedLineNumber,
				this._languageService.languageIdCodec
			);

			cell.insertAdjacentHTML('beforeend', html2);
			lineContent = modifiedModel.getLineContent(item.modifiedLineNumber);
		} else {
			let html2 = this._getLineHtml(
				originalModel,
				originalOptions,
				originalModelOpts.tabSize,
				item.originalLineNumber,
				this._languageService.languageIdCodec
			);

			cell.insertAdjacentHTML('beforeend', html2);
			lineContent = originalModel.getLineContent(item.originalLineNumber);
		}
		if (lineContent.length === 0) {
			lineContent = localize('blank');
		}
		let ariaLabel = '';
		switch (item.type) {
			case 1:
				if (item.originalLineNumber === item.modifiedLineNumber) {
					ariaLabel = localize(lineContent, item.originalLineNumber);
				} else {
					ariaLabel = localize(
						'{0} original line {1} modified line {2}',
						lineContent,
						item.originalLineNumber,
						item.modifiedLineNumber
					);
				}
				break;
			case 3:
				ariaLabel = localize(lineContent, item.modifiedLineNumber);
				break;
			case 2:
				ariaLabel = localize(lineContent, item.originalLineNumber);
				break;
		}
		row.setAttribute('aria-label', ariaLabel);
		return row;
	}
	_getLineHtml(model, options2, tabSize, lineNumber, languageIdCodec) {
		const lineContent = model.getLineContent(lineNumber);
		const fontInfo = options2.get(
			50
			// fontInfo
		);
		const lineTokens = LineTokens.createEmpty(lineContent, languageIdCodec);
		const isBasicASCII2 = ViewLineRenderingData.isBasicASCII(lineContent, model.mightContainNonBasicASCII());
		const containsRTL2 = ViewLineRenderingData.containsRTL(lineContent, isBasicASCII2, model.mightContainRTL());
		const r = renderViewLine2(
			new RenderLineInput(
				fontInfo.isMonospace &&
					!options2.get(
						33
						// disableMonospaceOptimizations
					),
				fontInfo.canUseHalfwidthRightwardsArrow,
				lineContent,
				false,
				isBasicASCII2,
				containsRTL2,
				0,
				lineTokens,
				[],
				tabSize,
				0,
				fontInfo.spaceWidth,
				fontInfo.middotWidth,
				fontInfo.wsmiddotWidth,
				options2.get(
					117
					// stopRenderingLineAfter
				),
				options2.get(
					99
					// renderWhitespace
				),
				options2.get(
					94
					// renderControlCharacters
				),
				options2.get(
					51
					// fontLigatures
				) !== EditorFontLigatures.OFF,
				null
			)
		);
		return r.html;
	}
}
__decorate([__param(5, ILanguageService)], View3);

class AccessibleDiffViewerModelFromEditors {
	constructor(editors) {
		this.editors = editors;
	}
	getOriginalModel() {
		return this.editors.original.getModel();
	}
	getOriginalOptions() {
		return this.editors.original.getOptions();
	}
	originalReveal(range2) {
		this.editors.original.revealRange(range2);
		this.editors.original.setSelection(range2);
		this.editors.original.focus();
	}
	getModifiedModel() {
		return this.editors.modified.getModel();
	}
	getModifiedOptions() {
		return this.editors.modified.getOptions();
	}
	modifiedReveal(range2) {
		if (range2) {
			this.editors.modified.revealRange(range2);
			this.editors.modified.setSelection(range2);
		}
		this.editors.modified.focus();
	}
	modifiedSetSelection(range2) {
		this.editors.modified.setSelection(range2);
	}
	modifiedFocus() {
		this.editors.modified.focus();
	}
	getModifiedPosition() {
		return this.editors.modified.getPosition();
	}
}