


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// node_modules/monaco-editor/esm/vs/editor/contrib/peekView/browser/peekView.js
var IPeekViewService = createEditorServiceDecorator('IPeekViewService');
registerSingleton(
	IPeekViewService,
	class {
		constructor() {
			this._widgets = new Map();
		}
		addExclusiveWidget(editor2, widget) {
			const existing = this._widgets.get(editor2);
			if (existing) {
				existing.listener.dispose();
				existing.widget.dispose();
			}
			const remove = () => {
				const data = this._widgets.get(editor2);
				if (data && data.widget === widget) {
					data.listener.dispose();
					this._widgets.delete(editor2);
				}
			};
			this._widgets.set(editor2, {
				widget,
				listener: widget.onDidClose(remove)
			});
		}
	},
	1 // InstantiationType.Delayed
);
const ck_inPeekEditor = new RawContextKey(
	'inReferenceSearchEditor',
	true,
	localize('Whether the current code editor is embedded inside peek')
);
const ck_notInPeekEditor = ck_inPeekEditor.toNegated();
class PeekContextController {
	constructor(editor2, contextKeyService) {
		if (editor2 instanceof EmbeddedCodeEditorWidget) {
			ck_inPeekEditor.bindTo(contextKeyService);
		}
	}
	dispose() {}
}
PeekContextController.ID = 'editor.contrib.referenceController';
__decorate([__param(1, IContextKeyService)], PeekContextController);
registerEditorContribution(
	PeekContextController.ID,
	PeekContextController,
	0 // Eager
);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



function getOuterEditor(accessor) {
	const editor2 = accessor.get(ICodeEditorService).getFocusedCodeEditor();
	if (editor2 instanceof EmbeddedCodeEditorWidget) {
		return editor2.getParentEditor();
	}
	return editor2;
}
var defaultOptions2 = {
	headerBackgroundColor: colorWhite,
	primaryHeadingColor: Color.fromHex('#333333'),
	secondaryHeadingColor: Color.fromHex('#6c6c6cb3')
};
class PeekViewWidget extends ZoneWidget {
	constructor(editor2, options2, instantiationService) {
		super(editor2, options2);
		this.instantiationService = instantiationService;
		this._onDidClose = new Emitter();
		this.onDidClose = this._onDidClose.event;
		mixin(this.options, defaultOptions2, false);
	}
	dispose() {
		if (!this.disposed) {
			this.disposed = true;
			super.dispose();
			this._onDidClose.fire(this);
		}
	}
	style(styles) {
		const options2 = this.options;
		if (styles.headerBackgroundColor) {
			options2.headerBackgroundColor = styles.headerBackgroundColor;
		}
		if (styles.primaryHeadingColor) {
			options2.primaryHeadingColor = styles.primaryHeadingColor;
		}
		if (styles.secondaryHeadingColor) {
			options2.secondaryHeadingColor = styles.secondaryHeadingColor;
		}
		super.style(styles);
	}
	_applyStyles() {
		super._applyStyles();
		const options2 = this.options;
		if (this._headElement && options2.headerBackgroundColor) {
			this._headElement.style.backgroundColor = options2.headerBackgroundColor.toString();
		}
		if (this._primaryHeading && options2.primaryHeadingColor) {
			this._primaryHeading.style.color = options2.primaryHeadingColor.toString();
		}
		if (this._secondaryHeading && options2.secondaryHeadingColor) {
			this._secondaryHeading.style.color = options2.secondaryHeadingColor.toString();
		}
		if (this._bodyElement && options2.frameColor) {
			this._bodyElement.style.borderColor = options2.frameColor.toString();
		}
	}
	_fillContainer(container) {
		this.setCssClass('peekview-widget');
		this._headElement = createDomElement('.head');
		this._bodyElement = createDomElement('.body');
		this._fillHead(this._headElement);
		this._fillBody(this._bodyElement);
		container.appendChild(this._headElement);
		container.appendChild(this._bodyElement);
	}
	_fillHead(container, noCloseAction) {
		this._titleElement = createDomElement('.peekview-title');
		if (this.options.supportOnTitleClick) {
			this._titleElement.classList.add('clickable');
			addStandardDisposableListener(this._titleElement, 'click', event => this._onTitleClick(event));
		}
		append(this._headElement, this._titleElement);
		this._fillTitleIcon(this._titleElement);
		this._primaryHeading = createDomElement('span.filename');
		this._secondaryHeading = createDomElement('span.dirname');
		this._metaHeading = createDomElement('span.meta');
		append(this._titleElement, this._primaryHeading, this._secondaryHeading, this._metaHeading);
		const actionsContainer = createDomElement('.peekview-actions');
		append(this._headElement, actionsContainer);
		const actionBarOptions = this._getActionBarOptions();
		this._actionbarWidget = new ActionBar(actionsContainer, actionBarOptions);
		this._disposables.add(this._actionbarWidget);
		if (!noCloseAction) {
			this._actionbarWidget.push(
				new Action('peekview.close', localize('Close'), asThemeIconClassNameString(codicon_close), true, () => {
					this.dispose();
					return Promise.resolve();
				}),
				{ label: false, icon: true }
			);
		}
	}
	_fillTitleIcon(container) {}
	_getActionBarOptions() {
		return {
			actionViewItemProvider: createActionViewItem.bind(undefined, this.instantiationService),
			orientation: 0 // HORIZONTAL
		};
	}
	_onTitleClick(event) {}
	setTitle(primaryHeading, secondaryHeading) {
		if (this._primaryHeading && this._secondaryHeading) {
			this._primaryHeading.innerText = primaryHeading;
			this._primaryHeading.setAttribute('title', primaryHeading);
			if (secondaryHeading) {
				this._secondaryHeading.innerText = secondaryHeading;
			} else {
				clearNode(this._secondaryHeading);
			}
		}
	}
	setMetaTitle(value) {
		if (this._metaHeading) {
			if (value) {
				this._metaHeading.innerText = value;
				show(this._metaHeading);
			} else {
				hide(this._metaHeading);
			}
		}
	}
	_doLayout(heightInPixel, widthInPixel) {
		if (!this._isShowing && heightInPixel < 0) {
			this.dispose();
			return;
		}
		const headHeight = Math.ceil(
			this.editor.getOption(
				67 // lineHeight
			) * 1.2
		);
		const bodyHeight = Math.round(heightInPixel - (headHeight + 2));
		this._doLayoutHead(headHeight, widthInPixel);
		this._doLayoutBody(bodyHeight, widthInPixel);
	}
	_doLayoutHead(heightInPixel, widthInPixel) {
		if (this._headElement) {
			this._headElement.style.height = `${heightInPixel}px`;
			this._headElement.style.lineHeight = this._headElement.style.height;
		}
	}
	_doLayoutBody(heightInPixel, widthInPixel) {
		if (this._bodyElement) {
			this._bodyElement.style.height = `${heightInPixel}px`;
		}
	}
}
__decorate([__param(2, IInstantiationService)], PeekViewWidget); // node_modules/monaco-editor/esm/vs/editor/contrib/gotoSymbol/browser/referencesModel.js
class OneReference {
	constructor(isProviderFirst, parent, link, _rangeCallback) {
		this.isProviderFirst = isProviderFirst;
		this.parent = parent;
		this.link = link;
		this._rangeCallback = _rangeCallback;
		this.id = defaultGenerator.nextId();
	}
	get uri() {
		return this.link.uri;
	}
	get range() {
		return this._range ?? this.link.targetSelectionRange ?? this.link.range;
	}
	set range(value) {
		this._range = value;
		this._rangeCallback(this);
	}
}
class FilePreview {
	constructor(_modelReference) {
		this._modelReference = _modelReference;
	}
	dispose() {
		this._modelReference.dispose();
	}
	preview(range2, n = 8) {
		const model = this._modelReference.object.textEditorModel;
		if (!model) {
			return;
		}
		const { startLineNumber, startColumn, endLineNumber, endColumn } = range2;
		const word = model.getWordUntilPosition({
			lineNumber: startLineNumber,
			column: startColumn - n
		});
		const beforeRange = new Range(startLineNumber, word.startColumn, startLineNumber, startColumn);
		const afterRange = new Range(
			endLineNumber,
			endColumn,
			endLineNumber,
			1073741824 // MAX_SAFE_SMALL_INTEGER
		);
		const before = model.getValueInRange(beforeRange).replace(/^\s+/, '');
		const inside = model.getValueInRange(range2);
		const after2 = model.getValueInRange(afterRange).replace(/\s+$/, '');
		return {
			value: before + inside + after2,
			highlight: {
				start: before.length,
				end: before.length + inside.length
			}
		};
	}
}
class FileReferences {
	constructor(parent, uri) {
		this.parent = parent;
		this.uri = uri;
		this.children = [];
		this._previews = new ResourceMap();
	}
	dispose() {
		dispose(this._previews.values());
		this._previews.clear();
	}
	getPreview(child) {
		return this._previews.get(child.uri);
	}
	async resolve(textModelResolverService) {
		if (this._previews.size !== 0) {
			return this;
		}
		for (const child of this.children) {
			if (this._previews.has(child.uri)) {
				continue;
			}
			try {
				const ref = await textModelResolverService.createModelReference(child.uri);
				this._previews.set(child.uri, new FilePreview(ref));
			} catch (err) {
				onUnexpectedError(err);
			}
		}
		return this;
	}
}
class ReferencesModel {
	constructor(links, title) {
		this.groups = [];
		this.references = [];
		this._onDidChangeReferenceRange = new Emitter();
		this.onDidChangeReferenceRange = this._onDidChangeReferenceRange.event;
		this._links = links;
		this._title = title;
		const [providersFirst] = links;
		links.sort(ReferencesModel._compareReferences);
		let current;
		for (const link of links) {
			if (!current || !extUri.isEqual(current.uri, link.uri, true)) {
				current = new FileReferences(this, link.uri);
				this.groups.push(current);
			}
			if (
				current.children.length === 0 ||
				ReferencesModel._compareReferences(link, current.children[current.children.length - 1]) !== 0
			) {
				const oneRef = new OneReference(providersFirst === link, current, link, ref => this._onDidChangeReferenceRange.fire(ref));
				this.references.push(oneRef);
				current.children.push(oneRef);
			}
		}
	}
	dispose() {
		dispose(this.groups);
		this._onDidChangeReferenceRange.dispose();
		this.groups.length = 0;
	}
	clone() {
		return new ReferencesModel(this._links, this._title);
	}
	get title() {
		return this._title;
	}
	get isEmpty() {
		return this.groups.length === 0;
	}
	nextOrPreviousReference(reference, next) {
		const { parent } = reference;
		let idx = parent.children.indexOf(reference);
		const childCount = parent.children.length;
		const groupCount = parent.parent.groups.length;
		if (groupCount === 1 || (next && idx + 1 < childCount) || (!next && idx > 0)) {
			if (next) {
				idx = (idx + 1) % childCount;
			} else {
				idx = (idx + childCount - 1) % childCount;
			}
			return parent.children[idx];
		}
		idx = parent.parent.groups.indexOf(parent);
		if (next) {
			idx = (idx + 1) % groupCount;
			return parent.parent.groups[idx].children[0];
		} else {
			idx = (idx + groupCount - 1) % groupCount;
			return parent.parent.groups[idx].children[parent.parent.groups[idx].children.length - 1];
		}
	}
	nearestReference(resource, position) {
		const nearest = this.references
			.map((ref, idx) => {
				return {
					idx,
					prefixLen: commonPrefixLength(ref.uri.toString(), resource.toString()),
					offsetDist:
						Math.abs(ref.range.startLineNumber - position.lineNumber) * 100 + Math.abs(ref.range.startColumn - position.column)
				};
			})
			.sort((a, b) => {
				if (a.prefixLen > b.prefixLen) {
					return -1;
				} else if (a.prefixLen < b.prefixLen) {
					return 1;
				} else if (a.offsetDist < b.offsetDist) {
					return -1;
				} else if (a.offsetDist > b.offsetDist) {
					return 1;
				} else {
					return 0;
				}
			})[0];
		if (nearest) {
			return this.references[nearest.idx];
		}
		return;
	}
	referenceAt(resource, position) {
		for (const ref of this.references) {
			if (ref.uri.toString() === resource.toString()) {
				if (Range.containsPosition(ref.range, position)) {
					return ref;
				}
			}
		}
		return;
	}
	firstReference() {
		for (const ref of this.references) {
			if (ref.isProviderFirst) {
				return ref;
			}
		}
		return this.references[0];
	}
	static _compareReferences(a, b) {
		return extUri.compare(a.uri, b.uri) || Range.compareRangesUsingStarts(a.range, b.range);
	}
}

// node_modules/monaco-editor/esm/vs/editor/contrib/gotoSymbol/browser/peek/referencesTree.js

class DataSource {
	constructor(_resolverService) {
		this._resolverService = _resolverService;
	}
	hasChildren(element) {
		if (element instanceof ReferencesModel) {
			return true;
		}
		if (element instanceof FileReferences) {
			return true;
		}
		return false;
	}
	getChildren(element) {
		if (element instanceof ReferencesModel) {
			return element.groups;
		}
		if (element instanceof FileReferences) {
			return element.resolve(this._resolverService).then(val => {
				return val.children;
			});
		}
		throw new Error('bad tree');
	}
}
__decorate([__param(0, ITextModelService)], DataSource);
class Delegate {
	getHeight() {
		return 23;
	}
	getTemplateId(element) {
		if (element instanceof FileReferences) {
			return FileReferencesRenderer.id;
		} else {
			return OneReferenceRenderer.id;
		}
	}
}
class StringRepresentationProvider {
	constructor(_keybindingService) {
		this._keybindingService = _keybindingService;
	}
	getKeyboardNavigationLabel(element) {
		if (element instanceof OneReference) {
			const parts = element.parent.getPreview(element)?.preview(element.range);
			if (parts) {
				return parts.value;
			}
		}
		return basename2(element.uri);
	}
}
__decorate([__param(0, IKeybindingService)], StringRepresentationProvider);
class IdentityProvider {
	getId(element) {
		return element instanceof OneReference ? element.id : element.uri;
	}
}
class FileReferencesTemplate extends Disposable {
	constructor(container, _labelService) {
		super();
		this._labelService = _labelService;
		const parent = document.createElement('div');
		parent.classList.add('reference-file');
		this.file = this._register(new IconLabel(parent, { supportHighlights: true }));
		this.badge = new CountBadge(append(parent, createDomElement('.count')), {}, defaultStyle_countBadge);
		container.appendChild(parent);
	}
	set(element, matches) {
		const parent = dirname2(element.uri);
		this.file.setLabel(
			this._labelService.getUriBasenameLabel(element.uri),
			this._labelService.getUriLabel(parent, { relative: true }),
			{ title: this._labelService.getUriLabel(element.uri), matches }
		);
		const len = element.children.length;
		this.badge.setCount(len);
		if (len > 1) {
			this.badge.setTitleFormat(localize(len));
		} else {
			this.badge.setTitleFormat(localize(len));
		}
	}
}
__decorate([__param(1, ILabelService)], FileReferencesTemplate);
class FileReferencesRenderer {
	constructor(_instantiationService) {
		this._instantiationService = _instantiationService;
		this.templateId = FileReferencesRenderer.id;
	}
	renderTemplate(container) {
		return this._instantiationService.createInstance(FileReferencesTemplate, container);
	}
	renderElement(node, index, template) {
		template.set(node.element, createMatches(node.filterData));
	}
	disposeTemplate(templateData) {
		templateData.dispose();
	}
}
FileReferencesRenderer.id = 'FileReferencesRenderer';
__decorate([__param(0, IInstantiationService)], FileReferencesRenderer);
class OneReferenceTemplate extends Disposable {
	constructor(container) {
		super();
		this.label = this._register(new HighlightedLabel(container));
	}
	set(element, score3) {
		const preview = element.parent.getPreview(element)?.preview(element.range);
		if (!preview || !preview.value) {
			this.label.set(`${basename2(element.uri)}:${element.range.startLineNumber + 1}:${element.range.startColumn + 1}`);
		} else {
			const { value, highlight } = preview;
			if (score3 && !isFuzzyScoreDefault(score3)) {
				this.label.element.classList.toggle('referenceMatch', false);
				this.label.set(value, createMatches(score3));
			} else {
				this.label.element.classList.toggle('referenceMatch', true);
				this.label.set(value, [highlight]);
			}
		}
	}
}
class OneReferenceRenderer {
	constructor() {
		this.templateId = OneReferenceRenderer.id;
	}
	renderTemplate(container) {
		return new OneReferenceTemplate(container);
	}
	renderElement(node, index, templateData) {
		templateData.set(node.element, node.filterData);
	}
	disposeTemplate(templateData) {
		templateData.dispose();
	}
}
OneReferenceRenderer.id = 'OneReferenceRenderer';


// node_modules/monaco-editor/esm/vs/editor/contrib/gotoSymbol/browser/peek/referencesWidget.js

class DecorationsManager {
	constructor(_editor, _model) {
		this._editor = _editor;
		this._model = _model;
		this._decorations = new Map();
		this._decorationIgnoreSet = new Set();
		this._callOnDispose = new DisposableStore();
		this._callOnModelChange = new DisposableStore();
		this._callOnDispose.add(this._editor.onDidChangeModel(() => this._onModelChanged()));
		this._onModelChanged();
	}
	dispose() {
		this._callOnModelChange.dispose();
		this._callOnDispose.dispose();
		this.removeDecorations();
	}
	_onModelChanged() {
		this._callOnModelChange.clear();
		const model = this._editor.getModel();
		if (!model) {
			return;
		}
		for (const ref of this._model.references) {
			if (ref.uri.toString() === model.uri.toString()) {
				this._addDecorations(ref.parent);
				return;
			}
		}
	}
	_addDecorations(reference) {
		if (!this._editor.hasModel()) {
			return;
		}
		this._callOnModelChange.add(this._editor.getModel().onDidChangeDecorations(() => this._onDecorationChanged()));
		const newDecorations = [];
		const newDecorationsActualIndex = [];
		for (let i = 0, len = reference.children.length; i < len; i++) {
			const oneReference = reference.children[i];
			if (this._decorationIgnoreSet.has(oneReference.id)) {
				continue;
			}
			if (oneReference.uri.toString() !== this._editor.getModel().uri.toString()) {
				continue;
			}
			newDecorations.push({
				range: oneReference.range,
				options: DecorationsManager.DecorationOptions
			});
			newDecorationsActualIndex.push(i);
		}
		this._editor.changeDecorations(changeAccessor => {
			const decorations = changeAccessor.deltaDecorations([], newDecorations);
			for (let i = 0; i < decorations.length; i++) {
				this._decorations.set(decorations[i], reference.children[newDecorationsActualIndex[i]]);
			}
		});
	}
	_onDecorationChanged() {
		const toRemove = [];
		const model = this._editor.getModel();
		if (!model) {
			return;
		}
		for (const [decorationId, reference] of this._decorations) {
			const newRange = model.getDecorationRange(decorationId);
			if (!newRange) {
				continue;
			}
			let ignore = false;
			if (Range.equalsRange(newRange, reference.range)) {
				continue;
			}
			if (Range.spansMultipleLines(newRange)) {
				ignore = true;
			} else {
				const lineLength = reference.range.endColumn - reference.range.startColumn;
				const newLineLength = newRange.endColumn - newRange.startColumn;
				if (lineLength !== newLineLength) {
					ignore = true;
				}
			}
			if (ignore) {
				this._decorationIgnoreSet.add(reference.id);
				toRemove.push(decorationId);
			} else {
				reference.range = newRange;
			}
		}
		for (let i = 0, len = toRemove.length; i < len; i++) {
			this._decorations.delete(toRemove[i]);
		}
		this._editor.removeDecorations(toRemove);
	}
	removeDecorations() {
		this._editor.removeDecorations([...this._decorations.keys()]);
		this._decorations.clear();
	}
}
DecorationsManager.DecorationOptions = ModelDecorationOptions.register({
	description: 'reference-decoration',
	stickiness: 1,
	className: 'reference-decoration'
});
class LayoutData {
	constructor() {
		this.ratio = 0.7;
		this.heightInLines = 18;
	}
	static fromJSON(raw) {
		let ratio;
		let heightInLines;
		try {
			const data = JSON.parse(raw);
			ratio = data.ratio;
			heightInLines = data.heightInLines;
		} catch (exception) {}
		return { ratio: ratio || 0.7, heightInLines: heightInLines || 18 };
	}
}
class ReferencesTree extends WorkbenchAsyncDataTree {}
class ReferenceWidget extends PeekViewWidget {
	constructor(
		editor2,
		_defaultTreeKeyboardSupport,
		layoutData,
		themeService,
		_textModelResolverService,
		_instantiationService,
		_peekViewService,
		_uriLabel,
		_undoRedoService,
		_keybindingService,
		_languageService,
		_languageConfigurationService
	) {
		super(
			editor2,
			{
				showFrame: false,
				showArrow: true,
				isResizeable: true,
				isAccessible: true,
				supportOnTitleClick: true
			},
			_instantiationService
		);
		this._defaultTreeKeyboardSupport = _defaultTreeKeyboardSupport;
		this.layoutData = layoutData;
		this._textModelResolverService = _textModelResolverService;
		this._instantiationService = _instantiationService;
		this._peekViewService = _peekViewService;
		this._uriLabel = _uriLabel;
		this._undoRedoService = _undoRedoService;
		this._keybindingService = _keybindingService;
		this._languageService = _languageService;
		this._languageConfigurationService = _languageConfigurationService;
		this._disposeOnNewModel = new DisposableStore();
		this._callOnDispose = new DisposableStore();
		this._onDidSelectReference = new Emitter();
		this.onDidSelectReference = this._onDidSelectReference.event;
		this._dim = new Dimension(0, 0);
		this._applyTheme(themeService.getColorTheme());
		this._callOnDispose.add(themeService.onDidColorThemeChange(this._applyTheme.bind(this)));
		this._peekViewService.addExclusiveWidget(editor2, this);
		this.create();
	}
	dispose() {
		this.setModel(undefined);
		this._callOnDispose.dispose();
		this._disposeOnNewModel.dispose();
		dispose(this._preview);
		dispose(this._previewNotAvailableMessage);
		dispose(this._tree);
		dispose(this._previewModelReference);
		this._splitView.dispose();
		super.dispose();
	}
	_applyTheme(theme) {
		const borderColor = theme.getColor(colorId_peekView_border) || colorTransparent;
		this.style({
			arrowColor: borderColor,
			frameColor: borderColor,
			headerBackgroundColor: theme.getColor(colorId_peekViewTitle_background) || colorTransparent,
			primaryHeadingColor: theme.getColor(colorId_peekViewTitle_foreground),
			secondaryHeadingColor: theme.getColor(colorId_peekViewTitleDescription_foreground)
		});
	}
	show(where) {
		super.show(where, this.layoutData.heightInLines || 18);
	}
	focusOnReferenceTree() {
		this._tree.domFocus();
	}
	focusOnPreviewEditor() {
		this._preview.focus();
	}
	isPreviewEditorFocused() {
		return this._preview.hasTextFocus();
	}
	_onTitleClick(e) {
		if (this._preview && this._preview.getModel()) {
			this._onDidSelectReference.fire({
				element: this._getFocusedReference(),
				kind: e.ctrlKey || e.metaKey || e.altKey ? 'side' : 'open',
				source: 'title'
			});
		}
	}
	_fillBody(containerElement) {
		this.setCssClass('reference-zone-widget');
		this._messageContainer = append(containerElement, createDomElement('div.messages'));
		hide(this._messageContainer);
		this._splitView = new SplitView(containerElement, {
			orientation: 1 // Orientation.HORIZONTAL
		});
		this._previewContainer = append(containerElement, createDomElement('div.preview.inline'));
		const options2 = {
			scrollBeyondLastLine: false,
			scrollbar: {
				verticalScrollbarSize: 14,
				horizontal: 'auto',
				useShadows: true,
				verticalHasArrows: false,
				horizontalHasArrows: false,
				alwaysConsumeMouseWheel: true
			},
			overviewRulerLanes: 2,
			fixedOverflowWidgets: true,
			minimap: { enabled: false }
		};
		this._preview = this._instantiationService.createInstance(
			EmbeddedCodeEditorWidget,
			this._previewContainer,
			options2,
			{},
			this.editor
		);
		hide(this._previewContainer);
		this._previewNotAvailableMessage = new TextModel(
			localize('no preview available'),
			PLAINTEXT_LANGUAGE_ID,
			TextModel.DEFAULT_CREATION_OPTIONS,
			null,
			this._undoRedoService,
			this._languageService,
			this._languageConfigurationService
		);
		this._treeContainer = append(containerElement, createDomElement('div.ref-tree.inline'));
		const treeOptions = {
			keyboardSupport: this._defaultTreeKeyboardSupport,
			keyboardNavigationLabelProvider: this._instantiationService.createInstance(StringRepresentationProvider),
			identityProvider: new IdentityProvider(),
			openOnSingleClick: true,
			selectionNavigation: true,
			overrideStyles: {
				listBackground: colorId_peekViewResults_background
			}
		};
		if (this._defaultTreeKeyboardSupport) {
			this._callOnDispose.add(
				addStandardDisposableListener(
					this._treeContainer,
					'keydown',
					e => {
						if (
							e.equals(
								9 // Escape
							)
						) {
							this._keybindingService.dispatchEvent(e, e.target);
							e.stopPropagation();
						}
					},
					true
				)
			);
		}
		this._tree = this._instantiationService.createInstance(
			ReferencesTree,
			'ReferencesWidget',
			this._treeContainer,
			new Delegate(),
			[
				this._instantiationService.createInstance(FileReferencesRenderer),
				this._instantiationService.createInstance(OneReferenceRenderer)
			],
			this._instantiationService.createInstance(DataSource),
			treeOptions
		);
		this._splitView.addView(
			{
				onDidChange: editorEvent_none,
				element: this._previewContainer,
				minimumSize: 200,
				maximumSize: Number.MAX_VALUE,
				layout: width2 => {
					this._preview.layout({
						height: this._dim.height,
						width: width2
					});
				}
			},
			{ type: 'distribute' }
		);
		this._splitView.addView(
			{
				onDidChange: editorEvent_none,
				element: this._treeContainer,
				minimumSize: 100,
				maximumSize: Number.MAX_VALUE,
				layout: width2 => {
					this._treeContainer.style.height = `${this._dim.height}px`;
					this._treeContainer.style.width = `${width2}px`;
					this._tree.layout(this._dim.height, width2);
				}
			},
			{ type: 'distribute' }
		);
		this._disposables.add(
			this._splitView.onDidSashChange(() => {
				if (this._dim.width) {
					this.layoutData.ratio = this._splitView.getViewSize(0) / this._dim.width;
				}
			}, undefined)
		);
		const onEvent = (element, kind) => {
			if (element instanceof OneReference) {
				if (kind === 'show') {
					this._revealReference(element, false);
				}
				this._onDidSelectReference.fire({
					element,
					kind,
					source: 'tree'
				});
			}
		};
		this._tree.onDidOpen(e => {
			if (e.sideBySide) {
				onEvent(e.element, 'side');
			} else if (e.editorOptions.pinned) {
				onEvent(e.element, 'goto');
			} else {
				onEvent(e.element, 'show');
			}
		});
		hide(this._treeContainer);
	}
	_onWidth(width2) {
		if (this._dim) {
			this._doLayoutBody(this._dim.height, width2);
		}
	}
	_doLayoutBody(heightInPixel, widthInPixel) {
		super._doLayoutBody(heightInPixel, widthInPixel);
		this._dim = new Dimension(widthInPixel, heightInPixel);
		this.layoutData.heightInLines = this._viewZone ? this._viewZone.heightInLines : this.layoutData.heightInLines;
		this._splitView.layout(widthInPixel);
		this._splitView.resizeView(0, widthInPixel * this.layoutData.ratio);
	}
	setSelection(selection) {
		return this._revealReference(selection, true).then(() => {
			if (!this._model) {
				return;
			}
			this._tree.setSelection([selection]);
			this._tree.setFocus([selection]);
		});
	}
	setModel(newModel) {
		this._disposeOnNewModel.clear();
		this._model = newModel;
		if (this._model) {
			return this._onNewModel();
		}
		return Promise.resolve();
	}
	_onNewModel() {
		if (!this._model) {
			return Promise.resolve(undefined);
		}
		if (this._model.isEmpty) {
			this.setTitle('');
			this._messageContainer.innerText = localize('No results');
			show(this._messageContainer);
			return Promise.resolve(undefined);
		}
		hide(this._messageContainer);
		this._decorationsManager = new DecorationsManager(this._preview, this._model);
		this._disposeOnNewModel.add(this._decorationsManager);
		this._disposeOnNewModel.add(this._model.onDidChangeReferenceRange(reference => this._tree.rerender(reference)));
		this._disposeOnNewModel.add(
			this._preview.onMouseDown(e => {
				const { event, target } = e;
				if (event.detail !== 2) {
					return;
				}
				const element = this._getFocusedReference();
				if (!element) {
					return;
				}
				this._onDidSelectReference.fire({
					element: { uri: element.uri, range: target.range },
					kind: event.ctrlKey || event.metaKey || event.altKey ? 'side' : 'open',
					source: 'editor'
				});
			})
		);
		this.container.classList.add('results-loaded');
		show(this._treeContainer);
		show(this._previewContainer);
		this._splitView.layout(this._dim.width);
		this.focusOnReferenceTree();
		return this._tree.setInput(this._model.groups.length === 1 ? this._model.groups[0] : this._model);
	}
	_getFocusedReference() {
		const [element] = this._tree.getFocus();
		if (element instanceof OneReference) {
			return element;
		} else if (element instanceof FileReferences) {
			if (element.children.length > 0) {
				return element.children[0];
			}
		}
		return;
	}
	async revealReference(reference) {
		await this._revealReference(reference, false);
		this._onDidSelectReference.fire({
			element: reference,
			kind: 'goto',
			source: 'tree'
		});
	}
	async _revealReference(reference, revealParent) {
		if (this._revealedReference === reference) {
			return;
		}
		this._revealedReference = reference;
		if (reference.uri.scheme !== Schemas.inMemory) {
			this.setTitle(basenameOrAuthority(reference.uri), this._uriLabel.getUriLabel(dirname2(reference.uri)));
		} else {
			this.setTitle(localize('References'));
		}
		const promise = this._textModelResolverService.createModelReference(reference.uri);
		if (this._tree.getInput() === reference.parent) {
			this._tree.reveal(reference);
		} else {
			if (revealParent) {
				this._tree.reveal(reference.parent);
			}
			await this._tree.expand(reference.parent);
			this._tree.reveal(reference);
		}
		const ref = await promise;
		if (!this._model) {
			ref.dispose();
			return;
		}
		dispose(this._previewModelReference);
		const model = ref.object;
		if (model) {
			const scrollType = this._preview.getModel() === model.textEditorModel ? 0 : 1;
			const sel = Range.lift(reference.range).collapseToStart();
			this._previewModelReference = ref;
			this._preview.setModel(model.textEditorModel);
			this._preview.setSelection(sel);
			this._preview.revealRangeInCenter(sel, scrollType);
		} else {
			this._preview.setModel(this._previewNotAvailableMessage);
			ref.dispose();
		}
	}
}
__decorate(
	[
		__param(3, IThemeService),
		__param(4, ITextModelService),
		__param(5, IInstantiationService),
		__param(6, IPeekViewService),
		__param(7, ILabelService),
		__param(8, IUndoRedoService),
		__param(9, IKeybindingService),
		__param(10, ILanguageService),
		__param(11, ILanguageConfigurationService)
	],
	ReferenceWidget
);


var ctxReferenceSearchVisible = new RawContextKey(
	'referenceSearchVisible',
	false,
);


const referencesControllerId = 'editor.contrib.referencesController';
const getReferencesControllerOf = editor => editor.getContribution(referencesControllerId);
class ReferencesController {
	constructor(
		defaultTreeKeyboardSupport,
		editor,
		contextKeyService,
		editorService,
		notificationService,
		instantiationService,
		storageService,
		configurationService
	) {
		this._defaultTreeKeyboardSupport = defaultTreeKeyboardSupport;
		this._editor = editor;
		this._referenceSearchVisible = ctxReferenceSearchVisible.bindTo(contextKeyService);
		this._editorService = editorService;
		this._notificationService = notificationService;
		this._instantiationService = instantiationService;
		this._storageService = storageService;
		this._configurationService = configurationService;
		this._disposables = new DisposableStore();
		this._ignoreModelChangeEvent = false;
		this._requestIdPool = 0;
	}
	dispose() {
		this._referenceSearchVisible.reset();
		this._disposables.dispose();
		this._widget?.dispose();
		this._model?.dispose();
		this._widget = undefined;
		this._model = undefined;
	}
	toggleWidget(range2, modelPromise, peekMode) {
		let widgetPosition;
		if (this._widget) {
			widgetPosition = this._widget.position;
		}
		this.closeWidget();
		if (!!widgetPosition && range2.containsPosition(widgetPosition)) {
			return;
		}
		this._peekMode = peekMode;
		this._referenceSearchVisible.set(true);
		this._disposables.add(
			this._editor.onDidChangeModelLanguage(() => {
				this.closeWidget();
			})
		);
		this._disposables.add(
			this._editor.onDidChangeModel(() => {
				if (!this._ignoreModelChangeEvent) {
					this.closeWidget();
				}
			})
		);
		const storageKey = 'peekViewLayout';
		const data = LayoutData.fromJSON(this._storageService.get(storageKey, 0, '{}'));
		this._widget = this._instantiationService.createInstance(ReferenceWidget, this._editor, this._defaultTreeKeyboardSupport, data);
		this._widget.setTitle(localize('Loading...'));
		this._widget.show(range2);
		this._disposables.add(
			this._widget.onDidClose(() => {
				modelPromise.cancel();
				if (this._widget) {
					this._storageService.store(
						storageKey,
						JSON.stringify(this._widget.layoutData),
						0,
						1 // StorageTarget.MACHINE
					);
					this._widget = undefined;
				}
				this.closeWidget();
			})
		);
		this._disposables.add(
			this._widget.onDidSelectReference(event => {
				const { element, kind } = event;
				if (!element) {
					return;
				}
				switch (kind) {
					case 'open':
						if (event.source !== 'editor' || !this._configurationService.getValue('editor.stablePeek')) {
							this.openReference(element, false, false);
						}
						break;
					case 'side':
						this.openReference(element, true, false);
						break;
					case 'goto':
						if (peekMode) {
							this._gotoReference(element, true);
						} else {
							this.openReference(element, false, true);
						}
						break;
				}
			})
		);
		const requestId = ++this._requestIdPool;
		modelPromise.then(
			model => {
				if (requestId !== this._requestIdPool || !this._widget) {
					model.dispose();
					return;
				}
				this._model?.dispose();
				this._model = model;
				return this._widget.setModel(this._model).then(() => {
					if (this._widget && this._model && this._editor.hasModel()) {
						if (!this._model.isEmpty) {
							this._widget.setMetaTitle(localize(this._model.title, this._model.references.length));
						} else {
							this._widget.setMetaTitle('');
						}
						const uri = this._editor.getModel().uri;
						const pos = new Position(range2.startLineNumber, range2.startColumn);
						const selection = this._model.nearestReference(uri, pos);
						if (selection) {
							return this._widget.setSelection(selection).then(() => {
								if (
									this._widget &&
									this._editor.getOption(
										87 // peekWidgetDefaultFocus
									) === 'editor'
								) {
									this._widget.focusOnPreviewEditor();
								}
							});
						}
					}
					return;
				});
			},
			error => {
				this._notificationService.error(error);
			}
		);
	}
	changeFocusBetweenPreviewAndReferences() {
		if (!this._widget) {
			return;
		}
		if (this._widget.isPreviewEditorFocused()) {
			this._widget.focusOnReferenceTree();
		} else {
			this._widget.focusOnPreviewEditor();
		}
	}
	async goToNextOrPreviousReference(fwd) {
		if (!this._editor.hasModel() || !this._model || !this._widget) {
			return;
		}
		const currentPosition = this._widget.position;
		if (!currentPosition) {
			return;
		}
		const source = this._model.nearestReference(this._editor.getModel().uri, currentPosition);
		if (!source) {
			return;
		}
		const target = this._model.nextOrPreviousReference(source, fwd);
		const editorFocus = this._editor.hasTextFocus();
		const previewEditorFocus = this._widget.isPreviewEditorFocused();
		await this._widget.setSelection(target);
		await this._gotoReference(target, false);
		if (editorFocus) {
			this._editor.focus();
		} else if (this._widget && previewEditorFocus) {
			this._widget.focusOnPreviewEditor();
		}
	}
	async revealReference(reference) {
		if (!this._editor.hasModel() || !this._model || !this._widget) {
			return;
		}
		await this._widget.revealReference(reference);
	}
	closeWidget(focusEditor = true) {
		this._widget?.dispose();
		this._model?.dispose();
		this._referenceSearchVisible.reset();
		this._disposables.clear();
		this._widget = undefined;
		this._model = undefined;
		if (focusEditor) {
			this._editor.focus();
		}
		this._requestIdPool += 1;
	}
	_gotoReference(ref, pinned) {
		this._widget?.hide();
		this._ignoreModelChangeEvent = true;
		const range2 = Range.lift(ref.range).collapseToStart();
		return this._editorService
			.openCodeEditor(
				{
					resource: ref.uri,
					options: {
						selection: range2,
						selectionSource: 'code.jump',
						pinned
					}
				},
				this._editor
			)
			.then(
				openedEditor => {
					this._ignoreModelChangeEvent = false;
					if (!openedEditor || !this._widget) {
						this.closeWidget();
						return;
					}
					if (this._editor === openedEditor) {
						this._widget.show(range2);
						this._widget.focusOnReferenceTree();
					} else {
						const other = getReferencesControllerOf(openedEditor);
						const model = this._model.clone();
						this.closeWidget();
						openedEditor.focus();
						other === null || other === undefined
							? undefined
							: other.toggleWidget(
									range2,
									createCancelablePromise(_ => Promise.resolve(model)),
									this._peekMode ?? false
								);
					}
				},
				err => {
					this._ignoreModelChangeEvent = false;
					onUnexpectedError(err);
				}
			);
	}
	openReference(ref, sideBySide, pinned) {
		if (!sideBySide) {
			this.closeWidget();
		}
		const { uri, range: range2 } = ref;
		this._editorService.openCodeEditor(
			{
				resource: uri,
				options: {
					selection: range2,
					selectionSource: 'code.jump',
					pinned
				}
			},
			this._editor,
			sideBySide
		);
	}
}
__decorate(
	[
		__param(2, IContextKeyService),
		__param(3, ICodeEditorService),
		__param(4, INotificationService),
		__param(5, IInstantiationService),
		__param(6, IStorageService),
		__param(7, IConfigurationService)
	],
	ReferencesController
);




class StandaloneReferencesController extends ReferencesController {
	constructor(editor, contextKeyService, editorService, notificationService, instantiationService, storageService, configurationService) {
		super(
			true,
			editor,
			contextKeyService,
			editorService,
			notificationService,
			instantiationService,
			storageService,
			configurationService
		);
	}
}
__decorate(
	[
		__param(1, IContextKeyService),
		__param(2, ICodeEditorService),
		__param(3, INotificationService),
		__param(4, IInstantiationService),
		__param(5, IStorageService),
		__param(6, IConfigurationService)
	],
	StandaloneReferencesController
);
registerEditorContribution(
	referencesControllerId,
	StandaloneReferencesController,
	4 // Instantiation Lazy
);





function withController(accessor, fn) {
	const outerEditor = getOuterEditor(accessor);
	if (!outerEditor) {
		return;
	}
	const controller = getReferencesControllerOf(outerEditor);
	if (controller) {
		fn(controller);
	}
}
keybindingsRegistry.registerCommandAndKeybindingRule({
	id: 'togglePeekWidgetFocus',
	weight: 100,
	primary: KeyChord(
		2048 | 41,
		60 // F2
	),
	when: ContextKeyExpr.or(ctxReferenceSearchVisible, ck_inPeekEditor),
	handler(accessor) {
		withController(accessor, controller => {
			controller.changeFocusBetweenPreviewAndReferences();
		});
	}
});
keybindingsRegistry.registerCommandAndKeybindingRule({
	id: 'goToNextReference',
	weight: 100 - 10,
	primary: 62,
	secondary: [
		70 //F12
	],
	when: ContextKeyExpr.or(ctxReferenceSearchVisible, ck_inPeekEditor),
	handler(accessor) {
		withController(accessor, controller => {
			controller.goToNextOrPreviousReference(true);
		});
	}
});
keybindingsRegistry.registerCommandAndKeybindingRule({
	id: 'goToPreviousReference',
	weight: 100 - 10,
	primary: 1024 | 62,
	secondary: [
		1024 | 70 // F12
	],
	when: ContextKeyExpr.or(ctxReferenceSearchVisible, ck_inPeekEditor),
	handler(accessor) {
		withController(accessor, controller => {
			controller.goToNextOrPreviousReference(false);
		});
	}
});

commandsRegistry.registerCommandAlias('goToNextReferenceFromEmbeddedEditor', 'goToNextReference');
commandsRegistry.registerCommandAlias('goToPreviousReferenceFromEmbeddedEditor', 'goToPreviousReference');
commandsRegistry.registerCommandAlias('closeReferenceSearchEditor', 'closeReferenceSearch');
commandsRegistry.registerCommand('closeReferenceSearch', accessor => withController(accessor, controller => controller.closeWidget()));
keybindingsRegistry.registerKeybindingRule({
	id: 'closeReferenceSearch',
	weight: 100 - 101,
	primary: 9,
	secondary: [
		1024 | 9 // Escape
	],
	when: ContextKeyExpr.and(ck_inPeekEditor, ContextKeyExpr.not('config.editor.stablePeek'))
});
keybindingsRegistry.registerKeybindingRule({
	id: 'closeReferenceSearch',
	weight: 200 + 50,
	primary: 9,
	secondary: [
		1024 | 9 // Escape
	],
	when: ContextKeyExpr.and(
		ctxReferenceSearchVisible,
		ContextKeyExpr.not('config.editor.stablePeek'),
		ContextKeyExpr.or(ck_editorFocus_text, InputFocusedContext.negate())
	)
});
keybindingsRegistry.registerCommandAndKeybindingRule({
	id: 'revealReference',
	weight: 200,
	primary: 3,
	mac: {
		primary: 3,
		secondary: [
			2048 | 18 // DownArrow
		]
	},
	when: ContextKeyExpr.and(
		ctxReferenceSearchVisible,
		WorkbenchListFocusContextKey,
		WorkbenchTreeElementCanCollapse.negate(),
		WorkbenchTreeElementCanExpand.negate()
	),
	handler(accessor) {
		const listService = accessor.get(IListService);
		const focus = listService.lastFocusedList?.getFocus();
		if (isArray(focus) && focus[0] instanceof OneReference) {
			withController(accessor, controller => controller.revealReference(focus[0]));
		}
	}
});
keybindingsRegistry.registerCommandAndKeybindingRule({
	id: 'openReferenceToSide',
	weight: 100,
	primary: 2048 | 3,
	mac: {
		primary: 256 | 3 // Enter
	},
	when: ContextKeyExpr.and(
		ctxReferenceSearchVisible,
		WorkbenchListFocusContextKey,
		WorkbenchTreeElementCanCollapse.negate(),
		WorkbenchTreeElementCanExpand.negate()
	),
	handler(accessor) {
		const listService = accessor.get(IListService);
		const focus = listService.lastFocusedList?.getFocus();
		if (isArray(focus) && focus[0] instanceof OneReference) {
			withController(accessor, controller => controller.openReference(focus[0], true, true));
		}
	}
});
commandsRegistry.registerCommand('openReference', accessor => {
	const listService = accessor.get(IListService);
	const focus = listService.lastFocusedList?.getFocus();
	if (isArray(focus) && focus[0] instanceof OneReference) {
		withController(accessor, controller => controller.openReference(focus[0], false, true));
	}
}); // node_modules/monaco-editor/esm/vs/editor/contrib/gotoSymbol/browser/symbolNavigation.js
var ctxHasSymbols = new RawContextKey(
	'hasSymbols',
	false,
	localize('Whether there are symbol locations that can be navigated via keyboard-only.')
);

class EditorState2 {
	constructor(editorService) {
		this._listener = new Map();
		this._disposables = new DisposableStore();
		this._onDidChange = new Emitter();
		this.onDidChange = this._onDidChange.event;
		this._disposables.add(editorService.onCodeEditorRemove(this._onDidRemoveEditor, this));
		this._disposables.add(editorService.onCodeEditorAdd(this._onDidAddEditor, this));
		editorService.listCodeEditors().forEach(this._onDidAddEditor, this);
	}
	dispose() {
		this._disposables.dispose();
		this._onDidChange.dispose();
		dispose(this._listener.values());
	}
	_onDidAddEditor(editor2) {
		this._listener.set(
			editor2,
			combinedDisposable(
				editor2.onDidChangeCursorPosition(_ => this._onDidChange.fire({ editor: editor2 })),
				editor2.onDidChangeModelContent(_ => this._onDidChange.fire({ editor: editor2 }))
			)
		);
	}
	_onDidRemoveEditor(editor2) {
		this._listener.get(editor2)?.dispose();
		this._listener.delete(editor2);
	}
}
__decorate([__param(0, ICodeEditorService)], EditorState2);

var ISymbolNavigationService = createEditorServiceDecorator('ISymbolNavigationService');
class SymbolNavigationService {
	constructor(contextKeyService, _editorService, _notificationService, _keybindingService) {
		this._editorService = _editorService;
		this._notificationService = _notificationService;
		this._keybindingService = _keybindingService;
		this._currentModel = undefined;
		this._currentIdx = -1;
		this._ignoreEditorChange = false;
		this._ctxHasSymbols = ctxHasSymbols.bindTo(contextKeyService);
	}
	reset() {
		this._ctxHasSymbols.reset();
		this._currentState?.dispose();
		this._currentMessage?.dispose();
		this._currentModel = undefined;
		this._currentIdx = -1;
	}
	put(anchor) {
		const refModel = anchor.parent.parent;
		if (refModel.references.length <= 1) {
			this.reset();
			return;
		}
		this._currentModel = refModel;
		this._currentIdx = refModel.references.indexOf(anchor);
		this._ctxHasSymbols.set(true);
		this._showMessage();
		const editorState = new EditorState2(this._editorService);
		const listener = editorState.onDidChange(_ => {
			if (this._ignoreEditorChange) {
				return;
			}
			const editor2 = this._editorService.getActiveCodeEditor();
			if (!editor2) {
				return;
			}
			const model = editor2.getModel();
			const position = editor2.getPosition();
			if (!model || !position) {
				return;
			}
			let seenUri = false;
			let seenPosition = false;
			for (const reference of refModel.references) {
				if (isEqual(reference.uri, model.uri)) {
					seenUri = true;
					seenPosition = seenPosition || Range.containsPosition(reference.range, position);
				} else if (seenUri) {
					break;
				}
			}
			if (!seenUri || !seenPosition) {
				this.reset();
			}
		});
		this._currentState = combinedDisposable(editorState, listener);
	}
	revealNext(source) {
		if (!this._currentModel) {
			return Promise.resolve();
		}
		this._currentIdx += 1;
		this._currentIdx %= this._currentModel.references.length;
		const reference = this._currentModel.references[this._currentIdx];
		this._showMessage();
		this._ignoreEditorChange = true;
		return this._editorService
			.openCodeEditor(
				{
					resource: reference.uri,
					options: {
						selection: Range.collapseToStart(reference.range),
						selectionRevealType: 3 // NearTopIfOutsideViewport
					}
				},
				source
			)
			.finally(() => {
				this._ignoreEditorChange = false;
			});
	}
	_showMessage() {
		this._currentMessage?.dispose();
		const kb = this._keybindingService.lookupKeybinding('editor.gotoNextSymbolFromResult');
		const message = kb
			? localize('Symbol {0} of {1}, {2} for next', this._currentIdx + 1, this._currentModel.references.length, kb.getLabel())
			: localize(this._currentIdx + 1, this._currentModel.references.length);
		this._currentMessage = this._notificationService.status(message);
	}
}
__decorate(
	[__param(0, IContextKeyService), __param(1, ICodeEditorService), __param(2, INotificationService), __param(3, IKeybindingService)],
	SymbolNavigationService
);
registerSingleton(
	ISymbolNavigationService,
	SymbolNavigationService,
	1 // Delayed
);

class GotoNextSymbolFromResultCmd extends EditorCommand {
	constructor() {
		super({
			id: 'editor.gotoNextSymbolFromResult',
			precondition: ctxHasSymbols,
			kbOpts: {
				weight: 100,
				primary: 70 // F12
			}
		});
	}
	runEditorCommand(accessor, editor2) {
		return accessor.get(ISymbolNavigationService).revealNext(editor2);
	}
}
registerEditorCommand(new GotoNextSymbolFromResultCmd());
keybindingsRegistry.registerCommandAndKeybindingRule({
	id: 'editor.gotoNextSymbolFromResult.cancel',
	weight: 100,
	when: ctxHasSymbols,
	primary: 9,
	handler(accessor) {
		accessor.get(ISymbolNavigationService).reset();
	}
});
