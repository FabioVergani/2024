class WordHighlightNavigationAction extends EditorAction {
	constructor(next, opts) {
		super(opts);
		this._isNext = next;
	}
	run(accessor, editor2) {
		const controller = WordHighlighterContribution.get(editor2);
		if (!controller) {
			return;
		}
		if (this._isNext) {
			controller.moveNext();
		} else {
			controller.moveBack();
		}
	}
}

class NextWordHighlightAction extends WordHighlightNavigationAction {
	constructor() {
		super(true, {
			id: 'editor.action.wordHighlight.next',
			label: localize('Go to Next Symbol Highlight'),
			alias: 'Go to Next Symbol Highlight',
			precondition: ck_hasWordHighlights,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 65,
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorAction(NextWordHighlightAction);

class PrevWordHighlightAction extends WordHighlightNavigationAction {
	constructor() {
		super(false, {
			id: 'editor.action.wordHighlight.prev',
			label: localize('Go to Previous Symbol Highlight'),
			alias: 'Go to Previous Symbol Highlight',
			precondition: ck_hasWordHighlights,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 1024 | 65,
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorAction(PrevWordHighlightAction);

class TriggerWordHighlightAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.wordHighlight.trigger',
			label: localize('Trigger Symbol Highlight'),
			alias: 'Trigger Symbol Highlight',
			precondition: ck_hasWordHighlights.toNegated(),
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 0,
				weight: 100 //editorContrib
			}
		});
	}
	run(accessor, editor2) {
		const controller = WordHighlighterContribution.get(editor2);
		if (!controller) {
			return;
		}
		controller.restoreViewState(true);
	}
}
registerEditorAction(TriggerWordHighlightAction);