
class DocumentFormattingEditProvider {
	constructor(_worker) {
		this._worker = _worker;
	}
	provideDocumentFormattingEdits(model, options2, token) {
		const resource = model.uri;
		return this._worker(resource).then(worker2 => {
			return worker2
				.format(
					resource.toString(),
					null,

					{ tabSize: options2.tabSize, insertSpaces: options2.insertSpaces }
				)
				.then(edits => {
					if (!edits || edits.length === 0) {
						return;
					}
					return edits.map(toTextEdit0);
				});
		});
	}
}

class DocumentRangeFormattingEditProvider {
	constructor(_worker) {
		this._worker = _worker;
		this.canFormatMultipleRanges = false;
	}
	provideDocumentRangeFormattingEdits(model, range2, options2, token) {
		const resource = model.uri;
		return this._worker(resource).then(worker2 => {
			return worker2
				.format(resource.toString(), fromRange0(range2), { tabSize: options2.tabSize, insertSpaces: options2.insertSpaces })
				.then(edits => {
					if (!edits || edits.length === 0) {
						return;
					}
					return edits.map(toTextEdit0);
				});
		});
	}
}




const isCodeEditor = e => 1 === e?.getEditorType?.();



class DocumentFormattingEditProvider {
	constructor(_worker) {
		this._worker = _worker;
	}
	provideDocumentFormattingEdits(model, options2, token) {
		const resource = model.uri;
		return this._worker(resource).then(worker2 => {
			return worker2
				.format(resource.toString(), null, { tabSize: options2.tabSize, insertSpaces: options2.insertSpaces })
				.then(edits => {
					if (!edits || edits.length === 0) {
						return;
					}
					return edits.map(toTextEdit);
				});
		});
	}
}


const registerDocumentFormattingEditProvider = (languageSelector, provider) => {
	return getService_LanguageFeatures().documentFormattingEditProvider.register(languageSelector, provider);
};


const registerDocumentRangeFormattingEditProvider = (languageSelector, provider) => {
	return getService_LanguageFeatures().documentRangeFormattingEditProvider.register(languageSelector, provider);
};


const registerOnTypeFormattingEditProvider = (languageSelector, provider) => {
	return getService_LanguageFeatures().onTypeFormattingEditProvider.register(languageSelector, provider);
};

class FormatOnType {
	constructor(_editor, _languageFeaturesService, _workerService) {
		this._editor = _editor;
		this._languageFeaturesService = _languageFeaturesService;
		this._workerService = _workerService;

		this._disposables = new DisposableStore();
		this._sessionDisposables = new DisposableStore();
		this._disposables.add(_languageFeaturesService.onTypeFormattingEditProvider.onDidChange(this._update, this));
		this._disposables.add(_editor.onDidChangeModel(() => this._update()));
		this._disposables.add(_editor.onDidChangeModelLanguage(() => this._update()));

		this._update();
	}
	dispose() {
		this._disposables.dispose();
		this._sessionDisposables.dispose();
	}
	_update() {
		this._sessionDisposables.clear();
		if (!this._editor.hasModel()) {
			return;
		}
		const model = this._editor.getModel();
		const [support] = this._languageFeaturesService.onTypeFormattingEditProvider.ordered(model);
		if (!support || !support.autoFormatTriggerCharacters) {
			return;
		}
		const triggerChars = new CharacterSet();
		for (const ch of support.autoFormatTriggerCharacters) {
			triggerChars.add(ch.charCodeAt(0));
		}
		this._sessionDisposables.add(
			this._editor.onDidType(text2 => {
				const lastCharCode = text2.charCodeAt(text2.length - 1);
				if (triggerChars.has(lastCharCode)) {
					this._trigger(String.fromCharCode(lastCharCode));
				}
			})
		);
	}
	_trigger(ch) {
		if (!this._editor.hasModel()) {
			return;
		}
		if (this._editor.getSelections().length > 1 || !this._editor.getSelection().isEmpty()) {
			return;
		}
		const model = this._editor.getModel();
		const position = this._editor.getPosition();
		const cts = new CancellationTokenSource();
		const unbind = this._editor.onDidChangeModelContent(e => {
			if (e.isFlush) {
				cts.cancel();
				unbind.dispose();
				return;
			}
			for (let i = 0, len = e.changes.length; i < len; i++) {
				const change = e.changes[i];
				if (change.range.endLineNumber <= position.lineNumber) {
					cts.cancel();
					unbind.dispose();
					return;
				}
			}
		});
		getOnTypeFormattingEdits(
			this._workerService,
			this._languageFeaturesService,
			model,
			position,
			ch,
			model.getFormattingOptions(),
			cts.token
		)
			.then(edits => {
				if (cts.token.isCancellationRequested) {
					return;
				}
				if (isArrayAndHasLength(edits)) {

					FormattingEdit.execute(this._editor, edits, true);
				}
			})
			.finally(() => {
				unbind.dispose();
			});
	}
}
FormatOnType.ID = 'editor.contrib.autoFormat';
__decorate([
	__param(1, ILanguageFeaturesService),
	__param(2, IEditorWorkerService),
], FormatOnType);

class FormatOnPaste {
	constructor(editor2, _languageFeaturesService, _instantiationService) {
		this.editor = editor2;
		this._languageFeaturesService = _languageFeaturesService;
		this._instantiationService = _instantiationService;
		this._callOnDispose = new DisposableStore();
		this._callOnModel = new DisposableStore();
		this._callOnDispose.add(editor2.onDidChangeConfiguration(() => this._update()));
		this._callOnDispose.add(editor2.onDidChangeModel(() => this._update()));
		this._callOnDispose.add(editor2.onDidChangeModelLanguage(() => this._update()));
		this._callOnDispose.add(_languageFeaturesService.documentRangeFormattingEditProvider.onDidChange(this._update, this));
	}
	dispose() {
		this._callOnDispose.dispose();
		this._callOnModel.dispose();
	}
	_update() {
		this._callOnModel.clear();
		if (
			!this.editor.getOption(
				55
				// formatOnPaste
			)
		) {
			return;
		}
		if (!this.editor.hasModel()) {
			return;
		}
		if (!this._languageFeaturesService.documentRangeFormattingEditProvider.has(this.editor.getModel())) {
			return;
		}
		this._callOnModel.add(this.editor.onDidPaste(({ range: range2 }) => this._trigger(range2)));
	}
	_trigger(range2) {
		if (!this.editor.hasModel()) {
			return;
		}
		if (this.editor.getSelections().length > 1) {
			return;
		}
		this._instantiationService
			.invokeFunction(formatDocumentRangesWithSelectedProvider, this.editor, range2, 2, Progress.None, cancellationToken_none, false)
			.catch(onUnexpectedError);
	}
}
FormatOnPaste.ID = 'editor.contrib.formatOnPaste';
__decorate([__param(1, ILanguageFeaturesService), __param(2, IInstantiationService)], FormatOnPaste);

class FormatDocumentAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.formatDocument',
			label: localize('Format Document'),
			alias: 'Format Document',
			precondition: ContextKeyExpr.and(ctxKeys_notInCompositeEditor, ctxKeys_writable, ctxKeys_editorHasProvider_documentFormatting),
			kbOpts: {
				kbExpr: ctxKeys_editorFocus_text,
				primary: 1024 | 512 | 36,
				linux: {
					primary: 2048 | 1024 | 39
					/* KeyCode.KeyI */
				},
				weight: 100
				/* KeybindingWeight.EditorContrib */
			},
			contextMenuOpts: {
				group: '1_modification',
				order: 1.3
			}
		});
	}
	async run(accessor, editor2) {
		if (editor2.hasModel()) {
			const instaService = accessor.get(IInstantiationService);
			const progressService = accessor.get(IEditorProgressService);
			await progressService.showWhile(
				instaService.invokeFunction(formatDocumentWithSelectedProvider, editor2, 1, Progress.None, cancellationToken_none, true),
				250
			);
		}
	}
}

class FormatSelectionAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.formatSelection',
			label: localize('Format EditorSelection'),
			alias: 'Format EditorSelection',
			precondition: ContextKeyExpr.and(ctxKeys_writable, ctxKeys_editorHasProvider_selectionFormatting),
			kbOpts: {
				kbExpr: ctxKeys_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 36
					/* KeyCode.KeyF */
				),
				weight: 100
				/* KeybindingWeight.EditorContrib */
			},
			contextMenuOpts: {
				when: ctxKeys_editorHasSelection,
				group: '1_modification',
				order: 1.31
			}
		});
	}
	async run(accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const instaService = accessor.get(IInstantiationService);
		const model = editor2.getModel();
		const ranges = editor2.getSelections().map(range2 => {
			return range2.isEmpty()
				? new Range(range2.startLineNumber, 1, range2.startLineNumber, model.getLineMaxColumn(range2.startLineNumber))
				: range2;
		});
		const progressService = accessor.get(IEditorProgressService);
		await progressService.showWhile(
			instaService.invokeFunction(
				formatDocumentRangesWithSelectedProvider,
				editor2,
				ranges,
				1,
				Progress.None,
				cancellationToken_none,
				true
			),
			250
		);
	}
}
registerEditorContribution(
	FormatOnType.ID,
	FormatOnType,
	2
	/* EditorContributionInstantiation.BeforeFirstInteraction */
);
registerEditorContribution(
	FormatOnPaste.ID,
	FormatOnPaste,
	2
	/* EditorContributionInstantiation.BeforeFirstInteraction */
);
registerEditorAction(FormatDocumentAction);
registerEditorAction(FormatSelectionAction);
commandsRegistry.registerCommand('editor.action.format', async accessor => {
	const editor2 = accessor.get(ICodeEditorService).getFocusedCodeEditor();
	if (!editor2 || !editor2.hasModel()) {
		return;
	}
	const commandService = accessor.get(ICommandService);
	if (editor2.getSelection().isEmpty()) {
		await commandService.executeCommand('editor.action.formatDocument');
	} else {
		await commandService.executeCommand('editor.action.formatSelection');
	}
});