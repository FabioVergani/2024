const SelectionAnchorSet = new RawContextKey('selectionAnchorSet', false);
class SelectionAnchorController {
	static get(editor2) {
		return editor2.getContribution(SelectionAnchorController.ID);
	}
	constructor(editor2, contextKeyService) {
		this.editor = editor2;
		this.selectionAnchorSetContextKey = SelectionAnchorSet.bindTo(contextKeyService);
		this.modelChangeListener = editor2.onDidChangeModel(() => this.selectionAnchorSetContextKey.reset());
	}
	setSelectionAnchor() {
		if (this.editor.hasModel()) {
			const position = this.editor.getPosition();
			this.editor.changeDecorations(accessor => {
				if (this.decorationId) {
					accessor.removeDecoration(this.decorationId);
				}
				this.decorationId = accessor.addDecoration(EditorSelection.fromPositions(position, position), {
					description: 'selection-anchor',
					stickiness: 1,
					hoverMessage: new MarkdownString().appendText(localize('EditorSelection Anchor')),
					className: 'selection-anchor'
				});
			});
			this.selectionAnchorSetContextKey.set(!!this.decorationId);
			alert(localize(position.lineNumber, position.column));
		}
	}
	goToSelectionAnchor() {
		if (this.editor.hasModel() && this.decorationId) {
			const anchorPosition = this.editor.getModel().getDecorationRange(this.decorationId);
			if (anchorPosition) {
				this.editor.setPosition(anchorPosition.getStartPosition());
			}
		}
	}
	selectFromAnchorToCursor() {
		if (this.editor.hasModel() && this.decorationId) {
			const start = this.editor.getModel().getDecorationRange(this.decorationId);
			if (start) {
				const end = this.editor.getPosition();
				this.editor.setSelection(EditorSelection.fromPositions(start.getStartPosition(), end));
				this.cancelSelectionAnchor();
			}
		}
	}
	cancelSelectionAnchor() {
		if (this.decorationId) {
			const decorationId = this.decorationId;
			this.editor.changeDecorations(accessor => {
				accessor.removeDecoration(decorationId);
				this.decorationId = undefined;
			});
			this.selectionAnchorSetContextKey.set(false);
		}
	}
	dispose() {
		this.cancelSelectionAnchor();
		this.modelChangeListener.dispose();
	}
}
SelectionAnchorController.ID = 'editor.contrib.selectionAnchorController';
__decorate([__param(1, IContextKeyService)], SelectionAnchorController);
class SetSelectionAnchor extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.setSelectionAnchor',
			label: localize('Set EditorSelection Anchor'),
			alias: 'Set EditorSelection Anchor',
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 32 // KeyB
				),
				weight: 100 //editorContrib
			}
		});
	}
	async run(_accessor, editor2) {
		SelectionAnchorController.get(editor2)?.setSelectionAnchor();
	}
}
registerEditorAction(SetSelectionAnchor);
class GoToSelectionAnchor extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.goToSelectionAnchor',
			label: localize('Go to EditorSelection Anchor'),
			alias: 'Go to EditorSelection Anchor',
			precondition: SelectionAnchorSet
		});
	}
	async run(_accessor, editor2) {
		SelectionAnchorController.get(editor2)?.goToSelectionAnchor();
	}
}
registerEditorAction(GoToSelectionAnchor);
class SelectFromAnchorToCursor extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.selectFromAnchorToCursor',
			label: localize('Select from Anchor to Cursor'),
			alias: 'Select from Anchor to Cursor',
			precondition: SelectionAnchorSet,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 41 //KeyK
				),
				weight: 100 // KeybindingWeight
			}
		});
	}
	async run(_accessor, editor2) {
		SelectionAnchorController.get(editor2)?.selectFromAnchorToCursor();
	}
}
registerEditorAction(SelectFromAnchorToCursor);
class CancelSelectionAnchor extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.cancelSelectionAnchor',
			label: localize('Cancel EditorSelection Anchor'),
			alias: 'Cancel EditorSelection Anchor',
			precondition: SelectionAnchorSet,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 9,
				weight: 100 //editorContrib
			}
		});
	}
	async run(_accessor, editor2) {
		SelectionAnchorController.get(editor2)?.cancelSelectionAnchor();
	}
}
registerEditorContribution(
	SelectionAnchorController.ID,
	SelectionAnchorController,
	4 // EditorContributionInstantiation.Lazy
);
registerEditorAction(CancelSelectionAnchor);