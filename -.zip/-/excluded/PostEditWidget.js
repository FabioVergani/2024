

const ck_pasteWidgetVisible = new RawContextKey('pasteWidgetVisible');


function createCombinedWorkspaceEdit(uri, ranges, edit) {
	if (typeof edit.insertText === 'string' ? edit.insertText === '' : edit.insertText.snippet === '') {
		return {
			edits: edit.additionalEdit?.edits || []
		};
	}
	return {
		edits: [
			...ranges.map(
				range2 =>
					new ResourceTextEdit(uri, {
						range: range2,
						text: typeof edit.insertText === 'string' ? SnippetParser.escape(edit.insertText) + '$0' : edit.insertText.snippet,
						insertAsSnippet: true
					})
			),
			...(edit.additionalEdit?.edits || [])
		]
	};
}



class EditorButton extends Disposable {
	get onDidClick() {
		return this._onDidClick.event;
	}
	constructor(container, options2) {
		super();
		this._label = '';
		this._onDidClick = this._register(new Emitter());
		this._onDidEscape = this._register(new Emitter());
		this.options = options2;
		this._element = document.createElement('a');
		this._element.classList.add('monaco-button');
		this._element.tabIndex = 0;
		this._element.setAttribute('role', 'button');
		this._element.classList.toggle('secondary', !!options2.secondary);
		const background = options2.secondary ? options2.buttonSecondaryBackground : options2.buttonBackground;
		const foreground2 = options2.secondary ? options2.buttonSecondaryForeground : options2.buttonForeground;
		this._element.style.color = foreground2 || '';
		this._element.style.backgroundColor = background || '';
		if (options2.supportShortLabel) {
			this._labelShortElement = document.createElement('div');
			this._labelShortElement.classList.add('monaco-button-label-short');
			this._element.appendChild(this._labelShortElement);
			this._labelElement = document.createElement('div');
			this._labelElement.classList.add('monaco-button-label');
			this._element.appendChild(this._labelElement);
			this._element.classList.add('monaco-text-button-with-short-label');
		}
		if (typeof options2.title === 'string') {
			this.setTitle(options2.title);
		}
		container.appendChild(this._element);
		this._register(Gesture.addTarget(this._element));
		[EventType.CLICK, GestureType.Tap].forEach(eventType => {
			this._register(
				addDisposableListener(this._element, eventType, e => {
					if (!this.enabled) {
						EventHelper.stop(e);
						return;
					}
					this._onDidClick.fire(e);
				})
			);
		});
		this._register(
			addDisposableListener(this._element, EventType.KEY_DOWN, e => {
				const event = new StandardKeyboardEvent(e);
				let eventHandled = false;
				if (
					this.enabled &&
					(event.equals(
						3 //Enter
					) ||
						event.equals(
							10 //Space
						))
				) {
					this._onDidClick.fire(e);
					eventHandled = true;
				} else if (
					event.equals(
						9 //Escape
					)
				) {
					this._onDidEscape.fire(e);
					this._element.blur();
					eventHandled = true;
				}
				if (eventHandled) {
					EventHelper.stop(event, true);
				}
			})
		);
		this._register(
			addDisposableListener(this._element, EventType.MOUSE_OVER, e => {
				if (!this._element.classList.contains('disabled')) {
					this.updateBackground(true);
				}
			})
		);
		this._register(
			addDisposableListener(this._element, EventType.MOUSE_OUT, e => {
				this.updateBackground(false);
			})
		);
		this.focusTracker = this._register(trackFocus(this._element));
		this._register(
			this.focusTracker.onDidFocus(() => {
				if (this.enabled) {
					this.updateBackground(true);
				}
			})
		);
		this._register(
			this.focusTracker.onDidBlur(() => {
				if (this.enabled) {
					this.updateBackground(false);
				}
			})
		);
	}
	dispose() {
		super.dispose();
		this._element.remove();
	}
	getContentElements(content) {
		const elements = [];
		for (let segment of renderLabelWithIcons(content)) {
			if (typeof segment === 'string') {
				segment = segment.trim();
				if (segment === '') {
					continue;
				}
				const node = document.createElement('span');
				node.textContent = segment;
				elements.push(node);
			} else {
				elements.push(segment);
			}
		}
		return elements;
	}
	updateBackground(hover) {
		let background;
		if (this.options.secondary) {
			background = hover ? this.options.buttonSecondaryHoverBackground : this.options.buttonSecondaryBackground;
		} else {
			background = hover ? this.options.buttonHoverBackground : this.options.buttonBackground;
		}
		if (background) {
			this._element.style.backgroundColor = background;
		}
	}
	get element() {
		return this._element;
	}
	set label(value) {
		if (this._label === value) {
			return;
		}
		this._element.classList.add('monaco-text-button');
		const labelElement = this.options.supportShortLabel ? this._labelElement : this._element;

		if (this.options.supportIcons) {
			reset(labelElement, ...this.getContentElements(value));
		} else {
			labelElement.textContent = value;
		}

		let title = '';
		if (typeof this.options.title === 'string') {
			title = this.options.title;
		} else if (this.options.title) {
			title = renderStringAsPlaintext(value);
		}
		this.setTitle(title);
		this._label = value;
	}
	get label() {
		return this._label;
	}
	set icon(icon) {
		this._element.classList.add(...asThemeIconClassNameArray(icon));
	}
	set enabled(value) {
		if (value) {
			this._element.classList.remove('disabled');
			this._element.tabIndex = 0;
		} else {
			this._element.classList.add('disabled');
		}
	}
	get enabled() {
		return !this._element.classList.contains('disabled');
	}
	setTitle(title) {
		if (!this._hover && title !== '') {
			this._hover = this._register(baseHoverDelegate.setupUpdatableHover(this.options.hoverDelegate ?? defaultHoverDelegateMouse.value, this._element, title));
		} else if (this._hover) {
			this._hover.update(title);
		}
	}
}


class PostEditWidget extends Disposable {
	constructor(typeId, editor2, visibleContext, showCommand, range2, edits, onSelectNewEdit, _contextMenuService, contextKeyService, _keybindingService) {
		super();
		this.typeId = typeId;
		this.editor = editor2;
		this.showCommand = showCommand;
		this.range = range2;
		this.edits = edits;
		this.onSelectNewEdit = onSelectNewEdit;
		this._contextMenuService = _contextMenuService;
		this._keybindingService = _keybindingService;
		this.allowEditorOverflow = true;
		this.suppressMouseDown = true;
		this.create();
		this.visibleContext = visibleContext.bindTo(contextKeyService);
		this.visibleContext.set(true);
		this._register(toDisposable(() => this.visibleContext.reset()));
		this.editor.addContentWidget(this);
		this.editor.layoutContentWidget(this);
		this._register(toDisposable(() => this.editor.removeContentWidget(this)));
		this._register(
			this.editor.onDidChangeCursorPosition(e => {
				if (!range2.containsPosition(e.position)) {
					this.dispose();
				}
			})
		);
		this._register(
			editorEventRunAndSubscribe(_keybindingService.onDidUpdateKeybindings, () => {
				this._updateButtonTitle();
			})
		);
	}
	_updateButtonTitle() {
		const binding = this._keybindingService.lookupKeybinding(this.showCommand.id)?.getLabel();
		this.button.element.title = this.showCommand.label + (binding ? ` (${binding})` : '');
	}
	create() {
		this.domNode = createDomElement('.post-edit-widget');
		this.button = this._register(
			new EditorButton(this.domNode, {
				supportIcons: true
			})
		);
		this.button.label = '$(insert)';
		this._register(addDisposableListener(this.domNode, EventType.CLICK, () => this.showSelector()));
	}
	getId() {
		return 'editor.widget.postEditWidget.' + this.typeId;
	}
	getDomNode() {
		return this.domNode;
	}
	getPosition() {
		return {
			position: this.range.getEndPosition(),
			preference: [
				2 // BELOW
			]
		};
	}
	showSelector() {
		this._contextMenuService.showContextMenu({
			getAnchor: () => {
				const pos = getDomNodePagePosition(this.button.element);
				return { x: pos.left + pos.width, y: pos.top + pos.height };
			},
			getActions: () => {
				return this.edits.allEdits.map((edit, i) =>
					toActionObj({
						id: '',
						label: edit.title,
						checked: i === this.edits.activeEditIndex,
						run: () => {
							if (i !== this.edits.activeEditIndex) {
								return this.onSelectNewEdit(i);
							}
						}
					})
				);
			}
		});
	}
}
__decorate(
	[
		__param(7, IContextMenuService),
		__param(8, IContextKeyService),
		__param(9, IKeybindingService)
		//...
	],
	PostEditWidget
);
