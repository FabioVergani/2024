

class EditorDropIntoEditor extends BaseEditorOption {
	constructor() {
		const defaults = { enabled: true, showDropSelector: 'afterDrop' };
		super(36, 'dropIntoEditor', defaults, {
			'editor.dropIntoEditor.enabled': {
				type: 'boolean',
				default: defaults.enabled
			},
			'editor.dropIntoEditor.showDropSelector': {
				type: 'string',
				enum: [
					'afterDrop', //Show the drop selector widget after a file is dropped into the editor.
					'never' //Never show the drop selector widget. Instead the default drop provider is always used.
				],
				default: 'afterDrop'
			}
		});
	}
	validate(_input) {
		if (!_input || typeof _input !== 'object') {
			return this.defaultValue;
		}
		const input = _input;
		return {
			enabled: boolean(input.enabled, this.defaultValue.enabled),
			showDropSelector: stringSet(input.showDropSelector, this.defaultValue.showDropSelector, ['afterDrop', 'never'])
		};
	}
}

dropIntoEditor: registerEditorOption(new EditorDropIntoEditor()),