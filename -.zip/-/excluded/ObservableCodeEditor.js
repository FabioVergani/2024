function obsCodeEditor(editor2) {
	return ObservableCodeEditor.get(editor2);
}

class ObservableCodeEditor {
	static get(editor2) {
		let result = ObservableCodeEditor._map.get(editor2);
		if (!result) {
			result = new ObservableCodeEditor(editor2);
			ObservableCodeEditor._map.set(editor2, result);
			const d = editor2.onDidDispose(() => {
				ObservableCodeEditor._map.delete(editor2);
				d.dispose();
			});
		}
		return result;
	}
	constructor(editor2) {
		this.editor = editor2;
		this.model = observableFromEvent(this.editor.onDidChangeModel, () => this.editor.getModel());
	}
}
ObservableCodeEditor._map = new Map();