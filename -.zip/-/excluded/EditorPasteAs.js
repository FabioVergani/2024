class EditorPasteAs extends BaseEditorOption {
	constructor() {
		const defaults = { enabled: true, showPasteSelector: 'afterPaste' };
		super(85, 'pasteAs', defaults, {
			'editor.pasteAs.enabled': {
				type: 'boolean',
				default: defaults.enabled
			},
			'editor.pasteAs.showPasteSelector': {
				type: 'string',
				enum: [
					'afterPaste', //Show the paste selector widget after content is pasted into the editor.
					'never' //Never show the paste selector widget. Instead the default pasting behavior is always used.
				],
				default: 'afterPaste'
			}
		});
	}
	validate(_input) {
		if (!_input || typeof _input !== 'object') {
			return this.defaultValue;
		}
		const input = _input;
		return {
			enabled: boolean(input.enabled, this.defaultValue.enabled),
			showPasteSelector: stringSet(input.showPasteSelector, this.defaultValue.showPasteSelector, ['afterPaste', 'never'])
		};
	}
}

pasteAs: registerEditorOption(new EditorPasteAs()),


	pasteAs(preferred) {
		this._editor.focus();
		try {
			this._pasteAsActionContext = { preferred };
			getActiveDocument().execCommand('paste');
		} finally {
			this._pasteAsActionContext = undefined;
		}
	}

	isPasteAsEnabled() {
		return (
			this._editor.getOption(
				85 // pasteAs
			).enabled &&
			!this._editor.getOption(
				91 // readOnly
			)
		);
	}
	showPasteAsNoEditMessage(selections, preference) {}
	showPasteAsPick(preference, allProviders, selections, dataTransfer, metadata) {
		const p = createCancelablePromise(async token => {
			const editor2 = this._editor;
			if (!editor2.hasModel()) {
				return;
			}
			const model = editor2.getModel();
			const tokenSource = new EditorStateCancellationTokenSource(editor2, 1 | 2, undefined, token);
			try {
				await this.mergeInDataFromCopy(dataTransfer, metadata, tokenSource.token);
				if (tokenSource.token.isCancellationRequested) {
					return;
				}
				let supportedProviders = allProviders.filter(provider => this.isSupportedPasteProvider(provider, dataTransfer, preference));
				if (preference) {
					supportedProviders = supportedProviders.filter(provider => this.providerMatchesPreference(provider, preference));
				}
				const context = {
					triggerKind: 1, //PasteAs
					only: preference && preference instanceof HierarchicalKind ? preference : undefined
				};
				let providerEdits = await this.getPasteEdits(
					supportedProviders,
					dataTransfer,
					model,
					selections,
					context,
					tokenSource.token
				);
				if (tokenSource.token.isCancellationRequested) {
					return;
				}
				if (preference) {
					providerEdits = providerEdits.filter(edit => {
						if (preference instanceof HierarchicalKind) {
							return preference.contains(edit.kind);
						} else {
							return preference.providerId === edit.provider.id;
						}
					});
				}
				if (!providerEdits.length) {
					if (context.only) {
						this.showPasteAsNoEditMessage(selections, context.only);
					}
					return;
				}
				let pickedEdit;
				if (preference) {
					pickedEdit = providerEdits.at(0);
				} else {
					const selected = await this._quickInputService.pick(
						providerEdits.map(edit => {
							return {
								label: edit.title,
								description: edit.kind?.value,
								edit
							};
						}),
						{ placeHolder: localize('Select Paste Action') }
					);
					pickedEdit = selected?.edit;
				}
				if (!pickedEdit) {
					return;
				}
				const combinedWorkspaceEdit = createCombinedWorkspaceEdit(model.uri, selections, pickedEdit);
				await this._bulkEditService.apply(combinedWorkspaceEdit, {
					editor: this._editor
				});
			} finally {
				tokenSource.dispose();
				if (this._currentPasteOperation === p) {
					this._currentPasteOperation = undefined;
				}
			}
		});
		this._progressService.withProgress(
			{
				location: 10,
				title: localize('Running paste handlers')
			},
			() => p
		);
	}





		if (this._pasteAsActionContext) {
			this.showPasteAsPick(this._pasteAsActionContext.preferred, allProviders, selections, dataTransfer, metadata);
		}

				if (this._pasteAsActionContext?.preferred) {
				this.showPasteAsNoEditMessage(selections, this._pasteAsActionContext.preferred);
			}


							if (e.clipboardData && this.isPasteAsEnabled()) {
				const model = this._editor.getModel();
				const selections = this._editor.getSelections();
				if (!model || !selections?.length) {
					return;
				}
				const enableEmptySelectionClipboard = this._editor.getOption(
					37 // emptySelectionClipboard
				);
				let ranges = selections;
				const wasFromEmptySelection = selections.length === 1 && selections[0].isEmpty();
				if (wasFromEmptySelection) {
					if (!enableEmptySelectionClipboard) {
						return;
					}
					ranges = [
						new Range(
							ranges[0].startLineNumber,
							1,
							ranges[0].startLineNumber,
							1 + model.getLineLength(ranges[0].startLineNumber)
						)
					];
				}
				const toCopy = this._editor._getViewModel()?.getPlainTextToCopy(selections, enableEmptySelectionClipboard, isWindows);
				const multicursorText = isArray(toCopy) ? toCopy : null;
				const defaultPastePayload = {
					multicursorText,
					pasteOnNewLine: wasFromEmptySelection,
					mode: null
				};
				const providers = this._languageFeaturesService.documentPasteEditProvider
					.ordered(model)
					.filter(x => !!x.prepareDocumentPaste);
				if (!providers.length) {
					this.setCopyMetadata(e.clipboardData, {
						defaultPastePayload
					});
					return;
				}
				const dataTransfer = toVSDataTransfer(e.clipboardData);
				const providerCopyMimeTypes = providers.flatMap(x => {
					return x.copyMimeTypes ?? [];
				});
				const handle = generateUuid();
				this.setCopyMetadata(e.clipboardData, {
					id: handle,
					providerCopyMimeTypes,
					defaultPastePayload
				});
				const promise = createCancelablePromise(async token => {
					const results = await Promise.all(
						providers.map(async provider => {
							try {
								return await provider.prepareDocumentPaste(model, ranges, dataTransfer, token);
							} catch (err) {
								console.error(err);
								return;
							}
						})
					);
					results.filter(e => !!e).reverse();
					for (const result of results) {
						for (const [mime, value] of result) {
							dataTransfer.replace(mime, value);
						}
					}
					return dataTransfer;
				});
				CopyPasteController._currentCopyOperation?.dataTransferPromise.cancel();
				CopyPasteController._currentCopyOperation = {
					handle,
					dataTransferPromise: promise
				};
			}

										const preference = this._pasteAsActionContext?.preferred;
			if (preference) {
				if (provider.providedPasteEditKinds && !this.providerMatchesPreference(provider, preference)) {
					return false;
				}
			}