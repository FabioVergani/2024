class EditorAccessibilitySupport extends BaseEditorOption {
	constructor() {
		super(2, 'accessibilitySupport', 0, {
			type: 'string',
			enum: ['auto', 'on', 'off'],
			enumDescriptions: [
				localize('Use platform APIs to detect when a Screen Reader is attached.'),
				localize('Optimize for usage with a Screen Reader.'),
				localize('Assume a screen reader is not attached.')
			],
			default: 'auto',
			tags: ['accessibility'],
			description: localize('Controls if the UI should run in a mode where it is optimized for screen readers.')
		});
	}
	validate(input) {
		switch (input) {
			case 'auto':
				return 0;
			case 'off':
				return 1;
			case 'on':
				return 2;
		}
		return this.defaultValue;
	}
	compute(env2, options2, value) {
		if (value === 0) {
			return env2.accessibilitySupport;
		}
		return value;
	}
}







class ListViewAccessibilityProvider {
	constructor(accessibilityProvider) {
		if (accessibilityProvider?.getSetSize) {
			this.getSetSize = accessibilityProvider.getSetSize.bind(accessibilityProvider);
		} else {
			this.getSetSize = (e, i, l) => l;
		}
		if (accessibilityProvider?.getPosInSet) {
			this.getPosInSet = accessibilityProvider.getPosInSet.bind(accessibilityProvider);
		} else {
			this.getPosInSet = (e, i) => i + 1;
		}
		if (accessibilityProvider?.getRole) {
			this.getRole = accessibilityProvider.getRole.bind(accessibilityProvider);
		} else {
			this.getRole = _ => 'listitem';
		}
		if (accessibilityProvider?.isChecked) {
			this.isChecked = accessibilityProvider.isChecked.bind(accessibilityProvider);
		} else {
			this.isChecked = _ => undefined;
		}
	}
}




class QuickInputAccessibilityProvider {
	getWidgetAriaLabel() {
		return localize('Quick Input');
	}
	getAriaLabel(element) {
		return element.separator?.label ? `${element.saneAriaLabel}, ${element.separator.label}` : element.saneAriaLabel;
	}
	getWidgetRole() {
		return 'listbox';
	}
	getRole(element) {
		return element.hasCheckbox ? 'checkbox' : 'option';
	}
	isChecked(element) {
		if (!element.hasCheckbox || !(element instanceof QuickPickItemElement)) {
			return;
		}
		return {
			get value() {
				return element.checked;
			},
			onDidChange: e => element.onChecked(() => e())
		};
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class AccessibilityService extends Disposable {
	constructor(_contextKeyService, _layoutService, _configurationService) {
		super();
		this._contextKeyService = _contextKeyService;
		this._layoutService = _layoutService;
		this._configurationService = _configurationService;
		this._accessibilitySupport = 0;
		this._onDidChangeScreenReaderOptimized = new Emitter();
		this._onDidChangeReducedMotion = new Emitter();
		this._accessibilityModeEnabledContext = CONTEXT_ACCESSIBILITY_MODE_ENABLED.bindTo(this._contextKeyService);
		const updateContextKey = () => this._accessibilityModeEnabledContext.set(this.isScreenReaderOptimized());
		this._register(
			this._configurationService.onDidChangeConfiguration(e => {
				if (e.affectsConfiguration('editor.accessibilitySupport')) {
					updateContextKey();
					this._onDidChangeScreenReaderOptimized.fire();
				}
				if (e.affectsConfiguration('workbench.reduceMotion')) {
					this._configMotionReduced = this._configurationService.getValue('workbench.reduceMotion');
					this._onDidChangeReducedMotion.fire();
				}
			})
		);
		updateContextKey();
		this._register(this.onDidChangeScreenReaderOptimized(() => updateContextKey()));
		const reduceMotionMatcher = mainWindow.matchMedia(`(prefers-reduced-motion: reduce)`);
		this._systemMotionReduced = reduceMotionMatcher.matches;
		this._configMotionReduced = this._configurationService.getValue('workbench.reduceMotion');
		this.initReducedMotionListeners(reduceMotionMatcher);
	}
	initReducedMotionListeners(reduceMotionMatcher) {
		this._register(
			addDisposableListener(reduceMotionMatcher, 'change', () => {
				this._systemMotionReduced = reduceMotionMatcher.matches;
				if (this._configMotionReduced === 'auto') {
					this._onDidChangeReducedMotion.fire();
				}
			})
		);
		const updateRootClasses = () => {
			const reduce = this.isMotionReduced();
			this._layoutService.mainContainer.classList.toggle('reduce-motion', reduce);
			this._layoutService.mainContainer.classList.toggle('enable-motion', !reduce);
		};
		updateRootClasses();
		this._register(this.onDidChangeReducedMotion(() => updateRootClasses()));
	}
	get onDidChangeScreenReaderOptimized() {
		return this._onDidChangeScreenReaderOptimized.event;
	}
	isScreenReaderOptimized() {
		const config = this._configurationService.getValue('editor.accessibilitySupport');
		return config === 'on' || (config === 'auto' && this._accessibilitySupport === 2);
	}
	get onDidChangeReducedMotion() {
		return this._onDidChangeReducedMotion.event;
	}
	isMotionReduced() {
		const config = this._configMotionReduced;
		return config === 'on' || (config === 'auto' && this._systemMotionReduced);
	}
	getAccessibilitySupport() {
		return this._accessibilitySupport;
	}
}
__decorate([__param(0, IContextKeyService), __param(1, ILayoutService), __param(2, IConfigurationService)], AccessibilityService);
registerSingleton(
	IAccessibilityService,
	AccessibilityService,
	0
	/* InstantiationType.Eager */
);


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const IAccessibilitySignalService = createEditorServiceDecorator('accessibilitySignalService');


class StandaloneAccessbilitySignalService {
	async playSignal(cue, options2) {}
}

registerSingleton(
	IAccessibilitySignalService,
	StandaloneAccessbilitySignalService,
	0
	/* InstantiationType.Eager */
);


//accessibility
const IAccessibilityService = createEditorServiceDecorator('accessibilityService');
const CONTEXT_ACCESSIBILITY_MODE_ENABLED = new RawContextKey('accessibilityModeEnabled', false);





class AccessibilityProvider {
	getWidgetAriaLabel() {
		return localize('References');
	}
	getAriaLabel(element) {
		return element.ariaMessage;
	}
}






class CursorWordAccessibilityLeft extends WordLeftCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 3,
			id: 'cursorWordAccessibilityLeft',
			precondition: undefined
		});
	}
	_move(wordCharacterClassifier, model, position, wordNavigationType) {
		return super._move(
			getMapForWordSeparators(editorOptions.wordSeparators.defaultValue, wordCharacterClassifier.intlSegmenterLocales),
			model,
			position,
			wordNavigationType
		);
	}
}
registerEditorCommand(new CursorWordAccessibilityLeft());

class CursorWordAccessibilityLeftSelect extends WordLeftCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 3,
			id: 'cursorWordAccessibilityLeftSelect',
			precondition: undefined
		});
	}
	_move(wordCharacterClassifier, model, position, wordNavigationType) {
		return super._move(
			getMapForWordSeparators(editorOptions.wordSeparators.defaultValue, wordCharacterClassifier.intlSegmenterLocales),
			model,
			position,
			wordNavigationType
		);
	}
}
registerEditorCommand(new CursorWordAccessibilityLeftSelect());


class CursorWordAccessibilityRight extends WordRightCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 3,
			id: 'cursorWordAccessibilityRight',
			precondition: undefined
		});
	}
	_move(wordCharacterClassifier, model, position, wordNavigationType) {
		return super._move(
			getMapForWordSeparators(editorOptions.wordSeparators.defaultValue, wordCharacterClassifier.intlSegmenterLocales),
			model,
			position,
			wordNavigationType
		);
	}
}
registerEditorCommand(new CursorWordAccessibilityRight());

class CursorWordAccessibilityRightSelect extends WordRightCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 3,
			id: 'cursorWordAccessibilityRightSelect',
			precondition: undefined
		});
	}
	_move(wordCharacterClassifier, model, position, wordNavigationType) {
		return super._move(
			getMapForWordSeparators(editorOptions.wordSeparators.defaultValue, wordCharacterClassifier.intlSegmenterLocales),
			model,
			position,
			wordNavigationType
		);
	}
}
registerEditorCommand(new CursorWordAccessibilityRightSelect());



	_getAriaLabel(options2) {
		const accessibilitySupport = options2.get(
			2
			// accessibilitySupport
		);
		if (accessibilitySupport === 1) {
			const toggleKeybindingLabel = this._keybindingService
				.lookupKeybinding('editor.action.toggleScreenReaderAccessibilityMode')
				?.getAriaLabel();
			const runCommandKeybindingLabel = this._keybindingService.lookupKeybinding('workbench.action.showCommands')?.getAriaLabel();
			const keybindingEditorKeybindingLabel = this._keybindingService
				.lookupKeybinding('workbench.action.openGlobalKeybindings')
				?.getAriaLabel();
			const editorNotAccessibleMessage = localize('The editor is not accessible at this time.');
			if (toggleKeybindingLabel) {
				return localize('{0} To enable screen reader optimized mode, use {1}', editorNotAccessibleMessage, toggleKeybindingLabel);
			} else if (runCommandKeybindingLabel) {
				return localize(
					'{0} To enable screen reader optimized mode, open the quick pick with {1} and run the command Toggle Screen Reader Accessibility Mode, which is currently not triggerable via keyboard.',
					editorNotAccessibleMessage,
					runCommandKeybindingLabel
				);
			} else if (keybindingEditorKeybindingLabel) {
				return localize(
					'{0} Please assign a keybinding for the command Toggle Screen Reader Accessibility Mode by accessing the keybindings editor with {1} and run it.',
					editorNotAccessibleMessage,
					keybindingEditorKeybindingLabel
				);
			} else {
				return editorNotAccessibleMessage;
			}
		}
		return options2.get(
			4
			// ariaLabel
		);
	}
	_setAccessibilityOptions(options2) {
		this._accessibilitySupport = options2.get(
			2
			// accessibilitySupport
		);
		const accessibilityPageSize = options2.get(
			3
			// accessibilityPageSize
		);
		if (this._accessibilitySupport === 2 && accessibilityPageSize === editorOptions.accessibilityPageSize.defaultValue) {
			this._accessibilityPageSize = 500;
		} else {
			this._accessibilityPageSize = accessibilityPageSize;
		}
		const layoutInfo = options2.get(
			145
			// layoutInfo
		);
		const wrappingColumn = layoutInfo.wrappingColumn;
		if (wrappingColumn !== -1 && this._accessibilitySupport !== 1) {
			const fontInfo = options2.get(
				50
				// fontInfo
			);
			this._textAreaWrapping = true;
			this._textAreaWidth = Math.round(wrappingColumn * fontInfo.typicalHalfwidthCharacterWidth);
		} else {
			this._textAreaWrapping = false;
			this._textAreaWidth = 0;
		}
	}


		getAriaLabel() {
		return AriaLabelProvider.toLabel(this._os, this._chords, keybinding => this._getAriaLabel(keybinding));
	}



		if (this.accessibilityProvider) {
			this.ariaLabel = this.accessibilityProvider.getWidgetAriaLabel();
		}
if (this.accessibilityProvider?.getActiveDescendantId) {
				id = this.accessibilityProvider.getActiveDescendantId(this.view.element(focus[0]));
			}




		this.accessibilityProvider = _options.accessibilityProvider;
class AccessibiltyRenderer {
	constructor(accessibilityProvider) {
		this.accessibilityProvider = accessibilityProvider;
		this.templateId = 'a18n';
	}
	renderTemplate(container) {
		return { container, disposables: new DisposableStore() };
	}
	renderElement(element, index, data) {
		const ariaLabel = this.accessibilityProvider.getAriaLabel(element);
		const observable = ariaLabel && typeof ariaLabel !== 'string' ? ariaLabel : constObservable(ariaLabel);
		data.disposables.add(
			autorun(reader => {
				this.setAriaLabel(reader.readObservable(observable), data.container);
			})
		);
		const ariaLevel = this.accessibilityProvider.getAriaLevel && this.accessibilityProvider.getAriaLevel(element);
		if (typeof ariaLevel === 'number') {
			data.container.setAttribute('aria-level', `${ariaLevel}`);
		} else {
			data.container.removeAttribute('aria-level');
		}
	}
	setAriaLabel(ariaLabel, element) {
		if (ariaLabel) {
			element.setAttribute('aria-label', ariaLabel);
		} else {
			element.removeAttribute('aria-label');
		}
	}
	disposeElement(element, index, templateData, height) {
		templateData.disposables.clear();
	}
	disposeTemplate(templateData) {
		templateData.disposables.dispose();
	}
}

		if (this.accessibilityProvider) {
			baseRenderers.push(new AccessibiltyRenderer(this.accessibilityProvider));
			this.accessibilityProvider?.onDidChangeActiveDescendant?.call(
				this.accessibilityProvider,
				this.onDidChangeActiveDescendant,
				this,
				this.disposables
			);
		}




class PagedAccessibilityProvider {
	constructor(modelProvider, accessibilityProvider) {
		this.modelProvider = modelProvider;
		this.accessibilityProvider = accessibilityProvider;
	}
	getWidgetAriaLabel() {
		return this.accessibilityProvider.getWidgetAriaLabel();
	}
	getAriaLabel(index) {
		const model = this.modelProvider();
		if (!model.isResolved(index)) {
			return null;
		}
		return this.accessibilityProvider.getAriaLabel(model.get(index));
	}
}

function getHoverAccessibleViewHint(shouldHaveHint, keybinding) {
	return shouldHaveHint && keybinding
		? localize(keybinding)
		: shouldHaveHint
			? localize(
					'Inspect this in the accessible view via the command Open Accessible View which is currently not triggerable via keybinding.'
				)
			: '';
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class CursorWordAccessibilityLeft extends WordLeftCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 3,
			id: 'cursorWordAccessibilityLeft',
			precondition: undefined
		});
	}
	_move(wordCharacterClassifier, model, position, wordNavigationType) {
		return super._move(
			getMapForWordSeparators(editorOptions.wordSeparators.defaultValue, wordCharacterClassifier.intlSegmenterLocales),
			model,
			position,
			wordNavigationType
		);
	}
}
registerEditorCommand(new CursorWordAccessibilityLeft());

class CursorWordAccessibilityLeftSelect extends WordLeftCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 3,
			id: 'cursorWordAccessibilityLeftSelect',
			precondition: undefined
		});
	}
	_move(wordCharacterClassifier, model, position, wordNavigationType) {
		return super._move(
			getMapForWordSeparators(editorOptions.wordSeparators.defaultValue, wordCharacterClassifier.intlSegmenterLocales),
			model,
			position,
			wordNavigationType
		);
	}
}
registerEditorCommand(new CursorWordAccessibilityLeftSelect());

class CursorWordAccessibilityRight extends WordRightCommand {
	constructor() {
		super({
			inSelectionMode: false,
			wordNavigationType: 3,
			id: 'cursorWordAccessibilityRight',
			precondition: undefined
		});
	}
	_move(wordCharacterClassifier, model, position, wordNavigationType) {
		return super._move(
			getMapForWordSeparators(editorOptions.wordSeparators.defaultValue, wordCharacterClassifier.intlSegmenterLocales),
			model,
			position,
			wordNavigationType
		);
	}
}
registerEditorCommand(new CursorWordAccessibilityRight());

class CursorWordAccessibilityRightSelect extends WordRightCommand {
	constructor() {
		super({
			inSelectionMode: true,
			wordNavigationType: 3,
			id: 'cursorWordAccessibilityRightSelect',
			precondition: undefined
		});
	}
	_move(wordCharacterClassifier, model, position, wordNavigationType) {
		return super._move(
			getMapForWordSeparators(editorOptions.wordSeparators.defaultValue, wordCharacterClassifier.intlSegmenterLocales),
			model,
			position,
			wordNavigationType
		);
	}
}
registerEditorCommand(new CursorWordAccessibilityRightSelect());

//getAriaLabel

const StandaloneCodeEditorNLS = {
	editorViewAccessibleLabel: localize('Editor content'),
	accessibilityHelpMessage: localize('Press Alt+F1 for Accessibility Options.')
};
		options2.ariaLabel = options2.ariaLabel || StandaloneCodeEditorNLS.editorViewAccessibleLabel;
		options2.ariaLabel = options2.ariaLabel + ';' + StandaloneCodeEditorNLS.accessibilityHelpMessage;



		/*
		const role = this.accessibilityProvider.getRole(item.element) || 'listitem';
		item.row.domNode.setAttribute('role', role);
		const checked = this.accessibilityProvider.isChecked(item.element);
		if (typeof checked === 'boolean') {
			item.row.domNode.setAttribute('aria-checked', String(!!checked));
		} else if (checked) {
			const update = checked2 => item.row.domNode.setAttribute('aria-checked', String(!!checked2));
			update(checked.value);
			item.checkedDisposable = checked.onDidChange(() => update(checked.value));
		}
		*/

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

//#aria.
function setARIAContainer(parent) {
	ariaContainer = document.createElement('div');
	ariaContainer.className = 'monaco-aria-container';
	const createAlertContainer = () => {
		const element = document.createElement('div');
		element.className = 'monaco-alert';
		element.setAttribute('role', 'alert');
		element.setAttribute('aria-atomic', 'true');
		ariaContainer.appendChild(element);
		return element;
	};
	alertContainer = createAlertContainer();
	alertContainer2 = createAlertContainer();
	const createStatusContainer = () => {
		const element = document.createElement('div');
		element.className = 'monaco-status';
		element.setAttribute('aria-live', 'polite');
		element.setAttribute('aria-atomic', 'true');
		ariaContainer.appendChild(element);
		return element;
	};
	statusContainer = createStatusContainer();
	statusContainer2 = createStatusContainer();
	parent.appendChild(ariaContainer);
}
function alert(msg) {
	if (!ariaContainer) {
		return;
	}
	if (alertContainer.textContent !== msg) {
		clearNode(alertContainer2);
		insertMessage(alertContainer, msg);
	} else {
		clearNode(alertContainer);
		insertMessage(alertContainer2, msg);
	}
}
function status(msg) {
	if (!ariaContainer) {
		return;
	}
	if (statusContainer.textContent !== msg) {
		clearNode(statusContainer2);
		insertMessage(statusContainer, msg);
	} else {
		clearNode(statusContainer);
		insertMessage(statusContainer2, msg);
	}
}
function insertMessage(target, msg) {
	clearNode(target);
	if (msg.length > MAX_MESSAGE_LENGTH) {
		msg = msg.substr(0, MAX_MESSAGE_LENGTH);
	}
	target.textContent = msg;
	target.style.visibility = 'hidden';
	target.style.visibility = 'visible';
}
var ariaContainer, alertContainer, alertContainer2, statusContainer, statusContainer2;
const MAX_MESSAGE_LENGTH = 2e4;

function createAriaDomNode(parent) {
	if (!parent) {
		if (ariaDomNodeCreated) {
			return;
		}
		ariaDomNodeCreated = true;
	}
	setARIAContainer(parent || mainWindow.document.body);
}








