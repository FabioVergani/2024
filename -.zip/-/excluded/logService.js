const ILogService = createEditorServiceDecorator('logService');

const LogLevel = {
	Off: 0,
	Trace: 1,
	Debug: 2,
	Info: 3,
	Warning: 4,
	Error: 5,
	0: 'Off',
	1: 'Trace',
	2: 'Debug',
	3: 'Info',
	4: 'Warning',
	5: 'Error'
};

const DEFAULT_LOG_LEVEL = LogLevel.Info;
class AbstractLogger extends Disposable {
	constructor() {
		super(...arguments);
		this.level = DEFAULT_LOG_LEVEL;
		this._onDidChangeLogLevel = this._register(new Emitter());
		this.onDidChangeLogLevel = this._onDidChangeLogLevel.event;
	}
	setLevel(level) {
		if (this.level !== level) {
			this.level = level;
			this._onDidChangeLogLevel.fire(this.level);
		}
	}
	getLevel() {
		return this.level;
	}
	checkLogLevel(level) {
		return this.level !== LogLevel.Off && this.level <= level;
	}
}
class ConsoleLogger extends AbstractLogger {
	constructor(logLevel = DEFAULT_LOG_LEVEL, useColors = true) {
		super();
		this.useColors = useColors;
		this.setLevel(logLevel);
	}
	trace(message, ...args) {
		if (this.checkLogLevel(LogLevel.Trace)) {
			if (this.useColors) {
				console.log('%cTRACE', 'color: #888', message, ...args);
			} else {
				console.log(message, ...args);
			}
		}
	}
	debug(message, ...args) {
		if (this.checkLogLevel(LogLevel.Debug)) {
			if (this.useColors) {
				console.log('%cDEBUG', 'background: #eee; color: #888', message, ...args);
			} else {
				console.log(message, ...args);
			}
		}
	}
	info(message, ...args) {
		if (this.checkLogLevel(LogLevel.Info)) {
			if (this.useColors) {
				console.log('%c INFO', 'color: #33f', message, ...args);
			} else {
				console.log(message, ...args);
			}
		}
	}
	warn(message, ...args) {
		if (this.checkLogLevel(LogLevel.Warning)) {
			if (this.useColors) {
				console.log('%c WARN', 'color: #993', message, ...args);
			} else {
				console.log(message, ...args);
			}
		}
	}
	error(message, ...args) {
		if (this.checkLogLevel(LogLevel.Error)) {
			if (this.useColors) {
				console.log('%c  ERR', 'color: #f33', message, ...args);
			} else {
				console.error(message, ...args);
			}
		}
	}
}
class MultiplexLogger extends AbstractLogger {
	constructor(loggers) {
		super();
		this.loggers = loggers;
		if (loggers.length) {
			this.setLevel(loggers[0].getLevel());
		}
	}
	setLevel(level) {
		for (const logger of this.loggers) {
			logger.setLevel(level);
		}
		super.setLevel(level);
	}
	trace(message, ...args) {
		for (const logger of this.loggers) {
			logger.trace(message, ...args);
		}
	}
	debug(message, ...args) {
		for (const logger of this.loggers) {
			logger.debug(message, ...args);
		}
	}
	info(message, ...args) {
		for (const logger of this.loggers) {
			logger.info(message, ...args);
		}
	}
	warn(message, ...args) {
		for (const logger of this.loggers) {
			logger.warn(message, ...args);
		}
	}
	error(message, ...args) {
		for (const logger of this.loggers) {
			logger.error(message, ...args);
		}
	}
	dispose() {
		for (const logger of this.loggers) {
			logger.dispose();
		}
		super.dispose();
	}
}
const CONTEXT_LOG_LEVEL = new RawContextKey('logLevel', 'info');

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class LogService extends Disposable {
	constructor(primaryLogger, otherLoggers = []) {
		super();
		this.logger = new MultiplexLogger([primaryLogger, ...otherLoggers]);
		this._register(primaryLogger.onDidChangeLogLevel(level => this.setLevel(level)));
	}
	get onDidChangeLogLevel() {
		return this.logger.onDidChangeLogLevel;
	}
	setLevel(level) {
		this.logger.setLevel(level);
	}
	getLevel() {
		return this.logger.getLevel();
	}
	trace(message, ...args) {
		this.logger.trace(message, ...args);
	}
	debug(message, ...args) {
		this.logger.debug(message, ...args);
	}
	info(message, ...args) {
		this.logger.info(message, ...args);
	}
	warn(message, ...args) {
		this.logger.warn(message, ...args);
	}
	error(message, ...args) {
		this.logger.error(message, ...args);
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class StandaloneLogService extends LogService {
	constructor() {
		super(new ConsoleLogger());
	}
}
registerSingleton(
	ILogService,
	StandaloneLogService,
	0
	/* InstantiationType.Eager */
);