// node_modules/monaco-editor/esm/vs/editor/contrib/unicodeHighlighter/browser/bannerController.js

const BANNER_ELEMENT_HEIGHT = 26;
class Banner extends Disposable {
	constructor(instantiationService) {
		super();
		this.instantiationService = instantiationService;
		this.markdownRenderer = this.instantiationService.createInstance(MarkdownRenderer, {});
		this.element = $('div.editor-banner');
		this.element.tabIndex = 0;
	}

	getBannerMessage(message) {
		if (typeof message === 'string') {
			const element = $('span');
			element.innerText = message;
			return element;
		}
		return this.markdownRenderer.render(message).element;
	}
	clear() {
		clearNode(this.element);
	}
	show(item) {
		clearNode(this.element);

		const iconContainer = append(this.element, $('div.icon-container'));

		if (item.icon) {
			iconContainer.appendChild($(`div${asThemeIconCSSSelector(item.icon)}`));
		}
		const messageContainer = append(this.element, $('div.message-container'));

		messageContainer.appendChild(this.getBannerMessage(item.message));
		this.messageActionsContainer = append(this.element, $('div.message-actions-container'));
		if (item.actions) {
			for (const action of item.actions) {
				this._register(
					this.instantiationService.createInstance(Link2, this.messageActionsContainer, { ...action, tabIndex: -1 }, {})
				);
			}
		}
		const actionBarContainer = append(this.element, $('div.action-container'));
		this.actionBar = this._register(new ActionBar(actionBarContainer));
		this.actionBar.push(
			this._register(
				new Action('banner.close', 'Close Banner', asThemeIconClassNameString(registeredIcon_widgetClose), true, () => {
					if (typeof item.onClose === 'function') {
						item.onClose();
					}
				})
			),
			{ icon: true, label: false }
		);
		this.actionBar.setFocusable(false);
	}
}
class BannerController extends Disposable {
	constructor(_editor, instantiationService) {
		super();
		this._editor = _editor;
		this.instantiationService = instantiationService;
		this.banner = this._register(this.instantiationService.createInstance(Banner));
	}
	hide() {
		this._editor.setBanner(null, 0);
		this.banner.clear();
	}
	show(item) {
		this.banner.show({
			...item,
			onClose: () => {
				this.hide();
				item.onClose?.call(item);
			}
		});
		this._editor.setBanner(this.banner.element, BANNER_ELEMENT_HEIGHT);
	}
}
__decorate([__param(1, IInstantiationService)], BannerController);


__decorate([__param(0, IInstantiationService)], Banner);