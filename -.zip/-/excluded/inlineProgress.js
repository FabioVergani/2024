var inlineProgressDecoration = ModelDecorationOptions.register({
	description: 'inline-progress-widget',
	stickiness: 1,
	showIfCollapsed: true,
	after: {
		content: noBreakWhitespace,
		inlineClassName: 'inline-editor-progress-decoration',
		inlineClassNameAffectsLetterSpacing: true
	}
});
class InlineProgressWidget extends Disposable {
	constructor(typeId, editor2, range2, title, delegate) {
		super();
		this.typeId = typeId;
		this.editor = editor2;
		this.range = range2;
		this.delegate = delegate;
		this.allowEditorOverflow = false;
		this.suppressMouseDown = true;
		this.create(title);
		this.editor.addContentWidget(this);
		this.editor.layoutContentWidget(this);
	}
	create(title) {
		this.domNode = createDomElement('.inline-progress-widget');
		this.domNode.role = 'button';
		this.domNode.title = title;
		const iconElement = createDomElement('span.icon');
		this.domNode.append(iconElement);
		iconElement.classList.add(...asThemeIconClassNameArray(codicon_loading), 'codicon-modifier-spin');
		const updateSize = () => {
			const lineHeight = this.editor.getOption(
				67 // lineHeight
			);
			this.domNode.style.height = `${lineHeight}px`;
			this.domNode.style.width = `${Math.ceil(0.8 * lineHeight)}px`;
		};
		updateSize();
		this._register(
			this.editor.onDidChangeConfiguration(c => {
				if (
					c.hasChanged(
						52 // fontSize
					) ||
					c.hasChanged(
						67 // lineHeight
					)
				) {
					updateSize();
				}
			})
		);
		this._register(
			addDisposableListener(this.domNode, EventType.CLICK, e => {
				this.delegate.cancel();
			})
		);
	}
	getId() {
		return InlineProgressWidget.baseId + '.' + this.typeId;
	}
	getDomNode() {
		return this.domNode;
	}
	getPosition() {
		return {
			position: {
				lineNumber: this.range.startLineNumber,
				column: this.range.startColumn
			},
			preference: [
				0 // EXACT
			]
		};
	}
	dispose() {
		super.dispose();
		this.editor.removeContentWidget(this);
	}
}
InlineProgressWidget.baseId = 'editor.widget.inlineProgressWidget';
class InlineProgressManager extends Disposable {
	constructor(id, _editor, _instantiationService) {
		super();
		this.id = id;
		this._editor = _editor;
		this._instantiationService = _instantiationService;
		this._showDelay = 500;
		this._showPromise = this._register(new MutableDisposable());
		this._currentWidget = new MutableDisposable();
		this._operationIdPool = 0;
		this._currentDecorations = _editor.createDecorationsCollection();
	}
	async showWhile(position, title, promise) {
		const operationId = this._operationIdPool++;
		this._currentOperation = operationId;
		this.clear();
		this._showPromise.value = disposableTimeout(() => {
			const range2 = Range.fromPositions(position);
			const decorationIds = this._currentDecorations.set([{ range: range2, options: inlineProgressDecoration }]);
			if (decorationIds.length > 0) {
				this._currentWidget.value = this._instantiationService.createInstance(
					InlineProgressWidget,
					this.id,
					this._editor,
					range2,
					title,
					promise
				);
			}
		}, this._showDelay);
		try {
			return await promise;
		} finally {
			if (this._currentOperation === operationId) {
				this.clear();
				this._currentOperation = undefined;
			}
		}
	}
	clear() {
		this._showPromise.clear();
		this._currentDecorations.clear();
		this._currentWidget.clear();
	}
}
__decorate([__param(2, IInstantiationService)], InlineProgressManager);
