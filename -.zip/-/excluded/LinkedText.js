class LinkedText {
	constructor(nodes) {
		this.nodes = nodes;
	}
	toString() {
		return this.nodes.map(node => (typeof node === 'string' ? node : node.label)).join('');
	}
}
__decorate([memoizeMethod], LinkedText.prototype, 'toString', null);
