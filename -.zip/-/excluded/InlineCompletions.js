




			function _canShowSuggestOnTriggerCharacters(editor2, contextKeyService, configurationService) {
				if (!Boolean(contextKeyService.getContextKeyValue('inlineSuggestionVisible'))) {
					return true;
				}
				const suppressSuggestions = contextKeyService.getContextKeyValue(InlineCompletionContextKeys.suppressSuggestions.key);
				if (suppressSuggestions !== undefined) {
					return !suppressSuggestions;
				}
				return !editor2.getOption(
					62 // inlineSuggest
				).suppressSuggestions;
			}
			if (!_canShowSuggestOnTriggerCharacters(this._editor, this._contextKeyService, this._configurationService)) {
				return;
			}

				function _canShowQuickSuggest(editor2, contextKeyService, configurationService) {
					if (!Boolean(contextKeyService.getContextKeyValue(InlineCompletionContextKeys.inlineSuggestionVisible.key))) {
						return true;
					}
					const suppressSuggestions = contextKeyService.getContextKeyValue(InlineCompletionContextKeys.suppressSuggestions.key);
					if (suppressSuggestions !== undefined) {
						return !suppressSuggestions;
					}
					return !editor2.getOption(
						62 // inlineSuggest
					).suppressSuggestions;
				}
				if (!_canShowQuickSuggest(this._editor, this._contextKeyService, this._configurationService)) {
					return;
				}

// node_modules/monaco-editor/esm/vs/editor/contrib/inlineCompletions/browser/inlineCompletionContextKeys.js

class InlineCompletionContextKeys extends Disposable {
	constructor(contextKeyService, model) {
		super();
		this.contextKeyService = contextKeyService;
		this.model = model;
		this.inlineCompletionVisible = InlineCompletionContextKeys.inlineSuggestionVisible.bindTo(this.contextKeyService);
		this.inlineCompletionSuggestsIndentation = InlineCompletionContextKeys.inlineSuggestionHasIndentation.bindTo(
			this.contextKeyService
		);
		this.inlineCompletionSuggestsIndentationLessThanTabSize =
			InlineCompletionContextKeys.inlineSuggestionHasIndentationLessThanTabSize.bindTo(this.contextKeyService);
		this.suppressSuggestions = InlineCompletionContextKeys.suppressSuggestions.bindTo(this.contextKeyService);
		this._register(
			autorun(reader => {
				const model2 = this.model.read(reader);
				const state = model2?.state.read(reader);
				const isInlineCompletionVisible =
					!!state?.inlineCompletion && state?.primaryGhostText !== undefined && !state?.primaryGhostText.isEmpty();
				this.inlineCompletionVisible.set(isInlineCompletionVisible);
				if (state?.primaryGhostText && state?.inlineCompletion) {
					this.suppressSuggestions.set(state.inlineCompletion.inlineCompletion.source.inlineCompletions.suppressSuggestions);
				}
			})
		);
		this._register(
			autorun(reader => {
				const model2 = this.model.read(reader);
				let startsWithIndentation = false;
				let startsWithIndentationLessThanTabSize = true;
				const ghostText = model2?.primaryGhostText.read(reader);
				if (!!model2?.selectedSuggestItem && ghostText && ghostText.parts.length > 0) {
					const { column, lines } = ghostText.parts[0];
					const firstLine = lines[0];
					const indentationEndColumn = model2.textModel.getLineIndentColumn(ghostText.lineNumber);
					const inIndentation = column <= indentationEndColumn;
					if (inIndentation) {
						let firstNonWsIdx = firstNonWhitespaceIndex(firstLine);
						if (firstNonWsIdx === -1) {
							firstNonWsIdx = firstLine.length - 1;
						}
						startsWithIndentation = firstNonWsIdx > 0;
						const tabSize = model2.textModel.getOptions().tabSize;
						const visibleColumnIndentation = CursorColumns.visibleColumnFromColumn(firstLine, firstNonWsIdx + 1, tabSize);
						startsWithIndentationLessThanTabSize = visibleColumnIndentation < tabSize;
					}
				}
				this.inlineCompletionSuggestsIndentation.set(startsWithIndentation);
				this.inlineCompletionSuggestsIndentationLessThanTabSize.set(startsWithIndentationLessThanTabSize);
			})
		);
	}
}
InlineCompletionContextKeys.inlineSuggestionVisible = new RawContextKey(
	'inlineSuggestionVisible',
	false,
	localize('Whether an inline suggestion is visible')
);
InlineCompletionContextKeys.inlineSuggestionHasIndentation = new RawContextKey(
	'inlineSuggestionHasIndentation',
	false,
	localize('Whether the inline suggestion starts with whitespace')
);
InlineCompletionContextKeys.inlineSuggestionHasIndentationLessThanTabSize = new RawContextKey(
	'inlineSuggestionHasIndentationLessThanTabSize',
	true,
	localize('Whether the inline suggestion starts with whitespace that is less than what would be inserted by tab')
);
InlineCompletionContextKeys.suppressSuggestions = new RawContextKey(
	'inlineSuggestionSuppressSuggestions',
	undefined,
	localize('Whether suggestions should be suppressed for the current suggestion')
);

// node_modules/monaco-editor/esm/vs/editor/contrib/inlineCompletions/browser/ghostText.js
class GhostText {
	constructor(lineNumber, parts) {
		this.lineNumber = lineNumber;
		this.parts = parts;
	}
	equals(other) {
		return (
			this.lineNumber === other.lineNumber &&
			this.parts.length === other.parts.length &&
			this.parts.every((part, index) => part.equals(other.parts[index]))
		);
	}
	renderForScreenReader(lineText) {
		if (this.parts.length === 0) {
			return '';
		}
		const lastPart = this.parts[this.parts.length - 1];
		const cappedLineText = lineText.substr(0, lastPart.column - 1);
		const text2 = new TextEdit([
			...this.parts.map(p => new SingleTextEdit(Range.fromPositions(new Position(1, p.column)), p.lines.join('\n')))
		]).applyToString(cappedLineText);
		return text2.substring(this.parts[0].column - 1);
	}
	isEmpty() {
		return this.parts.every(p => p.lines.length === 0);
	}
	get lineCount() {
		return 1 + this.parts.reduce((r, p) => r + p.lines.length - 1, 0);
	}
}
class GhostTextPart {
	constructor(column, text2, preview) {
		this.column = column;
		this.text = text2;
		this.preview = preview;
		this.lines = splitLines(this.text);
	}
	equals(other) {
		return (
			this.column === other.column &&
			this.lines.length === other.lines.length &&
			this.lines.every((line, index) => line === other.lines[index])
		);
	}
}
class GhostTextReplacement {
	constructor(lineNumber, columnRange, text2, additionalReservedLineCount = 0) {
		this.lineNumber = lineNumber;
		this.columnRange = columnRange;
		this.text = text2;
		this.additionalReservedLineCount = additionalReservedLineCount;
		this.parts = [new GhostTextPart(this.columnRange.endColumnExclusive, this.text, false)];
		this.newLines = splitLines(this.text);
	}
	renderForScreenReader(_lineText) {
		return this.newLines.join('\n');
	}
	get lineCount() {
		return this.newLines.length;
	}
	isEmpty() {
		return this.parts.every(p => p.lines.length === 0);
	}
	equals(other) {
		return (
			this.lineNumber === other.lineNumber &&
			this.columnRange.equals(other.columnRange) &&
			this.newLines.length === other.newLines.length &&
			this.newLines.every((line, index) => line === other.newLines[index]) &&
			this.additionalReservedLineCount === other.additionalReservedLineCount
		);
	}
}
function ghostTextsOrReplacementsEqual(a, b) {
	return equals(a, b, ghostTextOrReplacementEquals);
}
function ghostTextOrReplacementEquals(a, b) {
	if (a === b) {
		return true;
	}
	if (!a || !b) {
		return false;
	}
	if (a instanceof GhostText && b instanceof GhostText) {
		return a.equals(b);
	}
	if (a instanceof GhostTextReplacement && b instanceof GhostTextReplacement) {
		return a.equals(b);
	}
	return false;
}

// node_modules/monaco-editor/esm/vs/editor/contrib/inlineCompletions/browser/utils.js
function getReadonlyEmptyArray() {
	return [];
}
class ColumnRange {
	constructor(startColumn, endColumnExclusive) {
		this.startColumn = startColumn;
		this.endColumnExclusive = endColumnExclusive;
		if (startColumn > endColumnExclusive) {
			throw new BugIndicatingError(`startColumn ${startColumn} cannot be after endColumnExclusive ${endColumnExclusive}`);
		}
	}
	toRange(lineNumber) {
		return new Range(lineNumber, this.startColumn, lineNumber, this.endColumnExclusive);
	}
	equals(other) {
		return this.startColumn === other.startColumn && this.endColumnExclusive === other.endColumnExclusive;
	}
}
function applyObservableDecorations2(editor2, decorations) {
	const d = new DisposableStore();
	const decorationsCollection = editor2.createDecorationsCollection();
	d.add(
		autorunOpts(
			{
				debugName: () => `Apply decorations from ${decorations.debugName}`
			},
			reader => {
				const d2 = decorations.read(reader);
				decorationsCollection.set(d2);
			}
		)
	);
	d.add({
		dispose: () => {
			decorationsCollection.clear();
		}
	});
	return d;
}
function addPositions(pos1, pos2) {
	return new Position(pos1.lineNumber + pos2.lineNumber - 1, pos2.lineNumber === 1 ? pos1.column + pos2.column - 1 : pos2.column);
}
function subtractPositions(pos1, pos2) {
	return new Position(
		pos1.lineNumber - pos2.lineNumber + 1,
		pos1.lineNumber - pos2.lineNumber === 0 ? pos1.column - pos2.column + 1 : pos1.column
	);
}

// node_modules/monaco-editor/esm/vs/editor/contrib/inlineCompletions/browser/ghostTextWidget.js

var GHOST_TEXT_DESCRIPTION = 'ghost-text';
class GhostTextWidget extends Disposable {
	constructor(editor2, model, languageService) {
		super();
		this.editor = editor2;
		this.model = model;
		this.languageService = languageService;
		this.isDisposed = observableValue(this, false);
		this.currentTextModel = observableFromEvent(this.editor.onDidChangeModel, () => this.editor.getModel());
		this.uiState = derived(this, reader => {
			if (this.isDisposed.read(reader)) {
				return;
			}
			const textModel = this.currentTextModel.read(reader);
			if (textModel !== this.model.targetTextModel.read(reader)) {
				return;
			}
			const ghostText = this.model.ghostText.read(reader);
			if (!ghostText) {
				return;
			}
			const replacedRange = ghostText instanceof GhostTextReplacement ? ghostText.columnRange : undefined;
			const inlineTexts = [];
			const additionalLines = [];
			function addToAdditionalLines(lines, className) {
				if (additionalLines.length > 0) {
					const lastLine = additionalLines[additionalLines.length - 1];
					if (className) {
						lastLine.decorations.push(
							new LineDecoration(
								lastLine.content.length + 1,
								lastLine.content.length + 1 + lines[0].length,
								className,
								0 // InlineDecorationType.Regular */
							)
						);
					}
					lastLine.content += lines[0];
					lines = lines.slice(1);
				}
				for (const line of lines) {
					additionalLines.push({
						content: line,
						decorations: className
							? [
									new LineDecoration(
										1,
										line.length + 1,
										className,
										0 //InlineDecorationType.Regular */
									)
								]
							: []
					});
				}
			}
			const textBufferLine = textModel.getLineContent(ghostText.lineNumber);
			let hiddenTextStartColumn = undefined;
			let lastIdx = 0;
			for (const part of ghostText.parts) {
				let lines = part.lines;
				if (hiddenTextStartColumn === undefined) {
					inlineTexts.push({
						column: part.column,
						text: lines[0],
						preview: part.preview
					});
					lines = lines.slice(1);
				} else {
					addToAdditionalLines([textBufferLine.substring(lastIdx, part.column - 1)], undefined);
				}
				if (lines.length > 0) {
					addToAdditionalLines(lines, GHOST_TEXT_DESCRIPTION);
					if (hiddenTextStartColumn === undefined && part.column <= textBufferLine.length) {
						hiddenTextStartColumn = part.column;
					}
				}
				lastIdx = part.column - 1;
			}
			if (hiddenTextStartColumn !== undefined) {
				addToAdditionalLines([textBufferLine.substring(lastIdx)], undefined);
			}
			const hiddenRange =
				hiddenTextStartColumn !== undefined ? new ColumnRange(hiddenTextStartColumn, textBufferLine.length + 1) : undefined;
			return {
				replacedRange,
				inlineTexts,
				additionalLines,
				hiddenRange,
				lineNumber: ghostText.lineNumber,
				additionalReservedLineCount: this.model.minReservedLineCount.read(reader),
				targetTextModel: textModel
			};
		});
		this.decorations = derived(this, reader => {
			const uiState = this.uiState.read(reader);
			if (!uiState) {
				return [];
			}
			const decorations = [];
			if (uiState.replacedRange) {
				decorations.push({
					range: uiState.replacedRange.toRange(uiState.lineNumber),
					options: {
						inlineClassName: 'inline-completion-text-to-replace',
						description: 'GhostTextReplacement'
					}
				});
			}
			if (uiState.hiddenRange) {
				decorations.push({
					range: uiState.hiddenRange.toRange(uiState.lineNumber),
					options: {
						inlineClassName: 'ghost-text-hidden',
						description: 'ghost-text-hidden'
					}
				});
			}
			for (const p of uiState.inlineTexts) {
				decorations.push({
					range: Range.fromPositions(new Position(uiState.lineNumber, p.column)),
					options: {
						description: GHOST_TEXT_DESCRIPTION,
						after: {
							content: p.text,
							inlineClassName: p.preview ? 'ghost-text-decoration-preview' : 'ghost-text-decoration',
							cursorStops: InjectedTextCursorStops2.Left
						},
						showIfCollapsed: true
					}
				});
			}
			return decorations;
		});
		this.additionalLinesWidget = this._register(
			new AdditionalLinesWidget(
				this.editor,
				this.languageService.languageIdCodec,
				derived(reader => {
					const uiState = this.uiState.read(reader);
					return uiState
						? {
								lineNumber: uiState.lineNumber,
								additionalLines: uiState.additionalLines,
								minReservedLineCount: uiState.additionalReservedLineCount,
								targetTextModel: uiState.targetTextModel
							}
						: undefined;
				})
			)
		);
		this._register(
			toDisposable(() => {
				this.isDisposed.set(true, undefined);
			})
		);
		this._register(applyObservableDecorations2(this.editor, this.decorations));
	}
	ownsViewZone(viewZoneId) {
		return this.additionalLinesWidget.viewZoneId === viewZoneId;
	}
}
__decorate([__param(2, ILanguageService)], GhostTextWidget);
class AdditionalLinesWidget extends Disposable {
	get viewZoneId() {
		return this._viewZoneId;
	}
	constructor(editor2, languageIdCodec, lines) {
		super();
		this.editor = editor2;
		this.languageIdCodec = languageIdCodec;
		this.lines = lines;
		this._viewZoneId = undefined;
		this.editorOptionsChanged = observableSignalFromEvent(
			'editorOptionChanged',
			editorEventFilter(
				this.editor.onDidChangeConfiguration,
				e =>
					e.hasChanged(
						33 // disableMonospaceOptimizations
					) ||
					e.hasChanged(
						117 // stopRenderingLineAfter
					) ||
					e.hasChanged(
						99 // renderWhitespace
					) ||
					e.hasChanged(
						94 // renderControlCharacters
					) ||
					e.hasChanged(
						51 // fontLigatures
					) ||
					e.hasChanged(
						50 // fontInfo
					) ||
					e.hasChanged(
						67 // lineHeight
					)
			)
		);
		this._register(
			autorun(reader => {
				const lines2 = this.lines.read(reader);
				this.editorOptionsChanged.read(reader);
				if (lines2) {
					this.updateLines(lines2.lineNumber, lines2.additionalLines, lines2.minReservedLineCount);
				} else {
					this.clear();
				}
			})
		);
	}
	dispose() {
		super.dispose();
		this.clear();
	}
	clear() {
		this.editor.changeViewZones(changeAccessor => {
			if (this._viewZoneId) {
				changeAccessor.removeZone(this._viewZoneId);
				this._viewZoneId = undefined;
			}
		});
	}
	updateLines(lineNumber, additionalLines, minReservedLineCount) {
		const textModel = this.editor.getModel();
		if (!textModel) {
			return;
		}
		const { tabSize } = textModel.getOptions();
		this.editor.changeViewZones(changeAccessor => {
			if (this._viewZoneId) {
				changeAccessor.removeZone(this._viewZoneId);
				this._viewZoneId = undefined;
			}
			const heightInLines = Math.max(additionalLines.length, minReservedLineCount);
			if (heightInLines > 0) {
				const domNode = document.createElement('div');
				renderLines2(domNode, tabSize, additionalLines, this.editor.getOptions(), this.languageIdCodec);
				this._viewZoneId = changeAccessor.addZone({
					afterLineNumber: lineNumber,
					heightInLines,
					domNode,
					afterColumnAffinity: 1 // Right
				});
			}
		});
	}
}
function renderLines2(domNode, tabSize, lines, opts, languageIdCodec) {
	const disableMonospaceOptimizations = opts.get(
		33 // disableMonospaceOptimizations
	);
	const stopRenderingLineAfter = opts.get(
		117 // stopRenderingLineAfter
	);
	const renderWhitespace = 'none';
	const renderControlCharacters = opts.get(
		94 // renderControlCharacters
	);
	const fontLigatures = opts.get(
		51 // fontLigatures
	);
	const fontInfo = opts.get(
		50 // fontInfo
	);
	const lineHeight = opts.get(
		67 // lineHeight
	);
	const sb = new StringBuilder(1e4);
	sb.appendString('<div class="suggest-preview-text">');
	for (let i = 0, len = lines.length; i < len; i++) {
		const lineData = lines[i];
		const line = lineData.content;
		sb.appendString('<div class="view-line');
		sb.appendString('" style="top:');
		sb.appendString(String(i * lineHeight));
		sb.appendString('px;width:1000000px;">');
		const isBasicASCII2 = isBasicASCII(line);
		const containsRTL2 = containsRTL(line);
		const lineTokens = LineTokens.createEmpty(line, languageIdCodec);
		renderViewLine(
			new RenderLineInput(
				fontInfo.isMonospace && !disableMonospaceOptimizations,
				fontInfo.canUseHalfwidthRightwardsArrow,
				line,
				false,
				isBasicASCII2,
				containsRTL2,
				0,
				lineTokens,
				lineData.decorations,
				tabSize,
				0,
				fontInfo.spaceWidth,
				fontInfo.middotWidth,
				fontInfo.wsmiddotWidth,
				stopRenderingLineAfter,
				renderWhitespace,
				renderControlCharacters,
				fontLigatures !== EditorFontLigatures.OFF,
				null
			),
			sb
		);
		sb.appendString('</div>');
	}
	sb.appendString('</div>');
	applyFontInfo(domNode, fontInfo);
	domNode.innerHTML = sb.build();
} //

class StaticTokenizerSource {
	constructor(lines) {
		this.lines = lines;
		this.tokenization = {
			getLineTokens: lineNumber => {
				return this.lines[lineNumber - 1];
			}
		};
	}
	getLineCount() {
		return this.lines.length;
	}
	getLineLength(lineNumber) {
		return this.lines[lineNumber - 1].getLineContent().length;
	}
}

function fixBracketsInLine(tokens, languageConfigurationService) {
	const denseKeyProvider = new DenseKeyProvider();
	const bracketTokens = new LanguageAgnosticBracketTokens(denseKeyProvider, languageId =>
		languageConfigurationService.getLanguageConfiguration(languageId)
	);
	const tokenizer = new TextBufferTokenizer(new StaticTokenizerSource([tokens]), bracketTokens);
	const node = parseDocument(tokenizer, [], undefined, true);
	let str = '';
	const line = tokens.getLineContent();
	function processNode(node2, offset) {
		if (node2.kind === 2) {
			processNode(node2.openingBracket, offset);
			offset = lengthAdd(offset, node2.openingBracket.length);
			if (node2.child) {
				processNode(node2.child, offset);
				offset = lengthAdd(offset, node2.child.length);
			}
			if (node2.closingBracket) {
				processNode(node2.closingBracket, offset);
				offset = lengthAdd(offset, node2.closingBracket.length);
			} else {
				const singleLangBracketTokens = bracketTokens.getSingleLanguageBracketTokens(node2.openingBracket.languageId);
				const closingTokenText = singleLangBracketTokens.findClosingTokenText(node2.openingBracket.bracketIds);
				str += closingTokenText;
			}
		} else if (node2.kind === 3) {
		} else if (node2.kind === 0 || node2.kind === 1) {
			str += line.substring(
				lengthGetColumnCountIfZeroLineCount(offset),
				lengthGetColumnCountIfZeroLineCount(lengthAdd(offset, node2.length))
			);
		} else if (node2.kind === 4) {
			for (const child of node2.children) {
				processNode(child, offset);
				offset = lengthAdd(offset, child.length);
			}
		}
	}
	processNode(node, lengthZero);
	return str;
}



// node_modules/monaco-editor/esm/vs/editor/contrib/inlineCompletions/browser/provideInlineCompletions.js
async function provideInlineCompletions(registry, position, model, context, token = cancellationToken_none, languageConfigurationService) {
	const defaultReplaceRange = getDefaultRange(position, model);
	const providers = registry.all(model);
	const multiMap = new SetMap();
	for (const provider of providers) {
		if (provider.groupId) {
			multiMap.add(provider.groupId, provider);
		}
	}
	function getPreferredProviders(provider) {
		if (!provider.yieldsToGroupIds) {
			return [];
		}
		const result = [];
		for (const groupId of provider.yieldsToGroupIds || []) {
			const providers2 = multiMap.get(groupId);
			for (const p of providers2) {
				result.push(p);
			}
		}
		return result;
	}
	const states = new Map();
	const seen = new Set();
	function findPreferredProviderCircle(provider, stack) {
		stack = [...stack, provider];
		if (seen.has(provider)) {
			return stack;
		}
		seen.add(provider);
		try {
			const preferred = getPreferredProviders(provider);
			for (const p of preferred) {
				const c = findPreferredProviderCircle(p, stack);
				if (c) {
					return c;
				}
			}
		} finally {
			seen.delete(provider);
		}
		return;
	}
	function processProvider(provider) {
		const state = states.get(provider);
		if (state) {
			return state;
		}
		const circle = findPreferredProviderCircle(provider, []);
		if (circle) {
			onUnexpectedExternalError(
				new Error(
					`Inline completions: cyclic yield-to dependency detected. Path: ${circle.map(s => (s.toString ? s.toString() : '' + s)).join(' -> ')}`
				)
			);
		}
		const deferredPromise = new DeferredPromise();
		states.set(provider, deferredPromise.p);
		(async () => {
			if (!circle) {
				const preferred = getPreferredProviders(provider);
				for (const p of preferred) {
					const result = await processProvider(p);
					if (result && result.items.length > 0) {
						return;
					}
				}
			}
			try {
				const completions = await provider.provideInlineCompletions(model, position, context, token);
				return completions;
			} catch (e) {
				onUnexpectedExternalError(e);
				return;
			}
		})().then(
			c => deferredPromise.complete(c),
			e => deferredPromise.error(e)
		);
		return deferredPromise.p;
	}
	const providerResults = await Promise.all(
		providers.map(async provider => ({
			provider,
			completions: await processProvider(provider)
		}))
	);
	const itemsByHash = new Map();
	const lists = [];
	for (const result of providerResults) {
		const completions = result.completions;
		if (!completions) {
			continue;
		}
		const list = new InlineCompletionList(completions, result.provider);
		lists.push(list);
		for (const item of completions.items) {
			const inlineCompletionItem = InlineCompletionItem.from(item, list, defaultReplaceRange, model, languageConfigurationService);
			itemsByHash.set(inlineCompletionItem.hash(), inlineCompletionItem);
		}
	}
	return new InlineCompletionProviderResult(Array.from(itemsByHash.values()), new Set(itemsByHash.keys()), lists);
}
class InlineCompletionProviderResult {
	constructor(completions, hashs, providerResults) {
		this.completions = completions;
		this.hashs = hashs;
		this.providerResults = providerResults;
	}
	has(item) {
		return this.hashs.has(item.hash());
	}
	dispose() {
		for (const result of this.providerResults) {
			result.removeRef();
		}
	}
}
class InlineCompletionList {
	constructor(inlineCompletions, provider) {
		this.inlineCompletions = inlineCompletions;
		this.provider = provider;
		this.refCount = 1;
	}
	addRef() {
		this.refCount++;
	}
	removeRef() {
		this.refCount--;
		if (this.refCount === 0) {
			this.provider.freeInlineCompletions(this.inlineCompletions);
		}
	}
}
class InlineCompletionItem {
	static from(inlineCompletion, source, defaultReplaceRange, textModel, languageConfigurationService) {
		let insertText;
		let snippetInfo;
		let range2 = inlineCompletion.range ? Range.lift(inlineCompletion.range) : defaultReplaceRange;
		if (typeof inlineCompletion.insertText === 'string') {
			insertText = inlineCompletion.insertText;
			if (languageConfigurationService && inlineCompletion.completeBracketPairs) {
				insertText = closeBrackets(insertText, range2.getStartPosition(), textModel, languageConfigurationService);
				const diff = insertText.length - inlineCompletion.insertText.length;
				if (diff !== 0) {
					range2 = new Range(range2.startLineNumber, range2.startColumn, range2.endLineNumber, range2.endColumn + diff);
				}
			}
			snippetInfo = undefined;
		} else if ('snippet' in inlineCompletion.insertText) {
			const preBracketCompletionLength = inlineCompletion.insertText.snippet.length;
			if (languageConfigurationService && inlineCompletion.completeBracketPairs) {
				inlineCompletion.insertText.snippet = closeBrackets(
					inlineCompletion.insertText.snippet,
					range2.getStartPosition(),
					textModel,
					languageConfigurationService
				);
				const diff = inlineCompletion.insertText.snippet.length - preBracketCompletionLength;
				if (diff !== 0) {
					range2 = new Range(range2.startLineNumber, range2.startColumn, range2.endLineNumber, range2.endColumn + diff);
				}
			}
			const snippet = new SnippetParser().parse(inlineCompletion.insertText.snippet);
			if (snippet.children.length === 1 && snippet.children[0] instanceof Text) {
				insertText = snippet.children[0].value;
				snippetInfo = undefined;
			} else {
				insertText = snippet.toString();
				snippetInfo = {
					snippet: inlineCompletion.insertText.snippet,
					range: range2
				};
			}
		} else {
			new Error(inlineCompletion.insertText);
		}
		return new InlineCompletionItem(
			insertText,
			inlineCompletion.command,
			range2,
			insertText,
			snippetInfo,
			inlineCompletion.additionalTextEdits || getReadonlyEmptyArray(),
			inlineCompletion,
			source
		);
	}
	constructor(filterText, command, range2, insertText, snippetInfo, additionalTextEdits, sourceInlineCompletion, source) {
		this.filterText = filterText;
		this.command = command;
		this.range = range2;
		this.insertText = insertText;
		this.snippetInfo = snippetInfo;
		this.additionalTextEdits = additionalTextEdits;
		this.sourceInlineCompletion = sourceInlineCompletion;
		this.source = source;
		filterText = filterText.replace(/\r\n|\r/g, '\n');
		insertText = filterText.replace(/\r\n|\r/g, '\n');
	}
	withRange(updatedRange) {
		return new InlineCompletionItem(
			this.filterText,
			this.command,
			updatedRange,
			this.insertText,
			this.snippetInfo,
			this.additionalTextEdits,
			this.sourceInlineCompletion,
			this.source
		);
	}
	hash() {
		return JSON.stringify({
			insertText: this.insertText,
			range: this.range.toString()
		});
	}
}
function getDefaultRange(position, model) {
	const word = model.getWordAtPosition(position);
	const maxColumn = model.getLineMaxColumn(position.lineNumber);
	return word
		? new Range(position.lineNumber, word.startColumn, position.lineNumber, maxColumn)
		: Range.fromPositions(position, position.with(undefined, maxColumn));
}
function closeBrackets(text2, position, model, languageConfigurationService) {
	const lineStart = model.getLineContent(position.lineNumber).substring(0, position.column - 1);
	const newLine = lineStart + text2;
	const newTokens = model.tokenization.tokenizeLineWithEdit(position, newLine.length - (position.column - 1), text2);
	const slicedTokens = newTokens?.sliceAndInflate(position.column - 1, newLine.length, 0);
	if (!slicedTokens) {
		return text2;
	}
	const newText = fixBracketsInLine(slicedTokens, languageConfigurationService);
	return newText;
}




// node_modules/monaco-editor/esm/vs/editor/contrib/inlineCompletions/browser/singleTextEdit.js

function singleTextRemoveCommonPrefix(edit, model, validModelRange) {
	const modelRange = validModelRange ? edit.range.intersectRanges(validModelRange) : edit.range;
	if (!modelRange) {
		return edit;
	}
	const valueToReplace = model.getValueInRange(
		modelRange,
		1 // LF
	);
	const commonPrefixLen = commonPrefixLength(valueToReplace, edit.text);
	const start = TextLength.ofText(valueToReplace.substring(0, commonPrefixLen)).addToPosition(edit.range.getStartPosition());
	const text2 = edit.text.substring(commonPrefixLen);
	const range2 = Range.fromPositions(start, edit.range.getEndPosition());
	return new SingleTextEdit(range2, text2);
}
function singleTextEditAugments(edit, base) {
	return edit.text.startsWith(base.text) && rangeExtends(edit.range, base.range);
}
function computeGhostText(edit, model, mode, cursorPosition, previewSuffixLength = 0) {
	let e = singleTextRemoveCommonPrefix(edit, model);
	if (e.range.endLineNumber !== e.range.startLineNumber) {
		return;
	}
	const sourceLine = model.getLineContent(e.range.startLineNumber);
	const sourceIndentationLength = getLeadingWhitespace(sourceLine).length;
	const suggestionTouchesIndentation = e.range.startColumn - 1 <= sourceIndentationLength;
	if (suggestionTouchesIndentation) {
		const suggestionAddedIndentationLength = getLeadingWhitespace(e.text).length;
		const replacedIndentation = sourceLine.substring(e.range.startColumn - 1, sourceIndentationLength);
		const [startPosition, endPosition] = [e.range.getStartPosition(), e.range.getEndPosition()];
		const newStartPosition =
			startPosition.column + replacedIndentation.length <= endPosition.column
				? startPosition.delta(0, replacedIndentation.length)
				: endPosition;
		const rangeThatDoesNotReplaceIndentation = Range.fromPositions(newStartPosition, endPosition);
		const suggestionWithoutIndentationChange = e.text.startsWith(replacedIndentation)
			? e.text.substring(replacedIndentation.length)
			: e.text.substring(suggestionAddedIndentationLength);
		e = new SingleTextEdit(rangeThatDoesNotReplaceIndentation, suggestionWithoutIndentationChange);
	}
	const valueToBeReplaced = model.getValueInRange(e.range);
	const changes = cachingDiff(valueToBeReplaced, e.text);
	if (!changes) {
		return;
	}
	const lineNumber = e.range.startLineNumber;
	const parts = new Array();
	if (mode === 'prefix') {
		const filteredChanges = changes.filter(c => c.originalLength === 0);
		if (filteredChanges.length > 1 || (filteredChanges.length === 1 && filteredChanges[0].originalStart !== valueToBeReplaced.length)) {
			return;
		}
	}
	const previewStartInCompletionText = e.text.length - previewSuffixLength;
	for (const c of changes) {
		const insertColumn = e.range.startColumn + c.originalStart + c.originalLength;
		if (
			mode === 'subwordSmart' &&
			cursorPosition &&
			cursorPosition.lineNumber === e.range.startLineNumber &&
			insertColumn < cursorPosition.column
		) {
			return;
		}
		if (c.originalLength > 0) {
			return;
		}
		if (c.modifiedLength === 0) {
			continue;
		}
		const modifiedEnd = c.modifiedStart + c.modifiedLength;
		const nonPreviewTextEnd = Math.max(c.modifiedStart, Math.min(modifiedEnd, previewStartInCompletionText));
		const nonPreviewText = e.text.substring(c.modifiedStart, nonPreviewTextEnd);
		const italicText = e.text.substring(nonPreviewTextEnd, Math.max(c.modifiedStart, modifiedEnd));
		if (nonPreviewText.length > 0) {
			parts.push(new GhostTextPart(insertColumn, nonPreviewText, false));
		}
		if (italicText.length > 0) {
			parts.push(new GhostTextPart(insertColumn, italicText, true));
		}
	}
	return new GhostText(lineNumber, parts);
}
function rangeExtends(extendingRange, rangeToExtend) {
	return (
		rangeToExtend.getStartPosition().equals(extendingRange.getStartPosition()) &&
		rangeToExtend.getEndPosition().isBeforeOrEqual(extendingRange.getEndPosition())
	);
}
var lastRequest = undefined;
function cachingDiff(originalValue, newValue) {
	if (lastRequest?.originalValue === originalValue && lastRequest?.newValue === newValue) {
		return lastRequest?.changes;
	} else {
		let changes = smartDiff(originalValue, newValue, true);
		if (changes) {
			const deletedChars = deletedCharacters(changes);
			if (deletedChars > 0) {
				const newChanges = smartDiff(originalValue, newValue, false);
				if (newChanges && deletedCharacters(newChanges) < deletedChars) {
					changes = newChanges;
				}
			}
		}
		lastRequest = { originalValue, newValue, changes };
		return changes;
	}
}
function deletedCharacters(changes) {
	let sum = 0;
	for (const c of changes) {
		sum += c.originalLength;
	}
	return sum;
}
function smartDiff(originalValue, newValue, smartBracketMatching) {
	if (originalValue.length > 5e3 || newValue.length > 5e3) {
		return;
	}
	function getMaxCharCode(val) {
		let maxCharCode2 = 0;
		for (let i = 0, len = val.length; i < len; i++) {
			const charCode = val.charCodeAt(i);
			if (charCode > maxCharCode2) {
				maxCharCode2 = charCode;
			}
		}
		return maxCharCode2;
	}
	const maxCharCode = Math.max(getMaxCharCode(originalValue), getMaxCharCode(newValue));
	function getUniqueCharCode(id) {
		if (id < 0) {
			throw new Error('unexpected');
		}
		return maxCharCode + id + 1;
	}
	function getElements(source) {
		let level = 0;
		let group = 0;
		const characters = new Int32Array(source.length);
		for (let i = 0, len = source.length; i < len; i++) {
			if (smartBracketMatching && source[i] === '(') {
				const id = group * 100 + level;
				characters[i] = getUniqueCharCode(2 * id);
				level++;
			} else if (smartBracketMatching && source[i] === ')') {
				level = Math.max(level - 1, 0);
				const id = group * 100 + level;
				characters[i] = getUniqueCharCode(2 * id + 1);
				if (level === 0) {
					group++;
				}
			} else {
				characters[i] = source.charCodeAt(i);
			}
		}
		return characters;
	}
	const elements1 = getElements(originalValue);
	const elements2 = getElements(newValue);
	return new LcsDiff({ getElements: () => elements1 }, { getElements: () => elements2 }).ComputeDiff(false).changes;
}



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// #inlineCompletionsModel

function getSecondaryEdits(textModel, positions, primaryEdit) {
	if (positions.length === 1) {
		return [];
	}
	const primaryPosition = positions[0];
	const secondaryPositions = positions.slice(1);
	const primaryEditStartPosition = primaryEdit.range.getStartPosition();
	const primaryEditEndPosition = primaryEdit.range.getEndPosition();
	const replacedTextAfterPrimaryCursor = textModel.getValueInRange(Range.fromPositions(primaryPosition, primaryEditEndPosition));
	const positionWithinTextEdit = subtractPositions(primaryPosition, primaryEditStartPosition);
	if (positionWithinTextEdit.lineNumber < 1) {
		onUnexpectedError(
			new BugIndicatingError(`positionWithinTextEdit line number should be bigger than 0.
			Invalid subtraction between ${primaryPosition.toString()} and ${primaryEditStartPosition.toString()}`)
		);
		return [];
	}
	function _substringPos(text2, pos) {
		let subtext = '';
		function _splitLinesIncludeSeparators(e) {
			const a = [];
			const b = e.split(lineBreakRE0);
			for (let i = 0; i < Math.ceil(b.length / 2); ++i) {
				const x = 2 * i;
				a.push(b[x] + (b[x + 1] ?? ''));
			}
			return a;
		}
		const lines = _splitLinesIncludeSeparators(text2);

		for (let i = pos.lineNumber - 1; i < lines.length; i++) {
			subtext += lines[i].substring(i === pos.lineNumber - 1 ? pos.column - 1 : 0);
		}
		return subtext;
	}
	const secondaryEditText = _substringPos(primaryEdit.text, positionWithinTextEdit);
	return secondaryPositions.map(pos => {
		const posEnd = addPositions(subtractPositions(pos, primaryEditStartPosition), primaryEditEndPosition);
		const textAfterSecondaryCursor = textModel.getValueInRange(Range.fromPositions(pos, posEnd));
		const l = commonPrefixLength(replacedTextAfterPrimaryCursor, textAfterSecondaryCursor);
		const range2 = Range.fromPositions(pos, pos.delta(0, l));
		return new SingleTextEdit(range2, secondaryEditText);
	});
}

function getEndPositionsAfterApplying(edits) {
	const sortPerm = Permutation.createSortPermutation(edits, (edit1, edit2) => Range.compareRangesUsingStarts(edit1.range, edit2.range));
	const edit = new TextEdit(sortPerm.apply(edits));
	const sortedNewRanges = edit.getNewRanges();
	const newRanges = sortPerm.inverse().apply(sortedNewRanges);
	return newRanges.map(range2 => range2.getEndPosition());
}

class InlineCompletionsModel extends Disposable {
	get isAcceptingPartially() {
		return this._isAcceptingPartially;
	}
	constructor(
		textModel,
		selectedSuggestItem,
		textModelVersionId,
		_positions,
		_debounceValue,
		_suggestPreviewEnabled,
		_suggestPreviewMode,
		_inlineSuggestMode,
		_enabled,
		_instantiationService,
		_commandService,
		_languageConfigurationService
	) {
		super();
		this.textModel = textModel;
		this.selectedSuggestItem = selectedSuggestItem;
		this.textModelVersionId = textModelVersionId;
		this._positions = _positions;
		this._debounceValue = _debounceValue;
		this._suggestPreviewEnabled = _suggestPreviewEnabled;
		this._suggestPreviewMode = _suggestPreviewMode;
		this._inlineSuggestMode = _inlineSuggestMode;
		this._enabled = _enabled;
		this._instantiationService = _instantiationService;
		this._commandService = _commandService;
		this._languageConfigurationService = _languageConfigurationService;
		this._source = this._register(
			this._instantiationService.createInstance(InlineCompletionsSource, this.textModel, this.textModelVersionId, this._debounceValue)
		);
		this._isActive = observableValue(this, false);
		this._forceUpdateExplicitlySignal = observableSignal(this);
		this._selectedInlineCompletionId = observableValue(this, undefined);
		this._primaryPosition = derived(this, reader => {
			return this._positions.read(reader)[0] ?? new Position(1, 1);
		});
		this._isAcceptingPartially = false;
		this._preserveCurrentCompletionReasons = new Set([
			1, //Redo
			0, //Undo
			2 //AcceptWord
		]);
		this._fetchInlineCompletionsPromise = derivedHandleChanges(
			{
				owner: this,
				createEmptyChangeSummary: () => ({
					preserveCurrentCompletion: false,
					inlineCompletionTriggerKind: 0 //Automatic
				}),
				handleChange: (ctx, changeSummary) => {
					if (ctx.didChange(this.textModelVersionId) && this._preserveCurrentCompletionReasons.has(ctx.change)) {
						changeSummary.preserveCurrentCompletion = true;
					} else if (ctx.didChange(this._forceUpdateExplicitlySignal)) {
						changeSummary.inlineCompletionTriggerKind = 1; //Explicit
					}
					return true;
				}
			},
			(reader, changeSummary) => {
				this._forceUpdateExplicitlySignal.read(reader);
				const shouldUpdate = (this._enabled.read(reader) && this.selectedSuggestItem.read(reader)) || this._isActive.read(reader);
				if (!shouldUpdate) {
					this._source.cancelUpdate();
					return;
				}
				this.textModelVersionId.read(reader);
				const suggestWidgetInlineCompletions = this._source.suggestWidgetInlineCompletions.get();
				const suggestItem = this.selectedSuggestItem.read(reader);
				if (suggestWidgetInlineCompletions && !suggestItem) {
					const inlineCompletions = this._source.inlineCompletions.get();
					transaction(tx => {
						if (!inlineCompletions || suggestWidgetInlineCompletions.request.versionId > inlineCompletions.request.versionId) {
							this._source.inlineCompletions.set(suggestWidgetInlineCompletions.clone(), tx);
						}
						this._source.clearSuggestWidgetInlineCompletions(tx);
					});
				}
				const cursorPosition = this._primaryPosition.read(reader);
				const context = {
					triggerKind: changeSummary.inlineCompletionTriggerKind,
					selectedSuggestionInfo: suggestItem?.toSelectedSuggestionInfo()
				};
				const itemToPreserveCandidate = this.selectedInlineCompletion.get();
				const itemToPreserve =
					changeSummary.preserveCurrentCompletion ||
					(itemToPreserveCandidate === null || itemToPreserveCandidate === undefined
						? undefined
						: itemToPreserveCandidate.forwardStable)
						? itemToPreserveCandidate
						: undefined;
				return this._source.fetch(cursorPosition, context, itemToPreserve);
			}
		);
		this._filteredInlineCompletionItems = derivedOpts({ owner: this, equalsFn: itemsEquals() }, reader => {
			const c = this._source.inlineCompletions.read(reader);
			if (!c) {
				return [];
			}
			const cursorPosition = this._primaryPosition.read(reader);
			const filteredCompletions = c.inlineCompletions.filter(c2 => c2.isVisible(this.textModel, cursorPosition, reader));
			return filteredCompletions;
		});
		this.selectedInlineCompletionIndex = derived(this, reader => {
			const selectedInlineCompletionId = this._selectedInlineCompletionId.read(reader);
			const filteredCompletions = this._filteredInlineCompletionItems.read(reader);
			const idx =
				this._selectedInlineCompletionId === undefined
					? -1
					: filteredCompletions.findIndex(v => v.semanticId === selectedInlineCompletionId);
			if (idx === -1) {
				this._selectedInlineCompletionId.set(undefined, undefined);
				return 0;
			}
			return idx;
		});
		this.selectedInlineCompletion = derived(this, reader => {
			const filteredCompletions = this._filteredInlineCompletionItems.read(reader);
			const idx = this.selectedInlineCompletionIndex.read(reader);
			return filteredCompletions[idx];
		});
		this.activeCommands = derivedOpts({ owner: this, equalsFn: itemsEquals() }, r => {
			return this.selectedInlineCompletion.read(r)?.inlineCompletion.source.inlineCompletions.commands ?? [];
		});
		this.lastTriggerKind = this._source.inlineCompletions.map(this, v => v?.request.context.triggerKind);
		this.inlineCompletionsCount = derived(this, reader => {
			if (
				1 === this.lastTriggerKind.read(reader) //Explicit
			) {
				return this._filteredInlineCompletionItems.read(reader).length;
			} else {
				return;
			}
		});
		this.state = derivedOpts(
			{
				owner: this,
				equalsFn: (a, b) => {
					if (!a || !b) {
						return a === b;
					}
					return (
						ghostTextsOrReplacementsEqual(a.ghostTexts, b.ghostTexts) &&
						a.inlineCompletion === b.inlineCompletion &&
						a.suggestItem === b.suggestItem
					);
				}
			},
			reader => {
				const model = this.textModel;
				const suggestItem = this.selectedSuggestItem.read(reader);
				if (suggestItem) {
					const suggestCompletionEdit = singleTextRemoveCommonPrefix(suggestItem.toSingleTextEdit(), model);
					const augmentation = this._computeAugmentation(suggestCompletionEdit, reader);
					const isSuggestionPreviewEnabled = this._suggestPreviewEnabled.read(reader);
					if (!isSuggestionPreviewEnabled && !augmentation) {
						return;
					}
					const fullEdit = augmentation?.edit ?? suggestCompletionEdit;
					const fullEditPreviewLength = augmentation ? augmentation.edit.text.length - suggestCompletionEdit.text.length : 0;
					const mode = this._suggestPreviewMode.read(reader);
					const positions = this._positions.read(reader);
					const edits = [fullEdit, ...getSecondaryEdits(this.textModel, positions, fullEdit)];
					const ghostTexts = edits
						.map((edit, idx) => computeGhostText(edit, model, mode, positions[idx], fullEditPreviewLength))
						.filter(notIsNullOrUndefined);
					const primaryGhostText = ghostTexts[0] ?? new GhostText(fullEdit.range.endLineNumber, []);
					return {
						edits,
						primaryGhostText,
						ghostTexts,
						inlineCompletion: augmentation?.completion,
						suggestItem
					};
				} else {
					if (!this._isActive.read(reader)) {
						return;
					}
					const inlineCompletion = this.selectedInlineCompletion.read(reader);
					if (!inlineCompletion) {
						return;
					}
					const replacement = inlineCompletion.toSingleTextEdit(reader);
					const mode = this._inlineSuggestMode.read(reader);
					const positions = this._positions.read(reader);
					const edits = [replacement, ...getSecondaryEdits(this.textModel, positions, replacement)];
					const ghostTexts = edits
						.map((edit, idx) => computeGhostText(edit, model, mode, positions[idx], 0))
						.filter(notIsNullOrUndefined);
					if (!ghostTexts[0]) {
						return;
					}
					return {
						edits,
						primaryGhostText: ghostTexts[0],
						ghostTexts,
						inlineCompletion,
						suggestItem: undefined
					};
				}
			}
		);
		this.ghostTexts = derivedOpts(
			{
				owner: this,
				equalsFn: ghostTextsOrReplacementsEqual
			},
			reader => {
				const v = this.state.read(reader);
				if (!v) {
					return;
				}
				return v.ghostTexts;
			}
		);
		this.primaryGhostText = derivedOpts(
			{
				owner: this,
				equalsFn: ghostTextOrReplacementEquals
			},
			reader => {
				const v = this.state.read(reader);
				if (!v) {
					return;
				}
				return v?.primaryGhostText;
			}
		);
		this._register(recomputeInitiallyAndOnChange(this._fetchInlineCompletionsPromise));
		let lastItem = undefined;
		this._register(
			autorun(reader => {
				const item = this.state.read(reader);
				const completion = item?.inlineCompletion;
				if (completion?.semanticId !== lastItem?.semanticId) {
					lastItem = completion;
					if (completion) {
						const i = completion.inlineCompletion;
						const src = i.source;
						const e = src.provider;
						e.handleItemDidShow?.call(e, src.inlineCompletions, i.sourceInlineCompletion, i.insertText);
					}
				}
			})
		);
	}
	async trigger(tx) {
		this._isActive.set(true, tx);
		await this._fetchInlineCompletionsPromise.get();
	}
	async triggerExplicitly(tx) {
		subtransaction(tx, tx2 => {
			this._isActive.set(true, tx2);
			this._forceUpdateExplicitlySignal.trigger(tx2);
		});
		await this._fetchInlineCompletionsPromise.get();
	}
	stop(tx) {
		subtransaction(tx, tx2 => {
			this._isActive.set(false, tx2);
			this._source.clear(tx2);
		});
	}
	_computeAugmentation(suggestCompletion, reader) {
		const model = this.textModel;
		const suggestWidgetInlineCompletions = this._source.suggestWidgetInlineCompletions.read(reader);
		const candidateInlineCompletions = suggestWidgetInlineCompletions
			? suggestWidgetInlineCompletions.inlineCompletions
			: [this.selectedInlineCompletion.read(reader)].filter(notIsNullOrUndefined);
		const augmentedCompletion = mapFindFirst(candidateInlineCompletions, completion => {
			let r = completion.toSingleTextEdit(reader);
			r = singleTextRemoveCommonPrefix(
				r,
				model,
				Range.fromPositions(r.range.getStartPosition(), suggestCompletion.range.getEndPosition())
			);
			return singleTextEditAugments(r, suggestCompletion) ? { completion, edit: r } : undefined;
		});
		return augmentedCompletion;
	}
	async _deltaSelectedInlineCompletionIndex(delta) {
		await this.triggerExplicitly();
		const completions = this._filteredInlineCompletionItems.get() || [];
		if (completions.length > 0) {
			const newIdx = (this.selectedInlineCompletionIndex.get() + delta + completions.length) % completions.length;
			this._selectedInlineCompletionId.set(completions[newIdx].semanticId, undefined);
		} else {
			this._selectedInlineCompletionId.set(undefined, undefined);
		}
	}
	async next() {
		await this._deltaSelectedInlineCompletionIndex(1);
	}
	async previous() {
		await this._deltaSelectedInlineCompletionIndex(-1);
	}
	async accept(editor2) {
		if (editor2.getModel() !== this.textModel) {
			throw new BugIndicatingError();
		}
		const state = this.state.get();
		if (!state || state.primaryGhostText.isEmpty() || !state.inlineCompletion) {
			return;
		}
		const completion = state.inlineCompletion.toInlineCompletion(undefined);
		editor2.pushUndoStop();
		if (completion.snippetInfo) {
			editor2.executeEdits('inlineSuggestion.accept', [
				EditOperation.replace(completion.range, ''),
				...completion.additionalTextEdits
			]);
			editor2.setPosition(completion.snippetInfo.range.getStartPosition(), 'inlineCompletionAccept');
			SnippetController2.get(editor2)?.insert(completion.snippetInfo.snippet, { undoStopBefore: false });
		} else {
			const edits = state.edits;
			const selections = getEndPositionsAfterApplying(edits).map(p => EditorSelection.fromPositions(p));
			editor2.executeEdits('inlineSuggestion.accept', [
				...edits.map(edit => EditOperation.replace(edit.range, edit.text)),
				...completion.additionalTextEdits
			]);
			editor2.setSelections(selections, 'inlineCompletionAccept');
		}
		if (completion.command) {
			completion.source.addRef();
		}
		transaction(tx => {
			this._source.clear(tx);
			this._isActive.set(false, tx);
		});
		if (completion.command) {
			await this._commandService
				.executeCommand(completion.command.id, ...(completion.command.arguments || []))
				.then(undefined, onUnexpectedExternalError);
			completion.source.removeRef();
		}
	}
	async acceptNextWord(editor2) {
		await this._acceptNext(
			editor2,
			(pos, text2) => {
				const langId = this.textModel.getLanguageIdAtPosition(pos.lineNumber, pos.column);
				const config = this._languageConfigurationService.getLanguageConfiguration(langId);
				const wordRegExp = new RegExp(config.wordDefinition.source, config.wordDefinition.flags.replace('g', ''));
				const m1 = text2.match(wordRegExp);
				let acceptUntilIndexExclusive = 0;
				if (m1 && m1.index !== undefined) {
					if (m1.index === 0) {
						acceptUntilIndexExclusive = m1[0].length;
					} else {
						acceptUntilIndexExclusive = m1.index;
					}
				} else {
					acceptUntilIndexExclusive = text2.length;
				}
				const wsRegExp = /\s+/g;
				const m2 = wsRegExp.exec(text2);
				if (m2 && m2.index !== undefined) {
					if (m2.index + m2[0].length < acceptUntilIndexExclusive) {
						acceptUntilIndexExclusive = m2.index + m2[0].length;
					}
				}
				return acceptUntilIndexExclusive;
			},
			0 // Word
		);
	}
	async acceptNextLine(editor2) {
		await this._acceptNext(
			editor2,
			(pos, text2) => {
				const m = text2.match(/\n/);
				if (m && m.index !== undefined) {
					return m.index + 1;
				}
				return text2.length;
			},
			1 // Line
		);
	}
	async _acceptNext(editor2, getAcceptUntilIndex, kind) {
		if (editor2.getModel() !== this.textModel) {
			throw new BugIndicatingError();
		}
		const state = this.state.get();
		if (!state || state.primaryGhostText.isEmpty() || !state.inlineCompletion) {
			return;
		}
		const ghostText = state.primaryGhostText;
		const completion = state.inlineCompletion.toInlineCompletion(undefined);
		if (completion.snippetInfo || completion.filterText !== completion.insertText) {
			await this.accept(editor2);
			return;
		}
		const firstPart = ghostText.parts[0];
		const ghostTextPos = new Position(ghostText.lineNumber, firstPart.column);
		const ghostTextVal = firstPart.text;
		const acceptUntilIndexExclusive = getAcceptUntilIndex(ghostTextPos, ghostTextVal);
		if (acceptUntilIndexExclusive === ghostTextVal.length && ghostText.parts.length === 1) {
			await this.accept(editor2);
			return;
		}
		const partialGhostTextVal = ghostTextVal.substring(0, acceptUntilIndexExclusive);
		const positions = this._positions.get();
		const cursorPosition = positions[0];
		completion.source.addRef();
		try {
			this._isAcceptingPartially = true;
			try {
				editor2.pushUndoStop();
				const replaceRange = Range.fromPositions(cursorPosition, ghostTextPos);
				const newText = editor2.getModel().getValueInRange(replaceRange) + partialGhostTextVal;
				const primaryEdit = new SingleTextEdit(replaceRange, newText);
				const edits = [primaryEdit, ...getSecondaryEdits(this.textModel, positions, primaryEdit)];
				const selections = getEndPositionsAfterApplying(edits).map(p => EditorSelection.fromPositions(p));
				editor2.executeEdits(
					'inlineSuggestion.accept',
					edits.map(edit => EditOperation.replace(edit.range, edit.text))
				);
				editor2.setSelections(selections, 'inlineCompletionPartialAccept');
			} finally {
				this._isAcceptingPartially = false;
			}
			if (completion.source.provider.handlePartialAccept) {
				const acceptedRange = Range.fromPositions(
					completion.range.getStartPosition(),
					TextLength.ofText(partialGhostTextVal).addToPosition(ghostTextPos)
				);
				const text2 = editor2.getModel().getValueInRange(
					acceptedRange,
					1
					// LF
				);
				completion.source.provider.handlePartialAccept(
					completion.source.inlineCompletions,
					completion.sourceInlineCompletion,
					text2.length,
					{
						kind
					}
				);
			}
		} finally {
			completion.source.removeRef();
		}
	}
	handleSuggestAccepted(item) {
		const itemEdit = singleTextRemoveCommonPrefix(item.toSingleTextEdit(), this.textModel);
		const augmentedCompletion = this._computeAugmentation(itemEdit, undefined);
		if (augmentedCompletion) {
			const inlineCompletion = augmentedCompletion.completion.inlineCompletion;
			const s = inlineCompletion.source;
			const e = s.provider;
			e.handlePartialAccept?.call(e, s.inlineCompletions, inlineCompletion.sourceInlineCompletion, itemEdit.text.length, { kind: 2 });
		}
	}
}

__decorate(
	[__param(9, IInstantiationService), __param(10, ICommandService), __param(11, ILanguageConfigurationService)],
	InlineCompletionsModel
);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// node_modules/monaco-editor/esm/vs/editor/contrib/suggest/browser/suggestWidgetRenderer.js

var suggestMoreInfoIcon = iconRegistry.registerIcon(
	'suggest-more-info',
	codicon_chevronRight,
	localize('Icon for more information in the suggest widget.')
);

class ColorExtractor {
	extract(item, out) {
		if (item.textLabel.match(ColorExtractor._regexStrict)) {
			out[0] = item.textLabel;
			return true;
		}
		if (item.completion.detail && item.completion.detail.match(ColorExtractor._regexStrict)) {
			out[0] = item.completion.detail;
			return true;
		}
		if (item.completion.documentation) {
			const value =
				typeof item.completion.documentation === 'string' ? item.completion.documentation : item.completion.documentation.value;
			const match2 = ColorExtractor._regexRelaxed.exec(value);
			if (match2 && (match2.index === 0 || match2.index + match2[0].length === value.length)) {
				out[0] = match2[0];
				return true;
			}
		}
		return false;
	}
}

ColorExtractor._regexRelaxed =
	/(#([\da-fA-F]{3}){1,2}|(rgb|hsl)a\(\s*(\d{1,3}%?\s*,\s*){3}(1|0?\.\d+)\)|(rgb|hsl)\(\s*\d{1,3}%?(\s*,\s*\d{1,3}%?){2}\s*\))/;
ColorExtractor._regexStrict = new RegExp(`^${ColorExtractor._regexRelaxed.source}$`, 'i');

var _completionItemColor = new ColorExtractor();

class ItemRenderer {
	constructor(_editor, _modelService, _languageService, _themeService) {
		this._editor = _editor;
		this._modelService = _modelService;
		this._languageService = _languageService;
		this._themeService = _themeService;
		this._onDidToggleDetails = new Emitter();
		this.onDidToggleDetails = this._onDidToggleDetails.event;
		this.templateId = 'suggestion';
	}
	dispose() {
		this._onDidToggleDetails.dispose();
	}
	renderTemplate(container) {
		const disposables = new DisposableStore();
		const root = container;
		root.classList.add('show-file-icons');
		const icon = append(container, $('.icon'));
		const colorspan = append(icon, $('span.colorspan'));
		const text2 = append(container, $('.contents'));
		const main = append(text2, $('.main'));
		const iconContainer = append(main, $('.icon-label.codicon'));
		const left = append(main, $('span.left'));
		const right = append(main, $('span.right'));
		const iconLabel = new IconLabel(left, { supportHighlights: true, supportIcons: true });
		disposables.add(iconLabel);
		const parametersLabel = append(left, $('span.signature-label'));
		const qualifierLabel = append(left, $('span.qualifier-label'));
		const detailsLabel = append(right, $('span.details-label'));
		const readMore = append(right, $('span.readMore' + asThemeIconCSSSelector(suggestMoreInfoIcon)));
		readMore.title = localize('Read More');
		const configureFont = () => {
			const options2 = this._editor.getOptions();
			const fontInfo = options2.get(
				50
				// fontInfo
			);
			const fontFamily = fontInfo.getMassagedFontFamily();
			const fontFeatureSettings = fontInfo.fontFeatureSettings;
			const fontSize =
				options2.get(
					119
					// suggestFontSize
				) || fontInfo.fontSize;
			const lineHeight =
				options2.get(
					120
					// suggestLineHeight
				) || fontInfo.lineHeight;
			const fontWeight = fontInfo.fontWeight;
			const letterSpacing = fontInfo.letterSpacing;
			const fontSizePx = `${fontSize}px`;
			const lineHeightPx = `${lineHeight}px`;
			const letterSpacingPx = `${letterSpacing}px`;
			root.style.fontSize = fontSizePx;
			root.style.fontWeight = fontWeight;
			root.style.letterSpacing = letterSpacingPx;
			main.style.fontFamily = fontFamily;
			main.style.fontFeatureSettings = fontFeatureSettings;
			main.style.lineHeight = lineHeightPx;
			icon.style.height = lineHeightPx;
			icon.style.width = lineHeightPx;
			readMore.style.height = lineHeightPx;
			readMore.style.width = lineHeightPx;
		};
		return {
			root,
			left,
			right,
			icon,
			colorspan,
			iconLabel,
			iconContainer,
			parametersLabel,
			qualifierLabel,
			detailsLabel,
			readMore,
			disposables,
			configureFont
		};
	}
	renderElement(element, index, data) {
		data.configureFont();
		const { completion } = element;

		data.colorspan.style.backgroundColor = '';
		const labelOptions = {
			labelEscapeNewLines: true,
			matches: createMatches(element.score)
		};
		const color = [];
		if (completion.kind === 19 && _completionItemColor.extract(element, color)) {
			data.icon.className = 'icon customcolor';
			data.iconContainer.className = 'icon hide';
			data.colorspan.style.backgroundColor = color[0];
		} else if (completion.kind === 20 && this._themeService.getFileIconTheme().hasFileIcons) {
			data.icon.className = 'icon hide';
			data.iconContainer.className = 'icon hide';
			const labelClasses = getIconClasses(
				this._modelService,
				this._languageService,
				URI.from({ scheme: 'fake', path: element.textLabel }),
				FileKind.FILE
			);
			const detailClasses = getIconClasses(
				this._modelService,
				this._languageService,
				URI.from({ scheme: 'fake', path: completion.detail }),
				FileKind.FILE
			);
			labelOptions.extraClasses = labelClasses.length > detailClasses.length ? labelClasses : detailClasses;
		} else if (completion.kind === 23 && this._themeService.getFileIconTheme().hasFolderIcons) {
			data.icon.className = 'icon hide';
			data.iconContainer.className = 'icon hide';
			labelOptions.extraClasses = [
				getIconClasses(
					this._modelService,
					this._languageService,
					URI.from({ scheme: 'fake', path: element.textLabel }),
					FileKind.FOLDER
				),
				getIconClasses(
					this._modelService,
					this._languageService,
					URI.from({ scheme: 'fake', path: completion.detail }),
					FileKind.FOLDER
				)
			].flat();
		} else {
			data.icon.className = 'icon hide';
			data.iconContainer.className = '';
			data.iconContainer.classList.add(
				'suggest-icon',
				...asThemeIconClassNameArray(completionItemKindsValuesCodiconMap.get(completion.kind) ?? codicon_symbolProperty)
			);
		}
		if (
			completion.tags &&
			completion.tags.indexOf(
				1 // Deprecated
			) >= 0
		) {
			labelOptions.extraClasses = (labelOptions.extraClasses || []).concat(['deprecated']);
			labelOptions.matches = [];
		}
		data.iconLabel.setLabel(element.textLabel, undefined, labelOptions);
		if (typeof completion.label === 'string') {
			data.parametersLabel.textContent = '';
			data.detailsLabel.textContent = stripNewLines(completion.detail || '');
			data.root.classList.add('string-label');
		} else {
			data.parametersLabel.textContent = stripNewLines(completion.label.detail || '');
			data.detailsLabel.textContent = stripNewLines(completion.label.description || '');
			data.root.classList.remove('string-label');
		}
		if (
			this._editor.getOption(
				118
				// suggest
			).showInlineDetails
		) {
			show(data.detailsLabel);
		} else {
			hide(data.detailsLabel);
		}
		if (canExpandCompletionItem(element)) {
			data.right.classList.add('can-expand-details');
			show(data.readMore);
			data.readMore.onmousedown = e => {
				e.stopPropagation();
				e.preventDefault();
			};
			data.readMore.onclick = e => {
				e.stopPropagation();
				e.preventDefault();
				this._onDidToggleDetails.fire();
			};
		} else {
			data.right.classList.remove('can-expand-details');
			hide(data.readMore);
			data.readMore.onmousedown = null;
			data.readMore.onclick = null;
		}
	}
	disposeTemplate(templateData) {
		templateData.disposables.dispose();
	}
}
__decorate([__param(1, IModelService), __param(2, ILanguageService), __param(3, IThemeService)], ItemRenderer);

function stripNewLines(str) {
	return str.replace(lineBreakRE2, '');
}

// node_modules/monaco-editor/esm/vs/editor/contrib/suggest/browser/suggestWidget.js

class PersistedWidgetSize {
	constructor(_service, editor2) {
		this._service = _service;
		this._key = `suggestWidget.size/${editor2.getEditorType()}/${editor2 instanceof EmbeddedCodeEditorWidget}`;
	}
	restore() {
		const raw =
			this._service.get(
				this._key,
				0
				/* StorageScope.PROFILE */
			) || '';
		try {
			const obj = JSON.parse(raw);
			if (Dimension.is(obj)) {
				return Dimension.lift(obj);
			}
		} catch (exception) {}
		return;
	}
	store(size2) {
		this._service.store(
			this._key,
			JSON.stringify(size2),
			0,
			1
			/* StorageTarget.MACHINE */
		);
	}
	reset() {
		this._service.remove(
			this._key,
			0
			/* StorageScope.PROFILE */
		);
	}
}

class SuggestWidget {
	constructor(editor2, _storageService, _contextKeyService, _themeService, instantiationService) {
		this.editor = editor2;
		this._storageService = _storageService;
		this._state = 0;
		this._isAuto = false;
		this._pendingLayout = new MutableDisposable();
		this._pendingShowDetails = new MutableDisposable();
		this._ignoreFocusEvents = false;
		this._forceRenderingAbove = false;
		this._explainMode = false;
		this._showTimeout = new TimeoutTimer();
		this._disposables = new DisposableStore();
		this._onDidSelect = new PauseableEmitter();
		this._onDidFocus = new PauseableEmitter();
		this._onDidHide = new Emitter();
		this._onDidShow = new Emitter();
		this.onDidSelect = this._onDidSelect.event;
		this.onDidFocus = this._onDidFocus.event;
		this.onDidHide = this._onDidHide.event;
		this.onDidShow = this._onDidShow.event;
		this._onDetailsKeydown = new Emitter();
		this.onDetailsKeyDown = this._onDetailsKeydown.event;
		this.element = new ResizableHTMLElement();
		this.element.domNode.classList.add('editor-widget', 'suggest-widget');
		this._contentWidget = new SuggestContentWidget(this, editor2);
		this._persistedSize = new PersistedWidgetSize(_storageService, editor2);
		class ResizeState {
			constructor(persistedSize, currentSize, persistHeight = false, persistWidth = false) {
				this.persistedSize = persistedSize;
				this.currentSize = currentSize;
				this.persistHeight = persistHeight;
				this.persistWidth = persistWidth;
			}
		}
		let state;
		this._disposables.add(
			this.element.onDidWillResize(() => {
				this._contentWidget.lockPreference();
				state = new ResizeState(this._persistedSize.restore(), this.element.size);
			})
		);
		this._disposables.add(
			this.element.onDidResize(e => {
				this._resize(e.dimension.width, e.dimension.height);
				if (state) {
					state.persistHeight = state.persistHeight || !!e.north || !!e.south;
					state.persistWidth = state.persistWidth || !!e.east || !!e.west;
				}
				if (!e.done) {
					return;
				}
				if (state) {
					const { itemHeight, defaultSize } = this.getLayoutInfo();
					const threshold = Math.round(itemHeight / 2);
					let { width: width2, height } = this.element.size;
					if (!state.persistHeight || Math.abs(state.currentSize.height - height) <= threshold) {
						height = state.persistedSize?.height ?? defaultSize.height;
					}
					if (!state.persistWidth || Math.abs(state.currentSize.width - width2) <= threshold) {
						width2 = state.persistedSize?.width ?? defaultSize.width;
					}
					this._persistedSize.store(new Dimension(width2, height));
				}
				this._contentWidget.unlockPreference();
				state = undefined;
			})
		);
		this._messageElement = append(this.element.domNode, $('.message'));
		this._listElement = append(this.element.domNode, $('.tree'));
		const details = this._disposables.add(instantiationService.createInstance(SuggestDetailsWidget, this.editor));
		details.onDidClose(this.toggleDetails, this, this._disposables);
		this._details = new SuggestDetailsOverlay(details, this.editor);
		const applyIconStyle = () =>
			this.element.domNode.classList.toggle(
				'no-icons',
				!this.editor.getOption(
					118
					// suggest
				).showIcons
			);
		applyIconStyle();
		const renderer = instantiationService.createInstance(ItemRenderer, this.editor);
		this._disposables.add(renderer);
		this._disposables.add(renderer.onDidToggleDetails(() => this.toggleDetails()));
		this._list = new List(
			'SuggestWidget',
			this._listElement,
			{
				getHeight: _element => this.getLayoutInfo().itemHeight,
				getTemplateId: _element => 'suggestion'
			},
			[renderer],
			{
				alwaysConsumeMouseWheel: true,
				useShadows: false,
				mouseSupport: false,
				multipleSelectionSupport: false
			}
		);
		this._list.style(
			getListStyles({
				listInactiveFocusBackground: colorId_suggestWidgetSelected_background,
				listInactiveFocusOutline: colorId_activeContrast_border
			})
		);
		this._status = instantiationService.createInstance(SuggestWidgetStatus, this.element.domNode, suggestWidgetStatusbar_menuId);
		const applyStatusBarStyle = () =>
			this.element.domNode.classList.toggle(
				'with-status-bar',
				this.editor.getOption(
					118
					// suggest
				).showStatusBar
			);
		applyStatusBarStyle();
		this._disposables.add(_themeService.onDidColorThemeChange(t => this._onThemeChange(t)));
		this._onThemeChange(_themeService.getColorTheme());
		this._disposables.add(this._list.onMouseDown(e => this._onListMouseDownOrTap(e)));
		this._disposables.add(this._list.onTap(e => this._onListMouseDownOrTap(e)));
		this._disposables.add(this._list.onDidChangeSelection(e => this._onListSelection(e)));
		this._disposables.add(this._list.onDidChangeFocus(e => this._onListFocus(e)));
		this._disposables.add(this.editor.onDidChangeCursorSelection(() => this._onCursorSelectionChanged()));
		this._disposables.add(
			this.editor.onDidChangeConfiguration(e => {
				if (
					e.hasChanged(
						118
						// suggest
					)
				) {
					applyStatusBarStyle();
					applyIconStyle();
				}
				if (
					this._completionModel &&
					(e.hasChanged(
						50
						// fontInfo
					) ||
						e.hasChanged(
							119
							// suggestFontSize
						) ||
						e.hasChanged(
							120
							// suggestLineHeight
						))
				) {
					this._list.splice(0, this._list.length, this._completionModel.items);
				}
			})
		);
		this._ctxSuggestWidgetVisible = Context2.Visible.bindTo(_contextKeyService);
		this._ctxSuggestWidgetDetailsVisible = Context2.DetailsVisible.bindTo(_contextKeyService);
		this._ctxSuggestWidgetMultipleSuggestions = Context2.MultipleSuggestions.bindTo(_contextKeyService);
		this._ctxSuggestWidgetHasFocusedSuggestion = Context2.HasFocusedSuggestion.bindTo(_contextKeyService);
		this._disposables.add(
			addStandardDisposableListener(this._details.widget.domNode, 'keydown', e => {
				this._onDetailsKeydown.fire(e);
			})
		);
		this._disposables.add(this.editor.onMouseDown(e => this._onEditorMouseDown(e)));
	}
	dispose() {
		this._details.widget.dispose();
		this._details.dispose();
		this._list.dispose();
		this._status.dispose();
		this._disposables.dispose();
		this._loadingTimeout?.dispose();
		this._pendingLayout.dispose();
		this._pendingShowDetails.dispose();
		this._showTimeout.dispose();
		this._contentWidget.dispose();
		this.element.dispose();
	}
	_onEditorMouseDown(mouseEvent) {
		if (this._details.widget.domNode.contains(mouseEvent.target.element)) {
			this._details.widget.domNode.focus();
		} else {
			if (this.element.domNode.contains(mouseEvent.target.element)) {
				this.editor.focus();
			}
		}
	}
	_onCursorSelectionChanged() {
		if (this._state !== 0) {
			this._contentWidget.layout();
		}
	}
	_onListMouseDownOrTap(e) {
		if (typeof e.element === 'undefined' || typeof e.index === 'undefined') {
			return;
		}
		e.browserEvent.preventDefault();
		e.browserEvent.stopPropagation();
		this._select(e.element, e.index);
	}
	_onListSelection(e) {
		if (e.elements.length) {
			this._select(e.elements[0], e.indexes[0]);
		}
	}
	_select(item, index) {
		const completionModel = this._completionModel;
		if (completionModel) {
			this._onDidSelect.fire({ item, index, model: completionModel });
			this.editor.focus();
		}
	}
	_onThemeChange(theme) {
		this._details.widget.borderWidth = isHighContrast(theme.type) ? 2 : 1;
	}
	_onListFocus(e) {
		if (!this._ignoreFocusEvents) {
			if (!e.elements.length) {
				if (this._currentSuggestionDetails) {
					this._currentSuggestionDetails.cancel();
					this._currentSuggestionDetails = undefined;
					this._focusedItem = undefined;
				}

				this._ctxSuggestWidgetHasFocusedSuggestion.set(false);
				return;
			}
			if (!this._completionModel) {
				return;
			}
			this._ctxSuggestWidgetHasFocusedSuggestion.set(true);
			const item = e.elements[0];
			const index = e.indexes[0];
			if (item !== this._focusedItem) {
				this._currentSuggestionDetails?.cancel();
				this._currentSuggestionDetails = undefined;
				this._focusedItem = item;
				this._list.reveal(index);
				this._currentSuggestionDetails = createCancelablePromise(async token => {
					const loading = disposableTimeout(() => {
						if (this._isDetailsVisible()) {
							this.showDetails(true);
						}
					}, 250);
					const sub = token.onCancellationRequested(() => loading.dispose());
					try {
						return await item.resolve(token);
					} finally {
						loading.dispose();
						sub.dispose();
					}
				});
				this._currentSuggestionDetails
					.then(() => {
						if (index >= this._list.length || item !== this._list.element(index)) {
							return;
						}
						this._ignoreFocusEvents = true;
						this._list.splice(index, 1, [item]);
						this._list.setFocus([index]);
						this._ignoreFocusEvents = false;
						if (this._isDetailsVisible()) {
							this.showDetails(false);
						} else {
							this.element.domNode.classList.remove('docs-side');
						}
					})
					.catch(onUnexpectedError);
			}
			this._onDidFocus.fire({ item, index, model: this._completionModel });
		}
	}
	_setState(state) {
		if (this._state === state) {
			return;
		}
		this._state = state;
		this.element.domNode.classList.toggle(
			'frozen',
			state === 4
			/* State.Frozen */
		);
		this.element.domNode.classList.remove('message');
		switch (state) {
			case 0:
				hide(this._messageElement, this._listElement, this._status.element);
				this._details.hide(true);
				this._status.hide();
				this._contentWidget.hide();
				this._ctxSuggestWidgetVisible.reset();
				this._ctxSuggestWidgetMultipleSuggestions.reset();
				this._ctxSuggestWidgetHasFocusedSuggestion.reset();
				this._showTimeout.cancel();
				this.element.domNode.classList.remove('visible');
				this._list.splice(0, this._list.length);
				this._focusedItem = undefined;
				this._cappedHeight = undefined;
				this._explainMode = false;
				break;
			case 1:
				this.element.domNode.classList.add('message');
				this._messageElement.textContent = SuggestWidget.LOADING_MESSAGE;
				hide(this._listElement, this._status.element);
				show(this._messageElement);
				this._details.hide();
				this._show();
				this._focusedItem = undefined;

				break;
			case 2:
				this.element.domNode.classList.add('message');
				this._messageElement.textContent = SuggestWidget.NO_SUGGESTIONS_MESSAGE;
				hide(this._listElement, this._status.element);
				show(this._messageElement);
				this._details.hide();
				this._show();
				this._focusedItem = undefined;

				break;
			case 3:
				hide(this._messageElement);
				show(this._listElement, this._status.element);
				this._show();
				break;
			case 4:
				hide(this._messageElement);
				show(this._listElement, this._status.element);
				this._show();
				break;
			case 5:
				hide(this._messageElement);
				show(this._listElement, this._status.element);
				this._details.show();
				this._show();
				break;
		}
	}
	_show() {
		this._status.show();
		this._contentWidget.show();
		this._layout(this._persistedSize.restore());
		this._ctxSuggestWidgetVisible.set(true);
		this._showTimeout.cancelAndSet(() => {
			this.element.domNode.classList.add('visible');
			this._onDidShow.fire(this);
		}, 100);
	}
	showTriggered(auto, delay) {
		if (this._state !== 0) {
			return;
		}
		this._contentWidget.setPosition(this.editor.getPosition());
		this._isAuto = !!auto;
		if (!this._isAuto) {
			this._loadingTimeout = disposableTimeout(
				() =>
					this._setState(
						1
						/* State.Loading */
					),
				delay
			);
		}
	}
	showSuggestions(completionModel, selectionIndex, isFrozen2, isAuto, noFocus) {
		this._contentWidget.setPosition(this.editor.getPosition());
		this._loadingTimeout?.dispose();

		this._currentSuggestionDetails?.cancel();

		this._currentSuggestionDetails = undefined;
		if (this._completionModel !== completionModel) {
			this._completionModel = completionModel;
		}
		if (isFrozen2 && this._state !== 2 && this._state !== 0) {
			this._setState(
				4 //Frozen
			);
			return;
		}
		const visibleCount = this._completionModel.items.length;
		const isEmpty = visibleCount === 0;
		this._ctxSuggestWidgetMultipleSuggestions.set(visibleCount > 1);
		if (isEmpty) {
			this._setState(
				isAuto ? 0 : 2 //State.Empty
			);
			this._completionModel = undefined;
			return;
		}
		this._focusedItem = undefined;
		this._onDidFocus.pause();
		this._onDidSelect.pause();
		try {
			this._list.splice(0, this._list.length, this._completionModel.items);
			this._setState(
				isFrozen2 ? 4 : 3
				/* State.Open */
			);
			this._list.reveal(selectionIndex, 0);
			this._list.setFocus(noFocus ? [] : [selectionIndex]);
		} finally {
			this._onDidFocus.resume();
			this._onDidSelect.resume();
		}
		this._pendingLayout.value = runAtThisOrScheduleAtNextAnimationFrame(getWindow(this.element.domNode), () => {
			this._pendingLayout.clear();
			this._layout(this.element.size);
			this._details.widget.domNode.classList.remove('focused');
		});
	}
	focusSelected() {
		if (this._list.length > 0) {
			this._list.setFocus([0]);
		}
	}
	selectNextPage() {
		switch (this._state) {
			case 0:
				return false;
			case 5:
				this._details.widget.pageDown();
				return true;
			case 1:
				return !this._isAuto;
			default:
				this._list.focusNextPage();
				return true;
		}
	}
	selectNext() {
		switch (this._state) {
			case 0:
				return false;
			case 1:
				return !this._isAuto;
			default:
				this._list.focusNext(1, true);
				return true;
		}
	}
	selectLast() {
		switch (this._state) {
			case 0:
				return false;
			case 5:
				this._details.widget.scrollBottom();
				return true;
			case 1:
				return !this._isAuto;
			default:
				this._list.focusLast();
				return true;
		}
	}
	selectPreviousPage() {
		switch (this._state) {
			case 0:
				return false;
			case 5:
				this._details.widget.pageUp();
				return true;
			case 1:
				return !this._isAuto;
			default:
				this._list.focusPreviousPage();
				return true;
		}
	}
	selectPrevious() {
		switch (this._state) {
			case 0:
				return false;
			case 1:
				return !this._isAuto;
			default:
				this._list.focusPrevious(1, true);
				return false;
		}
	}
	selectFirst() {
		switch (this._state) {
			case 0:
				return false;
			case 5:
				this._details.widget.scrollTop();
				return true;
			case 1:
				return !this._isAuto;
			default:
				this._list.focusFirst();
				return true;
		}
	}
	getFocusedItem() {
		if (this._state !== 0 && this._state !== 2 && this._state !== 1 && this._completionModel && this._list.getFocus().length > 0) {
			return {
				item: this._list.getFocusedElements()[0],
				index: this._list.getFocus()[0],
				model: this._completionModel
			};
		}
		return;
	}
	toggleDetailsFocus() {
		if (this._state === 5) {
			this._setState(
				3
				/* State.Open */
			);
			this._details.widget.domNode.classList.remove('focused');
		} else if (this._state === 3 && this._isDetailsVisible()) {
			this._setState(
				5
				/* State.Details */
			);
			this._details.widget.domNode.classList.add('focused');
		}
	}
	toggleDetails() {
		if (this._isDetailsVisible()) {
			this._pendingShowDetails.clear();
			this._ctxSuggestWidgetDetailsVisible.set(false);
			this._setDetailsVisible(false);
			this._details.hide();
			this.element.domNode.classList.remove('shows-details');
		} else if (
			(canExpandCompletionItem(this._list.getFocusedElements()[0]) || this._explainMode) &&
			(this._state === 3 || this._state === 5 || this._state === 4)
		) {
			this._ctxSuggestWidgetDetailsVisible.set(true);
			this._setDetailsVisible(true);
			this.showDetails(false);
		}
	}
	showDetails(loading) {
		this._pendingShowDetails.value = runAtThisOrScheduleAtNextAnimationFrame(getWindow(this.element.domNode), () => {
			this._pendingShowDetails.clear();
			this._details.show();
			if (loading) {
				this._details.widget.renderLoading();
			} else {
				this._details.widget.renderItem(this._list.getFocusedElements()[0], this._explainMode);
			}
			if (!this._details.widget.isEmpty) {
				this._positionDetails();
				this.element.domNode.classList.add('shows-details');
			} else {
				this._details.hide();
			}
			this.editor.focus();
		});
	}
	toggleExplainMode() {
		if (this._list.getFocusedElements()[0]) {
			this._explainMode = !this._explainMode;
			if (!this._isDetailsVisible()) {
				this.toggleDetails();
			} else {
				this.showDetails(false);
			}
		}
	}
	resetPersistedSize() {
		this._persistedSize.reset();
	}
	hideWidget() {
		this._pendingLayout.clear();
		this._pendingShowDetails.clear();
		this._loadingTimeout?.dispose();
		this._setState(
			0
			/* State.Hidden */
		);
		this._onDidHide.fire(this);
		this.element.clearSashHoverState();
		const dim = this._persistedSize.restore();
		const minPersistedHeight = Math.ceil(this.getLayoutInfo().itemHeight * 4.3);
		if (dim && dim.height < minPersistedHeight) {
			this._persistedSize.store(dim.with(undefined, minPersistedHeight));
		}
	}
	isFrozen() {
		return this._state === 4;
	}
	_afterRender(position) {
		if (position === null) {
			if (this._isDetailsVisible()) {
				this._details.hide();
			}
			return;
		}
		if (this._state === 2 || this._state === 1) {
			return;
		}
		if (this._isDetailsVisible() && !this._details.widget.isEmpty) {
			this._details.show();
		}
		this._positionDetails();
	}
	_layout(size2) {
		if (this.editor.hasModel() && this.editor.getDomNode()) {
			const bodyBox = getClientArea(this.element.domNode.ownerDocument.body);
			const info = this.getLayoutInfo();
			if (!size2) {
				size2 = info.defaultSize;
			}
			let height = size2.height;
			let width2 = size2.width;
			this._status.element.style.height = `${info.itemHeight}px`;
			if (this._state === 2 || this._state === 1) {
				height = info.itemHeight + info.borderHeight;
				width2 = info.defaultSize.width / 2;
				this.element.enableSashes(false, false, false, false);
				this.element.minSize = this.element.maxSize = new Dimension(width2, height);
				this._contentWidget.setPreference(
					2
					// BELOW
				);
			} else {
				const maxWidth = bodyBox.width - info.borderHeight - 2 * info.horizontalPadding;
				if (width2 > maxWidth) {
					width2 = maxWidth;
				}
				const preferredWidth = this._completionModel
					? this._completionModel.stats.pLabelLen * info.typicalHalfwidthCharacterWidth
					: width2;
				const fullHeight = info.statusBarHeight + this._list.contentHeight + info.borderHeight;
				const minHeight = info.itemHeight + info.statusBarHeight;
				const editorBox = getDomNodePagePosition(this.editor.getDomNode());
				const cursorBox = this.editor.getScrolledVisiblePosition(this.editor.getPosition());
				const cursorBottom = editorBox.top + cursorBox.top + cursorBox.height;
				const maxHeightBelow = Math.min(bodyBox.height - cursorBottom - info.verticalPadding, fullHeight);
				const availableSpaceAbove = editorBox.top + cursorBox.top - info.verticalPadding;
				const maxHeightAbove = Math.min(availableSpaceAbove, fullHeight);
				let maxHeight = Math.min(Math.max(maxHeightAbove, maxHeightBelow) + info.borderHeight, fullHeight);
				if (height === this._cappedHeight?.capped) {
					height = this._cappedHeight.wanted;
				}
				if (height < minHeight) {
					height = minHeight;
				}
				if (height > maxHeight) {
					height = maxHeight;
				}
				const forceRenderingAboveRequiredSpace = 150;
				if (height > maxHeightBelow || (this._forceRenderingAbove && availableSpaceAbove > forceRenderingAboveRequiredSpace)) {
					this._contentWidget.setPreference(
						1
						// ABOVE
					);
					this.element.enableSashes(true, true, false, false);
					maxHeight = maxHeightAbove;
				} else {
					this._contentWidget.setPreference(
						2
						// BELOW
					);
					this.element.enableSashes(false, true, true, false);
					maxHeight = maxHeightBelow;
				}
				this.element.preferredSize = new Dimension(preferredWidth, info.defaultSize.height);
				this.element.maxSize = new Dimension(maxWidth, maxHeight);
				this.element.minSize = new Dimension(220, minHeight);
				this._cappedHeight =
					height === fullHeight
						? {
								wanted: this._cappedHeight?.wanted ?? size2.height,
								capped: height
							}
						: undefined;
			}
			this._resize(width2, height);
		}
	}
	_resize(width2, height) {
		const { width: maxWidth, height: maxHeight } = this.element.maxSize;
		width2 = Math.min(maxWidth, width2);
		height = Math.min(maxHeight, height);
		const { statusBarHeight } = this.getLayoutInfo();
		this._list.layout(height - statusBarHeight, width2);
		this._listElement.style.height = `${height - statusBarHeight}px`;
		this.element.layout(height, width2);
		this._contentWidget.layout();
		this._positionDetails();
	}
	_positionDetails() {
		if (this._isDetailsVisible()) {
			this._details.placeAtAnchor(
				this.element.domNode,
				this._contentWidget.getPosition()?.preference[0] === 2
				// BELOW
			);
		}
	}
	getLayoutInfo() {
		const fontInfo = this.editor.getOption(
			50
			// fontInfo
		);
		const itemHeight = clamp(
			this.editor.getOption(
				120
				// suggestLineHeight
			) || fontInfo.lineHeight,
			8,
			1e3
		);
		const statusBarHeight =
			!this.editor.getOption(
				118
				// suggest
			).showStatusBar ||
			this._state === 2 ||
			this._state === 1
				? 0
				: itemHeight;
		const borderWidth = this._details.widget.borderWidth;
		const borderHeight = 2 * borderWidth;
		return {
			itemHeight,
			statusBarHeight,
			borderWidth,
			borderHeight,
			typicalHalfwidthCharacterWidth: fontInfo.typicalHalfwidthCharacterWidth,
			verticalPadding: 22,
			horizontalPadding: 14,
			defaultSize: new Dimension(430, statusBarHeight + 12 * itemHeight + borderHeight)
		};
	}
	_isDetailsVisible() {
		return this._storageService.getBoolean('expandSuggestionDocs', 0, false);
	}
	_setDetailsVisible(value) {
		this._storageService.store(
			'expandSuggestionDocs',
			value,
			0,
			0
			/* StorageTarget.USER */
		);
	}
	forceRenderingAbove() {
		if (!this._forceRenderingAbove) {
			this._forceRenderingAbove = true;
			this._layout(this._persistedSize.restore());
		}
	}
	stopForceRenderingAbove() {
		this._forceRenderingAbove = false;
	}
}
SuggestWidget.LOADING_MESSAGE = localize('Loading...');
SuggestWidget.NO_SUGGESTIONS_MESSAGE = localize('No suggestions.');
__decorate(
	[__param(1, IStorageService), __param(2, IContextKeyService), __param(3, IThemeService), __param(4, IInstantiationService)],
	SuggestWidget
);

class SuggestContentWidget {
	constructor(_widget, _editor) {
		this._widget = _widget;
		this._editor = _editor;
		this.allowEditorOverflow = true;
		this.suppressMouseDown = false;
		this._preferenceLocked = false;
		this._added = false;
		this._hidden = false;
	}
	dispose() {
		if (this._added) {
			this._added = false;
			this._editor.removeContentWidget(this);
		}
	}
	getId() {
		return 'editor.widget.suggestWidget';
	}
	getDomNode() {
		return this._widget.element.domNode;
	}
	show() {
		this._hidden = false;
		if (!this._added) {
			this._added = true;
			this._editor.addContentWidget(this);
		}
	}
	hide() {
		if (!this._hidden) {
			this._hidden = true;
			this.layout();
		}
	}
	layout() {
		this._editor.layoutContentWidget(this);
	}
	getPosition() {
		if (this._hidden || !this._position || !this._preference) {
			return null;
		}
		return {
			position: this._position,
			preference: [this._preference]
		};
	}
	beforeRender() {
		const { height, width: width2 } = this._widget.element.size;
		const { borderWidth, horizontalPadding } = this._widget.getLayoutInfo();
		return new Dimension(width2 + 2 * borderWidth + horizontalPadding, height + 2 * borderWidth);
	}
	afterRender(position) {
		this._widget._afterRender(position);
	}
	setPreference(preference) {
		if (!this._preferenceLocked) {
			this._preference = preference;
		}
	}
	lockPreference() {
		this._preferenceLocked = true;
	}
	unlockPreference() {
		this._preferenceLocked = false;
	}
	setPosition(position) {
		this._position = position;
	}
}

// node_modules/monaco-editor/esm/vs/editor/contrib/suggest/browser/suggestController.js

var _sticky2 = false;
class LineSuffix {
	constructor(_model, _position) {
		this._model = _model;
		this._position = _position;
		this._decorationOptions = ModelDecorationOptions.register({
			description: 'suggest-line-suffix',
			stickiness: 1
			// NeverGrowsWhenTypingAtEdges
		});
		const maxColumn = _model.getLineMaxColumn(_position.lineNumber);
		if (maxColumn !== _position.column) {
			const offset = _model.getOffsetAt(_position);
			const end = _model.getPositionAt(offset + 1);
			_model.changeDecorations(accessor => {
				if (this._marker) {
					accessor.removeDecoration(this._marker);
				}
				this._marker = accessor.addDecoration(Range.fromPositions(_position, end), this._decorationOptions);
			});
		}
	}
	dispose() {
		if (this._marker && !this._model.isDisposed()) {
			this._model.changeDecorations(accessor => {
				accessor.removeDecoration(this._marker);
				this._marker = undefined;
			});
		}
	}
	delta(position) {
		if (this._model.isDisposed() || this._position.lineNumber !== position.lineNumber) {
			return 0;
		}
		if (this._marker) {
			const range2 = this._model.getDecorationRange(this._marker);
			const end = this._model.getOffsetAt(range2.getStartPosition());
			return end - this._model.getOffsetAt(position);
		} else {
			return this._model.getLineMaxColumn(position.lineNumber) - position.column;
		}
	}
}

class SuggestController {
	static get(editor2) {
		return editor2.getContribution(SuggestController.ID);
	}
	constructor(editor2, _memoryService, _commandService, _contextKeyService, _instantiationService) {
		this._memoryService = _memoryService;
		this._commandService = _commandService;
		this._contextKeyService = _contextKeyService;
		this._instantiationService = _instantiationService;

		this._lineSuffix = new MutableDisposable();
		this._toDispose = new DisposableStore();
		this._selectors = new PriorityRegistry(s => s.priority);
		this._onWillInsertSuggestItem = new Emitter();
		this.onWillInsertSuggestItem = this._onWillInsertSuggestItem.event;
		this.editor = editor2;
		this.model = _instantiationService.createInstance(SuggestModel, this.editor);
		this._selectors.register({
			priority: 0,
			select: (model, pos, items) => this._memoryService.select(model, pos, items)
		});
		const ctxInsertMode = Context2.InsertMode.bindTo(_contextKeyService);
		ctxInsertMode.set(
			editor2.getOption(
				118
				// suggest
			).insertMode
		);
		this._toDispose.add(
			this.model.onDidTrigger(() =>
				ctxInsertMode.set(
					editor2.getOption(
						118
						// suggest
					).insertMode
				)
			)
		);
		this.widget = this._toDispose.add(
			new WindowIdleValue(getWindow(editor2.getDomNode()), () => {
				const widget = this._instantiationService.createInstance(SuggestWidget, this.editor);
				this._toDispose.add(widget);
				this._toDispose.add(
					widget.onDidSelect(
						item =>
							this._insertSuggestion(
								item,
								0
								/* InsertFlags.None */
							),
						this
					)
				);
				const commitCharacterController = new CommitCharacterController(this.editor, widget, this.model, item =>
					this._insertSuggestion(
						item,
						2
						/* InsertFlags.NoAfterUndoStop */
					)
				);
				this._toDispose.add(commitCharacterController);
				const ctxMakesTextEdit = Context2.MakesTextEdit.bindTo(this._contextKeyService);
				const ctxHasInsertAndReplace = Context2.HasInsertAndReplaceRange.bindTo(this._contextKeyService);
				const ctxCanResolve = Context2.CanResolve.bindTo(this._contextKeyService);
				this._toDispose.add(
					toDisposable(() => {
						ctxMakesTextEdit.reset();
						ctxHasInsertAndReplace.reset();
						ctxCanResolve.reset();
					})
				);
				this._toDispose.add(
					widget.onDidFocus(({ item }) => {
						const position = this.editor.getPosition();
						const startColumn = item.editStart.column;
						const endColumn = position.column;
						let value = true;
						if (
							this.editor.getOption(
								1
								// acceptSuggestionOnEnter
							) === 'smart' &&
							this.model.state === 2 &&
							!item.completion.additionalTextEdits &&
							!(item.completion.insertTextRules & 4) &&
							endColumn - startColumn === item.completion.insertText.length
						) {
							const oldText = this.editor.getModel().getValueInRange({
								startLineNumber: position.lineNumber,
								startColumn,
								endLineNumber: position.lineNumber,
								endColumn
							});
							value = oldText !== item.completion.insertText;
						}
						ctxMakesTextEdit.set(value);
						ctxHasInsertAndReplace.set(!Position.equals(item.editInsertEnd, item.editReplaceEnd));
						ctxCanResolve.set(
							Boolean(item.provider.resolveCompletionItem) ||
								Boolean(item.completion.documentation) ||
								item.completion.detail !== item.completion.label
						);
					})
				);
				this._toDispose.add(
					widget.onDetailsKeyDown(e => {
						if (
							e.toKeyCodeChord().equals(
								new KeyCodeChord(
									true,
									false,
									false,
									false,
									33
									/* KeyCode.KeyC */
								)
							) ||
							(isMacintosh &&
								e.toKeyCodeChord().equals(
									new KeyCodeChord(
										false,
										false,
										false,
										true,
										33
										/* KeyCode.KeyC */
									)
								))
						) {
							e.stopPropagation();
							return;
						}
						if (!e.toKeyCodeChord().isModifierKey()) {
							this.editor.focus();
						}
					})
				);
				return widget;
			})
		);
		this._overtypingCapturer = this._toDispose.add(
			new WindowIdleValue(getWindow(editor2.getDomNode()), () => {
				return this._toDispose.add(new OvertypingCapturer(this.editor, this.model));
			})
		);
		this._alternatives = this._toDispose.add(
			new WindowIdleValue(getWindow(editor2.getDomNode()), () => {
				return this._toDispose.add(new SuggestAlternatives(this.editor, this._contextKeyService));
			})
		);
		this._toDispose.add(_instantiationService.createInstance(WordContextKey, editor2));
		this._toDispose.add(
			this.model.onDidTrigger(e => {
				this.widget.value.showTriggered(e.auto, e.shy ? 250 : 50);
				this._lineSuffix.value = new LineSuffix(this.editor.getModel(), e.position);
			})
		);
		this._toDispose.add(
			this.model.onDidSuggest(e => {
				if (e.triggerOptions.shy) {
					return;
				}
				let index = -1;
				for (const selector of this._selectors.itemsOrderedByPriorityDesc) {
					index = selector.select(this.editor.getModel(), this.editor.getPosition(), e.completionModel.items);
					if (index !== -1) {
						break;
					}
				}
				if (index === -1) {
					index = 0;
				}
				if (this.model.state === 0) {
					return;
				}
				let noFocus = false;
				if (e.triggerOptions.auto) {
					const options2 = this.editor.getOption(
						118
						// suggest
					);
					if (options2.selectionMode === 'never' || options2.selectionMode === 'always') {
						noFocus = options2.selectionMode === 'never';
					} else if (options2.selectionMode === 'whenTriggerCharacter') {
						noFocus = e.triggerOptions.triggerKind !== 1;
					} else if (options2.selectionMode === 'whenQuickSuggestion') {
						noFocus = e.triggerOptions.triggerKind === 1 && !e.triggerOptions.refilter;
					}
				}
				this.widget.value.showSuggestions(e.completionModel, index, e.isFrozen, e.triggerOptions.auto, noFocus);
			})
		);
		this._toDispose.add(
			this.model.onDidCancel(e => {
				if (!e.retrigger) {
					this.widget.value.hideWidget();
				}
			})
		);
		this._toDispose.add(
			this.editor.onDidBlurEditorWidget(() => {
				if (!_sticky2) {
					this.model.cancel();
					this.model.clear();
				}
			})
		);
		const acceptSuggestionsOnEnter = Context2.AcceptSuggestionsOnEnter.bindTo(_contextKeyService);
		const updateFromConfig = () => {
			const acceptSuggestionOnEnter = this.editor.getOption(
				1
				// acceptSuggestionOnEnter
			);
			acceptSuggestionsOnEnter.set(acceptSuggestionOnEnter === 'on' || acceptSuggestionOnEnter === 'smart');
		};
		this._toDispose.add(this.editor.onDidChangeConfiguration(() => updateFromConfig()));
		updateFromConfig();
	}
	dispose() {
		this._alternatives.dispose();
		this._toDispose.dispose();
		this.widget.dispose();
		this.model.dispose();
		this._lineSuffix.dispose();
		this._onWillInsertSuggestItem.dispose();
	}
	_insertSuggestion(event, flags) {
		if (!event || !event.item) {
			this._alternatives.value.reset();
			this.model.cancel();
			this.model.clear();
			return;
		}
		if (!this.editor.hasModel()) {
			return;
		}
		const snippetController = SnippetController2.get(this.editor);
		if (!snippetController) {
			return;
		}
		this._onWillInsertSuggestItem.fire({ item: event.item });
		const model = this.editor.getModel();
		const modelVersionNow = model.getAlternativeVersionId();
		const { item } = event;
		const tasks = [];
		const cts = new CancellationTokenSource();
		if (!(flags & 1)) {
			this.editor.pushUndoStop();
		}
		const info = this.getOverwriteInfo(
			item,
			Boolean(
				flags & 8
				/* InsertFlags.AlternativeOverwriteConfig */
			)
		);
		this._memoryService.memorize(model, this.editor.getPosition(), item);
		const isResolved = item.isResolved;
		let _commandExectionDuration = -1;
		let _additionalEditsAppliedAsync = -1;
		if (isArray(item.completion.additionalTextEdits)) {
			this.model.cancel();
			const scrollState = StableEditorScrollState.capture(this.editor);
			this.editor.executeEdits(
				'suggestController.additionalTextEdits.sync',
				item.completion.additionalTextEdits.map(edit => {
					let range2 = Range.lift(edit.range);
					if (range2.startLineNumber === item.position.lineNumber && range2.startColumn > item.position.column) {
						const columnDelta = this.editor.getPosition().column - item.position.column;
						const startColumnDelta = columnDelta;
						const endColumnDelta = Range.spansMultipleLines(range2) ? 0 : columnDelta;
						range2 = new Range(
							range2.startLineNumber,
							range2.startColumn + startColumnDelta,
							range2.endLineNumber,
							range2.endColumn + endColumnDelta
						);
					}
					return EditOperation.replaceMove(range2, edit.text);
				})
			);
			scrollState.restoreRelativeVerticalPositionOfCursor(this.editor);
		} else if (!isResolved) {
			const sw = new StopWatch();
			let position;
			const docListener = model.onDidChangeContent(e => {
				if (e.isFlush) {
					cts.cancel();
					docListener.dispose();
					return;
				}
				for (const change of e.changes) {
					const thisPosition = Range.getEndPosition(change.range);
					if (!position || Position.isBefore(thisPosition, position)) {
						position = thisPosition;
					}
				}
			});
			const oldFlags = flags;
			flags |= 2;
			let didType = false;
			const typeListener = this.editor.onWillType(() => {
				typeListener.dispose();
				didType = true;
				if (!(oldFlags & 2)) {
					this.editor.pushUndoStop();
				}
			});
			tasks.push(
				item
					.resolve(cts.token)
					.then(() => {
						if (!item.completion.additionalTextEdits || cts.token.isCancellationRequested) {
							return;
						}
						if (
							position &&
							item.completion.additionalTextEdits.some(edit =>
								Position.isBefore(position, Range.getStartPosition(edit.range))
							)
						) {
							return false;
						}
						if (didType) {
							this.editor.pushUndoStop();
						}
						const scrollState = StableEditorScrollState.capture(this.editor);
						this.editor.executeEdits(
							'suggestController.additionalTextEdits.async',
							item.completion.additionalTextEdits.map(edit => EditOperation.replaceMove(Range.lift(edit.range), edit.text))
						);
						scrollState.restoreRelativeVerticalPositionOfCursor(this.editor);
						if (didType || !(oldFlags & 2)) {
							this.editor.pushUndoStop();
						}
						return true;
					})
					.then(applied => {
						_additionalEditsAppliedAsync = applied === true ? 1 : applied === false ? 0 : -2;
					})
					.finally(() => {
						docListener.dispose();
						typeListener.dispose();
					})
			);
		}
		let { insertText } = item.completion;
		if (!(item.completion.insertTextRules & 4)) {
			insertText = SnippetParser.escape(insertText);
		}
		this.model.cancel();
		snippetController.insert(insertText, {
			overwriteBefore: info.overwriteBefore,
			overwriteAfter: info.overwriteAfter,
			undoStopBefore: false,
			undoStopAfter: false,
			adjustWhitespace: !(item.completion.insertTextRules & 1),
			clipboardText: event.model.clipboardText,
			overtypingCapturer: this._overtypingCapturer.value
		});
		if (!(flags & 2)) {
			this.editor.pushUndoStop();
		}
		if (item.completion.command) {
			if (item.completion.command.id === TriggerSuggestAction.id) {
				this.model.trigger({ auto: true, retrigger: true });
			} else {
				const sw = new StopWatch();
				tasks.push(
					this._commandService
						.executeCommand(
							item.completion.command.id,
							...(item.completion.command.arguments ? [...item.completion.command.arguments] : [])
						)
						.catch(e => {
							if (item.completion.extensionId) {
								onUnexpectedExternalError(e);
							} else {
								onUnexpectedError(e);
							}
						})
						.finally(() => {
							_commandExectionDuration = sw.elapsed();
						})
				);
			}
		}
		if (flags & 4) {
			this._alternatives.value.set(event, next => {
				cts.cancel();
				while (model.canUndo()) {
					if (modelVersionNow !== model.getAlternativeVersionId()) {
						model.undo();
					}
					this._insertSuggestion(next, 1 | 2 | (flags & 8 ? 8 : 0));
					break;
				}
			});
		}
		this._alertCompletionItem(item);
		Promise.all(tasks).finally(() => {
			this.model.clear();
			cts.dispose();
		});
	}

	getOverwriteInfo(item, toggleMode) {
		if (this.editor.hasModel()) {
			let replace =
				this.editor.getOption(
					118
					// suggest
				).insertMode === 'replace';
			if (toggleMode) {
				replace = !replace;
			}
			const overwriteBefore = item.position.column - item.editStart.column;
			const overwriteAfter = (replace ? item.editReplaceEnd.column : item.editInsertEnd.column) - item.position.column;
			const columnDelta = this.editor.getPosition().column - item.position.column;
			const suffixDelta = this._lineSuffix.value ? this._lineSuffix.value.delta(this.editor.getPosition()) : 0;
			return {
				overwriteBefore: overwriteBefore + columnDelta,
				overwriteAfter: overwriteAfter + suffixDelta
			};
		}
	}
	_alertCompletionItem(item) {
		if (isArrayAndHasLength(item.completion.additionalTextEdits)) {
			const msg = localize("Accepting '{0}' made {1} additional edits", item.textLabel, item.completion.additionalTextEdits.length);
			alert(msg);
		}
	}
	triggerSuggest(onlyFrom, auto, noFilter) {
		if (this.editor.hasModel()) {
			this.model.trigger({
				auto: auto !== null && auto !== undefined ? auto : false,
				completionOptions: {
					providerFilter: onlyFrom,
					kindFilter: noFilter ? new Set() : undefined
				}
			});
			this.editor.revealPosition(
				this.editor.getPosition(),
				0
				// Smooth
			);
			this.editor.focus();
		}
	}
	triggerSuggestAndAcceptBest(arg) {
		if (!this.editor.hasModel()) {
			return;
		}
		const positionNow = this.editor.getPosition();
		const fallback2 = () => {
			if (positionNow.equals(this.editor.getPosition())) {
				this._commandService.executeCommand(arg.fallback);
			}
		};
		const makesTextEdit = item => {
			if (item.completion.insertTextRules & 4 || item.completion.additionalTextEdits) {
				return true;
			}
			const position = this.editor.getPosition();
			const startColumn = item.editStart.column;
			const endColumn = position.column;
			if (endColumn - startColumn !== item.completion.insertText.length) {
				return true;
			}
			const textNow = this.editor.getModel().getValueInRange({
				startLineNumber: position.lineNumber,
				startColumn,
				endLineNumber: position.lineNumber,
				endColumn
			});
			return textNow !== item.completion.insertText;
		};
		editorEventOnce(this.model.onDidTrigger)(_ => {
			const listener = [];
			editorEventAny(this.model.onDidTrigger, this.model.onDidCancel)(
				() => {
					dispose(listener);
					fallback2();
				},
				undefined,
				listener
			);
			this.model.onDidSuggest(
				({ completionModel }) => {
					dispose(listener);
					if (completionModel.items.length === 0) {
						fallback2();
						return;
					}
					const index = this._memoryService.select(this.editor.getModel(), this.editor.getPosition(), completionModel.items);
					const item = completionModel.items[index];
					if (!makesTextEdit(item)) {
						fallback2();
						return;
					}
					this.editor.pushUndoStop();
					this._insertSuggestion(
						{ index, item, model: completionModel },
						4 | 1 | 2
						/* InsertFlags.NoAfterUndoStop */
					);
				},
				undefined,
				listener
			);
		});
		this.model.trigger({ auto: false, shy: true });
		this.editor.revealPosition(
			positionNow,
			0
			// Smooth
		);
		this.editor.focus();
	}
	acceptSelectedSuggestion(keepAlternativeSuggestions, alternativeOverwriteConfig) {
		const item = this.widget.value.getFocusedItem();
		let flags = 0;
		if (keepAlternativeSuggestions) {
			flags |= 4;
		}
		if (alternativeOverwriteConfig) {
			flags |= 8;
		}
		this._insertSuggestion(item, flags);
	}
	acceptNextSuggestion() {
		this._alternatives.value.next();
	}
	acceptPrevSuggestion() {
		this._alternatives.value.prev();
	}
	cancelSuggestWidget() {
		this.model.cancel();
		this.model.clear();
		this.widget.value.hideWidget();
	}
	focusSuggestion() {
		this.widget.value.focusSelected();
	}
	selectNextSuggestion() {
		this.widget.value.selectNext();
	}
	selectNextPageSuggestion() {
		this.widget.value.selectNextPage();
	}
	selectLastSuggestion() {
		this.widget.value.selectLast();
	}
	selectPrevSuggestion() {
		this.widget.value.selectPrevious();
	}
	selectPrevPageSuggestion() {
		this.widget.value.selectPreviousPage();
	}
	selectFirstSuggestion() {
		this.widget.value.selectFirst();
	}
	toggleSuggestionDetails() {
		this.widget.value.toggleDetails();
	}
	toggleExplainMode() {
		this.widget.value.toggleExplainMode();
	}
	toggleSuggestionFocus() {
		this.widget.value.toggleDetailsFocus();
	}
	resetWidgetSize() {
		this.widget.value.resetPersistedSize();
	}
	forceRenderingAbove() {
		this.widget.value.forceRenderingAbove();
	}
	stopForceRenderingAbove() {
		if (!this.widget.isInitialized) {
			return;
		}
		this.widget.value.stopForceRenderingAbove();
	}
	registerSelector(selector) {
		return this._selectors.register(selector);
	}
}
SuggestController.ID = 'editor.contrib.suggestController';
__decorate(
	[__param(1, ISuggestMemoryService), __param(2, ICommandService), __param(3, IContextKeyService), __param(4, IInstantiationService)],
	SuggestController
);

class PriorityRegistry {
	constructor(prioritySelector) {
		this.prioritySelector = prioritySelector;
		this._items = new Array();
	}
	register(value) {
		if (this._items.indexOf(value) !== -1) {
			throw new Error('Value is already registered');
		}
		this._items.push(value);
		this._items.sort((s1, s2) => this.prioritySelector(s2) - this.prioritySelector(s1));
		return {
			dispose: () => {
				const idx = this._items.indexOf(value);
				if (idx >= 0) {
					this._items.splice(idx, 1);
				}
			}
		};
	}
	get itemsOrderedByPriorityDesc() {
		return this._items;
	}
}

class TriggerSuggestAction extends EditorAction {
	constructor() {
		super({
			id: TriggerSuggestAction.id,
			label: localize('Trigger Suggest'),
			alias: 'Trigger Suggest',
			precondition: ContextKeyExpr.and(ctxKeys_writable, ctxKeys_editorHasProvider_completionItem, Context2.Visible.toNegated()),
			kbOpts: {
				kbExpr: ctxKeys_inputFocus_text,
				primary: 2048 | 10,
				secondary: [
					2048 | 39
					/* KeyCode.KeyI */
				],
				mac: {
					primary: 256 | 10,
					secondary: [
						512 | 9,
						2048 | 39
						/* KeyCode.KeyI */
					]
				},
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2, args) {
		const controller = SuggestController.get(editor2);
		if (!controller) {
			return;
		}
		let auto;
		if (args && typeof args === 'object') {
			if (args.auto === true) {
				auto = true;
			}
		}
		controller.triggerSuggest(undefined, auto, undefined);
	}
}
TriggerSuggestAction.id = 'editor.action.triggerSuggest';
registerEditorContribution(
	SuggestController.ID,
	SuggestController,
	2
	/* EditorContributionInstantiation.BeforeFirstInteraction */
);
registerEditorAction(TriggerSuggestAction);



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


var weight2 = 190;
var SuggestCommand = EditorCommand.bindToContribution(SuggestController.get);
registerEditorCommand(
	new SuggestCommand({
		id: 'acceptSelectedSuggestion',
		precondition: ContextKeyExpr.and(Context2.Visible, Context2.HasFocusedSuggestion),
		handler(x) {
			x.acceptSelectedSuggestion(true, false);
		},
		kbOpts: [
			{
				// normal tab
				primary: 2,
				kbExpr: ContextKeyExpr.and(Context2.Visible, ctxKeys_inputFocus_text),
				weight: weight2
			},
			{
				// accept on enter has special rules
				primary: 3,
				kbExpr: ContextKeyExpr.and(
					Context2.Visible,
					ctxKeys_inputFocus_text,
					Context2.AcceptSuggestionsOnEnter,
					Context2.MakesTextEdit
				),
				weight: weight2
			}
		],
		menuOpts: [
			{
				menuId: suggestWidgetStatusbar_menuId,
				title: localize('Insert'),
				group: 'left',
				order: 1,
				when: Context2.HasInsertAndReplaceRange.toNegated()
			},
			{
				menuId: suggestWidgetStatusbar_menuId,
				title: localize('Insert'),
				group: 'left',
				order: 1,
				when: ContextKeyExpr.and(Context2.HasInsertAndReplaceRange, Context2.InsertMode.isEqualTo('insert'))
			},
			{
				menuId: suggestWidgetStatusbar_menuId,
				title: localize('Replace'),
				group: 'left',
				order: 1,
				when: ContextKeyExpr.and(Context2.HasInsertAndReplaceRange, Context2.InsertMode.isEqualTo('replace'))
			}
		]
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'acceptAlternativeSelectedSuggestion',
		precondition: ContextKeyExpr.and(Context2.Visible, ctxKeys_inputFocus_text, Context2.HasFocusedSuggestion),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 1024 | 3,
			secondary: [
				1024 | 2
				/* KeyCode.Tab */
			]
		},
		handler(x) {
			x.acceptSelectedSuggestion(false, true);
		},
		menuOpts: [
			{
				menuId: suggestWidgetStatusbar_menuId,
				group: 'left',
				order: 2,
				when: ContextKeyExpr.and(Context2.HasInsertAndReplaceRange, Context2.InsertMode.isEqualTo('insert')),
				title: localize('Replace')
			},
			{
				menuId: suggestWidgetStatusbar_menuId,
				group: 'left',
				order: 2,
				when: ContextKeyExpr.and(Context2.HasInsertAndReplaceRange, Context2.InsertMode.isEqualTo('replace')),
				title: localize('Insert')
			}
		]
	})
);
commandsRegistry.registerCommandAlias('acceptSelectedSuggestionOnEnter', 'acceptSelectedSuggestion');
registerEditorCommand(
	new SuggestCommand({
		id: 'hideSuggestWidget',
		precondition: Context2.Visible,
		handler: x => x.cancelSuggestWidget(),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 9,
			secondary: [
				1024 | 9
				/* KeyCode.Escape */
			]
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'selectNextSuggestion',
		precondition: ContextKeyExpr.and(
			Context2.Visible,
			ContextKeyExpr.or(Context2.MultipleSuggestions, Context2.HasFocusedSuggestion.negate())
		),
		handler: c => c.selectNextSuggestion(),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 18,
			secondary: [
				2048 | 18
				// DownArrow
			],
			mac: {
				primary: 18,
				secondary: [
					2048 | 18,
					256 | 44
					/* KeyCode.KeyN */
				]
			}
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'selectNextPageSuggestion',
		precondition: ContextKeyExpr.and(
			Context2.Visible,
			ContextKeyExpr.or(Context2.MultipleSuggestions, Context2.HasFocusedSuggestion.negate())
		),
		handler: c => c.selectNextPageSuggestion(),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 12,
			secondary: [
				2048 | 12
				/* KeyCode.PageDown */
			]
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'selectLastSuggestion',
		precondition: ContextKeyExpr.and(
			Context2.Visible,
			ContextKeyExpr.or(Context2.MultipleSuggestions, Context2.HasFocusedSuggestion.negate())
		),
		handler: c => c.selectLastSuggestion()
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'selectPrevSuggestion',
		precondition: ContextKeyExpr.and(
			Context2.Visible,
			ContextKeyExpr.or(Context2.MultipleSuggestions, Context2.HasFocusedSuggestion.negate())
		),
		handler: c => c.selectPrevSuggestion(),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 16,
			secondary: [
				2048 | 16
				/* KeyCode.UpArrow */
			],
			mac: {
				primary: 16,
				secondary: [
					2048 | 16,
					256 | 46
					/* KeyCode.KeyP */
				]
			}
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'selectPrevPageSuggestion',
		precondition: ContextKeyExpr.and(
			Context2.Visible,
			ContextKeyExpr.or(Context2.MultipleSuggestions, Context2.HasFocusedSuggestion.negate())
		),
		handler: c => c.selectPrevPageSuggestion(),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 11,
			secondary: [
				2048 | 11
				/* KeyCode.PageUp */
			]
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'selectFirstSuggestion',
		precondition: ContextKeyExpr.and(
			Context2.Visible,
			ContextKeyExpr.or(Context2.MultipleSuggestions, Context2.HasFocusedSuggestion.negate())
		),
		handler: c => c.selectFirstSuggestion()
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'focusSuggestion',
		precondition: ContextKeyExpr.and(Context2.Visible, Context2.HasFocusedSuggestion.negate()),
		handler: x => x.focusSuggestion(),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 2048 | 10,
			secondary: [
				2048 | 39
				/* KeyCode.KeyI */
			],
			mac: {
				primary: 256 | 10,
				secondary: [
					2048 | 39
					/* KeyCode.KeyI */
				]
			}
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'focusAndAcceptSuggestion',
		precondition: ContextKeyExpr.and(Context2.Visible, Context2.HasFocusedSuggestion.negate()),
		handler: c => {
			c.focusSuggestion();
			c.acceptSelectedSuggestion(true, false);
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'toggleSuggestionDetails',
		precondition: ContextKeyExpr.and(Context2.Visible, Context2.HasFocusedSuggestion),
		handler: x => x.toggleSuggestionDetails(),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 2048 | 10,
			secondary: [
				2048 | 39
				/* KeyCode.KeyI */
			],
			mac: {
				primary: 256 | 10,
				secondary: [
					2048 | 39
					/* KeyCode.KeyI */
				]
			}
		},
		menuOpts: [
			{
				menuId: suggestWidgetStatusbar_menuId,
				group: 'right',
				order: 1,
				when: ContextKeyExpr.and(Context2.DetailsVisible, Context2.CanResolve),
				title: localize('show less')
			},
			{
				menuId: suggestWidgetStatusbar_menuId,
				group: 'right',
				order: 1,
				when: ContextKeyExpr.and(Context2.DetailsVisible.toNegated(), Context2.CanResolve),
				title: localize('show more')
			}
		]
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'toggleExplainMode',
		precondition: Context2.Visible,
		handler: x => x.toggleExplainMode(),
		kbOpts: {
			weight: 100,
			primary: 2048 | 90
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'toggleSuggestionFocus',
		precondition: Context2.Visible,
		handler: x => x.toggleSuggestionFocus(),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 2048 | 512 | 10,
			mac: {
				primary: 256 | 512 | 10
				/* KeyCode.Space */
			}
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'insertBestCompletion',
		precondition: ContextKeyExpr.and(
			ctxKeys_inputFocus_text,
			ContextKeyExpr.equals('config.editor.tabCompletion', 'on'),
			WordContextKey.AtEnd,
			Context2.Visible.toNegated(),
			SuggestAlternatives.OtherSuggestions.toNegated(),
			SnippetController2.InSnippetMode.toNegated()
		),
		handler: (x, arg) => {
			x.triggerSuggestAndAcceptBest(isLiteralObject(arg) ? { fallback: 'tab', ...arg } : { fallback: 'tab' });
		},
		kbOpts: {
			weight: weight2,
			primary: 2
			/* KeyCode.Tab */
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'insertNextSuggestion',
		precondition: ContextKeyExpr.and(
			ctxKeys_inputFocus_text,
			ContextKeyExpr.equals('config.editor.tabCompletion', 'on'),
			SuggestAlternatives.OtherSuggestions,
			Context2.Visible.toNegated(),
			SnippetController2.InSnippetMode.toNegated()
		),
		handler: x => x.acceptNextSuggestion(),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 2
			/* KeyCode.Tab */
		}
	})
);
registerEditorCommand(
	new SuggestCommand({
		id: 'insertPrevSuggestion',
		precondition: ContextKeyExpr.and(
			ctxKeys_inputFocus_text,
			ContextKeyExpr.equals('config.editor.tabCompletion', 'on'),
			SuggestAlternatives.OtherSuggestions,
			Context2.Visible.toNegated(),
			SnippetController2.InSnippetMode.toNegated()
		),
		handler: x => x.acceptPrevSuggestion(),
		kbOpts: {
			weight: weight2,
			kbExpr: ctxKeys_inputFocus_text,
			primary: 1024 | 2
			/* KeyCode.Tab */
		}
	})
);
registerEditorAction(
	class extends EditorAction {
		constructor() {
			super({
				id: 'editor.action.resetSuggestSize',
				label: localize('Reset Suggest Widget Size'),
				alias: 'Reset Suggest Widget Size'
			});
		}
		run(_accessor, editor2) {
			SuggestController.get(editor2)?.resetWidgetSize();
		}
	}
);


class SelectedSuggestionInfo {
	constructor(range, text, completionKind, isSnippetText) {
		this.range = range;
		this.text = text;
		this.completionKind = completionKind;
		this.isSnippetText = isSnippetText;
	}
	equals(other) {
		return (
			Range.lift(this.range).equalsRange(other.range) &&
			this.text === other.text &&
			this.completionKind === other.completionKind &&
			this.isSnippetText === other.isSnippetText
		);
	}
}

class SuggestItemInfo {
	static fromSuggestion(suggestController, model, position, item, toggleMode) {
		let { insertText } = item.completion;
		let isSnippetText = false;
		if (item.completion.insertTextRules & 4) {
			const snippet = new SnippetParser().parse(insertText);
			if (snippet.children.length < 100) {
				SnippetSession.adjustWhitespace(model, position, true, snippet);
			}
			insertText = snippet.toString();
			isSnippetText = true;
		}
		const info = suggestController.getOverwriteInfo(item, toggleMode);
		return new SuggestItemInfo(
			Range.fromPositions(position.delta(0, -info.overwriteBefore), position.delta(0, Math.max(info.overwriteAfter, 0))),
			insertText,
			item.completion.kind,
			isSnippetText
		);
	}
	constructor(range2, insertText, completionItemKind, isSnippetText) {
		this.range = range2;
		this.insertText = insertText;
		this.completionItemKind = completionItemKind;
		this.isSnippetText = isSnippetText;
	}
	equals(other) {
		return (
			this.range.equalsRange(other.range) &&
			this.insertText === other.insertText &&
			this.completionItemKind === other.completionItemKind &&
			this.isSnippetText === other.isSnippetText
		);
	}
	toSelectedSuggestionInfo() {
		return new SelectedSuggestionInfo(this.range, this.insertText, this.completionItemKind, this.isSnippetText);
	}
	toSingleTextEdit() {
		return new SingleTextEdit(this.range, this.insertText);
	}
}








class SuggestWidgetAdaptor extends Disposable {
	get selectedItem() {
		return this._selectedItem;
	}
	constructor(editor2, suggestControllerPreselector, checkModelVersion, onWillAccept) {
		super();
		this.editor = editor2;
		this.suggestControllerPreselector = suggestControllerPreselector;
		this.checkModelVersion = checkModelVersion;
		this.onWillAccept = onWillAccept;
		this.isSuggestWidgetVisible = false;
		this.isShiftKeyPressed = false;
		this._isActive = false;
		this._currentSuggestItemInfo = undefined;
		this._selectedItem = observableValue(this, undefined);
		this._register(
			editor2.onKeyDown(e => {
				if (e.shiftKey && !this.isShiftKeyPressed) {
					this.isShiftKeyPressed = true;
					this.update(this._isActive);
				}
			})
		);
		this._register(
			editor2.onKeyUp(e => {
				if (e.shiftKey && this.isShiftKeyPressed) {
					this.isShiftKeyPressed = false;
					this.update(this._isActive);
				}
			})
		);
		const suggestController = SuggestController.get(this.editor);
		if (suggestController) {
			this._register(
				suggestController.registerSelector({
					priority: 100,
					select: (model, pos, suggestItems) => {
						transaction(tx => this.checkModelVersion(tx));
						const textModel = this.editor.getModel();
						if (!textModel) {
							return -1;
						}
						const i = this.suggestControllerPreselector();
						const itemToPreselect = i ? singleTextRemoveCommonPrefix(i, textModel) : undefined;
						if (!itemToPreselect) {
							return -1;
						}
						const position = Position.lift(pos);
						const candidates = suggestItems
							.map((suggestItem, index) => {
								const suggestItemInfo = SuggestItemInfo.fromSuggestion(
									suggestController,
									textModel,
									position,
									suggestItem,
									this.isShiftKeyPressed
								);
								const suggestItemTextEdit = singleTextRemoveCommonPrefix(suggestItemInfo.toSingleTextEdit(), textModel);
								const valid = singleTextEditAugments(itemToPreselect, suggestItemTextEdit);
								return { index, valid, prefixLength: suggestItemTextEdit.text.length, suggestItem };
							})
							.filter(item => item && item.valid && item.prefixLength > 0);
						const result = findFirstMax(candidates, (a, b) => a.prefixLength - b.prefixLength);
						return result ? result.index : -1;
					}
				})
			);
			let isBoundToSuggestWidget = false;
			const bindToSuggestWidget = () => {
				if (isBoundToSuggestWidget) {
					return;
				}
				isBoundToSuggestWidget = true;
				this._register(
					suggestController.widget.value.onDidShow(() => {
						this.isSuggestWidgetVisible = true;
						this.update(true);
					})
				);
				this._register(
					suggestController.widget.value.onDidHide(() => {
						this.isSuggestWidgetVisible = false;
						this.update(false);
					})
				);
				this._register(
					suggestController.widget.value.onDidFocus(() => {
						this.isSuggestWidgetVisible = true;
						this.update(true);
					})
				);
			};
			this._register(
				editorEventOnce(suggestController.model.onDidTrigger)(e => {
					bindToSuggestWidget();
				})
			);
			this._register(
				suggestController.onWillInsertSuggestItem(e => {
					const position = this.editor.getPosition();
					const model = this.editor.getModel();
					if (!position || !model) {
						return;
					}
					const suggestItemInfo = SuggestItemInfo.fromSuggestion(
						suggestController,
						model,
						position,
						e.item,
						this.isShiftKeyPressed
					);
					this.onWillAccept(suggestItemInfo);
				})
			);
		}
		this.update(this._isActive);
	}
	update(newActive) {
		const newInlineCompletion = this.getSuggestItemInfo();
		function _suggestItemInfoEquals(a, b) {
			if (a === b) {
				return true;
			}
			if (!a || !b) {
				return false;
			}
			return a.equals(b);
		}
		if (this._isActive !== newActive || !_suggestItemInfoEquals(this._currentSuggestItemInfo, newInlineCompletion)) {
			this._isActive = newActive;
			this._currentSuggestItemInfo = newInlineCompletion;
			transaction(tx => {
				this.checkModelVersion(tx);
				this._selectedItem.set(this._isActive ? this._currentSuggestItemInfo : undefined, tx);
			});
		}
	}
	getSuggestItemInfo() {
		const suggestController = SuggestController.get(this.editor);
		if (!suggestController || !this.isSuggestWidgetVisible) {
			return;
		}
		const focusedItem = suggestController.widget.value.getFocusedItem();
		const position = this.editor.getPosition();
		const model = this.editor.getModel();
		if (!focusedItem || !position || !model) {
			return;
		}
		return SuggestItemInfo.fromSuggestion(suggestController, model, position, focusedItem.item, this.isShiftKeyPressed);
	}
	stopForceRenderingAbove() {
		SuggestController.get(this.editor)?.stopForceRenderingAbove();
	}
	forceRenderingAbove() {
		SuggestController.get(this.editor)?.forceRenderingAbove();
	}
}






class InlineCompletionsController extends Disposable {
	static get(editor2) {
		return editor2.getContribution(InlineCompletionsController.ID);
	}
	constructor(
		editor2,
		_instantiationService,
		_contextKeyService,
		_configurationService,
		_commandService,
		_debounceService,
		_languageFeaturesService,
		_keybindingService
	) {
		super();
		this.editor = editor2;
		this._instantiationService = _instantiationService;
		this._contextKeyService = _contextKeyService;
		this._configurationService = _configurationService;
		this._commandService = _commandService;
		this._debounceService = _debounceService;
		this._languageFeaturesService = _languageFeaturesService;
		this._keybindingService = _keybindingService;
		this.model = this._register(disposableObservableValue('inlineCompletionModel', undefined));
		this._textModelVersionId = observableValue(this, -1);
		this._positions = observableValueOpts({ owner: this, equalsFn: itemsEquals(itemEquals()) }, [new Position(1, 1)]);
		this._suggestWidgetAdaptor = this._register(
			new SuggestWidgetAdaptor(
				this.editor,
				() => {
					return this.model.get()?.selectedInlineCompletion.get()?.toSingleTextEdit(undefined);
				},
				tx => this.updateObservables(tx, 3),
				item => {
					transaction(tx => {
						this.updateObservables(tx, 3);
						this.model.get()?.handleSuggestAccepted(item);
					});
				}
			)
		);
		this._enabledInConfig = observableFromEvent(
			this.editor.onDidChangeConfiguration,
			() =>
				this.editor.getOption(
					62
					// inlineSuggest
				).enabled
		);

		this._editorDictationInProgress = observableFromEvent(
			this._contextKeyService.onDidChangeContext,
			() => this._contextKeyService.getContext(this.editor.getDomNode()).getValue('editorDictation.inProgress') === true
		);
		this._enabled = derived(this, reader => this._enabledInConfig.read(reader) && !this._editorDictationInProgress.read(reader));
		this._fontFamily = observableFromEvent(
			this.editor.onDidChangeConfiguration,
			() =>
				this.editor.getOption(
					62
					// inlineSuggest
				).fontFamily
		);
		this._ghostTexts = derived(this, reader => {
			const model = this.model.read(reader);
			return model?.ghostTexts?.read(reader) || [];
		});
		this._stablizedGhostTexts = convertItemsToStableObservables(this._ghostTexts, this._store);
		this._ghostTextWidgets = mapObservableArrayCached(this, this._stablizedGhostTexts, (ghostText, store) => {
			return store.add(
				this._instantiationService.createInstance(GhostTextWidget, this.editor, {
					ghostText,
					minReservedLineCount: constObservable(0),
					targetTextModel: this.model.map(v => v?.textModel)
				})
			);
		}).recomputeInitiallyAndOnChange(this._store);
		this._debounceValue = this._debounceService.for(
			this._languageFeaturesService.inlineCompletionsProvider,
			'InlineCompletionsDebounce',
			{
				min: 50,
				max: 50
			}
		);

		this._isReadonly = observableFromEvent(this.editor.onDidChangeConfiguration, () =>
			this.editor.getOption(
				91
				// readOnly
			)
		);
		this._textModel = observableFromEvent(this.editor.onDidChangeModel, () => this.editor.getModel());
		this._textModelIfWritable = derived(reader => (this._isReadonly.read(reader) ? undefined : this._textModel.read(reader)));
		this._register(new InlineCompletionContextKeys(this._contextKeyService, this.model));
		this._register(
			autorun(reader => {
				const textModel = this._textModelIfWritable.read(reader);
				transaction(tx => {
					this.model.set(undefined, tx);
					this.updateObservables(tx, 3);
					if (textModel) {
						const model = _instantiationService.createInstance(
							InlineCompletionsModel,
							textModel,
							this._suggestWidgetAdaptor.selectedItem,
							this._textModelVersionId,
							this._positions,
							this._debounceValue,
							observableFromEvent(
								editor2.onDidChangeConfiguration,
								() =>
									editor2.getOption(
										118
										// suggest
									).preview
							),
							observableFromEvent(
								editor2.onDidChangeConfiguration,
								() =>
									editor2.getOption(
										118
										// suggest
									).previewMode
							),
							observableFromEvent(
								editor2.onDidChangeConfiguration,
								() =>
									editor2.getOption(
										62
										// inlineSuggest
									).mode
							),
							this._enabled
						);
						this.model.set(model, tx);
					}
				});
			})
		);
		const styleElement = this._register(createStyleSheet2());
		this._register(
			autorun(reader => {
				const fontFamily = this._fontFamily.read(reader);
				styleElement.setStyle(
					fontFamily === '' || fontFamily === 'default'
						? ``
						: `
.monaco-editor .ghost-text-decoration,
.monaco-editor .ghost-text-decoration-preview,
.monaco-editor .ghost-text {
	font-family: ${fontFamily};
}`
				);
			})
		);
		const getReason = e => {
			if (e.isUndoing) {
				return 0;
			}
			if (e.isRedoing) {
				return 1;
			}
			if (this.model.get()?.isAcceptingPartially) {
				return 2; //AcceptWord
			}
			return 3; //Other
		};
		this._register(editor2.onDidChangeModelContent(e => transaction(tx => this.updateObservables(tx, getReason(e)))));
		this._register(
			editor2.onDidChangeCursorPosition(e =>
				transaction(tx => {
					this.updateObservables(tx, 3);
					if (e.reason === 3 || e.source === 'api') {
						this.model.get()?.stop(tx);
					}
				})
			)
		);
		this._register(
			editor2.onDidType(() =>
				transaction(tx => {
					this.updateObservables(tx, 3);
					if (this._enabled.get()) {
						this.model.get()?.trigger(tx);
					}
				})
			)
		);
		this._register(
			this._commandService.onDidExecuteCommand(e => {
				const commands = new Set([
					commandTab.id,
					commandDeleteLeft.id,
					commandDeleteRight.id,
					inlineSuggestCommitId,
					'acceptSelectedSuggestion'
				]);
				if (commands.has(e.commandId) && editor2.hasTextFocus() && this._enabled.get()) {
					transaction(tx => {
						this.model.get()?.trigger(tx);
					});
				}
			})
		);
		this._register(
			this.editor.onDidBlurEditorWidget(() => {
				if (
					this._contextKeyService.getContextKeyValue('accessibleViewIsShown') ||
					this._configurationService.getValue('editor.inlineSuggest.keepOnBlur') ||
					editor2.getOption(
						62
						// inlineSuggest
					).keepOnBlur
				) {
					return;
				}
				if (InlineSuggestionHintsContentWidget.dropDownVisible) {
					return;
				}
				transaction(tx => {
					this.model.get()?.stop(tx);
				});
			})
		);
		this._register(
			autorun(reader => {
				const state = this.model.read(reader)?.state.read(reader);
				if (state?.suggestItem) {
					if (state.primaryGhostText.lineCount >= 2) {
						this._suggestWidgetAdaptor.forceRenderingAbove();
					}
				} else {
					this._suggestWidgetAdaptor.stopForceRenderingAbove();
				}
			})
		);
		this._register(
			toDisposable(() => {
				this._suggestWidgetAdaptor.stopForceRenderingAbove();
			})
		);
		const cancellationStore = this._register(new DisposableStore());
		let lastInlineCompletionId = undefined;
		this._register(
			autorunHandleChanges(
				{
					handleChange: (context, changeSummary) => {
						if (context.didChange()) {
							lastInlineCompletionId = undefined;
						}
						return true;
					}
				},
				async (reader, _) => {
					const model = this.model.read(reader);
					const state = model?.state.read(reader);
					if (!model || !state || !state.inlineCompletion) {
						lastInlineCompletionId = undefined;
						return;
					}
					if (state.inlineCompletion.semanticId !== lastInlineCompletionId) {
						cancellationStore.clear();
						lastInlineCompletionId = state.inlineCompletion.semanticId;
						const lineText = model.textModel.getLineContent(state.primaryGhostText.lineNumber);
						await timeout(50, cancelOnDispose(cancellationStore));
						await waitForState(
							this._suggestWidgetAdaptor.selectedItem,
							isUndefined,
							() => false,
							cancelOnDispose(cancellationStore)
						);

						if (
							this.editor.getOption(
								8
								// screenReaderAnnounceInlineSuggestion
							)
						) {
							this.provideScreenReaderUpdate(state.primaryGhostText.renderForScreenReader(lineText));
						}
					}
				}
			)
		);
		this._register(new InlineCompletionsHintsWidget(this.editor, this.model, this._instantiationService));
	}

	provideScreenReaderUpdate(content) {
		alert(content);
	}

	updateObservables(tx, changeReason) {
		const newModel = this.editor.getModel();
		this._textModelVersionId.set(newModel?.getVersionId() ?? -1, tx, changeReason);
		this._positions.set(this.editor.getSelections()?.map(e => e.getPosition()) ?? [new Position(1, 1)], tx);
	}
	shouldShowHoverAt(range2) {
		const ghostText = this.model.get()?.primaryGhostText.get();
		return ghostText ? ghostText.parts.some(p => range2.containsPosition(new Position(ghostText.lineNumber, p.column))) : false;
	}
	shouldShowHoverAtViewZone(viewZoneId) {
		return this._ghostTextWidgets.get()[0]?.ownsViewZone(viewZoneId) ?? false;
	}
}
InlineCompletionsController.ID = 'editor.contrib.inlineCompletionsController';
__decorate(
	[
		__param(1, IInstantiationService),
		__param(2, IContextKeyService),
		__param(3, IConfigurationService),
		__param(4, ICommandService),
		__param(5, ILanguageFeatureDebounceService),
		__param(6, ILanguageFeaturesService),
		__param(7, IKeybindingService)
	],
	InlineCompletionsController
);

function convertItemsToStableObservables(items, store) {
	const result = observableValue('result', []);
	const innerObservables = [];
	store.add(
		autorun(reader => {
			const itemsValue = items.read(reader);
			transaction(tx => {
				if (itemsValue.length !== innerObservables.length) {
					innerObservables.length = itemsValue.length;
					for (let i = 0; i < innerObservables.length; i++) {
						if (!innerObservables[i]) {
							innerObservables[i] = observableValue('item', itemsValue[i]);
						}
					}
					result.set([...innerObservables], tx);
				}
				innerObservables.forEach((o, i) => o.set(itemsValue[i], tx));
			});
		})
	);
	return result;
}

// node_modules/monaco-editor/esm/vs/editor/contrib/inlineCompletions/browser/commands.js

class ShowNextInlineSuggestionAction extends EditorAction {
	constructor() {
		super({
			id: ShowNextInlineSuggestionAction.ID,
			label: localize('Show Next Inline Suggestion'),
			alias: 'Show Next Inline Suggestion',
			precondition: ContextKeyExpr.and(ctxKeys_writable, InlineCompletionContextKeys.inlineSuggestionVisible),
			kbOpts: {
				weight: 100,
				primary: 512 | 94
			}
		});
	}
	async run(accessor, editor) {
		InlineCompletionsController.get(editor).model.get()?.next();
	}
}
ShowNextInlineSuggestionAction.ID = showNextInlineSuggestionActionId;

class ShowPreviousInlineSuggestionAction extends EditorAction {
	constructor() {
		super({
			id: ShowPreviousInlineSuggestionAction.ID,
			label: localize('Show Previous Inline Suggestion'),
			alias: 'Show Previous Inline Suggestion',
			precondition: ContextKeyExpr.and(ctxKeys_writable, InlineCompletionContextKeys.inlineSuggestionVisible),
			kbOpts: {
				weight: 100,
				primary: 512 | 92
			}
		});
	}
	async run(accessor, editor) {
		InlineCompletionsController.get(editor).model.get()?.previous();
	}
}
ShowPreviousInlineSuggestionAction.ID = showPreviousInlineSuggestionActionId;

class TriggerInlineSuggestionAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.inlineSuggest.trigger',
			label: localize('Trigger Inline Suggestion'),
			alias: 'Trigger Inline Suggestion',
			precondition: ctxKeys_writable
		});
	}
	async run(accessor, editor2) {
		const controller = InlineCompletionsController.get(editor2);
		await asyncTransaction(async tx => {
			if (controller) {
				await controller.model.get()?.triggerExplicitly(tx);
			}
		});
	}
}

class AcceptNextWordOfInlineCompletion extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.inlineSuggest.acceptNextWord',
			label: localize('Accept Next Word Of Inline Suggestion'),
			alias: 'Accept Next Word Of Inline Suggestion',
			precondition: ContextKeyExpr.and(ctxKeys_writable, InlineCompletionContextKeys.inlineSuggestionVisible),
			kbOpts: {
				weight: 100 + 1,
				primary: 2048 | 17,
				kbExpr: ContextKeyExpr.and(ctxKeys_writable, InlineCompletionContextKeys.inlineSuggestionVisible)
			},
			menuOpts: [
				{
					menuId: inlineSuggestionToolbar_menuId,
					title: localize('Accept Word'),
					group: 'primary',
					order: 2
				}
			]
		});
	}
	async run(accessor, editor) {
		const controller = InlineCompletionsController.get(editor);
		await controller.model.get()?.acceptNextWord(controller.editor);
	}
}
class AcceptNextLineOfInlineCompletion extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.inlineSuggest.acceptNextLine',
			label: localize('Accept Next Line Of Inline Suggestion'),
			alias: 'Accept Next Line Of Inline Suggestion',
			precondition: ContextKeyExpr.and(ctxKeys_writable, InlineCompletionContextKeys.inlineSuggestionVisible),
			kbOpts: {
				weight: 100 + 1
			},
			menuOpts: [
				{
					menuId: inlineSuggestionToolbar_menuId,
					title: localize('Accept Line'),
					group: 'secondary',
					order: 2
				}
			]
		});
	}
	async run(accessor, editor2) {
		const controller = InlineCompletionsController.get(editor2);
		await controller?.model.get()?.acceptNextLine(controller.editor);
	}
}

class AcceptInlineCompletion extends EditorAction {
	constructor() {
		super({
			id: inlineSuggestCommitId,
			label: localize('Accept Inline Suggestion'),
			alias: 'Accept Inline Suggestion',
			precondition: InlineCompletionContextKeys.inlineSuggestionVisible,
			menuOpts: [
				{
					menuId: inlineSuggestionToolbar_menuId,
					title: localize('Accept'),
					group: 'primary',
					order: 1
				}
			],
			kbOpts: {
				primary: 2,
				weight: 200,
				kbExpr: ContextKeyExpr.and(
					InlineCompletionContextKeys.inlineSuggestionVisible,
					ctxKeys_editorTab_movesFocus.toNegated(),
					InlineCompletionContextKeys.inlineSuggestionHasIndentationLessThanTabSize,
					Context2.Visible.toNegated(),
					ctxKeys_editorHover_focused.toNegated()
				)
			}
		});
	}
	async run(accessor, editor) {
		const controller = InlineCompletionsController.get(editor);
		if (controller) {
			controller.model.get()?.accept(controller.editor);
			controller.editor.focus();
		}
	}
}

class HideInlineCompletion extends EditorAction {
	constructor() {
		super({
			id: HideInlineCompletion.ID,
			label: localize('Hide Inline Suggestion'),
			alias: 'Hide Inline Suggestion',
			precondition: InlineCompletionContextKeys.inlineSuggestionVisible,
			kbOpts: {
				weight: 100,
				primary: 9
			}
		});
	}
	async run(accessor, editor2) {
		const controller = InlineCompletionsController.get(editor2);
		transaction(tx => {
			controller.model.get()?.stop(tx);
		});
	}
}
HideInlineCompletion.ID = 'editor.action.inlineSuggest.hide';

class ToggleAlwaysShowInlineSuggestionToolbar extends Action2 {
	constructor() {
		super({
			id: ToggleAlwaysShowInlineSuggestionToolbar.ID,
			title: localize('Always Show Toolbar'),
			f1: false,

			menu: [
				{
					id: inlineSuggestionToolbar_menuId,
					group: 'secondary',
					order: 10
				}
			],
			toggled: ContextKeyExpr.equals('config.editor.inlineSuggest.showToolbar', 'always')
		});
	}
	async run(accessor, editor2) {
		const configService = accessor.get(IConfigurationService);
		const currentValue = configService.getValue('editor.inlineSuggest.showToolbar');
		const newValue = currentValue === 'always' ? 'onHover' : 'always';
		configService.updateValue('editor.inlineSuggest.showToolbar', newValue);
	}
}
ToggleAlwaysShowInlineSuggestionToolbar.ID = 'editor.action.inlineSuggest.toggleAlwaysShowToolbar';

// node_modules/monaco-editor/esm/vs/editor/contrib/inlineCompletions/browser/hoverParticipant.js

class InlineCompletionsHover {
	constructor(owner, range2, controller) {
		this.owner = owner;
		this.range = range2;
		this.controller = controller;
	}
	isValidForHoverAnchor(anchor) {
		return anchor.type === 1 && this.range.startColumn <= anchor.range.startColumn && this.range.endColumn >= anchor.range.endColumn;
	}
}

class InlineCompletionsHoverParticipant {
	constructor(_editor, _languageService, _openerService, _instantiationService) {
		this._editor = _editor;
		this._languageService = _languageService;
		this._openerService = _openerService;

		this._instantiationService = _instantiationService;

		this.hoverOrdinal = 4;
	}
	suggestHoverAnchor(mouseEvent) {
		const controller = InlineCompletionsController.get(this._editor);
		if (!controller) {
			return null;
		}
		const target = mouseEvent.target;
		if (target.type === 8) {
			const viewZoneData = target.detail;
			if (controller.shouldShowHoverAtViewZone(viewZoneData.viewZoneId)) {
				return new HoverForeignElementAnchor(
					1e3,
					this,
					Range.fromPositions(this._editor.getModel().validatePosition(viewZoneData.positionBefore || viewZoneData.position)),
					mouseEvent.event.posx,
					mouseEvent.event.posy,
					false
				);
			}
		}
		if (target.type === 7) {
			if (controller.shouldShowHoverAt(target.range)) {
				return new HoverForeignElementAnchor(1e3, this, target.range, mouseEvent.event.posx, mouseEvent.event.posy, false);
			}
		}
		if (target.type === 6) {
			const mightBeForeignElement = target.detail.mightBeForeignElement;
			if (mightBeForeignElement && controller.shouldShowHoverAt(target.range)) {
				return new HoverForeignElementAnchor(1e3, this, target.range, mouseEvent.event.posx, mouseEvent.event.posy, false);
			}
		}
		return null;
	}
	computeSync(anchor, lineDecorations) {
		if (
			this._editor.getOption(
				62
				// inlineSuggest
			).showToolbar !== 'onHover'
		) {
			return [];
		}
		const controller = InlineCompletionsController.get(this._editor);
		if (controller && controller.shouldShowHoverAt(anchor.range)) {
			return [new InlineCompletionsHover(this, anchor.range, controller)];
		}
		return [];
	}
	renderHoverParts(context, hoverParts) {
		const disposableStore = new DisposableStore();
		const part = hoverParts[0];

		const model = part.controller.model.get();
		const w = this._instantiationService.createInstance(
			InlineSuggestionHintsContentWidget,
			this._editor,
			false,
			constObservable(null),
			model.selectedInlineCompletionIndex,
			model.inlineCompletionsCount,
			model.activeCommands
		);
		context.fragment.appendChild(w.getDomNode());
		model.triggerExplicitly();
		disposableStore.add(w);
		return disposableStore;
	}
	renderScreenReaderText(context, part, disposableStore) {
		const markdownHoverElement = $('div.hover-row.markdown-hover');
		const hoverContentsElement = append(markdownHoverElement, $('div.hover-contents', {}));
		const renderer = disposableStore.add(new MarkdownRenderer({ editor: this._editor }, this._languageService, this._openerService));
		const render = code => {
			disposableStore.add(
				renderer.onDidRenderAsync(() => {
					hoverContentsElement.className = 'hover-contents code-hover-contents';
					context.onContentsChanged();
				})
			);
			const inlineSuggestionAvailable = localize('Suggestion:');
			const renderedContents = disposableStore.add(
				renderer.render(new MarkdownString().appendText(inlineSuggestionAvailable).appendCodeblock('text', code))
			);
			hoverContentsElement.replaceChildren(renderedContents.element);
		};
		disposableStore.add(
			autorun(reader => {
				const ghostText = part.controller.model.read(reader)?.primaryGhostText.read(reader);
				if (ghostText) {
					const lineText = this._editor.getModel().getLineContent(ghostText.lineNumber);
					render(ghostText.renderForScreenReader(lineText));
				} else {
					reset(hoverContentsElement);
				}
			})
		);
		context.fragment.appendChild(markdownHoverElement);
	}
}
__decorate(
	[__param(1, ILanguageService), __param(2, IOpenerService), __param(3, IInstantiationService)],
	InlineCompletionsHoverParticipant
);

// node_modules/monaco-editor/esm/vs/editor/contrib/inlineCompletions/browser/inlineCompletions.contribution.js

registerEditorContribution(
	InlineCompletionsController.ID,
	InlineCompletionsController,
	3
	/* EditorContributionInstantiation.Eventually */
);

registerEditorAction(TriggerInlineSuggestionAction);
registerEditorAction(ShowNextInlineSuggestionAction);
registerEditorAction(ShowPreviousInlineSuggestionAction);
registerEditorAction(AcceptNextWordOfInlineCompletion);
registerEditorAction(AcceptNextLineOfInlineCompletion);
registerEditorAction(AcceptInlineCompletion);
registerEditorAction(HideInlineCompletion);
registerEditorAction2(ToggleAlwaysShowInlineSuggestionToolbar);
hoverParticipantRegistry.register(InlineCompletionsHoverParticipant);
