class TransposeLettersAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.transposeLetters',
			label: localize('Transpose Letters'),
			alias: 'Transpose Letters',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_inputFocus_text,
				primary: 0,
				mac: {
					primary: 256 | 50 // KeyT
				},
				weight: 100 //editorContrib
			}
		});
	}
	run(accessor, editor2) {
		if (!editor2.hasModel()) {
			return;
		}
		const model = editor2.getModel();
		const commands = [];
		const selections = editor2.getSelections();
		for (const selection of selections) {
			if (!selection.isEmpty()) {
				continue;
			}
			const lineNumber = selection.startLineNumber;
			const column = selection.startColumn;
			const lastColumn = model.getLineMaxColumn(lineNumber);
			if (lineNumber === 1 && (column === 1 || (column === 2 && lastColumn === 2))) {
				continue;
			}
			const endPosition =
				column === lastColumn
					? selection.getPosition()
					: MoveOperations.rightPosition(model, selection.getPosition().lineNumber, selection.getPosition().column);
			const middlePosition = MoveOperations.leftPosition(model, endPosition);
			const beginPosition = MoveOperations.leftPosition(model, middlePosition);
			const leftChar = model.getValueInRange(Range.fromPositions(beginPosition, middlePosition));
			const rightChar = model.getValueInRange(Range.fromPositions(middlePosition, endPosition));
			const replaceRange = Range.fromPositions(beginPosition, endPosition);
			commands.push(new ReplaceCommand(replaceRange, rightChar + leftChar));
		}
		if (commands.length > 0) {
			editor2.pushUndoStop();
			editor2.executeCommands(this.id, commands);
			editor2.pushUndoStop();
		}
	}
}
registerEditorAction(TransposeLettersAction);