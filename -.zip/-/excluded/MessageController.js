class MessageController {
	static get(editor2) {
		return editor2.getContribution(MessageController.ID);
	}
	constructor(editor2, contextKeyService, _openerService) {
		this._openerService = _openerService;
		this._messageWidget = new MutableDisposable();
		this._messageListeners = new DisposableStore();
		this._mouseOverMessage = false;
		this._editor = editor2;
		this._visible = MessageController.MESSAGE_VISIBLE.bindTo(contextKeyService);
	}
	dispose() {
		this._message?.dispose();
		this._messageListeners.dispose();
		this._messageWidget.dispose();
		this._visible.reset();
	}
	showMessage(message, position) {
		alert(isMarkdownString(message) ? message.value : message);
		this._visible.set(true);
		this._messageWidget.clear();
		this._messageListeners.clear();
		this._message = isMarkdownString(message)
			? renderMarkdown(message, {
					actionHandler: {
						callback: url => {
							this.closeMessage();
							openLinkFromMarkdown(this._openerService, url, isMarkdownString(message) ? message.isTrusted : undefined);
						},
						disposables: this._messageListeners
					}
				})
			: undefined;
		this._messageWidget.value = new MessageWidget(
			this._editor,
			position,
			typeof message === 'string' ? message : this._message.element
		);
		this._messageListeners.add(
			editorEventDebounce(
				this._editor.onDidBlurEditorText,
				(last, event) => event,
				0
			)(() => {
				if (this._mouseOverMessage) {
					return;
				}
				if (this._messageWidget.value && isAncestor(getActiveElement(), this._messageWidget.value.getDomNode())) {
					return;
				}
				this.closeMessage();
			})
		);
		this._messageListeners.add(this._editor.onDidChangeCursorPosition(() => this.closeMessage()));
		this._messageListeners.add(this._editor.onDidDispose(() => this.closeMessage()));
		this._messageListeners.add(this._editor.onDidChangeModel(() => this.closeMessage()));
		this._messageListeners.add(
			addDisposableListener(
				this._messageWidget.value.getDomNode(),
				EventType.MOUSE_ENTER,
				() => (this._mouseOverMessage = true),
				true
			)
		);
		this._messageListeners.add(
			addDisposableListener(
				this._messageWidget.value.getDomNode(),
				EventType.MOUSE_LEAVE,
				() => (this._mouseOverMessage = false),
				true
			)
		);
		let bounds;
		this._messageListeners.add(
			this._editor.onMouseMove(e => {
				if (!e.target.position) {
					return;
				}
				if (!bounds) {
					bounds = new Range(position.lineNumber - 3, 1, e.target.position.lineNumber + 3, 1);
				} else if (!bounds.containsPosition(e.target.position)) {
					this.closeMessage();
				}
			})
		);
	}
	closeMessage() {
		this._visible.reset();
		this._messageListeners.clear();
		if (this._messageWidget.value) {
			this._messageListeners.add(MessageWidget.fadeOut(this._messageWidget.value));
		}
	}
}
MessageController.ID = 'editor.contrib.messageController';
MessageController.MESSAGE_VISIBLE = new RawContextKey(
	'messageVisible',
	false,
	localize('Whether the editor is currently showing an inline message')
);
__decorate([__param(1, IContextKeyService), __param(2, IOpenerService)], MessageController);
var MessageCommand = EditorCommand.bindToContribution(MessageController.get);
registerEditorCommand(
	new MessageCommand({
		id: 'leaveEditorMessage',
		precondition: MessageController.MESSAGE_VISIBLE,
		handler: c => c.closeMessage(),
		kbOpts: {
			weight: 130,
			primary: 9 //Escape
		}
	})
);
class MessageWidget {
	static fadeOut(messageWidget) {
		const dispose2 = () => {
			messageWidget.dispose();
			clearTimeout(handle);
			messageWidget.getDomNode().removeEventListener('animationend', dispose2);
		};
		const handle = setTimeout(dispose2, 110);
		messageWidget.getDomNode().addEventListener('animationend', dispose2);
		messageWidget.getDomNode().classList.add('fadeOut');
		return { dispose: dispose2 };
	}
	constructor(editor2, { lineNumber, column }, text2) {
		this.allowEditorOverflow = true;
		this.suppressMouseDown = false;
		this._editor = editor2;
		this._editor.revealLinesInCenterIfOutsideViewport(
			lineNumber,
			lineNumber,
			0 // Smooth
		);
		this._position = { lineNumber, column };
		this._domNode = document.createElement('div');
		this._domNode.classList.add('monaco-editor-overlaymessage');
		this._domNode.style.marginLeft = '-6px';
		const anchorTop = document.createElement('div');
		anchorTop.classList.add('anchor', 'top');
		this._domNode.appendChild(anchorTop);
		const message = document.createElement('div');
		if (typeof text2 === 'string') {
			message.classList.add('message');
			message.textContent = text2;
		} else {
			text2.classList.add('message');
			message.appendChild(text2);
		}
		this._domNode.appendChild(message);
		const anchorBottom = document.createElement('div');
		anchorBottom.classList.add('anchor', 'below');
		this._domNode.appendChild(anchorBottom);
		this._editor.addContentWidget(this);
		this._domNode.classList.add('fadeIn');
	}
	dispose() {
		this._editor.removeContentWidget(this);
	}
	getId() {
		return 'messageoverlay';
	}
	getDomNode() {
		return this._domNode;
	}
	getPosition() {
		return {
			position: this._position,
			preference: [1, 2],
			positionAffinity: 1
		};
	}
	afterRender(position) {
		this._domNode.classList.toggle(
			'below',
			position === 2 // BELOW
		);
	}
}
registerEditorContribution(
	MessageController.ID,
	MessageController,
	4 //Lazy
);