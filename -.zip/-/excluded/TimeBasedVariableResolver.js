var KnownSnippetVariableNames = freeze({
	CURRENT_YEAR: true,
	CURRENT_YEAR_SHORT: true,
	CURRENT_MONTH: true,
	CURRENT_DATE: true,
	CURRENT_HOUR: true,
	CURRENT_MINUTE: true,
	CURRENT_SECOND: true,
	CURRENT_DAY_NAME: true,
	CURRENT_DAY_NAME_SHORT: true,
	CURRENT_MONTH_NAME: true,
	CURRENT_MONTH_NAME_SHORT: true,
	CURRENT_SECONDS_UNIX: true,
	CURRENT_TIMEZONE_OFFSET: true,
	SELECTION: true,
	CLIPBOARD: true,
	TM_SELECTED_TEXT: true,
	TM_CURRENT_LINE: true,
	TM_CURRENT_WORD: true,
	TM_LINE_INDEX: true,
	TM_LINE_NUMBER: true,
	TM_FILENAME: true,
	TM_FILENAME_BASE: true,
	TM_DIRECTORY: true,
	TM_FILEPATH: true,
	CURSOR_INDEX: true,
	// 0-offset
	CURSOR_NUMBER: true,
	// 1-offset
	RELATIVE_FILEPATH: true,
	BLOCK_COMMENT_START: true,
	BLOCK_COMMENT_END: true,
	LINE_COMMENT: true,
	WORKSPACE_NAME: true,
	WORKSPACE_FOLDER: true,
	RANDOM: true,
	RANDOM_HEX: true,
	UUID: true
});
class CompositeSnippetVariableResolver {
	constructor(_delegates) {
		this._delegates = _delegates;
	}
	resolve(variable) {
		for (const delegate of this._delegates) {
			const value = delegate.resolve(variable);
			if (value !== undefined) {
				return value;
			}
		}
		return;
	}
}
class SelectionBasedVariableResolver {
	constructor(_model, _selection, _selectionIdx, _overtypingCapturer) {
		this._model = _model;
		this._selection = _selection;
		this._selectionIdx = _selectionIdx;
		this._overtypingCapturer = _overtypingCapturer;
	}
	resolve(variable) {
		const { name } = variable;
		if (name === 'SELECTION' || name === 'TM_SELECTED_TEXT') {
			let value = this._model.getValueInRange(this._selection) || undefined;
			let isMultiline = this._selection.startLineNumber !== this._selection.endLineNumber;
			if (!value && this._overtypingCapturer) {
				const info = this._overtypingCapturer.getLastOvertypedInfo(this._selectionIdx);
				if (info) {
					value = info.value;
					isMultiline = info.multiline;
				}
			}
			if (value && isMultiline && variable.snippet) {
				const line = this._model.getLineContent(this._selection.startLineNumber);
				const lineLeadingWhitespace = getLeadingWhitespace(line, 0, this._selection.startColumn - 1);
				let varLeadingWhitespace = lineLeadingWhitespace;
				variable.snippet.walk(marker => {
					if (marker === variable) {
						return false;
					}
					if (marker instanceof Text) {
						varLeadingWhitespace = getLeadingWhitespace(splitLines(marker.value).pop());
					}
					return true;
				});
				const whitespaceCommonLength = commonPrefixLength(varLeadingWhitespace, lineLeadingWhitespace);
				value = value.replace(
					/(\r\n|\r|\n)(.*)/g,
					(m, newline, rest) => `${newline}${varLeadingWhitespace.substr(whitespaceCommonLength)}${rest}`
				);
			}
			return value;
		} else if (name === 'TM_CURRENT_LINE') {
			return this._model.getLineContent(this._selection.positionLineNumber);
		} else if (name === 'TM_CURRENT_WORD') {
			const info = this._model.getWordAtPosition({
				lineNumber: this._selection.positionLineNumber,
				column: this._selection.positionColumn
			});
			return (info && info.word) || undefined;
		} else if (name === 'TM_LINE_INDEX') {
			return String(this._selection.positionLineNumber - 1);
		} else if (name === 'TM_LINE_NUMBER') {
			return String(this._selection.positionLineNumber);
		} else if (name === 'CURSOR_INDEX') {
			return String(this._selectionIdx);
		} else if (name === 'CURSOR_NUMBER') {
			return String(this._selectionIdx + 1);
		}
		return;
	}
}
class ModelBasedVariableResolver {
	constructor(_labelService, _model) {
		this._labelService = _labelService;
		this._model = _model;
	}
	resolve(variable) {
		const { name } = variable;
		if (name === 'TM_FILENAME') {
			return basename(this._model.uri.fsPath);
		} else if (name === 'TM_FILENAME_BASE') {
			const name2 = basename(this._model.uri.fsPath);
			const idx = name2.lastIndexOf('.');
			if (idx <= 0) {
				return name2;
			} else {
				return name2.slice(0, idx);
			}
		} else if (name === 'TM_DIRECTORY') {
			if (dirname(this._model.uri.fsPath) === '.') {
				return '';
			}
			return this._labelService.getUriLabel(dirname2(this._model.uri));
		} else if (name === 'TM_FILEPATH') {
			return this._labelService.getUriLabel(this._model.uri);
		} else if (name === 'RELATIVE_FILEPATH') {
			return this._labelService.getUriLabel(this._model.uri, { relative: true, noPrefix: true });
		}
		return;
	}
}
class ClipboardBasedVariableResolver {
	constructor(_readClipboardText, _selectionIdx, _selectionCount, _spread) {
		this._readClipboardText = _readClipboardText;
		this._selectionIdx = _selectionIdx;
		this._selectionCount = _selectionCount;
		this._spread = _spread;
	}
	resolve(variable) {
		if (variable.name !== 'CLIPBOARD') {
			return;
		}
		const clipboardText = this._readClipboardText();
		if (!clipboardText) {
			return;
		}
		if (this._spread) {
			const lines = clipboardText.split(/\r\n|\n|\r/).filter(s => !isFalsyOrNotStringOrIsBlank(s));
			if (lines.length === this._selectionCount) {
				return lines[this._selectionIdx];
			}
		}
		return clipboardText;
	}
}

class CommentBasedVariableResolver {
	constructor(_model, _selection, _languageConfigurationService) {
		this._model = _model;
		this._selection = _selection;
		this._languageConfigurationService = _languageConfigurationService;
	}
	resolve(variable) {
		const { name } = variable;
		const langId = this._model.getLanguageIdAtPosition(this._selection.selectionStartLineNumber, this._selection.selectionStartColumn);
		const config = this._languageConfigurationService.getLanguageConfiguration(langId).comments;
		if (!config) {
			return;
		}
		if (name === 'LINE_COMMENT') {
			return config.lineCommentToken || undefined;
		} else if (name === 'BLOCK_COMMENT_START') {
			return config.blockCommentStartToken || undefined;
		} else if (name === 'BLOCK_COMMENT_END') {
			return config.blockCommentEndToken || undefined;
		}
		return;
	}
}
__decorate([__param(2, ILanguageConfigurationService)], CommentBasedVariableResolver);



class WorkspaceBasedVariableResolver {
	constructor(_workspaceService) {
		this._workspaceService = _workspaceService;
	}
	resolve(variable) {
		if (!this._workspaceService) {
			return;
		}
		const workspaceIdentifier = toWorkspaceIdentifier(this._workspaceService.getWorkspace());
		if (isEmptyWorkspaceIdentifier(workspaceIdentifier)) {
			return;
		}
		if (variable.name === 'WORKSPACE_NAME') {
			return this._resolveWorkspaceName(workspaceIdentifier);
		} else if (variable.name === 'WORKSPACE_FOLDER') {
			return this._resoveWorkspacePath(workspaceIdentifier);
		}
		return;
	}
	_resolveWorkspaceName(workspaceIdentifier) {
		if (isSingleFolderWorkspaceIdentifier(workspaceIdentifier)) {
			return basename(workspaceIdentifier.uri.path);
		}
		let filename = basename(workspaceIdentifier.configPath.path);
		if (filename.endsWith(WORKSPACE_EXTENSION)) {
			filename = filename.substr(0, filename.length - WORKSPACE_EXTENSION.length - 1);
		}
		return filename;
	}
	_resoveWorkspacePath(workspaceIdentifier) {

		const normalizeDriveLetter = path => (
			(
				isWindows &&
				isWindowsDriveLetter(path.charCodeAt(0)) &&
				58 ===path.charCodeAt(1)

			) ? path.charAt(0).toUpperCase() + path.slice(1)
			  : path
		);


		if (isSingleFolderWorkspaceIdentifier(workspaceIdentifier)) {
			return normalizeDriveLetter(workspaceIdentifier.uri.fsPath);
		}
		const filename = basename(workspaceIdentifier.configPath.path);
		let folderpath = workspaceIdentifier.configPath.fsPath;
		if (folderpath.endsWith(filename)) {
			folderpath = folderpath.substr(0, folderpath.length - filename.length - 1);
		}
		return folderpath ? normalizeDriveLetter(folderpath) : '/';
	}
}
class RandomBasedVariableResolver {
	resolve(variable) {
		const { name } = variable;
		if (name === 'RANDOM') {
			return Math.random().toString().slice(-6);
		} else if (name === 'RANDOM_HEX') {
			return Math.random().toString(16).slice(-6);
		} else if (name === 'UUID') {
			return generateUuid();
		}
		return;
	}
}
class TimeBasedVariableResolver {
	constructor() {
		this._date = new Date();
	}
	resolve(variable) {
		const { name } = variable;
		if (name === 'CURRENT_YEAR') {
			return String(this._date.getFullYear());
		} else if (name === 'CURRENT_YEAR_SHORT') {
			return String(this._date.getFullYear()).slice(-2);
		} else if (name === 'CURRENT_MONTH') {
			return String(this._date.getMonth().valueOf() + 1).padStart(2, '0');
		} else if (name === 'CURRENT_DATE') {
			return String(this._date.getDate().valueOf()).padStart(2, '0');
		} else if (name === 'CURRENT_HOUR') {
			return String(this._date.getHours().valueOf()).padStart(2, '0');
		} else if (name === 'CURRENT_MINUTE') {
			return String(this._date.getMinutes().valueOf()).padStart(2, '0');
		} else if (name === 'CURRENT_SECOND') {
			return String(this._date.getSeconds().valueOf()).padStart(2, '0');
		} else if (name === 'CURRENT_DAY_NAME') {
			return TimeBasedVariableResolver.dayNames[this._date.getDay()];
		} else if (name === 'CURRENT_DAY_NAME_SHORT') {
			return TimeBasedVariableResolver.dayNamesShort[this._date.getDay()];
		} else if (name === 'CURRENT_MONTH_NAME') {
			return TimeBasedVariableResolver.monthNames[this._date.getMonth()];
		} else if (name === 'CURRENT_MONTH_NAME_SHORT') {
			return TimeBasedVariableResolver.monthNamesShort[this._date.getMonth()];
		} else if (name === 'CURRENT_SECONDS_UNIX') {
			return String(Math.floor(this._date.getTime() / 1e3));
		} else if (name === 'CURRENT_TIMEZONE_OFFSET') {
			const rawTimeOffset = this._date.getTimezoneOffset();
			const sign = rawTimeOffset > 0 ? '-' : '+';
			const hours = Math.trunc(Math.abs(rawTimeOffset / 60));
			const hoursString = hours < 10 ? '0' + hours : hours;
			const minutes = Math.abs(rawTimeOffset) - hours * 60;
			const minutesString = minutes < 10 ? '0' + minutes : minutes;
			return sign + hoursString + ':' + minutesString;
		}
		return;
	}
}
TimeBasedVariableResolver.dayNames = [
	localize('Sunday'),
	localize('Monday'),
	localize('Tuesday'),
	localize('Wednesday'),
	localize('Thursday'),
	localize('Friday'),
	localize('Saturday')
];
TimeBasedVariableResolver.dayNamesShort = [
	localize('Sun'),
	localize('Mon'),
	localize('Tue'),
	localize('Wed'),
	localize('Thu'),
	localize('Fri'),
	localize('Sat')
];
TimeBasedVariableResolver.monthNames = [
	localize('January'),
	localize('February'),
	localize('March'),
	localize('April'),
	localize('May'),
	localize('June'),
	localize('July'),
	localize('August'),
	localize('September'),
	localize('October'),
	localize('November'),
	localize('December')
];
TimeBasedVariableResolver.monthNamesShort = [
	localize('Jan'),
	localize('Feb'),
	localize('Mar'),
	localize('Apr'),
	localize('May'),
	localize('Jun'),
	localize('Jul'),
	localize('Aug'),
	localize('Sep'),
	localize('Oct'),
	localize('Nov'),
	localize('Dec')
];