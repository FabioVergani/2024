class TextModelText extends AbstractText {
	constructor(_textModel) {
		super();
		this._textModel = _textModel;
	}
	getValueOfRange(range2) {
		return this._textModel.getValueInRange(range2);
	}
	get length() {
		const lastLineNumber = this._textModel.getLineCount();
		const lastLineLen = this._textModel.getLineLength(lastLineNumber);
		return new TextLength(lastLineNumber - 1, lastLineLen);
	}
}

