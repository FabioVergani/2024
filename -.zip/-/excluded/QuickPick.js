




const unthemedKeybindingLabelOptions = {};
class KeybindingLabel extends Disposable {
	constructor(container, os, options2) {
		super();
		this.os = os;
		this.keyElements = new Set();
		this.options = options2 || Object.create(null);
		const labelForeground = this.options.keybindingLabelForeground;
		this.domNode = append(container, createDomElement('.monaco-keybinding'));
		if (labelForeground) {
			this.domNode.style.color = labelForeground;
		}
		this.hover = this._register(getBaseLayerHoverDelegate().setupUpdatableHover(getDefaultHoverDelegate('mouse'), this.domNode, ''));
		this.didEverRender = false;
		container.appendChild(this.domNode);
	}
	get element() {
		return this.domNode;
	}
	set(keybinding, matches) {
		if (this.didEverRender && this.keybinding === keybinding && KeybindingLabel.areSame(this.matches, matches)) {
			return;
		}
		this.keybinding = keybinding;
		this.matches = matches;
		this.render();
	}
	render() {
		this.clear();
		if (this.keybinding) {
			const chords = this.keybinding.getChords();
			if (chords[0]) {
				this.renderChord(this.domNode, chords[0], this.matches ? this.matches.firstPart : null);
			}
			for (let i = 1; i < chords.length; i++) {
				append(this.domNode, createDomElement('span.monaco-keybinding-key-chord-separator', undefined, ' '));
				this.renderChord(this.domNode, chords[i], this.matches ? this.matches.chordPart : null);
			}
			const title = this.options.disableTitle;
			this.hover.update(title);
		} else if (this.options && this.options.renderUnboundKeybindings) {
			this.renderUnbound(this.domNode);
		}
		this.didEverRender = true;
	}
	clear() {
		clearNode(this.domNode);
		this.keyElements.clear();
	}
	renderChord(parent, chord, match2) {
		const modifierLabels = UILabelProvider.modifierLabels[this.os];
		if (chord.ctrlKey) {
			this.renderKey(parent, modifierLabels.ctrlKey, Boolean(match2?.ctrlKey), modifierLabels.separator);
		}
		if (chord.shiftKey) {
			this.renderKey(parent, modifierLabels.shiftKey, Boolean(match2?.shiftKey), modifierLabels.separator);
		}
		if (chord.altKey) {
			this.renderKey(parent, modifierLabels.altKey, Boolean(match2?.altKey), modifierLabels.separator);
		}
		if (chord.metaKey) {
			this.renderKey(parent, modifierLabels.metaKey, Boolean(match2?.metaKey), modifierLabels.separator);
		}
		const keyLabel = chord.keyLabel;
		if (keyLabel) {
			this.renderKey(parent, keyLabel, Boolean(match2?.keyCode), '');
		}
	}
	renderKey(parent, label, highlight, separator) {
		append(parent, this.createKeyElement(label, highlight ? '.highlight' : ''));
		if (separator) {
			append(parent, createDomElement('span.monaco-keybinding-key-separator', undefined, separator));
		}
	}
	renderUnbound(parent) {
		append(parent, this.createKeyElement(localize('Unbound')));
	}
	createKeyElement(label, extraClass = '') {
		const keyElement = createDomElement('span.monaco-keybinding-key' + extraClass, undefined, label);
		this.keyElements.add(keyElement);
		if (this.options.keybindingLabelBackground) {
			keyElement.style.backgroundColor = this.options.keybindingLabelBackground;
		}
		if (this.options.keybindingLabelBorder) {
			keyElement.style.borderColor = this.options.keybindingLabelBorder;
		}
		if (this.options.keybindingLabelBottomBorder) {
			keyElement.style.borderBottomColor = this.options.keybindingLabelBottomBorder;
		}
		if (this.options.keybindingLabelShadow) {
			keyElement.style.boxShadow = `inset 0 -1px 0 ${this.options.keybindingLabelShadow}`;
		}
		return keyElement;
	}
	static areSame(a, b) {
		if (a === b || (!a && !b)) {
			return true;
		}
		return !!a && !!b && isDeepEqual(a.firstPart, b.firstPart) && isDeepEqual(a.chordPart, b.chordPart);
	}
}


const intlFileNameCollatorBaseNumeric = new Lazy(() => {
	const collator = new Intl.Collator(undefined, {
		numeric: true,
		sensitivity: 'base'
	});
	return {
		collator,
		collatorIsNumeric: collator.resolvedOptions().numeric
	};
});
const intlFileNameCollatorNumeric = new Lazy(() => {
	const collator = new Intl.Collator(undefined, { numeric: true });
	return { collator };
});
const intlFileNameCollatorNumericCaseInsensitive = new Lazy(() => {
	const collator = new Intl.Collator(undefined, {
		numeric: true,
		sensitivity: 'accent'
	});
	return {
		collator
	};
});







const backButton = {
	iconClass: asThemeIconClassNameString(codicon_arrowLeft),
	tooltip: localize('Back'),
	handle: -1
};

const LINK_REGEX = /\[([^\]]+)\]\(((?:https?:\/\/|command:|file:)[^\)\s]+)(?: (["'])(.+?)(\3))?\)/gi;

class QuickInput extends Disposable {
	constructor(ui) {
		super();
		this.ui = ui;
		this._widgetUpdated = false;
		this.visible = false;
		this._enabled = true;
		this._busy = false;
		this._ignoreFocusOut = false;
		this._buttons = [];
		this.buttonsUpdated = false;
		this._toggles = [];
		this.togglesUpdated = false;
		this.noValidationMessage = QuickInput.noPromptMessage;
		this._severity = 0;
		this.onDidTriggerButtonEmitter = this._register(new Emitter());
		this.onDidHideEmitter = this._register(new Emitter());
		this.onWillHideEmitter = this._register(new Emitter());
		this.onDisposeEmitter = this._register(new Emitter());
		this.visibleDisposables = this._register(new DisposableStore());
		this.onDidHide = this.onDidHideEmitter.event;
	}
	get title() {
		return this._title;
	}
	set title(title) {
		this._title = title;
		this.update();
	}
	get description() {
		return this._description;
	}
	set description(description) {
		this._description = description;
		this.update();
	}
	get step() {
		return this._steps;
	}
	set step(step) {
		this._steps = step;
		this.update();
	}
	get totalSteps() {
		return this._totalSteps;
	}
	set totalSteps(totalSteps) {
		this._totalSteps = totalSteps;
		this.update();
	}
	get enabled() {
		return this._enabled;
	}
	set enabled(enabled) {
		this._enabled = enabled;
		this.update();
	}
	get contextKey() {
		return this._contextKey;
	}
	set contextKey(contextKey) {
		this._contextKey = contextKey;
		this.update();
	}
	get busy() {
		return this._busy;
	}
	set busy(busy) {
		this._busy = busy;
		this.update();
	}
	get ignoreFocusOut() {
		return this._ignoreFocusOut;
	}
	set ignoreFocusOut(ignoreFocusOut) {
		const shouldUpdate = this._ignoreFocusOut !== ignoreFocusOut && !isIOS;
		this._ignoreFocusOut = ignoreFocusOut && !isIOS;
		if (shouldUpdate) {
			this.update();
		}
	}
	get buttons() {
		return this._buttons;
	}
	set buttons(buttons) {
		this._buttons = buttons;
		this.buttonsUpdated = true;
		this.update();
	}
	get toggles() {
		return this._toggles;
	}
	set toggles(toggles) {
		this._toggles = toggles !== null && toggles !== undefined ? toggles : [];
		this.togglesUpdated = true;
		this.update();
	}
	get validationMessage() {
		return this._validationMessage;
	}
	set validationMessage(validationMessage) {
		this._validationMessage = validationMessage;
		this.update();
	}
	get severity() {
		return this._severity;
	}
	set severity(severity) {
		this._severity = severity;
		this.update();
	}
	show() {
		if (this.visible) {
			return;
		}
		this.visibleDisposables.add(
			this.ui.onDidTriggerButton(button => {
				if (this.buttons.indexOf(button) !== -1) {
					this.onDidTriggerButtonEmitter.fire(button);
				}
			})
		);
		this.ui.show(this);
		this.visible = true;
		this._lastValidationMessage = undefined;
		this._lastSeverity = undefined;
		if (this.buttons.length) {
			this.buttonsUpdated = true;
		}
		if (this.toggles.length) {
			this.togglesUpdated = true;
		}
		this.update();
	}
	hide() {
		if (!this.visible) {
			return;
		}
		this.ui.hide();
	}
	didHide(reason = 3) {
		this.visible = false;
		this.visibleDisposables.clear();
		this.onDidHideEmitter.fire({ reason });
	}
	willHide(reason = 3) {
		this.onWillHideEmitter.fire({ reason });
	}
	update() {
		if (this.visible) {
			const title = this.getTitle();
			if (title && this.ui.title.textContent !== title) {
				this.ui.title.textContent = title;
			} else if (!title && this.ui.title.innerHTML !== '&nbsp;') {
				this.ui.title.innerText = '\xA0';
			}
			const description = this.getDescription();
			if (this.ui.description1.textContent !== description) {
				this.ui.description1.textContent = description;
			}
			if (this.ui.description2.textContent !== description) {
				this.ui.description2.textContent = description;
			}
			if (this._widgetUpdated) {
				this._widgetUpdated = false;
				if (this._widget) {
					reset(this.ui.widget, this._widget);
				} else {
					reset(this.ui.widget);
				}
			}
			if (this.busy && !this.busyDelay) {
				this.busyDelay = new TimeoutTimer();
				this.busyDelay.setIfNotSet(() => {
					if (this.visible) {
						this.ui.progressBar.infinite();
					}
				}, 800);
			}
			if (!this.busy && this.busyDelay) {
				this.ui.progressBar.stop();
				this.busyDelay.cancel();
				this.busyDelay = undefined;
			}
			if (this.buttonsUpdated) {
				this.buttonsUpdated = false;
				this.ui.leftActionBar.clear();
				const leftButtons = this.buttons
					.filter(button => button === backButton)
					.map((button, index) =>
						quickInputButtonToAction(button, `id-${index}`, async () => this.onDidTriggerButtonEmitter.fire(button))
					);
				this.ui.leftActionBar.push(leftButtons, {
					icon: true,
					label: false
				});
				this.ui.rightActionBar.clear();
				const rightButtons = this.buttons
					.filter(button => button !== backButton)
					.map((button, index) =>
						quickInputButtonToAction(button, `id-${index}`, async () => this.onDidTriggerButtonEmitter.fire(button))
					);
				this.ui.rightActionBar.push(rightButtons, {
					icon: true,
					label: false
				});
			}
			if (this.togglesUpdated) {
				this.togglesUpdated = false;
				const concreteToggles = this.toggles?.filter(opts => opts instanceof Toggle) ?? [];
				this.ui.inputBox.toggles = concreteToggles;
			}
			this.ui.ignoreFocusOut = this.ignoreFocusOut;
			this.ui.setEnabled(this.enabled);
			this.ui.setContextKey(this.contextKey);
			const validationMessage = this.validationMessage || this.noValidationMessage;
			if (this._lastValidationMessage !== validationMessage) {
				this._lastValidationMessage = validationMessage;
				reset(this.ui.message);
				function _renderQuickInputDescription(description, container, actionHandler) {
					reset(container);
					const result = [];
					let index = 0;
					let match;
					while ((match = LINK_REGEX.exec(description))) {
						if (match.index - index > 0) {
							result.push(description.substring(index, match.index));
						}
						const [, label, href, , title] = match;
						if (title) {
							result.push({ label, href, title });
						} else {
							result.push({ label, href });
						}
						index = match.index + match[0].length;
					}
					if (index < description.length) {
						result.push(description.substring(index));
					}
					const parsed = new LinkedText(result);
					let tabIndex = 0;
					for (const node of parsed.nodes) {
						if (typeof node === 'string') {
							container.append(...renderLabelWithIcons(node));
						} else {
							let title = node.title;
							if (!title && node.href.startsWith('command:')) {
								title = localize("Click to execute command '{0}'", node.href.substring('command:'.length));
							} else if (!title) {
								title = node.href;
							}
							const anchor = createDomElement(
								'a',
								{
									href: node.href,
									title,
									tabIndex: tabIndex++
								},
								node.label
							);
							anchor.style.textDecoration = 'underline';
							const handleOpen = e => {
								if (isEventLike(e)) {
									EventHelper.stop(e, true);
								}
								actionHandler.callback(node.href);
							};
							const onClick = actionHandler.disposables.add(new DomEmitter(anchor, EventType.CLICK)).event;
							const onKeydown = actionHandler.disposables.add(new DomEmitter(anchor, EventType.KEY_DOWN)).event;
							const onSpaceOrEnter = editorEventChain(onKeydown, $16 =>
								$16.filter(e => {
									const event = new StandardKeyboardEvent(e);
									return (
										event.equals(
											10 //Space
										) ||
										event.equals(
											3 //Enter
										)
									);
								})
							);
							actionHandler.disposables.add(Gesture.addTarget(anchor));
							const onTap = actionHandler.disposables.add(new DomEmitter(anchor, GestureType.Tap)).event;
							editorEventAny(onClick, onTap, onSpaceOrEnter)(handleOpen, null, actionHandler.disposables);
							container.appendChild(anchor);
						}
					}
				}
				_renderQuickInputDescription(validationMessage, this.ui.message, {
					callback: content => {
						this.ui.linkOpenerDelegate(content);
					},
					disposables: this.visibleDisposables
				});
			}
			if (this._lastSeverity !== this.severity) {
				this._lastSeverity = this.severity;
				this.showMessageDecoration(this.severity);
			}
		}
	}
	getTitle() {
		if (this.title && this.step) {
			return `${this.title} (${this.getSteps()})`;
		}
		if (this.title) {
			return this.title;
		}
		if (this.step) {
			return this.getSteps();
		}
		return '';
	}
	getDescription() {
		return this.description || '';
	}
	getSteps() {
		if (this.step && this.totalSteps) {
			return localize(this.step, this.totalSteps);
		}
		if (this.step) {
			return String(this.step);
		}
		return '';
	}
	showMessageDecoration(severity) {
		this.ui.inputBox.showDecoration(severity);
		if (severity !== 0) {
			const styles = this.ui.inputBox.stylesForType(severity);
			this.ui.message.style.color = styles.foreground ? `${styles.foreground}` : '';
			this.ui.message.style.backgroundColor = styles.background ? `${styles.background}` : '';
			this.ui.message.style.border = styles.border ? `1px solid ${styles.border}` : '';
			this.ui.message.style.marginBottom = '-2px';
		} else {
			this.ui.message.style.color = '';
			this.ui.message.style.backgroundColor = '';
			this.ui.message.style.border = '';
			this.ui.message.style.marginBottom = '';
		}
	}
	dispose() {
		this.hide();
		this.onDisposeEmitter.fire();
		super.dispose();
	}
}
QuickInput.noPromptMessage = localize("Press 'Enter' to confirm your input or 'Escape' to cancel");

class QuickPick extends QuickInput {
	constructor() {
		super(...arguments);
		this._value = '';
		this.onDidChangeValueEmitter = this._register(new Emitter());
		this.onWillAcceptEmitter = this._register(new Emitter());
		this.onDidAcceptEmitter = this._register(new Emitter());
		this.onDidCustomEmitter = this._register(new Emitter());
		this._items = [];
		this.itemsUpdated = false;
		this._canSelectMany = false;
		this._canAcceptInBackground = false;
		this._matchOnDescription = false;
		this._matchOnDetail = false;
		this._matchOnLabel = true;
		this._matchOnLabelMode = 'fuzzy';
		this._sortByLabel = true;
		this._keepScrollPosition = false;
		this._itemActivation = 1;
		this._activeItems = [];
		this.activeItemsUpdated = false;
		this.activeItemsToConfirm = [];
		this.onDidChangeActiveEmitter = this._register(new Emitter());
		this._selectedItems = [];
		this.selectedItemsUpdated = false;
		this.selectedItemsToConfirm = [];
		this.onDidChangeSelectionEmitter = this._register(new Emitter());
		this.onDidTriggerItemButtonEmitter = this._register(new Emitter());
		this.onDidTriggerSeparatorButtonEmitter = this._register(new Emitter());
		this.valueSelectionUpdated = true;
		this._ok = 'default';
		this._customButton = false;
		this.filterValue = value => value;
		this.onDidChangeValue = this.onDidChangeValueEmitter.event;
		this.onWillAccept = this.onWillAcceptEmitter.event;
		this.onDidAccept = this.onDidAcceptEmitter.event;
		this.onDidChangeActive = this.onDidChangeActiveEmitter.event;
		this.onDidChangeSelection = this.onDidChangeSelectionEmitter.event;
		this.onDidTriggerItemButton = this.onDidTriggerItemButtonEmitter.event;
		this.onDidTriggerSeparatorButton = this.onDidTriggerSeparatorButtonEmitter.event;
	}
	get quickNavigate() {
		return this._quickNavigate;
	}
	set quickNavigate(quickNavigate) {
		this._quickNavigate = quickNavigate;
		this.update();
	}
	get value() {
		return this._value;
	}
	set value(value) {
		this.doSetValue(value);
	}
	doSetValue(value, skipUpdate) {
		if (this._value !== value) {
			this._value = value;
			if (!skipUpdate) {
				this.update();
			}
			if (this.visible) {
				const didFilter = this.ui.list.filter(this.filterValue(this._value));
				if (didFilter) {
					this.trySelectFirst();
				}
			}
			this.onDidChangeValueEmitter.fire(this._value);
		}
	}
	get placeholder() {
		return this._placeholder;
	}
	set placeholder(placeholder) {
		this._placeholder = placeholder;
		this.update();
	}
	get items() {
		return this._items;
	}
	get scrollTop() {
		return this.ui.list.scrollTop;
	}
	set scrollTop(scrollTop) {
		this.ui.list.scrollTop = scrollTop;
	}
	set items(items) {
		this._items = items;
		this.itemsUpdated = true;
		this.update();
	}
	get canSelectMany() {
		return this._canSelectMany;
	}
	set canSelectMany(canSelectMany) {
		this._canSelectMany = canSelectMany;
		this.update();
	}
	get canAcceptInBackground() {
		return this._canAcceptInBackground;
	}
	set canAcceptInBackground(canAcceptInBackground) {
		this._canAcceptInBackground = canAcceptInBackground;
	}
	get matchOnDescription() {
		return this._matchOnDescription;
	}
	set matchOnDescription(matchOnDescription) {
		this._matchOnDescription = matchOnDescription;
		this.update();
	}
	get matchOnDetail() {
		return this._matchOnDetail;
	}
	set matchOnDetail(matchOnDetail) {
		this._matchOnDetail = matchOnDetail;
		this.update();
	}
	get matchOnLabel() {
		return this._matchOnLabel;
	}
	set matchOnLabel(matchOnLabel) {
		this._matchOnLabel = matchOnLabel;
		this.update();
	}
	get matchOnLabelMode() {
		return this._matchOnLabelMode;
	}
	set matchOnLabelMode(matchOnLabelMode) {
		this._matchOnLabelMode = matchOnLabelMode;
		this.update();
	}
	get sortByLabel() {
		return this._sortByLabel;
	}
	set sortByLabel(sortByLabel) {
		this._sortByLabel = sortByLabel;
		this.update();
	}
	get keepScrollPosition() {
		return this._keepScrollPosition;
	}
	set keepScrollPosition(keepScrollPosition) {
		this._keepScrollPosition = keepScrollPosition;
	}
	get itemActivation() {
		return this._itemActivation;
	}
	set itemActivation(itemActivation) {
		this._itemActivation = itemActivation;
	}
	get activeItems() {
		return this._activeItems;
	}
	set activeItems(activeItems) {
		this._activeItems = activeItems;
		this.activeItemsUpdated = true;
		this.update();
	}
	get selectedItems() {
		return this._selectedItems;
	}
	set selectedItems(selectedItems) {
		this._selectedItems = selectedItems;
		this.selectedItemsUpdated = true;
		this.update();
	}
	get keyMods() {
		if (this._quickNavigate) {
			return { ctrlCmd: false, alt: false };
		}
		return this.ui.keyMods;
	}
	get valueSelection() {
		const selection = this.ui.inputBox.getSelection();
		if (!selection) {
			return;
		}
		return [selection.start, selection.end];
	}
	set valueSelection(valueSelection) {
		this._valueSelection = valueSelection;
		this.valueSelectionUpdated = true;
		this.update();
	}
	get customButton() {
		return this._customButton;
	}
	set customButton(showCustomButton) {
		this._customButton = showCustomButton;
		this.update();
	}
	get customLabel() {
		return this._customButtonLabel;
	}
	set customLabel(label) {
		this._customButtonLabel = label;
		this.update();
	}
	get customHover() {
		return this._customButtonHover;
	}
	set customHover(hover) {
		this._customButtonHover = hover;
		this.update();
	}
	get ok() {
		return this._ok;
	}
	set ok(showOkButton) {
		this._ok = showOkButton;
		this.update();
	}
	get hideInput() {
		return !!this._hideInput;
	}
	set hideInput(hideInput) {
		this._hideInput = hideInput;
		this.update();
	}
	trySelectFirst() {
		if (!this.canSelectMany) {
			this.ui.list.focus(1);
		}
	}
	show() {
		if (!this.visible) {
			this.visibleDisposables.add(
				this.ui.inputBox.onDidChange(value => {
					this.doSetValue(
						value,
						true //kip update since this originates from the UI
					);
				})
			);
			this.visibleDisposables.add(
				(this._hideInput ? this.ui.list : this.ui.inputBox).onKeyDown(event => {
					switch (event.keyCode) {
						case 18:
							if (this.quickNavigate === undefined && (isMacintosh ? event.metaKey : event.altKey)) {
								this.ui.list.focus(8);
							} else {
								this.ui.list.focus(4);
							}
							if (this.canSelectMany) {
								this.ui.list.domFocus();
							}
							EventHelper.stop(event, true);
							break;
						case 16:
							if (this.quickNavigate === undefined && (isMacintosh ? event.metaKey : event.altKey)) {
								this.ui.list.focus(9);
							} else {
								this.ui.list.focus(5);
							}
							if (this.canSelectMany) {
								this.ui.list.domFocus();
							}
							EventHelper.stop(event, true);
							break;
						case 12:
							this.ui.list.focus(6);
							if (this.canSelectMany) {
								this.ui.list.domFocus();
							}
							EventHelper.stop(event, true);
							break;
						case 11:
							this.ui.list.focus(7);
							if (this.canSelectMany) {
								this.ui.list.domFocus();
							}
							EventHelper.stop(event, true);
							break;
						case 17:
							if (!this._canAcceptInBackground) {
								return;
							}
							if (!this.ui.inputBox.isSelectionAtEnd()) {
								return;
							}
							if (this.activeItems[0]) {
								this._selectedItems = [this.activeItems[0]];
								this.onDidChangeSelectionEmitter.fire(this.selectedItems);
								this.handleAccept(true);
							}
							break;
						case 14:
							if ((event.ctrlKey || event.metaKey) && !event.shiftKey && !event.altKey) {
								this.ui.list.focus(1);
								EventHelper.stop(event, true);
							}
							break;
						case 13:
							if ((event.ctrlKey || event.metaKey) && !event.shiftKey && !event.altKey) {
								this.ui.list.focus(3);
								EventHelper.stop(event, true);
							}
							break;
					}
				})
			);
			this.visibleDisposables.add(
				this.ui.onDidAccept(() => {
					if (this.canSelectMany) {
						if (!this.ui.list.getCheckedElements().length) {
							this._selectedItems = [];
							this.onDidChangeSelectionEmitter.fire(this.selectedItems);
						}
					} else if (this.activeItems[0]) {
						this._selectedItems = [this.activeItems[0]];
						this.onDidChangeSelectionEmitter.fire(this.selectedItems);
					}
					this.handleAccept(false);
				})
			);
			this.visibleDisposables.add(
				this.ui.onDidCustom(() => {
					this.onDidCustomEmitter.fire();
				})
			);
			this.visibleDisposables.add(
				this.ui.list.onDidChangeFocus(focusedItems => {
					if (this.activeItemsUpdated) {
						return;
					}
					if (this.activeItemsToConfirm !== this._activeItems && equals(focusedItems, this._activeItems, (a, b) => a === b)) {
						return;
					}
					this._activeItems = focusedItems;
					this.onDidChangeActiveEmitter.fire(focusedItems);
				})
			);
			this.visibleDisposables.add(
				this.ui.list.onDidChangeSelection(({ items: selectedItems, event }) => {
					if (this.canSelectMany) {
						if (selectedItems.length) {
							this.ui.list.setSelectedElements([]);
						}
						return;
					}
					if (
						this.selectedItemsToConfirm !== this._selectedItems &&
						equals(selectedItems, this._selectedItems, (a, b) => a === b)
					) {
						return;
					}
					this._selectedItems = selectedItems;
					this.onDidChangeSelectionEmitter.fire(selectedItems);
					if (selectedItems.length) {
						this.handleAccept(
							isMouseEvent(event) && event.button === 1 // mouse middle click
						);
					}
				})
			);
			this.visibleDisposables.add(
				this.ui.list.onChangedCheckedElements(checkedItems => {
					if (!this.canSelectMany) {
						return;
					}
					if (
						this.selectedItemsToConfirm !== this._selectedItems &&
						equals(checkedItems, this._selectedItems, (a, b) => a === b)
					) {
						return;
					}
					this._selectedItems = checkedItems;
					this.onDidChangeSelectionEmitter.fire(checkedItems);
				})
			);
			this.visibleDisposables.add(this.ui.list.onButtonTriggered(event => this.onDidTriggerItemButtonEmitter.fire(event)));
			this.visibleDisposables.add(
				this.ui.list.onSeparatorButtonTriggered(event => this.onDidTriggerSeparatorButtonEmitter.fire(event))
			);
			this.visibleDisposables.add(this.registerQuickNavigation());
			this.valueSelectionUpdated = true;
		}
		super.show();
	}
	handleAccept(inBackground) {
		let veto = false;
		this.onWillAcceptEmitter.fire({ veto: () => (veto = true) });
		if (!veto) {
			this.onDidAcceptEmitter.fire({ inBackground });
		}
	}
	registerQuickNavigation() {
		return addDisposableListener(this.ui.container, EventType.KEY_UP, e => {
			if (this.canSelectMany || !this._quickNavigate) {
				return;
			}
			const keyboardEvent = new StandardKeyboardEvent(e);
			const keyCode = keyboardEvent.keyCode;
			const quickNavKeys = this._quickNavigate.keybindings;
			const wasTriggerKeyPressed = quickNavKeys.some(k => {
				const chords = k.getChords();
				if (chords.length > 1) {
					return false;
				}
				if (chords[0].shiftKey && keyCode === 4) {
					if (keyboardEvent.ctrlKey || keyboardEvent.altKey || keyboardEvent.metaKey) {
						return false;
					}
					return true;
				}
				if (chords[0].altKey && keyCode === 6) {
					return true;
				}
				if (chords[0].ctrlKey && keyCode === 5) {
					return true;
				}
				if (chords[0].metaKey && keyCode === 57) {
					return true;
				}
				return false;
			});
			if (wasTriggerKeyPressed) {
				if (this.activeItems[0]) {
					this._selectedItems = [this.activeItems[0]];
					this.onDidChangeSelectionEmitter.fire(this.selectedItems);
					this.handleAccept(false);
				}
				this._quickNavigate = undefined;
			}
		});
	}
	update() {
		if (!this.visible) {
			return;
		}
		const scrollTopBefore = this.keepScrollPosition ? this.scrollTop : 0;
		const hasDescription = !!this.description;
		const visibilities = {
			title: !!this.title || !!this.step || !!this.buttons.length,
			description: hasDescription,
			checkAll: this.canSelectMany && !this._hideCheckAll,
			checkBox: this.canSelectMany,
			inputBox: !this._hideInput,
			progressBar: !this._hideInput || hasDescription,
			visibleCount: true,
			count: this.canSelectMany && !this._hideCountBadge,
			ok: this.ok === 'default' ? this.canSelectMany : this.ok,
			list: true,
			message: !!this.validationMessage,
			customButton: this.customButton
		};
		this.ui.setVisibilities(visibilities);
		super.update();
		if (this.ui.inputBox.value !== this.value) {
			this.ui.inputBox.value = this.value;
		}
		if (this.valueSelectionUpdated) {
			this.valueSelectionUpdated = false;
			this.ui.inputBox.select(
				this._valueSelection && {
					start: this._valueSelection[0],
					end: this._valueSelection[1]
				}
			);
		}
		if (this.ui.inputBox.placeholder !== (this.placeholder || '')) {
			this.ui.inputBox.placeholder = this.placeholder || '';
		}
		this.ui.list.matchOnDescription = this.matchOnDescription;
		this.ui.list.matchOnDetail = this.matchOnDetail;
		this.ui.list.matchOnLabel = this.matchOnLabel;
		this.ui.list.matchOnLabelMode = this.matchOnLabelMode;
		this.ui.list.sortByLabel = this.sortByLabel;
		if (this.itemsUpdated) {
			this.itemsUpdated = false;
			const currentActiveItems = this._activeItems;
			this.ui.list.setElements(this.items);
			this.ui.list.filter(this.filterValue(this.ui.inputBox.value));
			this.ui.checkAll.checked = this.ui.list.getAllVisibleChecked();
			this.ui.visibleCount.setCount(this.ui.list.getVisibleCount());
			this.ui.count.setCount(this.ui.list.getCheckedCount());
			switch (this._itemActivation) {
				case 0:
					if (currentActiveItems.length > 0) {
						this._activeItems = [];
						this.onDidChangeActiveEmitter.fire(this._activeItems);
					}
					this._itemActivation = 1;
					break;
				case 2:
					this.ui.list.focus(2);
					this._itemActivation = 1;
					break;
				case 3:
					this.ui.list.focus(3);
					this._itemActivation = 1;
					break;
				default:
					this.trySelectFirst();
					break;
			}
		}
		if (this.ui.container.classList.contains('show-checkboxes') !== !!this.canSelectMany) {
			if (this.canSelectMany) {
				this.ui.list.clearFocus();
			} else {
				this.trySelectFirst();
			}
		}
		if (this.activeItemsUpdated) {
			this.activeItemsUpdated = false;
			this.activeItemsToConfirm = this._activeItems;
			this.ui.list.setFocusedElements(this.activeItems);
			if (this.activeItemsToConfirm === this._activeItems) {
				this.activeItemsToConfirm = null;
			}
		}
		if (this.selectedItemsUpdated) {
			this.selectedItemsUpdated = false;
			this.selectedItemsToConfirm = this._selectedItems;
			if (this.canSelectMany) {
				this.ui.list.setCheckedElements(this.selectedItems);
			} else {
				this.ui.list.setSelectedElements(this.selectedItems);
			}
			if (this.selectedItemsToConfirm === this._selectedItems) {
				this.selectedItemsToConfirm = null;
			}
		}
		this.ui.customButton.label = this.customLabel || '';
		this.ui.customButton.element.title = this.customHover || '';
		if (!visibilities.inputBox) {
			this.ui.list.domFocus();
			if (this.canSelectMany) {
				this.ui.list.focus(1);
			}
		}
		if (this.keepScrollPosition) {
			this.scrollTop = scrollTopBefore;
		}
	}
}
QuickPick.DEFAULT_ARIA_LABEL = localize('Type to narrow down results.');
class InputBox2 extends QuickInput {
	constructor() {
		super(...arguments);
		this._value = '';
		this.valueSelectionUpdated = true;
		this._password = false;
		this.onDidValueChangeEmitter = this._register(new Emitter());
		this.onDidAcceptEmitter = this._register(new Emitter());
		this.onDidChangeValue = this.onDidValueChangeEmitter.event;
		this.onDidAccept = this.onDidAcceptEmitter.event;
	}
	get value() {
		return this._value;
	}
	set value(value) {
		this._value = value || '';
		this.update();
	}
	get placeholder() {
		return this._placeholder;
	}
	set placeholder(placeholder) {
		this._placeholder = placeholder;
		this.update();
	}
	get password() {
		return this._password;
	}
	set password(password) {
		this._password = password;
		this.update();
	}
	show() {
		if (!this.visible) {
			this.visibleDisposables.add(
				this.ui.inputBox.onDidChange(value => {
					if (value === this.value) {
						return;
					}
					this._value = value;
					this.onDidValueChangeEmitter.fire(value);
				})
			);
			this.visibleDisposables.add(this.ui.onDidAccept(() => this.onDidAcceptEmitter.fire()));
			this.valueSelectionUpdated = true;
		}
		super.show();
	}
	update() {
		if (!this.visible) {
			return;
		}
		this.ui.container.classList.remove('hidden-input');
		const visibilities = {
			title: !!this.title || !!this.step || !!this.buttons.length,
			description: !!this.description || !!this.step,
			inputBox: true,
			message: true,
			progressBar: true
		};
		this.ui.setVisibilities(visibilities);
		super.update();
		if (this.ui.inputBox.value !== this.value) {
			this.ui.inputBox.value = this.value;
		}
		if (this.valueSelectionUpdated) {
			this.valueSelectionUpdated = false;
			this.ui.inputBox.select(
				this._valueSelection && {
					start: this._valueSelection[0],
					end: this._valueSelection[1]
				}
			);
		}
		if (this.ui.inputBox.placeholder !== (this.placeholder || '')) {
			this.ui.inputBox.placeholder = this.placeholder || '';
		}
		if (this.ui.inputBox.password !== this.password) {
			this.ui.inputBox.password = this.password;
		}
	}
}

class QuickInputHoverDelegate extends WorkbenchHoverDelegate {
	constructor(configurationService, hoverService) {
		super('element', false, options2 => this.getOverrideOptions(options2), configurationService, hoverService);
	}
	getOverrideOptions(options2) {
		const showHoverHint = (
			options2.content instanceof HTMLElement
				? options2.content.textContent || ''
				: typeof options2.content === 'string'
					? options2.content
					: options2.content.value
		).includes('\n');
		return {
			persistence: {
				hideOnKeyDown: false
			},
			appearance: {
				showHoverHint,
				skipFadeInAnimation: true
			}
		};
	}
}
__decorate([__param(0, IConfigurationService), __param(1, IHoverService)], QuickInputHoverDelegate);