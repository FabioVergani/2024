class CursorState2 {
	constructor(selections) {
		this.selections = selections;
	}
	equals(other) {
		const thisLen = this.selections.length;
		const otherLen = other.selections.length;
		if (thisLen !== otherLen) {
			return false;
		}
		for (let i = 0; i < thisLen; i++) {
			if (!this.selections[i].equalsSelection(other.selections[i])) {
				return false;
			}
		}
		return true;
	}
}
class StackElement {
	constructor(cursorState, scrollTop, scrollLeft) {
		this.cursorState = cursorState;
		this.scrollTop = scrollTop;
		this.scrollLeft = scrollLeft;
	}
}


const cursorUndoRedoController_id = 'editor.contrib.cursorUndoRedoController';


class CursorUndoRedoController extends Disposable {
	static get(editor2) {
		return editor2.getContribution(cursorUndoRedoController_id);
	}
	constructor(editor2) {
		super();
		this._editor = editor2;
		this._isCursorUndoRedo = false;
		this._undoStack = [];
		this._redoStack = [];
		this._register(
			editor2.onDidChangeModel(e => {
				this._undoStack = [];
				this._redoStack = [];
			})
		);
		this._register(
			editor2.onDidChangeModelContent(e => {
				this._undoStack = [];
				this._redoStack = [];
			})
		);
		this._register(
			editor2.onDidChangeCursorSelection(e => {
				if (this._isCursorUndoRedo) {
					return;
				}
				if (!e.oldSelections) {
					return;
				}
				if (e.oldModelVersionId !== e.modelVersionId) {
					return;
				}
				const prevState = new CursorState2(e.oldSelections);
				const isEqualToLastUndoStack =
					this._undoStack.length > 0 && this._undoStack[this._undoStack.length - 1].cursorState.equals(prevState);
				if (!isEqualToLastUndoStack) {
					this._undoStack.push(new StackElement(prevState, editor2.getScrollTop(), editor2.getScrollLeft()));
					this._redoStack = [];
					if (this._undoStack.length > 50) {
						this._undoStack.shift();
					}
				}
			})
		);
	}
	cursorUndo() {
		if (!this._editor.hasModel() || this._undoStack.length === 0) {
			return;
		}
		this._redoStack.push(
			new StackElement(new CursorState2(this._editor.getSelections()), this._editor.getScrollTop(), this._editor.getScrollLeft())
		);
		this._applyState(this._undoStack.pop());
	}
	cursorRedo() {
		if (!this._editor.hasModel() || this._redoStack.length === 0) {
			return;
		}
		this._undoStack.push(
			new StackElement(new CursorState2(this._editor.getSelections()), this._editor.getScrollTop(), this._editor.getScrollLeft())
		);
		this._applyState(this._redoStack.pop());
	}
	_applyState(stackElement) {
		this._isCursorUndoRedo = true;
		this._editor.setSelections(stackElement.cursorState.selections);
		this._editor.setScrollPosition({
			scrollTop: stackElement.scrollTop,
			scrollLeft: stackElement.scrollLeft
		});
		this._isCursorUndoRedo = false;
	}
}

class CursorRedo extends EditorAction {
	constructor() {
		super({
			id: 'cursorRedo',
			label: localize('Cursor Redo'),
			alias: 'Cursor Redo'
		});
	}
	run(accessor, editor2, args) {
		CursorUndoRedoController.get(editor2)?.cursorRedo();
	}
}
registerEditorContribution(
	cursorUndoRedoController_id,
	CursorUndoRedoController,
	0 // Eager
);
registerEditorAction(CursorRedo);

class CursorUndo extends EditorAction {
	constructor() {
		super({
			id: 'cursorUndo',
			label: localize('Cursor Undo'),
			alias: 'Cursor Undo',
			kbOpts: {
				kbExpr: ck_inputFocus_text,
				primary: 2048 | 51,
				weight: 100 //editorContrib
			}
		});
	}
	run(accessor, editor, args) {
		CursorUndoRedoController.get(editor)?.cursorUndo();
	}
}
registerEditorAction(CursorUndo);