





const iconPathToClass = {};
const iconClassGenerator = new IdGenerator('quick-input-button-icon-');

function quickInputButtonToAction(button, id, run) {
	function _getIconClass(iconPath) {
		if (!iconPath) {
			return;
		}
		let iconClass;
		const key = iconPath.dark.toString();
		if (iconPathToClass[key]) {
			iconClass = iconPathToClass[key];
		} else {
			iconClass = iconClassGenerator.nextId();
			createCSSRule(`.${iconClass}, .hc-light .${iconClass}`, `background-image: ${asCSSUrl(iconPath.light || iconPath.dark)}`);
			createCSSRule(`.vs-dark .${iconClass}, .hc-black .${iconClass}`, `background-image: ${asCSSUrl(iconPath.dark)}`);
			iconPathToClass[key] = iconClass;
		}
		return iconClass;
	}
	let cssClasses = button.iconClass || _getIconClass(button.iconPath);
	if (button.alwaysVisible) {
		cssClasses = cssClasses ? `${cssClasses} always-visible` : 'always-visible';
	}
	return {
		id,
		label: '',
		tooltip: button.tooltip || '',
		class: cssClasses,
		enabled: true,
		run
	};
}
