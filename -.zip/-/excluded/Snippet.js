const oneSnippetActive_opts = ModelDecorationOptions.register({
	description: 'snippet-placeholder-1',
	className: 'snippet-placeholder',
	stickiness: 0
});
const oneSnippetActiveFinal_opts = ModelDecorationOptions.register({
	description: 'snippet-placeholder-3',
	className: 'finish-snippet-placeholder',
	stickiness: 1
});
const oneSnippetInactive_opts = ModelDecorationOptions.register({
	description: 'snippet-placeholder-2',
	className: 'snippet-placeholder',
	stickiness: 1
});
const oneSnippetInactiveFinal_opts = ModelDecorationOptions.register({
	description: 'snippet-placeholder-4',
	className: 'finish-snippet-placeholder',
	stickiness: 1
});

class OneSnippet {
	constructor(_editor, _snippet, _snippetLineLeadingWhitespace) {
		this._editor = _editor;
		this._snippet = _snippet;
		this._snippetLineLeadingWhitespace = _snippetLineLeadingWhitespace;
		this._offset = -1;
		this._nestingLevel = 1;
		this._placeholderGroups = groupBy(_snippet.placeholders, Placeholder.compareByIndex);
		this._placeholderGroupsIdx = -1;
	}
	initialize(textChange) {
		this._offset = textChange.newPosition;
	}
	dispose() {
		if (this._placeholderDecorations) {
			this._editor.removeDecorations([...this._placeholderDecorations.values()]);
		}
		this._placeholderGroups.length = 0;
	}
	_initDecorations() {
		if (this._offset === -1) {
			throw new Error(`Snippet not initialized!`);
		}
		if (this._placeholderDecorations) {
			return;
		}
		this._placeholderDecorations = new Map();
		const model = this._editor.getModel();
		this._editor.changeDecorations(accessor => {
			for (const placeholder of this._snippet.placeholders) {
				const placeholderOffset = this._snippet.offset(placeholder);
				const placeholderLen = this._snippet.fullLen(placeholder);
				const range2 = Range.fromPositions(model.getPositionAt(this._offset + placeholderOffset), model.getPositionAt(this._offset + placeholderOffset + placeholderLen));
				const options2 = placeholder.isFinalTabstop ? oneSnippetInactiveFinal_opts : oneSnippetInactive_opts;
				const handle = accessor.addDecoration(range2, options2);
				this._placeholderDecorations.set(placeholder, handle);
			}
		});
	}
	move(fwd) {
		if (!this._editor.hasModel()) {
			return [];
		}
		this._initDecorations();
		if (this._placeholderGroupsIdx >= 0) {
			const operations = [];
			for (const placeholder of this._placeholderGroups[this._placeholderGroupsIdx]) {
				if (placeholder.transform) {
					const id = this._placeholderDecorations.get(placeholder);
					const range2 = this._editor.getModel().getDecorationRange(id);
					const currentValue = this._editor.getModel().getValueInRange(range2);
					const transformedValueLines = placeholder.transform.resolve(currentValue).split(lineBreakRE1);
					for (let i = 1; i < transformedValueLines.length; i++) {
						transformedValueLines[i] = this._editor.getModel().normalizeIndentation(this._snippetLineLeadingWhitespace + transformedValueLines[i]);
					}
					operations.push({
						range: range2,
						text: transformedValueLines.join(this._editor.getModel().getEOL())
					});
				}
			}
			if (operations.length > 0) {
				this._editor.executeEdits('snippet.placeholderTransform', operations);
			}
		}
		let couldSkipThisPlaceholder = false;
		if (fwd === true && this._placeholderGroupsIdx < this._placeholderGroups.length - 1) {
			this._placeholderGroupsIdx += 1;
			couldSkipThisPlaceholder = true;
		} else if (fwd === false && this._placeholderGroupsIdx > 0) {
			this._placeholderGroupsIdx -= 1;
			couldSkipThisPlaceholder = true;
		}
		const newSelections = this._editor.getModel().changeDecorations(accessor => {
			const activePlaceholders = new Set();
			const selections = [];
			for (const placeholder of this._placeholderGroups[this._placeholderGroupsIdx]) {
				const id = this._placeholderDecorations.get(placeholder);
				const range2 = this._editor.getModel().getDecorationRange(id);
				selections.push(new EditorSelection(range2.startLineNumber, range2.startColumn, range2.endLineNumber, range2.endColumn));
				couldSkipThisPlaceholder = couldSkipThisPlaceholder && this._hasPlaceholderBeenCollapsed(placeholder);
				accessor.changeDecorationOptions(id, placeholder.isFinalTabstop ? oneSnippetActiveFinal_opts : oneSnippetActive_opts);
				activePlaceholders.add(placeholder);
				for (const enclosingPlaceholder of this._snippet.enclosingPlaceholders(placeholder)) {
					const id2 = this._placeholderDecorations.get(enclosingPlaceholder);
					accessor.changeDecorationOptions(id2, enclosingPlaceholder.isFinalTabstop ? oneSnippetActiveFinal_opts : oneSnippetActive_opts);
					activePlaceholders.add(enclosingPlaceholder);
				}
			}
			for (const [placeholder, id] of this._placeholderDecorations) {
				if (!activePlaceholders.has(placeholder)) {
					accessor.changeDecorationOptions(id, placeholder.isFinalTabstop ? oneSnippetInactiveFinal_opts : oneSnippetInactive_opts);
				}
			}
			return selections;
		});
		return !couldSkipThisPlaceholder ? (newSelections !== null && newSelections !== undefined ? newSelections : []) : this.move(fwd);
	}
	_hasPlaceholderBeenCollapsed(placeholder) {
		let marker = placeholder;
		while (marker) {
			if (marker instanceof Placeholder) {
				const id = this._placeholderDecorations.get(marker);
				const range2 = this._editor.getModel().getDecorationRange(id);
				if (range2.isEmpty() && marker.toString().length > 0) {
					return true;
				}
			}
			marker = marker.parent;
		}
		return false;
	}
	get isAtFirstPlaceholder() {
		return this._placeholderGroupsIdx <= 0 || this._placeholderGroups.length === 0;
	}
	get isAtLastPlaceholder() {
		return this._placeholderGroupsIdx === this._placeholderGroups.length - 1;
	}
	get hasPlaceholder() {
		return this._snippet.placeholders.length > 0;
	}
	get isTrivialSnippet() {
		if (this._snippet.placeholders.length === 0) {
			return true;
		}
		if (this._snippet.placeholders.length === 1) {
			const [placeholder] = this._snippet.placeholders;
			if (placeholder.isFinalTabstop) {
				if (this._snippet.rightMostDescendant === placeholder) {
					return true;
				}
			}
		}
		return false;
	}
	computePossibleSelections() {
		const result = new Map();
		for (const placeholdersWithEqualIndex of this._placeholderGroups) {
			let ranges;
			for (const placeholder of placeholdersWithEqualIndex) {
				if (placeholder.isFinalTabstop) {
					break;
				}
				if (!ranges) {
					ranges = [];
					result.set(placeholder.index, ranges);
				}
				const id = this._placeholderDecorations.get(placeholder);
				const range2 = this._editor.getModel().getDecorationRange(id);
				if (!range2) {
					result.delete(placeholder.index);
					break;
				}
				ranges.push(range2);
			}
		}
		return result;
	}
	get activeChoice() {
		if (!this._placeholderDecorations) {
			return;
		}
		const placeholder = this._placeholderGroups[this._placeholderGroupsIdx][0];
		if (!placeholder?.choice) {
			return;
		}
		const id = this._placeholderDecorations.get(placeholder);
		if (!id) {
			return;
		}
		const range2 = this._editor.getModel().getDecorationRange(id);
		if (!range2) {
			return;
		}
		return { range: range2, choice: placeholder.choice };
	}
	get hasChoice() {
		let result = false;
		this._snippet.walk(marker => {
			result = marker instanceof Choice;
			return !result;
		});
		return result;
	}
	merge(others) {
		const model = this._editor.getModel();
		this._nestingLevel *= 10;
		this._editor.changeDecorations(accessor => {
			for (const placeholder of this._placeholderGroups[this._placeholderGroupsIdx]) {
				const nested = others.shift();
				console.assert(nested._offset !== -1);
				console.assert(!nested._placeholderDecorations);
				const indexLastPlaceholder = nested._snippet.placeholderInfo.last.index;
				for (const nestedPlaceholder of nested._snippet.placeholderInfo.all) {
					if (nestedPlaceholder.isFinalTabstop) {
						nestedPlaceholder.index = placeholder.index + (indexLastPlaceholder + 1) / this._nestingLevel;
					} else {
						nestedPlaceholder.index = placeholder.index + nestedPlaceholder.index / this._nestingLevel;
					}
				}
				this._snippet.replace(placeholder, nested._snippet.children);
				const id = this._placeholderDecorations.get(placeholder);
				accessor.removeDecoration(id);
				this._placeholderDecorations.delete(placeholder);
				for (const placeholder2 of nested._snippet.placeholders) {
					const placeholderOffset = nested._snippet.offset(placeholder2);
					const placeholderLen = nested._snippet.fullLen(placeholder2);
					const range2 = Range.fromPositions(
						model.getPositionAt(nested._offset + placeholderOffset),
						model.getPositionAt(nested._offset + placeholderOffset + placeholderLen)
					);
					const handle = accessor.addDecoration(range2, OneSnippet._decor.inactive);
					this._placeholderDecorations.set(placeholder2, handle);
				}
			}
			this._placeholderGroups = groupBy(this._snippet.placeholders, Placeholder.compareByIndex);
		});
	}
}

const timeBased_monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map(localize);

const timeBased_monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(localize);

const timeBased_dayNamesShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(localize);

const timeBased_dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(localize);

class TimeBasedVariableResolver {
	constructor() {
		this._date = new Date();
	}
	resolve(variable) {
		const { name } = variable;
		if (name === 'CURRENT_YEAR') {
			return String(this._date.getFullYear());
		} else if (name === 'CURRENT_YEAR_SHORT') {
			return String(this._date.getFullYear()).slice(-2);
		} else if (name === 'CURRENT_MONTH') {
			return String(this._date.getMonth().valueOf() + 1).padStart(2, '0');
		} else if (name === 'CURRENT_DATE') {
			return String(this._date.getDate().valueOf()).padStart(2, '0');
		} else if (name === 'CURRENT_HOUR') {
			return String(this._date.getHours().valueOf()).padStart(2, '0');
		} else if (name === 'CURRENT_MINUTE') {
			return String(this._date.getMinutes().valueOf()).padStart(2, '0');
		} else if (name === 'CURRENT_SECOND') {
			return String(this._date.getSeconds().valueOf()).padStart(2, '0');
		} else if (name === 'CURRENT_DAY_NAME') {
			return timeBased_dayNames[this._date.getDay()];
		} else if (name === 'CURRENT_DAY_NAME_SHORT') {
			return timeBased_dayNamesShort[this._date.getDay()];
		} else if (name === 'CURRENT_MONTH_NAME') {
			return timeBased_monthNames[this._date.getMonth()];
		} else if (name === 'CURRENT_MONTH_NAME_SHORT') {
			return timeBased_monthNamesShort[this._date.getMonth()];
		} else if (name === 'CURRENT_SECONDS_UNIX') {
			return String(Math.floor(this._date.getTime() / 1e3));
		} else if (name === 'CURRENT_TIMEZONE_OFFSET') {
			const rawTimeOffset = this._date.getTimezoneOffset();
			const sign = rawTimeOffset > 0 ? '-' : '+';
			const hours = Math.trunc(Math.abs(rawTimeOffset / 60));
			const hoursString = hours < 10 ? '0' + hours : hours;
			const minutes = Math.abs(rawTimeOffset) - hours * 60;
			const minutesString = minutes < 10 ? '0' + minutes : minutes;
			return sign + hoursString + ':' + minutesString;
		}
		return;
	}
}

class RandomBasedVariableResolver {
	resolve(variable) {
		const { name } = variable;
		if (name === 'RANDOM') {
			return Math.random().toString().slice(-6);
		} else if (name === 'RANDOM_HEX') {
			return Math.random().toString(16).slice(-6);
		} else if (name === 'UUID') {
			return generateUuid();
		}
		return;
	}
}

const ssAdjustWhitespace = (model, position, adjustIndentation, snippet, filter) => {
	const line = model.getLineContent(position.lineNumber);
	const lineLeadingWhitespace = getLeadingWhitespace(line, 0, position.column - 1);
	let snippetTextString;
	snippet.walk(marker => {
		if (!(marker instanceof Text) || marker.parent instanceof Choice) {
			return true;
		}
		if (filter && !filter.has(marker)) {
			return true;
		}
		const lines = marker.value.split(lineBreakRE1);
		if (adjustIndentation) {
			const offset = snippet.offset(marker);
			if (offset === 0) {
				lines[0] = model.normalizeIndentation(lines[0]);
			} else {
				snippetTextString = snippetTextString !== null && snippetTextString !== undefined ? snippetTextString : snippet.toString();
				const prevChar = snippetTextString.charCodeAt(offset - 1);
				if (prevChar === 10 || prevChar === 13) {
					lines[0] = model.normalizeIndentation(lineLeadingWhitespace + lines[0]);
				}
			}
			for (let i = 1; i < lines.length; i++) {
				lines[i] = model.normalizeIndentation(lineLeadingWhitespace + lines[i]);
			}
		}
		const newValue = lines.join(model.getEOL());
		if (newValue !== marker.value) {
			marker.parent.replace(marker, [new Text(newValue)]);
			snippetTextString = undefined;
		}
		return true;
	});
	return lineLeadingWhitespace;
};

const ssAdjustSelection = (model, selection, overwriteBefore, overwriteAfter) => {
	if (overwriteBefore !== 0 || overwriteAfter !== 0) {
		const { positionLineNumber, positionColumn } = selection;
		const positionColumnBefore = positionColumn - overwriteBefore;
		const positionColumnAfter = positionColumn + overwriteAfter;
		const range2 = model.validateRange({
			startLineNumber: positionLineNumber,
			startColumn: positionColumnBefore,
			endLineNumber: positionLineNumber,
			endColumn: positionColumnAfter
		});
		selection = createEditorSelectionWithDirection(range2.startLineNumber, range2.startColumn, range2.endLineNumber, range2.endColumn, selection.getDirection());
	}
	return selection;
};

class SelectionBasedVariableResolver {
	constructor(_model, _selection, _selectionIdx, _overtypingCapturer) {
		this._model = _model;
		this._selection = _selection;
		this._selectionIdx = _selectionIdx;
		this._overtypingCapturer = _overtypingCapturer;
	}
	resolve(variable) {
		const { name } = variable;
		if (name === 'SELECTION' || name === 'TM_SELECTED_TEXT') {
			let value = this._model.getValueInRange(this._selection) || undefined;
			let isMultiline = this._selection.startLineNumber !== this._selection.endLineNumber;
			if (!value && this._overtypingCapturer) {
				const info = this._overtypingCapturer.getLastOvertypedInfo(this._selectionIdx);
				if (info) {
					value = info.value;
					isMultiline = info.multiline;
				}
			}
			if (value && isMultiline && variable.snippet) {
				const line = this._model.getLineContent(this._selection.startLineNumber);
				const lineLeadingWhitespace = getLeadingWhitespace(line, 0, this._selection.startColumn - 1);
				let varLeadingWhitespace = lineLeadingWhitespace;
				variable.snippet.walk(marker => {
					if (marker === variable) {
						return false;
					}
					if (marker instanceof Text) {
						varLeadingWhitespace = getLeadingWhitespace(splitLines(marker.value).pop());
					}
					return true;
				});
				const whitespaceCommonLength = commonPrefixLength(varLeadingWhitespace, lineLeadingWhitespace);
				value = value.replace(/(\r\n|\r|\n)(.*)/g, (m, newline, rest) => `${newline}${varLeadingWhitespace.substr(whitespaceCommonLength)}${rest}`);
			}
			return value;
		} else if (name === 'TM_CURRENT_LINE') {
			return this._model.getLineContent(this._selection.positionLineNumber);
		} else if (name === 'TM_CURRENT_WORD') {
			const info = this._model.getWordAtPosition({
				lineNumber: this._selection.positionLineNumber,
				column: this._selection.positionColumn
			});
			return (info && info.word) || undefined;
		} else if (name === 'TM_LINE_INDEX') {
			return String(this._selection.positionLineNumber - 1);
		} else if (name === 'TM_LINE_NUMBER') {
			return String(this._selection.positionLineNumber);
		} else if (name === 'CURSOR_INDEX') {
			return String(this._selectionIdx);
		} else if (name === 'CURSOR_NUMBER') {
			return String(this._selectionIdx + 1);
		}
		return;
	}
}

class ClipboardBasedVariableResolver {
	constructor(_readClipboardText, _selectionIdx, _selectionCount, _spread) {
		this._readClipboardText = _readClipboardText;
		this._selectionIdx = _selectionIdx;
		this._selectionCount = _selectionCount;
		this._spread = _spread;
	}
	resolve(variable) {
		if (variable.name !== 'CLIPBOARD') {
			return;
		}
		const clipboardText = this._readClipboardText();
		if (!clipboardText) {
			return;
		}
		if (this._spread) {
			const lines = clipboardText.split(/\r\n|\n|\r/).filter(s => !isFalsyOrNotStringOrIsBlank(s));
			if (lines.length === this._selectionCount) {
				return lines[this._selectionIdx];
			}
		}
		return clipboardText;
	}
}

class ModelBasedVariableResolver {
	constructor(_labelService, _model) {
		this._labelService = _labelService;
		this._model = _model;
	}
	resolve(variable) {
		const { name } = variable;
		if (name === 'TM_FILENAME') {
			return basename(this._model.uri.fsPath);
		} else if (name === 'TM_FILENAME_BASE') {
			const name2 = basename(this._model.uri.fsPath);
			const idx = name2.lastIndexOf('.');
			if (idx <= 0) {
				return name2;
			} else {
				return name2.slice(0, idx);
			}
		} else if (name === 'TM_DIRECTORY') {
			if (dirname(this._model.uri.fsPath) === '.') {
				return '';
			}
			return this._labelService.getUriLabel(dirname2(this._model.uri));
		} else if (name === 'TM_FILEPATH') {
			return this._labelService.getUriLabel(this._model.uri);
		} else if (name === 'RELATIVE_FILEPATH') {
			return this._labelService.getUriLabel(this._model.uri, {
				relative: true,
				noPrefix: true
			});
		}
		return;
	}
}

class CompositeSnippetVariableResolver {
	constructor(_delegates) {
		this._delegates = _delegates;
	}
	resolve(variable) {
		for (const delegate of this._delegates) {
			const value = delegate.resolve(variable);
			if (value !== undefined) {
				return value;
			}
		}
		return;
	}
}


class CommentBasedVariableResolver {
	constructor(_model, _selection, _languageConfigurationService) {
		this._model = _model;
		this._selection = _selection;
		this._languageConfigurationService = _languageConfigurationService;
	}
	resolve(variable) {
		const { name } = variable;
		const langId = this._model.getLanguageIdAtPosition(this._selection.selectionStartLineNumber, this._selection.selectionStartColumn);
		const config = this._languageConfigurationService.getLanguageConfiguration(langId).comments;
		if (!config) {
			return;
		}
		if (name === 'LINE_COMMENT') {
			return config.lineCommentToken || undefined;
		} else if (name === 'BLOCK_COMMENT_START') {
			return config.blockCommentStartToken || undefined;
		} else if (name === 'BLOCK_COMMENT_END') {
			return config.blockCommentEndToken || undefined;
		}
		return;
	}
}
__decorate(
	[
		__param(2, ILanguageConfigurationService) //
	],
	CommentBasedVariableResolver
);

class Session {
	constructor(_editor, _template, _options, _languageConfigurationService) {
		this._editor = _editor;
		this._template = _template;
		this._options = {
			overwriteBefore: 0,
			overwriteAfter: 0,
			adjustWhitespace: true,
			...(_options || {})
		};
		this._languageConfigurationService = _languageConfigurationService;
		this._templateMerges = [];
		this._snippets = [];
	}
	dispose() {
		dispose(this._snippets);
	}
	insert() {
		if (this._editor.hasModel()) {

			const ssCreateEditsAndSnippetsFromSelections = (
				editor2,
				template,
				overwriteBefore,
				overwriteAfter,
				enforceFinalTabstop,
				adjustWhitespace,
				clipboardText,
				overtypingCapturer,
				languageConfigurationService
			) => {
				const edits = [];
				const snippets = [];
				if (!editor2.hasModel()) {
					return { edits, snippets };
				}
				const model = editor2.getModel();

				const modelBasedVariableResolver = editor2.invokeWithinContext(accessor => new ModelBasedVariableResolver(accessor.get(ILabelService), model));
				const readClipboardText = () => clipboardText;
				const firstBeforeText = model.getValueInRange(ssAdjustSelection(model, editor2.getSelection(), overwriteBefore, 0));
				const firstAfterText = model.getValueInRange(ssAdjustSelection(model, editor2.getSelection(), 0, overwriteAfter));
				const firstLineFirstNonWhitespace = model.getLineFirstNonWhitespaceColumn(editor2.getSelection().positionLineNumber);
				const indexedSelections = editor2
					.getSelections()
					.map((selection, idx) => ({ selection, idx }))
					.sort((a, b) => Range.compareRangesUsingStarts(a.selection, b.selection));
				for (const { selection, idx } of indexedSelections) {
					let extensionBefore = ssAdjustSelection(model, selection, overwriteBefore, 0);
					let extensionAfter = ssAdjustSelection(model, selection, 0, overwriteAfter);
					if (firstBeforeText !== model.getValueInRange(extensionBefore)) {
						extensionBefore = selection;
					}
					if (firstAfterText !== model.getValueInRange(extensionAfter)) {
						extensionAfter = selection;
					}
					const snippetSelection = selection
						.setStartPosition(extensionBefore.startLineNumber, extensionBefore.startColumn)
						.setEndPosition(extensionAfter.endLineNumber, extensionAfter.endColumn);
					const snippet = new SnippetParser().parse(template, true, enforceFinalTabstop);
					const start = snippetSelection.getStartPosition();
					const snippetLineLeadingWhitespace = ssAdjustWhitespace(
						model,
						start,
						adjustWhitespace || (idx > 0 && firstLineFirstNonWhitespace !== model.getLineFirstNonWhitespaceColumn(selection.positionLineNumber)),
						snippet
					);
					snippet.resolveVariables(
						new CompositeSnippetVariableResolver([

							modelBasedVariableResolver,
							new ClipboardBasedVariableResolver(
								readClipboardText,
								idx,
								indexedSelections.length,
								editor2.getOption(
									79 // multiCursorPaste
								) === 'spread'
							),
							new SelectionBasedVariableResolver(model, selection, idx, overtypingCapturer),
							new CommentBasedVariableResolver(model, selection, languageConfigurationService),
							new TimeBasedVariableResolver(),
							new RandomBasedVariableResolver()

						])
					);
					edits[idx] = {
						range: snippetSelection,
						text: snippet.toString()
					};

					edits[idx].identifier = { major: idx, minor: 0 };
					edits[idx]._isTracked = true;
					snippets[idx] = new OneSnippet(editor2, snippet, snippetLineLeadingWhitespace);
				}
				return { edits, snippets };
			};

			const ssCreateEditsAndSnippetsFromEdits = (editor2, snippetEdits, enforceFinalTabstop, adjustWhitespace, clipboardText, overtypingCapturer, languageConfigurationService) => {
				if (!editor2.hasModel() || snippetEdits.length === 0) {
					return { edits: [], snippets: [] };
				}
				const edits = [];
				const model = editor2.getModel();
				const parser2 = new SnippetParser();
				const snippet = new TextmateSnippet();
				const resolver = new CompositeSnippetVariableResolver([
					editor2.invokeWithinContext(accessor => new ModelBasedVariableResolver(accessor.get(ILabelService), model)),
					new ClipboardBasedVariableResolver(
						() => clipboardText,
						0,
						editor2.getSelections().length,
						editor2.getOption(
							79 // multiCursorPaste
						) === 'spread'
					),
					new SelectionBasedVariableResolver(model, editor2.getSelection(), 0, overtypingCapturer),
					new CommentBasedVariableResolver(model, editor2.getSelection(), languageConfigurationService),
					new TimeBasedVariableResolver(),
					new RandomBasedVariableResolver()
				]);
				snippetEdits = snippetEdits.sort((a, b) => Range.compareRangesUsingStarts(a.range, b.range));
				let offset = 0;
				for (let i = 0; i < snippetEdits.length; i++) {
					const { range: range2, template } = snippetEdits[i];
					if (i > 0) {
						const lastRange = snippetEdits[i - 1].range;
						const textRange = Range.fromPositions(lastRange.getEndPosition(), range2.getStartPosition());
						const textNode = new Text(model.getValueInRange(textRange));
						snippet.appendChild(textNode);
						offset += textNode.value.length;
					}
					const newNodes = parser2.parseFragment(template, snippet);
					ssAdjustWhitespace(model, range2.getStartPosition(), true, snippet, new Set(newNodes));
					snippet.resolveVariables(resolver);
					const snippetText = snippet.toString();
					const snippetFragmentText = snippetText.slice(offset);
					offset = snippetText.length;
					const edit = {
						range: range2,
						text: snippetFragmentText
					};

					edit.identifier = { major: i, minor: 0 };
					edit._isTracked = true;
					edits.push(edit);
				}
				parser2.ensureFinalTabstop(snippet, enforceFinalTabstop, true);
				return { edits, snippets: [new OneSnippet(editor2, snippet, '')] };
			};

			const { edits, snippets } =
				typeof this._template === 'string'
					? ssCreateEditsAndSnippetsFromSelections(
							this._editor,
							this._template,
							this._options.overwriteBefore,
							this._options.overwriteAfter,
							false,
							this._options.adjustWhitespace,
							this._options.clipboardText,
							this._options.overtypingCapturer,
							this._languageConfigurationService
						)
					: ssCreateEditsAndSnippetsFromEdits(
							this._editor,
							this._template,
							false,
							this._options.adjustWhitespace,
							this._options.clipboardText,
							this._options.overtypingCapturer,
							this._languageConfigurationService
						);




			this._snippets = snippets;
			this._editor.executeEdits('snippet', edits, _undoEdits => {
				const undoEdits = _undoEdits.filter(edit => !!edit.identifier);
				for (let idx = 0; idx < snippets.length; idx++) {
					snippets[idx].initialize(undoEdits[idx].textChange);
				}
				if (this._snippets[0].hasPlaceholder) {
					return this._move(true);
				} else {
					return undoEdits.map(edit => editorSelectionFromPosition(edit.range.getEndPosition()));
				}
			});
			this._editor.revealRange(this._editor.getSelections()[0]);
		}
	}
	merge(template, options) {
		const options2 = {
			overwriteBefore: 0,
			overwriteAfter: 0,
			adjustWhitespace: true,
			...(_options || {})
		};
		if (!this._editor.hasModel()) {
			return;
		}
		this._templateMerges.push([this._snippets[0]._nestingLevel, this._snippets[0]._placeholderGroupsIdx, template]);
		const { edits, snippets } = ssCreateEditsAndSnippetsFromSelections(
			this._editor,
			template,
			options2.overwriteBefore,
			options2.overwriteAfter,
			true,
			options2.adjustWhitespace,
			options2.clipboardText,
			options2.overtypingCapturer,
			this._languageConfigurationService
		);
		this._editor.executeEdits('snippet', edits, _undoEdits => {
			const undoEdits = _undoEdits.filter(edit => !!edit.identifier);
			for (let idx = 0; idx < snippets.length; idx++) {
				snippets[idx].initialize(undoEdits[idx].textChange);
			}
			const isTrivialSnippet = snippets[0].isTrivialSnippet;
			if (!isTrivialSnippet) {
				for (const snippet of this._snippets) {
					snippet.merge(snippets);
				}
				console.assert(snippets.length === 0);
			}
			if (this._snippets[0].hasPlaceholder && !isTrivialSnippet) {
				return this._move(undefined);
			} else {
				return undoEdits.map(edit => editorSelectionFromPosition(edit.range.getEndPosition()));
			}
		});
	}
	next() {
		const newSelections = this._move(true);
		this._editor.setSelections(newSelections);
		this._editor.revealPositionInCenterIfOutsideViewport(newSelections[0].getPosition());
	}
	prev() {
		const newSelections = this._move(false);
		this._editor.setSelections(newSelections);
		this._editor.revealPositionInCenterIfOutsideViewport(newSelections[0].getPosition());
	}
	_move(fwd) {
		const selections = [];
		for (const snippet of this._snippets) {
			const oneSelection = snippet.move(fwd);
			selections.push(...oneSelection);
		}
		return selections;
	}
	get isAtFirstPlaceholder() {
		return this._snippets[0].isAtFirstPlaceholder;
	}
	get isAtLastPlaceholder() {
		return this._snippets[0].isAtLastPlaceholder;
	}
	get hasPlaceholder() {
		return this._snippets[0].hasPlaceholder;
	}
	get hasChoice() {
		return this._snippets[0].hasChoice;
	}
	get activeChoice() {
		return this._snippets[0].activeChoice;
	}
	isSelectionWithinPlaceholders() {
		if (!this.hasPlaceholder) {
			return false;
		}
		const selections = this._editor.getSelections();
		if (selections.length < this._snippets.length) {
			return false;
		}
		const allPossibleSelections = new Map();
		for (const snippet of this._snippets) {
			const possibleSelections = snippet.computePossibleSelections();
			if (allPossibleSelections.size === 0) {
				for (const [index, ranges] of possibleSelections) {
					ranges.sort(Range.compareRangesUsingStarts);
					for (const selection of selections) {
						if (ranges[0].containsRange(selection)) {
							allPossibleSelections.set(index, []);
							break;
						}
					}
				}
			}
			if (allPossibleSelections.size === 0) {
				return false;
			}
			allPossibleSelections.forEach((array2, index) => {
				array2.push(...possibleSelections.get(index));
			});
		}
		selections.sort(Range.compareRangesUsingStarts);
		for (const [index, ranges] of allPossibleSelections) {
			if (ranges.length !== selections.length) {
				allPossibleSelections.delete(index);
				continue;
			}
			ranges.sort(Range.compareRangesUsingStarts);
			for (let i = 0; i < ranges.length; i++) {
				if (!ranges[i].containsRange(selections[i])) {
					allPossibleSelections.delete(index);
					continue;
				}
			}
		}
		return allPossibleSelections.size > 0;
	}
}
__decorate(
	[
		__param(3, ILanguageConfigurationService) //
	],
	SnippetSession
);