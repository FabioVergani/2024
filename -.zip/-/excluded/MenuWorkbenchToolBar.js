




class ToggleMenuAction extends Action {
	constructor(toggleDropdownMenu, title) {
		title = title || localize('More Actions...');
		super(ToggleMenuAction.ID, title, undefined, true);
		this._menuActions = [];
		this.toggleDropdownMenu = toggleDropdownMenu;
	}
	async run() {
		this.toggleDropdownMenu();
	}
	get menuActions() {
		return this._menuActions;
	}
	set menuActions(actions) {
		this._menuActions = actions;
	}
}
ToggleMenuAction.ID = 'toolbar.toggle.more';

class ToolBar extends Disposable {
	constructor(
		container,
		contextMenuProvider,
		options2 = {
			orientation: 0 // HORIZONTAL
		}
	) {
		super();
		this.submenuActionViewItems = [];
		this.hasSecondaryActions = false;
		this._onDidChangeDropdownVisibility = this._register(new EventMultiplexer());
		this.onDidChangeDropdownVisibility = this._onDidChangeDropdownVisibility.event;
		this.disposables = this._register(new DisposableStore());
		options2.hoverDelegate = options2.hoverDelegate ?? this._register(createInstantHoverDelegate());
		this.options = options2;
		this.lookupKeybindings = typeof this.options.getKeyBinding === 'function';
		this.toggleMenuAction = this._register(
			new ToggleMenuAction(() => {
				return this.toggleMenuActionViewItem?.show();
			}, options2.toggleMenuTitle)
		);
		this.element = document.createElement('div');
		this.element.className = 'monaco-toolbar';
		container.appendChild(this.element);
		this.actionBar = this._register(
			new ActionBar(this.element, {
				orientation: options2.orientation,
				actionRunner: options2.actionRunner,
				allowContextMenu: options2.allowContextMenu,
				highlightToggledItems: options2.highlightToggledItems,
				hoverDelegate: options2.hoverDelegate,
				actionViewItemProvider: (action, viewItemOptions) => {
					if (action.id === ToggleMenuAction.ID) {
						this.toggleMenuActionViewItem = new DropdownMenuActionViewItem(action, action.menuActions, contextMenuProvider, {
							actionViewItemProvider: this.options.actionViewItemProvider,
							actionRunner: this.actionRunner,
							keybindingProvider: this.options.getKeyBinding,
							classNames: asThemeIconClassNameArray(options2.moreIcon ?? codicon_toolBarMore),
							anchorAlignmentProvider: this.options.anchorAlignmentProvider,
							menuAsChild: !!this.options.renderDropdownAsChildElement,
							isMenu: true,
							hoverDelegate: this.options.hoverDelegate
						});
						this.toggleMenuActionViewItem.setActionContext(this.actionBar.context);
						this.disposables.add(this._onDidChangeDropdownVisibility.add(this.toggleMenuActionViewItem.onDidChangeVisibility));
						return this.toggleMenuActionViewItem;
					}
					if (options2.actionViewItemProvider) {
						const result = options2.actionViewItemProvider(action, viewItemOptions);
						if (result) {
							return result;
						}
					}
					if (action instanceof SubmenuAction) {
						const result = new DropdownMenuActionViewItem(action, action.actions, contextMenuProvider, {
							actionViewItemProvider: this.options.actionViewItemProvider,
							actionRunner: this.actionRunner,
							keybindingProvider: this.options.getKeyBinding,
							classNames: action.class,
							anchorAlignmentProvider: this.options.anchorAlignmentProvider,
							menuAsChild: !!this.options.renderDropdownAsChildElement,
							hoverDelegate: this.options.hoverDelegate
						});
						result.setActionContext(this.actionBar.context);
						this.submenuActionViewItems.push(result);
						this.disposables.add(this._onDidChangeDropdownVisibility.add(result.onDidChangeVisibility));
						return result;
					}
					return;
				}
			})
		);
	}
	set actionRunner(actionRunner) {
		this.actionBar.actionRunner = actionRunner;
	}
	get actionRunner() {
		return this.actionBar.actionRunner;
	}
	getElement() {
		return this.element;
	}
	getItemAction(indexOrElement) {
		return this.actionBar.getAction(indexOrElement);
	}
	setActions(primaryActions, secondaryActions) {
		this.clear();
		const primaryActionsToSet = primaryActions ? primaryActions.slice(0) : [];
		this.hasSecondaryActions = !!(secondaryActions && secondaryActions.length > 0);
		if (this.hasSecondaryActions && secondaryActions) {
			this.toggleMenuAction.menuActions = secondaryActions.slice(0);
			primaryActionsToSet.push(this.toggleMenuAction);
		}
		primaryActionsToSet.forEach(action => {
			this.actionBar.push(action, {
				icon: true,
				label: false,
				keybinding: this.getKeybindingLabel(action)
			});
		});
	}
	getKeybindingLabel(action) {
		const key = this.lookupKeybindings ? this.options.getKeyBinding?.call(this.options, action) : undefined;
		return key?.getLabel();
	}
	clear() {
		this.submenuActionViewItems = [];
		this.disposables.clear();
		this.actionBar.clear();
	}
	dispose() {
		this.clear();
		this.disposables.dispose();
		super.dispose();
	}
}



class WorkbenchToolBar extends ToolBar {
	constructor(container, _options, _menuService, _contextKeyService, _contextMenuService, _keybindingService, _commandService) {
		super(container, _contextMenuService, {
			getKeyBinding: action => {
				return _keybindingService.lookupKeybinding(action.id);
			},
			..._options,
			allowContextMenu: true
		});
		this._options = _options;
		this._menuService = _menuService;
		this._contextKeyService = _contextKeyService;
		this._contextMenuService = _contextMenuService;
		this._keybindingService = _keybindingService;
		this._commandService = _commandService;
		this._sessionDisposables = this._store.add(new DisposableStore());
	}
	setActions(_primary, _secondary = [], menuIds) {
		this._sessionDisposables.clear();
		const primary = _primary.slice();
		const secondary = _secondary.slice();
		const toggleActions = [];
		let toggleActionsCheckedCount = 0;
		const extraSecondary = [];
		let someAreHidden = false;
		if (this._options?.hiddenItemStrategy !== -1) {
			for (let i = 0; i < primary.length; i++) {
				const action = primary[i];
				if (!(action instanceof MenuItemAction) && !(action instanceof SubmenuItemAction)) {
					continue;
				}
				if (!action.hideActions) {
					continue;
				}
				toggleActions.push(action.hideActions.toggle);
				if (action.hideActions.toggle.checked) {
					toggleActionsCheckedCount++;
				}
				if (action.hideActions.isHidden) {
					someAreHidden = true;
					primary[i] = undefined;
					if (this._options?.hiddenItemStrategy !== 0) {
						extraSecondary[i] = action;
					}
				}
			}
		}
		if (this._options?.overflowBehavior !== undefined) {
			const exemptedIds = new Set();
			const setA = new Set(this._options.overflowBehavior.exempted);
			for (const elem of iterableMap(primary, e => e?.id)) {
				if (setA.has(elem)) {
					exemptedIds.add(elem);
				}
			}
			const maxItems = this._options.overflowBehavior.maxItems - exemptedIds.size;
			let count = 0;
			for (let i = 0; i < primary.length; i++) {
				const action = primary[i];
				if (!action) {
					continue;
				}
				count++;
				if (exemptedIds.has(action.id)) {
					continue;
				}
				if (count >= maxItems) {
					primary[i] = undefined;
					extraSecondary[i] = action;
				}
			}
		}
		const coalesceInPlace = items => {
			let to = 0;
			for (let i = 0; i < items.length; ++i) {
				if (!!items[i]) {
					items[to] = items[i];
					to += 1;
				}
			}
			items.length = to;
		};
		coalesceInPlace(primary);
		coalesceInPlace(extraSecondary);
		super.setActions(primary, Separator.join(extraSecondary, secondary));
		if (toggleActions.length > 0 || primary.length > 0) {
			this._sessionDisposables.add(
				addDisposableListener(this.getElement(), 'contextmenu', e => {
					const event = new StandardMouseEvent(getWindow(this.getElement()), e);
					const action = this.getItemAction(event.target);
					if (!action) {
						return;
					}
					event.preventDefault();
					event.stopPropagation();
					const primaryActions = [];
					if (action instanceof MenuItemAction && action.menuKeybinding) {
						primaryActions.push(action.menuKeybinding);
					} else if (!(action instanceof SubmenuItemAction || action instanceof ToggleMenuAction)) {
						primaryActions.push(
							createConfigureKeybindingAction(action.id, undefined, this._commandService, this._keybindingService)
						);
					}
					if (toggleActions.length > 0) {
						let noHide = false;
						if (toggleActionsCheckedCount === 1 && this._options?.hiddenItemStrategy === 0) {
							noHide = true;
							for (let i = 0; i < toggleActions.length; i++) {
								if (toggleActions[i].checked) {
									toggleActions[i] = toActionObj({
										id: action.id,
										label: action.label,
										checked: true,
										enabled: false,
										run() {}
									});
									break;
								}
							}
						}
						if (!noHide && (action instanceof MenuItemAction || action instanceof SubmenuItemAction)) {
							if (!action.hideActions) {
								return;
							}
							primaryActions.push(action.hideActions.hide);
						} else {
							primaryActions.push(
								toActionObj({
									id: 'label',
									label: localize('Hide'),
									enabled: false,
									run() {}
								})
							);
						}
					}
					const actions = Separator.join(primaryActions, toggleActions);
					if (this._options?.resetMenu && !menuIds) {
						menuIds = [this._options.resetMenu];
					}
					if (someAreHidden && menuIds) {
						actions.push(new Separator());
						actions.push(
							toActionObj({
								id: 'resetThisMenu',
								label: localize('Reset Menu'),
								run: () => this._menuService.resetHiddenStates(menuIds)
							})
						);
					}
					if (actions.length === 0) {
						return;
					}
					this._contextMenuService.showContextMenu({
						getAnchor: () => event,
						getActions: () => actions, // add context menu actions (iff appicable)
						menuId: this._options?.contextMenu,
						menuActionOptions: {
							renderShortTitle: true,
							...this._options?.menuOptions
						},

						contextKeyService: this._contextKeyService
					});
				})
			);
		}
	}
}
__decorate(
	[
		__param(2, IMenuService),
		__param(3, IContextKeyService),
		__param(4, IContextMenuService),
		__param(5, IKeybindingService),
		__param(6, ICommandService)
	],
	WorkbenchToolBar
);

class MenuWorkbenchToolBar extends WorkbenchToolBar {
	constructor(container, menuId, options2, menuService, contextKeyService, contextMenuService, keybindingService, commandService) {
		super(
			container,
			{ resetMenu: menuId, ...options2 },
			menuService,
			contextKeyService,
			contextMenuService,
			keybindingService,
			commandService
		);
		this._onDidChangeMenuItems = this._store.add(new Emitter());
		this.onDidChangeMenuItems = this._onDidChangeMenuItems.event;
		const menu = this._store.add(
			menuService.createMenu(menuId, contextKeyService, {
				emitEventsForSubmenuChanges: true
			})
		);
		const updateToolbar = () => {
			const primary = [];
			const secondary = [];
			createAndFillInActionBarActions(
				menu,
				options2?.menuOptions,
				{ primary, secondary },
				options2?.toolbarOptions?.primaryGroup,
				options2?.toolbarOptions?.shouldInlineSubmenu,
				options2?.toolbarOptions?.useSeparatorsInPrimaryActions
			);
			container.classList.toggle('has-no-actions', primary.length === 0 && secondary.length === 0);
			super.setActions(primary, secondary);
		};
		this._store.add(
			menu.onDidChange(() => {
				updateToolbar();
				this._onDidChangeMenuItems.fire(this);
			})
		);
		updateToolbar();
	}
	setActions() {
		throw new BugIndicatingError('This toolbar is populated from a menu.');
	}
}
__decorate(
	[
		__param(3, IMenuService),
		__param(4, IContextKeyService),
		__param(5, IContextMenuService),
		__param(6, IKeybindingService),
		__param(7, ICommandService)
	],
	MenuWorkbenchToolBar
);