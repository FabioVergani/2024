class Toggle extends Widget {
	constructor(opts) {
		super();
		this._onChange = this._register(new Emitter());
		this.onChange = this._onChange.event;
		this._onKeyDown = this._register(new Emitter());
		this.onKeyDown = this._onKeyDown.event;
		this._opts = opts;
		this._checked = this._opts.isChecked;
		const classes = ['monaco-custom-toggle'];
		if (this._opts.icon) {
			this._icon = this._opts.icon;
			classes.push(...asThemeIconClassNameArray(this._icon));
		}
		if (this._opts.actionClassName) {
			classes.push(...this._opts.actionClassName.split(' '));
		}
		if (this._checked) {
			classes.push('checked');
		}
		this.domNode = document.createElement('div');
		this._hover = this._register(
			getBaseLayerHoverDelegate().setupUpdatableHover(
				opts.hoverDelegate ?? getDefaultHoverDelegate('mouse'),
				this.domNode,
				this._opts.title
			)
		);
		this.domNode.classList.add(...classes);
		if (!this._opts.notFocusable) {
			this.domNode.tabIndex = 0;
		}
		this.applyStyles();
		this.onclick(this.domNode, ev => {
			if (this.enabled) {
				this.checked = !this._checked;
				this._onChange.fire(false);
				ev.preventDefault();
			}
		});
		this._register(this.ignoreGesture(this.domNode));
		this.onkeydown(this.domNode, keyboardEvent => {
			if (keyboardEvent.keyCode === 10 || keyboardEvent.keyCode === 3) {
				this.checked = !this._checked;
				this._onChange.fire(true);
				keyboardEvent.preventDefault();
				keyboardEvent.stopPropagation();
				return;
			}
			this._onKeyDown.fire(keyboardEvent);
		});
	}
	focus() {
		this.domNode.focus();
	}
	get checked() {
		return this._checked;
	}
	set checked(newIsChecked) {
		this._checked = newIsChecked;
		this.domNode.classList.toggle('checked', this._checked);
		this.applyStyles();
	}
	width() {
		return 2 + 2 + 2 + 16;
	}
	applyStyles() {
		if (this.domNode) {
			this.domNode.style.borderColor = (this._checked && this._opts.inputActiveOptionBorder) || '';
			this.domNode.style.color = (this._checked && this._opts.inputActiveOptionForeground) || 'inherit';
			this.domNode.style.backgroundColor = (this._checked && this._opts.inputActiveOptionBackground) || '';
		}
	}
}

