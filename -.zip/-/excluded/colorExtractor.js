class ColorExtractor {
	extract(item, out) {
		if (item.textLabel.match(ColorExtractor._regexStrict)) {
			out[0] = item.textLabel;
			return true;
		}
		if (item.completion.detail && item.completion.detail.match(ColorExtractor._regexStrict)) {
			out[0] = item.completion.detail;
			return true;
		}
		if (item.completion.documentation) {
			const value =
				typeof item.completion.documentation === 'string' ? item.completion.documentation : item.completion.documentation.value;
			const match2 = ColorExtractor._regexRelaxed.exec(value);
			if (match2 && (match2.index === 0 || match2.index + match2[0].length === value.length)) {
				out[0] = match2[0];
				return true;
			}
		}
		return false;
	}
}
ColorExtractor._regexRelaxed =
	/(#([\da-fA-F]{3}){1,2}|(rgb|hsl)a\(\s*(\d{1,3}%?\s*,\s*){3}(1|0?\.\d+)\)|(rgb|hsl)\(\s*\d{1,3}%?(\s*,\s*\d{1,3}%?){2}\s*\))/;
ColorExtractor._regexStrict = new RegExp(`^${ColorExtractor._regexRelaxed.source}$`, 'i');

const colorExtractor = new ColorExtractor();

/*
if (completion.kind === 19 && colorExtractor.extract(element, color)) {
			data.icon.className = 'icon customcolor';
			data.iconContainer.className = 'icon hide';
			data.colorspan.style.backgroundColor = color[0];
		} else*/
