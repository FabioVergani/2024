


























// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -





				if (!properties[key].deprecationMessage && properties[key].markdownDeprecationMessage) {
					properties[key].deprecationMessage = properties[key].markdownDeprecationMessage;
				}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




 {
			const markdown = options2.content;
			const mdRenderer = this._instantiationService.createInstance(MarkdownRenderer, {
				codeBlockFontFamily: this._configurationService.getValue('editor').fontFamily || defaultEditorFont_family
			});
			const { element } = mdRenderer.render(markdown, {
				actionHandler: {
					callback: content => this._linkHandler(content),
					disposables: this._messageListeners
				},
				asyncRenderCallback: () => {
					contentsElement.classList.add('code-hover-contents');
					this.layout();
					this._onRequestLayout.fire();
				}
			});
			contentsElement.appendChild(element);
		}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

||
					(isMarkdownString(options2.content) &&
						!options2.content.value.includes('](') &&
						!options2.content.value.includes('</a>'))
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -





			if (content === undefined || 'string' === typeof content || content instanceof HTMLElement) {
				resolvedContent = content;
			} else {
				if (!this._hoverWidget) {
					this.show(localize('Loading...'), focus);
				}
				this._cancellationTokenSource = new CancellationTokenSource();
				const token = this._cancellationTokenSource.token;
				resolvedContent = await content.markdown(token);
				if (resolvedContent === undefined) {
					resolvedContent = content.markdownNotSupportedFallback;
				}
				if (this.isDisposed || token.isCancellationRequested) {
					return;
				}
			}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

registerLanguage({
	id: 'markdown',
	extensions: ['.md'],
	loader: () => {
		return Promise.resolve({
			conf: {
				comments: { blockComment: ['<!--', '-->'] },
				brackets: [
					['{', '}'],
					['[', ']'],
					['(', ')']
				],
				autoClosingPairs: [
					{ open: '{', close: '}' },
					{ open: '[', close: ']' },
					{ open: '(', close: ')' },
					{ open: '<', close: '>', notIn: ['string'] }
				],
				surroundingPairs: [
					{ open: '(', close: ')' },
					{ open: '[', close: ']' },
					{ open: '`', close: '`' }
				],
				folding: {
					markers: {
						start: new RegExp('^\\s*<!--\\s*#?region\\b.*-->'),
						end: new RegExp('^\\s*<!--\\s*#?endregion\\b.*-->')
					}
				}
			},
			language: {
				defaultToken: '',
				tokenPostfix: '.md', // escape codes
				control: /[\\`*_\[\]{}()#+\-\.!]/,
				noncontrol: /[^\\`*_\[\]{}()#+\-\.!]/,
				escapes: /\\(?:@control)/, // escape codes for javascript/CSS strings
				jsescapes: /\\(?:[btnfr\\"']|[0-7][0-7]?|[0-3][0-7]{2})/, // non matched elements
				empty: ['area', 'base', 'basefont', 'br', 'col', 'frame', 'hr', 'img', 'input', 'isindex', 'link', 'meta', 'param'],
				tokenizer: {
					root: [
						// markdown tables
						[/^\s*\|/, '@rematch', '@table_header'], // headers (with #)
						[/^(\s{0,3})(#+)((?:[^\\#]|@escapes)+)((?:#+)?)/, ['white', 'keyword', 'keyword', 'keyword']], // headers (with =)
						[/^\s*(=+|\-+)\s*$/, 'keyword'], // headers (with ***)
						[/^\s*((\*[ ]?)+)\s*$/, 'meta.separator'], // quote
						[/^\s*>+/, 'comment'], // list (starting with * or number)
						[/^\s*([\*\-+:]|\d+\.)\s/, 'keyword'], // code block (4 spaces indent)
						[/^(\t|[ ]{4})[^ ].*$/, 'string'], // code block (3 tilde)
						[/^\s*~~~\s*((?:\w|[\/\-#])+)?\s*$/, { token: 'string', next: '@codeblock' }], // github style code blocks (with backticks and language)
						[
							/^\s*```\s*((?:\w|[\/\-#])+).*$/,
							{
								token: 'string',
								next: '@codeblockgh',
								nextEmbedded: '$1'
							}
						], // github style code blocks (with backticks but no language)
						[/^\s*```\s*$/, { token: 'string', next: '@codeblock' }], // markup within lines
						{ include: '@linecontent' }
					],
					table_header: [
						{ include: '@table_common' },
						[/[^\|]+/, 'keyword.table.header'] // table header
					],
					table_body: [{ include: '@table_common' }, { include: '@linecontent' }],
					table_common: [
						[/\s*[\-:]+\s*/, { token: 'keyword', switchTo: 'table_body' }], // header-divider
						[/^\s*\|/, 'keyword.table.left'], // opening |
						[/^\s*[^\|]/, '@rematch', '@pop'], // exiting
						[/^\s*$/, '@rematch', '@pop'], // exiting
						[
							/\|/,
							{
								cases: {
									'@eos': 'keyword.table.right', // closing |
									'@default': 'keyword.table.middle' // inner |
								}
							}
						]
					],
					codeblock: [
						[/^\s*~~~\s*$/, { token: 'string', next: '@pop' }],
						[/^\s*```\s*$/, { token: 'string', next: '@pop' }],
						[/.*$/, 'variable.source']
					], // github style code blocks
					codeblockgh: [
						[/```\s*$/, { token: 'string', next: '@pop', nextEmbedded: '@pop' }],
						[/[^`]+/, 'variable.source']
					],
					linecontent: [
						// escapes
						[/&\w+;/, 'string.escape'],
						[/@escapes/, 'escape'], // various markup
						[/\b__([^\\_]|@escapes|_(?!_))+__\b/, 'strong'],
						[/\*\*([^\\*]|@escapes|\*(?!\*))+\*\*/, 'strong'],
						[/\b_[^_]+_\b/, 'emphasis'],
						[/\*([^\\*]|@escapes)+\*/, 'emphasis'],
						[/`([^\\`]|@escapes)+`/, 'variable'], // links
						[/\{+[^}]+\}+/, 'string.target'],
						[/(!?\[)((?:[^\]\\]|@escapes)*)(\]\([^\)]+\))/, ['string.link', '', 'string.link']],
						[/(!?\[)((?:[^\]\\]|@escapes)*)(\])/, 'string.link'], // or html
						{ include: 'html' }
					], // Note: it is tempting to rather switch to the real HTML mode instead of building our own here
					// but currently there is a limitation in Monarch that prevents us from doing it: The opening
					// '<' would start the HTML mode, however there is no way to jump 1 character back to let the
					// HTML mode also tokenize the opening angle bracket. Thus, even though we could jump to HTML,
					// we cannot correctly tokenize it in that mode yet.
					html: [
						// html tags
						[/<(\w+)\/>/, 'tag'],
						[
							/<(\w+)(\-|\w)*/,
							{
								cases: {
									'@empty': { token: 'tag', next: '@tag.$1' },
									'@default': { token: 'tag', next: '@tag.$1' }
								}
							}
						],
						[/<\/(\w+)(\-|\w)*\s*>/, { token: 'tag' }],
						[/<!--/, 'comment', '@comment']
					],
					comment: [
						[/[^<\-]+/, 'comment.content'],
						[/-->/, 'comment', '@pop'],
						[/<!--/, 'comment.content.invalid'],
						[/[<\-]/, 'comment.content']
					], // Almost full HTML tag matching, complete with embedded scripts & styles
					tag: [
						[/[ \t\r\n]+/, 'white'],
						[
							/(type)(\s*=\s*)(")([^"]+)(")/,
							[
								'attribute.name.html',
								'delimiter.html',
								'string.html',
								{ token: 'string.html', switchTo: '@tag.$S2.$4' },
								'string.html'
							]
						],
						[
							/(type)(\s*=\s*)(')([^']+)(')/,
							[
								'attribute.name.html',
								'delimiter.html',
								'string.html',
								{ token: 'string.html', switchTo: '@tag.$S2.$4' },
								'string.html'
							]
						],
						[/(\w+)(\s*=\s*)("[^"]*"|'[^']*')/, ['attribute.name.html', 'delimiter.html', 'string.html']],
						[/\w+/, 'attribute.name.html'],
						[/\/>/, 'tag', '@pop'],
						[
							/>/,
							{
								cases: {
									'$S2==style': {
										token: 'tag',
										switchTo: 'embeddedStyle',
										nextEmbedded: 'text/css'
									},
									'$S2==script': {
										cases: {
											$S3: {
												token: 'tag',
												switchTo: 'embeddedScript',
												nextEmbedded: '$S3'
											},
											'@default': {
												token: 'tag',
												switchTo: 'embeddedScript',
												nextEmbedded: 'text/javascript'
											}
										}
									},
									'@default': { token: 'tag', next: '@pop' }
								}
							}
						]
					],
					embeddedStyle: [
						[/[^<]+/, ''],
						[
							/<\/style\s*>/,
							{
								token: '@rematch',
								next: '@pop',
								nextEmbedded: '@pop'
							}
						],
						[/</, '']
					],
					embeddedScript: [
						[/[^<]+/, ''],
						[
							/<\/script\s*>/,
							{
								token: '@rematch',
								next: '@pop',
								nextEmbedded: '@pop'
							}
						],
						[/</, '']
					]
				}
			}
		});
	}
});


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -




const INCREASE_HOVER_VERBOSITY_ACTION_ID = 'editor.action.increaseHoverVerbosityLevel';

const DECREASE_HOVER_VERBOSITY_ACTION_ID = 'editor.action.decreaseHoverVerbosityLevel';

class MarkdownHover {
	constructor(owner, range2, contents, isBeforeContent, ordinal, source = undefined) {
		this.owner = owner;
		this.range = range2;
		this.contents = contents;
		this.isBeforeContent = isBeforeContent;
		this.ordinal = ordinal;
		this.source = source;
	}
	isValidForHoverAnchor(anchor) {
		return anchor.type === 1 && this.range.startColumn <= anchor.range.startColumn && this.range.endColumn >= anchor.range.endColumn;
	}
}

class HoverSource {
	constructor(hover, hoverProvider, hoverPosition) {
		this.hover = hover;
		this.hoverProvider = hoverProvider;
		this.hoverPosition = hoverPosition;
	}
	supportsVerbosityAction(e) {
		switch (e) {
			case 0:
				return this.hover.canIncreaseVerbosity ?? false;
			case 1:
				return this.hover.canDecreaseVerbosity ?? false;
		}
	}
}

class MarkdownRenderedHoverParts extends Disposable {
	constructor(
		hoverParts,
		hoverPartsContainer,
		_editor,
		_languageService,
		_openerService,
		_keybindingService,
		_hoverService,
		_configurationService,
		_onFinishedRendering
	) {
		super();
		this._editor = _editor;
		this._languageService = _languageService;
		this._openerService = _openerService;
		this._keybindingService = _keybindingService;
		this._hoverService = _hoverService;
		this._configurationService = _configurationService;
		this._onFinishedRendering = _onFinishedRendering;
		this._hoverFocusInfo = { hoverPartIndex: -1, focusRemains: false };
		this._renderedHoverParts = this._renderHoverParts(hoverParts, hoverPartsContainer, this._onFinishedRendering);
		this._register(
			toDisposable(() => {
				this._renderedHoverParts.forEach(renderedHoverPart => {
					renderedHoverPart.disposables.dispose();
				});
			})
		);
	}
	_renderHoverParts(hoverParts, hoverPartsContainer, onFinishedRendering) {
		hoverParts.sort((a, b) => a.ordinal - b.ordinal);
		return hoverParts.map((hoverPart, hoverIndex) => {
			const renderedHoverPart = this._renderHoverPart(hoverIndex, hoverPart.contents, hoverPart.source, onFinishedRendering);
			hoverPartsContainer.appendChild(renderedHoverPart.renderedMarkdown);
			return renderedHoverPart;
		});
	}
	_renderHoverPart(hoverPartIndex, hoverContents, hoverSource, onFinishedRendering) {
		const { renderedMarkdown, disposables } = this._renderMarkdownContent(hoverContents, onFinishedRendering);
		if (!hoverSource) {
			return { renderedMarkdown, disposables };
		}
		const canIncreaseVerbosity = hoverSource.supportsVerbosityAction(0);
		const canDecreaseVerbosity = hoverSource.supportsVerbosityAction(1);
		if (!canIncreaseVerbosity && !canDecreaseVerbosity) {
			return { renderedMarkdown, disposables, hoverSource };
		}
		const actionsContainer = createDomElement('div.verbosity-actions');
		renderedMarkdown.prepend(actionsContainer);
		disposables.add(this._renderHoverExpansionAction(actionsContainer, 0, canIncreaseVerbosity));
		disposables.add(this._renderHoverExpansionAction(actionsContainer, 1, canDecreaseVerbosity));
		const focusTracker = disposables.add(trackFocus(renderedMarkdown));
		disposables.add(
			focusTracker.onDidFocus(() => {
				this._hoverFocusInfo = { hoverPartIndex, focusRemains: true };
			})
		);
		disposables.add(
			focusTracker.onDidBlur(() => {
				if (this._hoverFocusInfo?.focusRemains) {
					this._hoverFocusInfo.focusRemains = false;
				}
			})
		);
		return { renderedMarkdown, disposables, hoverSource };
	}
	_renderMarkdownContent(markdownContent, onFinishedRendering) {
		const renderedMarkdown = createDomElement('div.hover-row');
		renderedMarkdown.tabIndex = 0;
		const renderedMarkdownContents = createDomElement('div.hover-row-contents');
		renderedMarkdown.appendChild(renderedMarkdownContents);
		const disposables = new DisposableStore();

		function _renderMarkdownInContainer(editor2, container, markdownStrings, languageService, openerService, onFinishedRendering) {
			const store = new DisposableStore();
			for (const contents of markdownStrings) {
				if (isEmptyMarkdownString(contents)) {
					continue;
				}
				const markdownHoverElement = createDomElement('div.markdown-hover');
				const hoverContentsElement = append(markdownHoverElement, createDomElement('div.hover-contents'));
				const renderer = store.add(new MarkdownRenderer({ editor: editor2 }, languageService, openerService));
				store.add(
					renderer.onDidRenderAsync(() => {
						hoverContentsElement.className = 'hover-contents code-hover-contents';
						onFinishedRendering();
					})
				);
				const renderedContents = store.add(renderer.render(contents));
				hoverContentsElement.appendChild(renderedContents.element);
				container.appendChild(markdownHoverElement);
			}
			return store;
		}

		disposables.add(
			_renderMarkdownInContainer(
				this._editor,
				renderedMarkdownContents,
				markdownContent,
				this._languageService,
				this._openerService,
				onFinishedRendering
			)
		);
		return { renderedMarkdown, disposables };
	}
	_renderHoverExpansionAction(container, action, actionEnabled) {
		const store = new DisposableStore();
		const isActionIncrease = action === 0;
		const actionElement = append(container, createDomElement(asThemeIconCSSSelector(isActionIncrease ? codicon_add : codicon_remove)));
		actionElement.tabIndex = 0;
		const hoverDelegate = new WorkbenchHoverDelegate(
			'mouse',
			false,
			{
				target: container,
				position: {
					hoverPosition: 0 // LEFT
				}
			},
			this._configurationService,
			this._hoverService
		);
		if (isActionIncrease) {
			const kb = this._keybindingService.lookupKeybinding(INCREASE_HOVER_VERBOSITY_ACTION_ID);
			store.add(
				this._hoverService.setupUpdatableHover(
					hoverDelegate,
					actionElement,
					kb ? localize(kb.getLabel()) : localize('Increase Verbosity')
				)
			);
		} else {
			const kb = this._keybindingService.lookupKeybinding(DECREASE_HOVER_VERBOSITY_ACTION_ID);
			store.add(
				this._hoverService.setupUpdatableHover(
					hoverDelegate,
					actionElement,
					kb ? localize(kb.getLabel()) : localize('Decrease Verbosity')
				)
			);
		}
		if (!actionEnabled) {
			actionElement.classList.add('disabled');
			return store;
		}
		actionElement.classList.add('enabled');
		const actionFunction = () => this.updateFocusedHoverPartVerbosityLevel(action);
		store.add(new ClickAction(actionElement, actionFunction));
		store.add(
			new KeyDownAction(actionElement, actionFunction, [
				3,
				10 // Space
			])
		);
		return store;
	}
	async updateFocusedHoverPartVerbosityLevel(action) {
		const model = this._editor.getModel();
		if (model) {
			const hoverFocusedPartIndex = this._hoverFocusInfo.hoverPartIndex;
			const hoverRenderedPart = this._getRenderedHoverPartAtIndex(hoverFocusedPartIndex);
			if (!hoverRenderedPart || !hoverRenderedPart.hoverSource?.supportsVerbosityAction(action)) {
				return;
			}
			const hoverPosition = hoverRenderedPart.hoverSource.hoverPosition;
			const hoverProvider = hoverRenderedPart.hoverSource.hoverProvider;
			const hover = hoverRenderedPart.hoverSource.hover;
			const hoverContext = {
				verbosityRequest: { action, previousHover: hover }
			};
			let newHover;
			try {
				newHover = await Promise.resolve(hoverProvider.provideHover(model, hoverPosition, cancellationToken_none, hoverContext));
			} catch (e) {
				onUnexpectedExternalError(e);
			}
			if (newHover) {
				const hoverSource = new HoverSource(newHover, hoverProvider, hoverPosition);
				const renderedHoverPart = this._renderHoverPart(
					hoverFocusedPartIndex,
					newHover.contents,
					hoverSource,
					this._onFinishedRendering
				);
				this._replaceRenderedHoverPartAtIndex(hoverFocusedPartIndex, renderedHoverPart);
				this._focusOnHoverPartWithIndex(hoverFocusedPartIndex);
				this._onFinishedRendering();
			}
		}
	}
	_replaceRenderedHoverPartAtIndex(index, renderedHoverPart) {
		if (index >= this._renderHoverParts.length || index < 0) {
			return;
		}
		const currentRenderedHoverPart = this._renderedHoverParts[index];
		const currentRenderedMarkdown = currentRenderedHoverPart.renderedMarkdown;
		currentRenderedMarkdown.replaceWith(renderedHoverPart.renderedMarkdown);
		currentRenderedHoverPart.disposables.dispose();
		this._renderedHoverParts[index] = renderedHoverPart;
	}
	_focusOnHoverPartWithIndex(index) {
		this._renderedHoverParts[index].renderedMarkdown.focus();
		this._hoverFocusInfo.focusRemains = true;
	}
	_getRenderedHoverPartAtIndex(index) {
		return this._renderedHoverParts[index];
	}
}

const getHoverProviderResultsAsAsyncIterable = (registry, model, position, token) => {
	const providers = registry.ordered(model);
	async function executeProvider(provider, ordinal, model, position, token) {
		const result = await Promise.resolve(provider.provideHover(model, position, token)).catch(onUnexpectedExternalError);
		function _isValid(result) {
			const hasRange = typeof result.range !== 'undefined';
			const hasHtmlContent = typeof result.contents !== 'undefined' && result.contents && result.contents.length > 0;
			return hasRange && hasHtmlContent;
		}
		if (!result || !_isValid(result)) {
			return;
		}
		return {
			provider: provider,
			hover: result,
			ordinal: ordinal
		};
	}
	const promises = providers.map((provider, index) => executeProvider(provider, index, model, position, token));
	return AsyncIterableObject.fromPromises(promises).coalesce();
};

class MarkdownHoverParticipant {
	constructor(
		_editor,
		_languageService,
		_openerService,
		_configurationService,
		_languageFeaturesService,
		_keybindingService,
		_hoverService
	) {
		this._editor = _editor;
		this._languageService = _languageService;
		this._openerService = _openerService;
		this._configurationService = _configurationService;
		this._languageFeaturesService = _languageFeaturesService;
		this._keybindingService = _keybindingService;
		this._hoverService = _hoverService;
		this.hoverOrdinal = 3;
	}
	createLoadingMessage(anchor) {
		return new MarkdownHover(this, anchor.range, [new MarkdownString().appendText(localize('Loading...'))], false, 2e3);
	}
	computeSync(anchor, lineDecorations) {
		if (!this._editor.hasModel() || anchor.type !== 1) {
			return [];
		}
		const model = this._editor.getModel();
		const lineNumber = anchor.range.startLineNumber;
		const maxColumn = model.getLineMaxColumn(lineNumber);
		const result = [];
		let index = 1e3;
		const lineLength = model.getLineLength(lineNumber);
		const languageId = model.getLanguageIdAtPosition(anchor.range.startLineNumber, anchor.range.startColumn);
		const stopRenderingLineAfter = this._editor.getOption(
			117 // stopRenderingLineAfter
		);
		const maxTokenizationLineLength = this._configurationService.getValue('editor.maxTokenizationLineLength', {
			overrideIdentifier: languageId
		});
		let stopRenderingMessage = false;
		if (stopRenderingLineAfter >= 0 && lineLength > stopRenderingLineAfter && anchor.range.startColumn >= stopRenderingLineAfter) {
			stopRenderingMessage = true;
			result.push(
				new MarkdownHover(
					this,
					anchor.range,
					[
						{
							value: localize(
								'Rendering paused for long line for performance reasons. This can be configured via `editor.stopRenderingLineAfter`.'
							)
						}
					],
					false,
					index++
				)
			);
		}
		if (!stopRenderingMessage && typeof maxTokenizationLineLength === 'number' && lineLength >= maxTokenizationLineLength) {
			result.push(
				new MarkdownHover(
					this,
					anchor.range,
					[
						{
							value: localize(
								'Tokenization is skipped for long lines for performance reasons. This can be configured via `editor.maxTokenizationLineLength`.'
							)
						}
					],
					false,
					index++
				)
			);
		}
		let isBeforeContent = false;
		for (const d of lineDecorations) {
			const startColumn = d.range.startLineNumber === lineNumber ? d.range.startColumn : 1;
			const endColumn = d.range.endLineNumber === lineNumber ? d.range.endColumn : maxColumn;
			const hoverMessage = d.options.hoverMessage;
			if (!hoverMessage || isEmptyMarkdownString(hoverMessage)) {
				continue;
			}
			if (d.options.beforeContentClassName) {
				isBeforeContent = true;
			}
			const range2 = new Range(anchor.range.startLineNumber, startColumn, anchor.range.startLineNumber, endColumn);
			result.push(new MarkdownHover(this, range2, asArray(hoverMessage), isBeforeContent, index++));
		}
		return result;
	}
	computeAsync(anchor, lineDecorations, token) {
		if (!this._editor.hasModel() || anchor.type !== 1) {
			return AsyncIterableObject.EMPTY;
		}
		const model = this._editor.getModel();
		const hoverProviderRegistry = this._languageFeaturesService.hoverProvider;
		if (!hoverProviderRegistry.has(model)) {
			return AsyncIterableObject.EMPTY;
		}
		const markdownHovers = this._getMarkdownHovers(hoverProviderRegistry, model, anchor, token);
		return markdownHovers;
	}
	_getMarkdownHovers(hoverProviderRegistry, model, anchor, token) {
		const position = anchor.range.getStartPosition();
		const hoverProviderResults = getHoverProviderResultsAsAsyncIterable(hoverProviderRegistry, model, position, token);
		const markdownHovers = hoverProviderResults
			.filter(item => !isEmptyMarkdownString(item.hover.contents))
			.map(item => {
				const range2 = item.hover.range ? Range.lift(item.hover.range) : anchor.range;
				const hoverSource = new HoverSource(item.hover, item.provider, position);
				return new MarkdownHover(this, range2, item.hover.contents, false, item.ordinal, hoverSource);
			});
		return markdownHovers;
	}
	renderHoverParts(context, hoverParts) {
		this._renderedHoverParts = new MarkdownRenderedHoverParts(
			hoverParts,
			context.fragment,
			this._editor,
			this._languageService,
			this._openerService,
			this._keybindingService,
			this._hoverService,
			this._configurationService,
			context.onContentsChanged
		);
		return this._renderedHoverParts;
	}
	updateFocusedMarkdownHoverPartVerbosityLevel(action) {
		this._renderedHoverParts?.updateFocusedHoverPartVerbosityLevel(action);
	}
}
__decorate(
	[
		__param(1, ILanguageService),
		__param(2, IOpenerService),
		__param(3, IConfigurationService),
		__param(4, ILanguageFeaturesService),
		__param(5, IKeybindingService),
		__param(6, IHoverService)
	],
	MarkdownHoverParticipant
);
hoverParticipantRegistry.register(MarkdownHoverParticipant);


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



		/*


				if (participantInstance instanceof MarkdownHoverParticipant) {
				this._markdownHoverParticipant = participantInstance;
			}
	async updateFocusedMarkdownHoverVerbosityLevel(action) {
		this._markdownHoverParticipant?.updateFocusedMarkdownHoverPartVerbosityLevel(action);
	}

	updateFocusedMarkdownHoverVerbosityLevel(action) {
		this._getOrCreateContentWidget().updateFocusedMarkdownHoverVerbosityLevel(action);
	}




		this._markdownRenderer = instaService.createInstance(MarkdownRenderer, {
			editor: _editor
		});


				if (explainMode) {
			documentation = new MarkdownString().appendCodeblock(
				'empty',
				`
				  score: ${item.score[0]}
				  prefix: ${item.word ?? '(no prefix)'}
				  word: ${item.completion.filterText ? item.completion.filterText + ' (filterText)' : item.textLabel}
				  distance: ${item.distance} (localityBonus-setting)
				  index: ${item.idx}, based on ${item.completion.sortText ? `sortText: "${item.completion.sortText}"` : 'label'}
				  commit_chars: ${item.completion.commitCharacters?.join('')}
				`
			);
			detail = `Provider: ${item.provider._debugDisplayName}`;
		}
		if (typeof documentation === 'string') {
			this._docs.classList.remove('markdown-docs');
			this._docs.textContent = documentation;
		} else if (documentation) {
			this._docs.classList.add('markdown-docs');
			clearNode(this._docs);
			const renderedContents = this._markdownRenderer.render(documentation);
			this._docs.appendChild(renderedContents.element);
			this._renderDisposeable.add(renderedContents);

			this._renderDisposeable.add(
				this._markdownRenderer.onDidRenderAsync(() => {
					this.layout(this._size.width, this._type.clientHeight + this._docs.clientHeight);
					this._onDidChangeContents.fire(this);
				})
			);

		}*/