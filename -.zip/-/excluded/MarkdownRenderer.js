
function escapeIcons(text2) {
	return text2.replace(escapeIconsRegex, (match2, escaped) => (escaped ? match2 : `\\${match2}`));
}
function markdownEscapeEscapedIcons(text2) {
	return text2.replace(markdownEscapedIconsRegex, match2 => `\\${match2}`);
}
function stripIcons(e) {
	if (e.indexOf('$(') === -1) {
		return e;
	}
	return e.replace(stripIconsRegex, (match2, preWhitespace, escaped, postWhitespace) =>
		escaped ? match2 : preWhitespace || postWhitespace || ''
	);
}

function parseLabelWithIcons(input) {
	_parseIconsRegex.lastIndex = 0;
	let text2 = '';
	const iconOffsets = [];
	let iconsOffset = 0;
	while (true) {
		const pos = _parseIconsRegex.lastIndex;
		const match2 = _parseIconsRegex.exec(input);
		const chars = input.substring(pos, match2?.index);
		if (chars.length > 0) {
			text2 += chars;
			for (let i = 0; i < chars.length; i++) {
				iconOffsets.push(iconsOffset);
			}
		}
		if (!match2) {
			break;
		}
		iconsOffset += match2[0].length;
	}
	return { text: text2, iconOffsets };
}
function matchesFuzzyIconAware(query, target, enableSeparateSubstringMatching = false) {
	const { text: text2, iconOffsets } = target;
	if (!iconOffsets || iconOffsets.length === 0) {
		return matchesFuzzy(query, text2, enableSeparateSubstringMatching);
	}
	const wordToMatchAgainstWithoutIconsTrimmed = trimsTrailingOccurrencesFromStart(text2, ' ');
	const leadingWhitespaceOffset = text2.length - wordToMatchAgainstWithoutIconsTrimmed.length;
	const matches = matchesFuzzy(query, wordToMatchAgainstWithoutIconsTrimmed, enableSeparateSubstringMatching);
	if (matches) {
		for (const match2 of matches) {
			const iconOffset = iconOffsets[match2.start + leadingWhitespaceOffset] + leadingWhitespaceOffset;
			match2.start += iconOffset;
			match2.end += iconOffset;
		}
	}
	return matches;
}

const iconsRegex = new RegExp(`\\$\\(${exp_editorIconName}(?:${exp_editorIconModifier})?\\)`, 'g');
const escapeIconsRegex = new RegExp(`(\\\\)?${iconsRegex.source}`, 'g');
const markdownEscapedIconsRegex = new RegExp(`\\\\${iconsRegex.source}`, 'g');
const stripIconsRegex = new RegExp(`(\\s)?(\\\\)?${iconsRegex.source}(\\s)?`, 'g');
const _parseIconsRegex = new RegExp(`\\$\\(${exp_editorIconChars}+\\)`, 'g');

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function isMarkdownString(thing) {
	if (thing instanceof MarkdownString) {
		return true;
	} else if (thing && typeof thing === 'object') {
		return (
			typeof thing.value === 'string' &&
			(typeof thing.isTrusted === 'boolean' || typeof thing.isTrusted === 'object' || thing.isTrusted === undefined) &&
			(typeof thing.supportThemeIcons === 'boolean' || thing.supportThemeIcons === undefined)
		);
	}
	return false;
}

function isEmptyMarkdownString(oneOrMany) {
	if (isMarkdownString(oneOrMany)) {
		return !oneOrMany.value;
	} else if (isArray(oneOrMany)) {
		return oneOrMany.every(isEmptyMarkdownString);
	} else {
		return true;
	}
}

function markdownStringEqual(a, b) {
	if (a === b) {
		return true;
	} else if (!a || !b) {
		return false;
	} else {
		return (
			a.value === b.value &&
			a.isTrusted === b.isTrusted &&
			a.supportThemeIcons === b.supportThemeIcons &&
			a.supportHtml === b.supportHtml &&
			(a.baseUri === b.baseUri || (!!a.baseUri && !!b.baseUri && isEqual(URI.from(a.baseUri), URI.from(b.baseUri))))
		);
	}
}
function escapeMarkdownSyntaxTokens(text2) {
	return text2.replace(/[\\`*_{}[\]()#+\-!~]/g, escapeReplacement);
}
function appendEscapedMarkdownCodeBlockFence(code, langId) {
	const longestFenceLength = code.match(/^`+/gm)?.reduce((a, b) => (a.length > b.length ? a : b)).length ?? 0;
	const desiredFenceLength = longestFenceLength >= 3 ? longestFenceLength + 1 : 3;
	return [`${'`'.repeat(desiredFenceLength)}${langId}`, code, `${'`'.repeat(desiredFenceLength)}`].join('\n');
}

function escapeDoubleQuotes(input) {
	return input.replace(/"/g, '&quot;');
}

function removeMarkdownEscapes(text2) {
	if (!text2) {
		return text2;
	}
	return text2.replace(/\\([\\`*_{}[\]()#+\-.!~])/g, '$1');
}
function parseHrefAndDimensions(href) {
	const dimensions = [];
	const splitted = href.split('|').map(s => s.trim());
	href = splitted[0];
	const parameters = splitted[1];
	if (parameters) {
		const heightFromParams = /height=(\d+)/.exec(parameters);
		const widthFromParams = /width=(\d+)/.exec(parameters);
		const height = heightFromParams ? heightFromParams[1] : '';
		const width2 = widthFromParams ? widthFromParams[1] : '';
		const widthIsFinite = isFinite(parseInt(width2));
		const heightIsFinite = isFinite(parseInt(height));
		if (widthIsFinite) {
			dimensions.push(`width="${width2}"`);
		}
		if (heightIsFinite) {
			dimensions.push(`height="${height}"`);
		}
	}
	return { href, dimensions };
}

class MarkdownString {
	constructor(value = '', isTrustedOrOptions = false) {
		this.value = value;
		if (typeof this.value !== 'string') {
			throw illegalArgument('value');
		}
		if (typeof isTrustedOrOptions === 'boolean') {
			this.isTrusted = isTrustedOrOptions;
			this.supportThemeIcons = false;
			this.supportHtml = false;
		} else {
			this.isTrusted = isTrustedOrOptions.isTrusted;
			this.supportThemeIcons = isTrustedOrOptions.supportThemeIcons ?? false;
			this.supportHtml = isTrustedOrOptions.supportHtml ?? false;
		}
	}
	appendText(value, newlineStyle = 0) {
		this.value += escapeMarkdownSyntaxTokens(this.supportThemeIcons ? escapeIcons(value) : value)
			.replace(/([ \t]+)/g, (_match, g1) => '&nbsp;'.repeat(g1.length))
			.replace(/\>/gm, '\\>')
			.replace(/\n/g, newlineStyle === 1 ? '\\\n' : '\n\n');
		return this;
	}
	appendMarkdown(value) {
		this.value += value;
		return this;
	}
	appendCodeblock(langId, code) {
		this.value += `
${appendEscapedMarkdownCodeBlockFence(code, langId)}
`;
		return this;
	}
	appendLink(target, label, title) {
		this.value += '[';
		this.value += this._escape(label, ']');
		this.value += '](';
		this.value += this._escape(String(target), ')');
		if (title) {
			this.value += ` "${this._escape(this._escape(title, '"'), ')')}"`;
		}
		this.value += ')';
		return this;
	}
	_escape(value, ch) {
		const r = new RegExp(escapeRegexChars(ch), 'g');
		return value.replace(r, (match2, offset) => {
			if (value.charAt(offset - 1) !== '\\') {
				return `\\${match2}`;
			} else {
				return match2;
			}
		});
	}
}



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



function stringify(obj) {
	function replacer(key, value) {
		if (value instanceof RegExp) {
			return {
				$mid: 2,
				source: value.source,
				flags: value.flags
			};
		}
		return value;
	}
	return JSON.stringify(obj, replacer);
}

function revive(obj, depth = 0) {
	if (!obj || depth > 200) {
		return obj;
	}
	if (typeof obj === 'object') {
		switch (obj.$mid) {
			case 1:
				return URI.revive(obj);
			case 2:
				return new RegExp(obj.source, obj.flags);
			case 17:
				return new Date(obj.source);
		}
		if (obj instanceof VSBuffer || obj instanceof Uint8Array) {
			return obj;
		}
		if (isArray(obj)) {
			for (let i = 0; i < obj.length; ++i) {
				obj[i] = revive(obj[i], depth + 1);
			}
		} else {
			for (const key in obj) {
				if (hasOwn(obj, key)) {
					obj[key] = revive(obj[key], depth + 1);
				}
			}
		}
	}
	return obj;
}

function parseAsJson(e) {
	return revive(JSON.parse(e));
}

function renderMarkdown(markdown, options2 = {}, markedOptions = {}) {
	const disposables = new DisposableStore();
	let isDisposed = false;
	const element = createElement(options2);
	const _uriMassage = function (part) {
		let data;
		try {
			data = parseAsJson(decodeURIComponent(part));
		} catch (e) {}
		if (!data) {
			return part;
		}
		data = _cloneAndChange(data, value2 => {
			if (markdown.uris && markdown.uris[value2]) {
				return URI.revive(markdown.uris[value2]);
			} else {
				return;
			}
		});
		return encodeURIComponent(JSON.stringify(data));
	};
	const _href = function (href, isDomUri) {
		const data = markdown.uris && markdown.uris[href];
		let uri = URI.revive(data);
		if (isDomUri) {
			if (href.startsWith(Schemas.data + ':')) {
				return href;
			}
			if (!uri) {
				uri = URI.parse(href);
			}
			return fileAccess.uriToBrowserUri(uri).toString(true);
		}
		if (!uri) {
			return href;
		}
		if (URI.parse(href).toString() === uri.toString()) {
			return href;
		}
		if (uri.query) {
			uri = uri.with({ query: _uriMassage(uri.query) });
		}
		return uri.toString();
	};
	const renderer = new Renderer();
	renderer.image = defaultMarkedRenderers.image;
	renderer.link = defaultMarkedRenderers.link;
	renderer.paragraph = defaultMarkedRenderers.paragraph;
	const codeBlocks = [];
	const syncCodeBlocks = [];
	if (options2.codeBlockRendererSync) {
		renderer.code = (code, lang) => {
			const id = defaultGenerator.nextId();
			const value2 = options2.codeBlockRendererSync(postProcessCodeBlockLanguageId(lang), code);
			syncCodeBlocks.push([id, value2]);
			return `<div class="code" data-code="${id}">${htmlCoreChars1toEntities(code)}</div>`;
		};
	} else if (options2.codeBlockRenderer) {
		renderer.code = (code, lang) => {
			const id = defaultGenerator.nextId();
			const value2 = options2.codeBlockRenderer(postProcessCodeBlockLanguageId(lang), code);
			codeBlocks.push(value2.then(element2 => [id, element2]));
			return `<div class="code" data-code="${id}">${htmlCoreChars1toEntities(code)}</div>`;
		};
	}
	if (options2.actionHandler) {
		const _activateLink = function (event) {
			let target = event.target;
			if (target.tagName !== 'A') {
				target = target.parentElement;
				if (!target || target.tagName !== 'A') {
					return;
				}
			}
			try {
				let href = target.dataset['href'];
				if (href) {
					if (markdown.baseUri) {
						href = resolveWithBaseUri(URI.from(markdown.baseUri), href);
					}
					options2.actionHandler.callback(href, event);
				}
			} catch (err) {
				onUnexpectedError(err);
			} finally {
				event.preventDefault();
			}
		};
		const onClick = options2.actionHandler.disposables.add(new DomEmitter(element, 'click'));
		const onAuxClick = options2.actionHandler.disposables.add(new DomEmitter(element, 'auxclick'));
		options2.actionHandler.disposables.add(
			editorEventAny(
				onClick.event,
				onAuxClick.event
			)(e => {
				const mouseEvent = new StandardMouseEvent(getWindow(element), e);
				if (!mouseEvent.leftButton && !mouseEvent.middleButton) {
					return;
				}
				_activateLink(mouseEvent);
			})
		);
		options2.actionHandler.disposables.add(
			addDisposableListener(element, 'keydown', e => {
				const keyboardEvent = new StandardKeyboardEvent(e);
				if (
					!keyboardEvent.equals(
						10 // Space
					) &&
					!keyboardEvent.equals(
						3 // Enter
					)
				) {
					return;
				}
				_activateLink(keyboardEvent);
			})
		);
	}
	if (!markdown.supportHtml) {
		markedOptions.sanitizer = html2 => {
			const match2 = markdown.isTrusted ? html2.match(/^(<span[^>]+>)|(<\/\s*span>)$/) : undefined;
			return match2 ? html2 : '';
		};
		markedOptions.sanitize = true;
		markedOptions.silent = true;
	}
	markedOptions.renderer = renderer;
	let value = markdown.value ?? '';
	if (value.length > 1e5) {
		value = `${value.substr(0, 1e5)}\u2026`;
	}
	if (markdown.supportThemeIcons) {
		value = markdownEscapeEscapedIcons(value);
	}
	let renderedMarkdown;

	if (markdown.supportThemeIcons) {
		const elements = renderLabelWithIcons(renderedMarkdown);
		renderedMarkdown = elements.map(e => (typeof e === 'string' ? e : e.outerHTML)).join('');
	}
	const htmlParser = new DOMParser();
	const markdownHtmlDoc = htmlParser.parseFromString(sanitizeRenderedMarkdown(markdown, renderedMarkdown), 'text/html');
	markdownHtmlDoc.body.querySelectorAll('img, audio, video, source').forEach(img => {
		const src = img.getAttribute('src');
		if (src) {
			let href = src;
			try {
				if (markdown.baseUri) {
					href = resolveWithBaseUri(URI.from(markdown.baseUri), href);
				}
			} catch (err) {}
			img.setAttribute('src', _href(href, true));
			if (options2.disallowRemoteImages) {
				const uriScheme = URI.parse(href).scheme;
				if (uriScheme !== Schemas.file && uriScheme !== Schemas.data) {
					img.replaceWith(createDomElement('', undefined, img.outerHTML));
				}
			}
		}
	});
	markdownHtmlDoc.body.querySelectorAll('a').forEach(a => {
		const href = a.getAttribute('href');
		a.setAttribute('href', '');
		if (
			!href ||
			/^data:|javascript:/i.test(href) ||
			(/^command:/i.test(href) && !markdown.isTrusted) ||
			/^command:(\/\/\/)?_workbench\.downloadResource/i.test(href)
		) {
			a.replaceWith(...a.childNodes);
		} else {
			let resolvedHref = _href(href, false);
			if (markdown.baseUri) {
				resolvedHref = resolveWithBaseUri(URI.from(markdown.baseUri), href);
			}
			a.dataset.href = resolvedHref;
		}
	});
	element.innerHTML = sanitizeRenderedMarkdown(markdown, markdownHtmlDoc.body.innerHTML);
	if (codeBlocks.length > 0) {
		Promise.all(codeBlocks).then(tuples => {
			if (!isDisposed) {
				const renderedElements = new Map(tuples);
				const placeholderElements = element.querySelectorAll(`div[data-code]`);
				for (const placeholderElement of placeholderElements) {
					const renderedElement = renderedElements.get(placeholderElement.dataset['code'] ?? '');
					if (renderedElement) {
						reset(placeholderElement, renderedElement);
					}
				}
				options2.asyncRenderCallback?.call(options2);
			}
		});
	} else if (syncCodeBlocks.length > 0) {
		const renderedElements = new Map(syncCodeBlocks);
		const placeholderElements = element.querySelectorAll(`div[data-code]`);
		for (const placeholderElement of placeholderElements) {
			const renderedElement = renderedElements.get(placeholderElement.dataset['code'] ?? '');
			if (renderedElement) {
				reset(placeholderElement, renderedElement);
			}
		}
	}
	if (options2.asyncRenderCallback) {
		for (const img of element.getElementsByTagName('img')) {
			const listener = disposables.add(
				addDisposableListener(img, 'load', () => {
					listener.dispose();
					options2.asyncRenderCallback();
				})
			);
		}
	}
	return {
		element,
		dispose: () => {
			isDisposed = true;
			disposables.dispose();
		}
	};
}
function postProcessCodeBlockLanguageId(lang) {
	if (!lang) {
		return '';
	}
	const parts = lang.split(/[\s+|:|,|\{|\?]/, 1);
	if (parts.length) {
		return parts[0];
	}
	return lang;
}
function resolveWithBaseUri(baseUri, href) {
	const hasScheme = /^\w[\w\d+.-]*:/.test(href);
	if (hasScheme) {
		return href;
	}
	if (baseUri.path.endsWith('/')) {
		return resolvePath(baseUri, href).toString();
	} else {
		return resolvePath(dirname2(baseUri), href).toString();
	}
}
function sanitizeRenderedMarkdown(options2, renderedMarkdown) {
	const { config, allowedSchemes } = getSanitizerOptions(options2);
	purify.addHook('uponSanitizeAttribute', (element, e) => {
		if (e.attrName === 'style' || e.attrName === 'class') {
			if (element.tagName === 'SPAN') {
				if (e.attrName === 'style') {
					e.keepAttr =
						/^(color\:(#[0-9a-fA-F]+|var\(--vscode(-[a-zA-Z]+)+\));)?(background-color\:(#[0-9a-fA-F]+|var\(--vscode(-[a-zA-Z]+)+\));)?$/.test(
							e.attrValue
						);
					return;
				} else if (e.attrName === 'class') {
					e.keepAttr = /^codicon codicon-[a-z\-]+( codicon-modifier-[a-z\-]+)?$/.test(e.attrValue);
					return;
				}
			}
			e.keepAttr = false;
			return;
		} else if (element.tagName === 'INPUT' && element.attributes.getNamedItem('type')?.value === 'checkbox') {
			if ((e.attrName === 'type' && e.attrValue === 'checkbox') || e.attrName === 'disabled' || e.attrName === 'checked') {
				e.keepAttr = true;
				return;
			}
			e.keepAttr = false;
		}
	});
	purify.addHook('uponSanitizeElement', (element, e) => {
		if (e.tagName === 'input') {
			if (element.attributes.getNamedItem('type')?.value === 'checkbox') {
				element.setAttribute('disabled', '');
			} else {
				element.parentElement?.removeChild(element);
			}
		}
	});
	const hook = hookDomPurifyHrefAndSrcSanitizer(allowedSchemes);
	try {
		return purify.sanitize(renderedMarkdown, {
			...config,
			RETURN_TRUSTED_TYPE: true
		});
	} finally {
		purify.removeHook('uponSanitizeAttribute');
		hook.dispose();
	}
}
function getSanitizerOptions(options2) {
	const allowedSchemes = [
		Schemas.http,
		Schemas.https,
		Schemas.mailto,
		Schemas.data,
		Schemas.file,
		Schemas.vscodeFileResource,
		Schemas.vscodeRemote,
		Schemas.vscodeRemoteResource
	];
	if (options2.isTrusted) {
		allowedSchemes.push(Schemas.command);
	}
	return {
		config: {
			// allowedTags should included everything that markdown renders to.
			// Since we have our own sanitize function for marked, it's possible we missed some tag so let dompurify make sure.
			// HTML tags that can result from markdown are from reading https://spec.commonmark.org/0.29/
			// HTML table tags that can result from markdown are from https://github.github.com/gfm/#tables-extension-
			ALLOWED_TAGS: [...basicMarkupHtmlTags],
			ALLOWED_ATTR: allowedMarkdownAttr,
			ALLOW_UNKNOWN_PROTOCOLS: true
		},
		allowedSchemes
	};
}
function renderStringAsPlaintext(string2) {
	return typeof string2 === 'string' ? string2 : renderMarkdownAsPlaintext(string2);
}

const plainTextRenderer = new Lazy(() => {
	const renderer = new parse2.Renderer();
	renderer.code = code => {
		return code;
	};
	renderer.blockquote = quote => {
		return quote;
	};
	renderer.html = _html => {
		return '';
	};
	renderer.heading = (text2, _level, _raw) => {
		return text2 + '\n';
	};
	renderer.hr = () => {
		return '';
	};
	renderer.list = (body, _ordered) => {
		return body;
	};
	renderer.listitem = text2 => {
		return text2 + '\n';
	};
	renderer.paragraph = text2 => {
		return text2 + '\n';
	};
	renderer.table = (header, body) => {
		return header + body + '\n';
	};
	renderer.tablerow = content => {
		return content;
	};
	renderer.tablecell = (content, _flags) => {
		return content + ' ';
	};
	renderer.strong = text2 => {
		return text2;
	};
	renderer.em = text2 => {
		return text2;
	};
	renderer.codespan = code => {
		return code;
	};
	renderer.br = () => {
		return '\n';
	};
	renderer.del = text2 => {
		return text2;
	};
	renderer.image = (_href, _title, _text) => {
		return '';
	};
	renderer.text = text2 => {
		return text2;
	};
	renderer.link = (_href, _title, text2) => {
		return text2;
	};
	return renderer;
});
function renderMarkdownAsPlaintext(markdown) {
	let value = markdown.value ?? '';
	if (value.length > 1e5) {
		value = `${value.substr(0, 1e5)}\u2026`;
	}
	//todo
	const html2 = parse2.parse(value, { renderer: plainTextRenderer.value }).replace(/&(#\d+|[a-zA-Z]+);/g, m => {
		return unescapeInfo.get?.(m) ?? m;
	});
	return sanitizeRenderedMarkdown({ isTrusted: false }, html2).toString();
}
function mergeRawTokenText(tokens) {
	let mergedTokenText = '';
	tokens.forEach(token => {
		mergedTokenText += token.raw;
	});
	return mergedTokenText;
}
function completeSingleLinePattern(token) {
	for (let i = 0; i < token.tokens.length; i++) {
		const subtoken = token.tokens[i];
		if (subtoken.type === 'text') {
			const lines = subtoken.raw.split('\n');
			const lastLine = lines[lines.length - 1];
			if (lastLine.includes('`')) {
				return completeCodespan(token);
			} else if (lastLine.includes('**')) {
				return completeDoublestar(token);
			} else if (lastLine.match(/\*\w/)) {
				return completeStar(token);
			} else if (lastLine.match(/(^|\s)__\w/)) {
				return completeDoubleUnderscore(token);
			} else if (lastLine.match(/(^|\s)_\w/)) {
				return completeUnderscore(token);
			} else if (lastLine.match(/(^|\s)\[.*\]\(\w*/)) {
				const nextTwoSubTokens = token.tokens.slice(i + 1);
				if (
					nextTwoSubTokens[0]?.type === 'link' &&
					nextTwoSubTokens[1]?.type === 'text' &&
					nextTwoSubTokens[1].raw.match(/^ *"[^"]*$/)
				) {
					return completeLinkTargetArg(token);
				}
				return completeLinkTarget(token);
			} else if (hasStartOfLinkTarget(lastLine)) {
				return completeLinkTarget(token);
			} else if (lastLine.match(/(^|\s)\[\w/) && !token.tokens.slice(i + 1).some(t => hasStartOfLinkTarget(t.raw))) {
				return completeLinkText(token);
			}
		}
	}
	return;
}
function hasStartOfLinkTarget(str) {
	return !!str.match(/^[^\[]*\]\([^\)]*$/);
}

function completeTable(tokens) {
	const mergedRawText = mergeRawTokenText(tokens);
	const lines = mergedRawText.split('\n');
	let numCols;
	let hasSeparatorRow = false;
	for (let i = 0; i < lines.length; i++) {
		const line = lines[i].trim();
		if (typeof numCols === 'undefined' && line.match(/^\s*\|/)) {
			const line1Matches = line.match(/(\|[^\|]+)(?=\||$)/g);
			if (line1Matches) {
				numCols = line1Matches.length;
			}
		} else if (typeof numCols === 'number') {
			if (line.match(/^\s*\|/)) {
				if (i !== lines.length - 1) {
					return;
				}
				hasSeparatorRow = true;
			} else {
				return;
			}
		}
	}
	if (typeof numCols === 'number' && numCols > 0) {
		const prefixText = hasSeparatorRow ? lines.slice(0, -1).join('\n') : mergedRawText;
		const line1EndsInPipe = !!prefixText.match(/\|\s*$/);
		const newRawText =
			prefixText +
			(line1EndsInPipe ? '' : '|') +
			`
|${' --- |'.repeat(numCols)}`;
		return parse2.lexer(newRawText);
	}
	return;
}

function completeCodeBlock(tokens, leader) {
	const mergedRawText = mergeRawTokenText(tokens);
	return parse2.lexer(
		mergedRawText +
			`
${leader}`
	);
}
function completeCodespan(token) {
	return completeWithString(token, '`');
}
function completeStar(tokens) {
	return completeWithString(tokens, '*');
}
function completeUnderscore(tokens) {
	return completeWithString(tokens, '_');
}
function completeLinkTarget(tokens) {
	return completeWithString(tokens, ')');
}
function completeLinkTargetArg(tokens) {
	return completeWithString(tokens, '")');
}
function completeLinkText(tokens) {
	return completeWithString(tokens, '](about:blank)');
}
function completeDoublestar(tokens) {
	return completeWithString(tokens, '**');
}
function completeDoubleUnderscore(tokens) {
	return completeWithString(tokens, '__');
}
function completeWithString(tokens, closingString) {
	const mergedRawText = mergeRawTokenText(isArray(tokens) ? tokens : [tokens]);
	return parse2.lexer(mergedRawText + closingString)[0];
}

const defaultMarkedRenderers = freeze({
	image: (href, title, text2) => {
		let dimensions = [];
		let attributes = [];
		if (href) {
			({ href, dimensions } = parseHrefAndDimensions(href));
			attributes.push(`src="${escapeDoubleQuotes(href)}"`);
		}
		if (text2) {
			attributes.push(`alt="${escapeDoubleQuotes(text2)}"`);
		}
		if (title) {
			attributes.push(`title="${escapeDoubleQuotes(title)}"`);
		}
		if (dimensions.length) {
			attributes = attributes.concat(dimensions);
		}
		return '<img ' + attributes.join(' ') + '>';
	},
	paragraph: text2 => {
		return `<p>${text2}</p>`;
	},
	link: (href, title, text2) => {
		if (typeof href !== 'string') {
			return '';
		}
		if (href === text2) {
			text2 = removeMarkdownEscapes(text2);
		}
		title = typeof title === 'string' ? escapeDoubleQuotes(removeMarkdownEscapes(title)) : '';
		href = removeMarkdownEscapes(href);
		href = href.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
		return `<a href="${href}" title="${title || href}" draggable="false">${text2}</a>`;
	}
});
const allowedMarkdownAttr = [
	'align',
	'autoplay',
	'alt',
	'checked',
	'class',
	'controls',
	'data-code',
	'data-href',
	'disabled',
	'draggable',
	'height',
	'href',
	'loop',
	'muted',
	'playsinline',
	'poster',
	'src',
	'style',
	'target',
	'title',
	'type',
	'width',
	'start'
];
const unescapeInfo = new Map([
	['&quot;', '"'],
	['&nbsp;', ' '],
	['&amp;', '&'],
	['&#39;', "'"],
	['&lt;', '<'],
	['&gt;', '>']
]);

async function openLink(openerService, link, isTrusted) {
	try {
		return await openerService.open(link, {
			fromUserGesture: true,
			allowContributedOpeners: true,
			allowCommands: isTrusted === true ? true : isTrusted && isArray(isTrusted.enabledCommands) ? isTrusted.enabledCommands : false
		});
	} catch (e) {
		onUnexpectedError(e);
		return false;
	}
}

class MarkdownRenderer {
	constructor(_options, _languageService, _openerService) {
		this._options = _options;
		this._languageService = _languageService;
		this._openerService = _openerService;
		this._onDidRenderAsync = new Emitter();
		this.onDidRenderAsync = this._onDidRenderAsync.event;
	}
	dispose() {
		this._onDidRenderAsync.dispose();
	}
	render(markdown, options2, markedOptions) {
		if (!markdown) {
			const element = document.createElement('span');
			return { element, dispose: dummyArrowFn };
		}
		const disposables = new DisposableStore();
		const rendered = disposables.add(
			renderMarkdown(
				markdown,
				{
					...this._getRenderOptions(markdown, disposables),
					...options2
				},
				markedOptions
			)
		);
		rendered.element.classList.add('rendered-markdown');
		return {
			element: rendered.element,
			dispose: () => disposables.dispose()
		};
	}
	_getRenderOptions(markdown, disposables) {
		return {
			codeBlockRenderer: async (languageAlias, value) => {
				let languageId;
				if (languageAlias) {
					languageId = this._languageService.getLanguageIdByLanguageName(languageAlias);
				} else if (this._options.editor) {
					languageId = this._options.editor.getModel()?.getLanguageId();
				}
				if (!languageId) {
					languageId = PLAINTEXT_LANGUAGE_ID;
				}
				const element = document.createElement('span');
				element.innerHTML = await tokenizeToString(this._languageService, value, languageId);
				if (this._options.editor) {
					const fontInfo = this._options.editor.getOption(
						50 // fontInfo
					);
					applyFontInfo(element, fontInfo);
				} else if (this._options.codeBlockFontFamily) {
					element.style.fontFamily = this._options.codeBlockFontFamily;
				}
				if (this._options.codeBlockFontSize !== undefined) {
					element.style.fontSize = this._options.codeBlockFontSize;
				}
				return element;
			},
			asyncRenderCallback: () => this._onDidRenderAsync.fire(),
			actionHandler: {
				callback: link => openLink(this._openerService, link, markdown.isTrusted),
				disposables
			}
		};
	}
}
__decorate(
	[
		__param(1, ILanguageService),
		__param(2, IOpenerService)
		//...
	],
	MarkdownRenderer
);
