class StandaloneColorPickerResult {
	// The color picker result consists of: an array of color results and a boolean indicating if the color was found in the editor
	constructor(value, foundInEditor) {
		this.value = value;
		this.foundInEditor = foundInEditor;
	}
}


class StandaloneColorPickerWidget extends Disposable {
	constructor(
		_editor,
		_standaloneColorPickerVisible,
		_standaloneColorPickerFocused,
		_instantiationService,
		_modelService,
		_keybindingService,
		_languageFeaturesService,
		_languageConfigurationService
	) {
		super();
		this._editor = _editor;
		this._standaloneColorPickerVisible = _standaloneColorPickerVisible;
		this._standaloneColorPickerFocused = _standaloneColorPickerFocused;
		this._modelService = _modelService;
		this._keybindingService = _keybindingService;
		this._languageFeaturesService = _languageFeaturesService;
		this._languageConfigurationService = _languageConfigurationService;
		this.allowEditorOverflow = true;
		this._position = undefined;
		this._body = document.createElement('div');
		this._colorHover = null;
		this._selectionSetInEditor = false;
		this._onResult = this._register(new Emitter());
		this.onResult = this._onResult.event;
		this._standaloneColorPickerVisible.set(true);
		this._standaloneColorPickerParticipant = _instantiationService.createInstance(StandaloneColorPickerParticipant, this._editor);
		this._position = this._editor._getViewModel()?.getPrimaryCursorState().modelState.position;
		const editorSelection = this._editor.getSelection();
		const selection = editorSelection
			? {
					startLineNumber: editorSelection.startLineNumber,
					startColumn: editorSelection.startColumn,
					endLineNumber: editorSelection.endLineNumber,
					endColumn: editorSelection.endColumn
				}
			: {
					startLineNumber: 0,
					endLineNumber: 0,
					endColumn: 0,
					startColumn: 0
				};
		const focusTracker = this._register(trackFocus(this._body));
		this._register(
			focusTracker.onDidBlur(_ => {
				this.hide();
			})
		);
		this._register(
			focusTracker.onDidFocus(_ => {
				this.focus();
			})
		);
		this._register(
			this._editor.onDidChangeCursorPosition(() => {
				if (!this._selectionSetInEditor) {
					this.hide();
				} else {
					this._selectionSetInEditor = false;
				}
			})
		);
		this._register(
			this._editor.onMouseMove(e => {
				if (e.target.element?.classList?.contains('colorpicker-color-decoration')) {
					this.hide();
				}
			})
		);
		this._register(
			this.onResult(result => {
				this._render(result.value, result.foundInEditor);
			})
		);
		this._start(selection);
		this._body.style.zIndex = '50';
		this._editor.addContentWidget(this);
	}
	updateEditor() {
		if (this._colorHover) {
			this._standaloneColorPickerParticipant.updateEditorModel(this._colorHover);
		}
	}
	getId() {
		return 'editor.contrib.standaloneColorPickerWidget';
	}
	getDomNode() {
		return this._body;
	}
	getPosition() {
		if (!this._position) {
			return null;
		}
		const positionPreference = this._editor.getOption(
			60 // hover
		).above;
		return {
			position: this._position,
			secondaryPosition: this._position,
			preference: positionPreference
				? [
						1,
						2 // BELOW
					]
				: [
						2,
						1 // ABOVE
					],
			positionAffinity: 2 // None
		};
	}
	hide() {
		this.dispose();
		this._standaloneColorPickerVisible.set(false);
		this._standaloneColorPickerFocused.set(false);
		this._editor.removeContentWidget(this);
		this._editor.focus();
	}
	focus() {
		this._standaloneColorPickerFocused.set(true);
		this._body.focus();
	}
	async _start(selection) {
		const computeAsyncResult = await this._computeAsync(selection);
		if (!computeAsyncResult) {
			return;
		}
		this._onResult.fire(new StandaloneColorPickerResult(computeAsyncResult.result, computeAsyncResult.foundInEditor));
	}
	async _computeAsync(range2) {
		if (!this._editor.hasModel()) {
			return null;
		}
		const colorInfo = {
			range: range2,
			color: { red: 0, green: 0, blue: 0, alpha: 1 }
		};
		const colorHoverResult = await this._standaloneColorPickerParticipant.createColorHover(
			colorInfo,
			new DefaultDocumentColorProvider(this._modelService, this._languageConfigurationService),
			this._languageFeaturesService.colorProvider
		);
		if (!colorHoverResult) {
			return null;
		}
		return {
			result: colorHoverResult.colorHover,
			foundInEditor: colorHoverResult.foundInEditor
		};
	}
	_render(colorHover, foundInEditor) {
		const fragment = document.createDocumentFragment();
		const statusBar = this._register(new EditorHoverStatusBar(this._keybindingService));
		let colorPickerWidget;
		const context = {
			fragment,
			statusBar,
			setColorPicker: widget => (colorPickerWidget = widget),
			onContentsChanged: dummyArrowFn,
			hide: () => this.hide()
		};
		this._colorHover = colorHover;
		this._register(this._standaloneColorPickerParticipant.renderHoverParts(context, [colorHover]));
		if (colorPickerWidget === undefined) {
			return;
		}
		this._body.classList.add('standalone-colorpicker-body');
		this._body.style.maxHeight = Math.max(this._editor.getLayoutInfo().height / 4, 250) + 'px';
		this._body.style.maxWidth = Math.max(this._editor.getLayoutInfo().width * 0.66, 500) + 'px';
		this._body.tabIndex = 0;
		this._body.appendChild(fragment);
		colorPickerWidget.layout();
		const colorPickerBody = colorPickerWidget.body;
		const saturationBoxWidth = colorPickerBody.saturationBox.domNode.clientWidth;
		const widthOfOriginalColorBox = colorPickerBody.domNode.clientWidth - saturationBoxWidth - 22 - 8;
		const enterButton = colorPickerWidget.body.enterButton;
		enterButton === null || enterButton === undefined
			? undefined
			: enterButton.onClicked(() => {
					this.updateEditor();
					this.hide();
				});
		const colorPickerHeader = colorPickerWidget.header;
		const pickedColorNode = colorPickerHeader.pickedColorNode;
		pickedColorNode.style.width = saturationBoxWidth + 8 + 'px';
		const originalColorNode = colorPickerHeader.originalColorNode;
		originalColorNode.style.width = widthOfOriginalColorBox + 'px';
		const closeButton = colorPickerWidget.header.closeButton;
		closeButton === null || closeButton === undefined
			? undefined
			: closeButton.onClicked(() => {
					this.hide();
				});
		if (foundInEditor) {
			if (enterButton) {
				enterButton.button.textContent = 'Replace';
			}
			this._selectionSetInEditor = true;
			this._editor.setSelection(colorHover.range);
		}
		this._editor.layoutContentWidget(this);
	}
}
__decorate(
	[
		__param(3, IInstantiationService),
		__param(4, IModelService),
		__param(5, IKeybindingService),
		__param(6, ILanguageFeaturesService),
		__param(7, ILanguageConfigurationService)
	],
	StandaloneColorPickerWidget
);



const standaloneColorPickerController_id = 'editor.contrib.standaloneColorPickerController';
class StandaloneColorPickerController extends Disposable {
	constructor(
		_editor,
		_contextKeyService,
		_modelService,
		_keybindingService,
		_instantiationService,
		_languageFeatureService,
		_languageConfigurationService
	) {
		super();
		this._editor = _editor;
		this._modelService = _modelService;
		this._keybindingService = _keybindingService;
		this._instantiationService = _instantiationService;
		this._languageFeatureService = _languageFeatureService;
		this._languageConfigurationService = _languageConfigurationService;
		this._standaloneColorPickerWidget = null;
		this._standaloneColorPickerVisible = ck_standaloneColorPicker_visible.bindTo(_contextKeyService);
		this._standaloneColorPickerFocused = ck_standaloneColorPicker_focused.bindTo(_contextKeyService);
	}
	showOrFocus() {
		if (this._editor.hasModel()) {
			if (!this._standaloneColorPickerVisible.get()) {
				this._standaloneColorPickerWidget = new StandaloneColorPickerWidget(
					this._editor,
					this._standaloneColorPickerVisible,
					this._standaloneColorPickerFocused,
					this._instantiationService,
					this._modelService,
					this._keybindingService,
					this._languageFeatureService,
					this._languageConfigurationService
				);
			} else if (!this._standaloneColorPickerFocused.get()) {
				this._standaloneColorPickerWidget?.focus();
			}
		}
	}
	hide() {
		this._standaloneColorPickerFocused.set(false);
		this._standaloneColorPickerVisible.set(false);
		this._standaloneColorPickerWidget?.hide();
		this._editor.focus();
	}
	insertColor() {
		this._standaloneColorPickerWidget?.updateEditor();
		this.hide();
	}
	static get(editor2) {
		return editor2.getContribution(standaloneColorPickerController_id);
	}
}
__decorate(
	[
		__param(1, IContextKeyService),
		__param(2, IModelService),
		__param(3, IKeybindingService),
		__param(4, IInstantiationService),
		__param(5, ILanguageFeaturesService),
		__param(6, ILanguageConfigurationService)
	],
	StandaloneColorPickerController
);
registerEditorContribution(
	standaloneColorPickerController_id,
	StandaloneColorPickerController,
	1 // AfterFirstRender
);




class ShowOrFocusStandaloneColorPicker extends EditorAction2 {
	constructor() {
		super({
			id: 'editor.action.showOrFocusStandaloneColorPicker',
			title: localize('Show or Focus Standalone Color Picker'),
			menu: [],
			metadata: {
				description: localize(
					'Show or focus a standalone color picker which uses the default color provider. It displays hex/rgb/hsl colors.'
				)
			}
		});
	}
	runEditorCommand(_accessor, editor2) {
		StandaloneColorPickerController.get(editor2)?.showOrFocus();
	}
}
registerEditorAction2(ShowOrFocusStandaloneColorPicker);

class HideStandaloneColorPicker extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.hideColorPicker',
			label: localize('Hide the Color Picker'),
			alias: 'Hide the Color Picker',
			precondition: ck_standaloneColorPicker_visible.isEqualTo(true),
			kbOpts: {
				primary: 9,
				weight: 100 //editorContrib
			},
			metadata: {}
		});
	}
	run(_accessor, editor2) {
		StandaloneColorPickerController.get(editor2)?.hide();
	}
}
registerEditorAction(HideStandaloneColorPicker);

class InsertColorWithStandaloneColorPicker extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.insertColorWithStandaloneColorPicker',
			label: localize('Insert Color with Standalone Color Picker'),
			alias: 'Insert Color with Standalone Color Picker',
			precondition: ck_standaloneColorPicker_focused.isEqualTo(true),
			kbOpts: {
				primary: 3,
				weight: 100 //editorContrib
			},
			metadata: {}
		});
	}
	run(_accessor, editor) {
		StandaloneColorPickerController.get(editor)?.insertColor();
	}
}
registerEditorAction(InsertColorWithStandaloneColorPicker);
