const connectionTokenQueryName = 'tkn';


class RemoteAuthorities {
	constructor() {
		this._hosts = Object.create(null);
		this._ports = Object.create(null);
		this._connectionTokens = Object.create(null);
		this._preferredWebSchema = 'http';
		this._delegate = null;
		this._serverRootPath = '/';
	}
	setPreferredWebSchema(schema) {
		this._preferredWebSchema = schema;
	}
	get _remoteResourcesPath() {
		return posix.join(this._serverRootPath, Schemas.vscodeRemoteResource);
	}
	rewrite(uri) {
		if (this._delegate) {
			try {
				return this._delegate(uri);
			} catch (err) {
				onUnexpectedError(err);
				return uri;
			}
		}
		const authority = uri.authority;
		let host = this._hosts[authority];
		if (host && host.indexOf(':') !== -1 && host.indexOf('[') === -1) {
			host = `[${host}]`;
		}
		const port = this._ports[authority];
		const connectionToken = this._connectionTokens[authority];
		let query = `path=${encodeURIComponent(uri.path)}`;
		if (typeof connectionToken === 'string') {
			query += `&${connectionTokenQueryName}=${encodeURIComponent(connectionToken)}`;
		}
		return URI.from({
			scheme: this._preferredWebSchema,
			authority: `${host}:${port}`,
			path: this._remoteResourcesPath,
			query
		});
	}
}
const remoteAuthorities = new RemoteAuthorities();
remoteAuthorities.setPreferredWebSchema(/^https:/.test(mainWindow.location.href) ? 'https' : 'http');

class FileAccess {
	uriToBrowserUri(uri) {
		if (uri.scheme === Schemas.vscodeRemote) {
			return remoteAuthorities.rewrite(uri);
		}
		if (
			// ...only ever for `file` resources
			uri.scheme === Schemas.file && // ...and we run in native environments
			webWorkerOrigin === `${Schemas.vscodeFileResource}://${FileAccess.FALLBACK_AUTHORITY}`
		) {
			return uri.with({
				scheme: Schemas.vscodeFileResource,
				// We need to provide an authority here so that it can serve
				// as origin for network and loading matters in chromium.
				// If the URI is not coming with an authority already, we
				// add our own
				authority: uri.authority || FileAccess.FALLBACK_AUTHORITY,
				query: null,
				fragment: null
			});
		}
		return uri;
	}
}
FileAccess.FALLBACK_AUTHORITY = 'vscode-app';
const fileAccess = new FileAccess();


