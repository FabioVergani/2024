class MarkerHover {
	constructor(owner, range2, marker) {
		this.owner = owner;
		this.range = range2;
		this.marker = marker;
	}
	isValidForHoverAnchor(anchor) {
		return anchor.type === 1 && this.range.startColumn <= anchor.range.startColumn && this.range.endColumn >= anchor.range.endColumn;
	}
}

const markerCodeActionTrigger = {
	type: 1,
	filter: { include: codeActionKind4.QuickFix },
	triggerAction: CodeActionTriggerSource.QuickFixHover
};

class MarkerHoverParticipant {
	constructor(_editor, _markerDecorationsService, _openerService, _languageFeaturesService) {
		this._editor = _editor;
		this._markerDecorationsService = _markerDecorationsService;
		this._openerService = _openerService;
		this._languageFeaturesService = _languageFeaturesService;
		this.hoverOrdinal = 1;
		this.recentMarkerCodeActionsInfo = undefined;
	}
	computeSync(anchor, lineDecorations) {
		if (!this._editor.hasModel() || (anchor.type !== 1 && !anchor.supportsMarkerHover)) {
			return [];
		}
		const model = this._editor.getModel();
		const lineNumber = anchor.range.startLineNumber;
		const maxColumn = model.getLineMaxColumn(lineNumber);
		const result = [];
		for (const d of lineDecorations) {
			const startColumn = d.range.startLineNumber === lineNumber ? d.range.startColumn : 1;
			const endColumn = d.range.endLineNumber === lineNumber ? d.range.endColumn : maxColumn;
			const marker = this._markerDecorationsService.getMarker(model.uri, d);
			if (!marker) {
				continue;
			}
			const range2 = new Range(anchor.range.startLineNumber, startColumn, anchor.range.startLineNumber, endColumn);
			result.push(new MarkerHover(this, range2, marker));
		}
		return result;
	}
	renderHoverParts(context, hoverParts) {
		if (!hoverParts.length) {
			return disposableNone;
		}
		const disposables = new DisposableStore();
		hoverParts.forEach(msg => context.fragment.appendChild(this.renderMarkerHover(msg, disposables)));
		const markerHoverForStatusbar =
			hoverParts.length === 1
				? hoverParts[0]
				: hoverParts.sort((a, b) => markerSeverityCompare(a.marker.severity, b.marker.severity))[0];
		this.renderMarkerStatusbar(context, markerHoverForStatusbar, disposables);
		return disposables;
	}
	renderMarkerHover(markerHover, disposables) {
		const hoverElement = $('div.hover-row');
		hoverElement.tabIndex = 0;
		const markerElement = append(hoverElement, $('div.marker.hover-contents'));
		const { source, message, code, relatedInformation } = markerHover.marker;
		this._editor.applyFontInfo(markerElement);
		const messageElement = append(markerElement, $('span'));
		messageElement.style.whiteSpace = 'pre-wrap';
		messageElement.innerText = message;
		if (source || code) {
			if (code && typeof code !== 'string') {
				const sourceAndCodeElement = $('span');
				if (source) {
					const sourceElement = append(sourceAndCodeElement, $('span'));
					sourceElement.innerText = source;
				}
				const codeLink = append(sourceAndCodeElement, $('a.code-link'));
				codeLink.setAttribute('href', code.target.toString());
				disposables.add(
					addDisposableListener(codeLink, 'click', e => {
						this._openerService.open(code.target, {
							allowCommands: true
						});
						e.preventDefault();
						e.stopPropagation();
					})
				);
				const codeElement = append(codeLink, $('span'));
				codeElement.innerText = code.value;
				const detailsElement = append(markerElement, sourceAndCodeElement);
				detailsElement.style.opacity = '0.6';
				detailsElement.style.paddingLeft = '6px';
			} else {
				const detailsElement = append(markerElement, $('span'));
				detailsElement.style.opacity = '0.6';
				detailsElement.style.paddingLeft = '6px';
				detailsElement.innerText = source && code ? `${source}(${code})` : source ? source : `(${code})`;
			}
		}
		if (isArrayAndHasLength(relatedInformation)) {
			for (const { message: message2, resource, startLineNumber, startColumn } of relatedInformation) {
				const relatedInfoContainer = append(markerElement, $('div'));
				relatedInfoContainer.style.marginTop = '8px';
				const a = append(relatedInfoContainer, $('a'));
				a.innerText = `${basename2(resource)}(${startLineNumber}, ${startColumn}): `;
				a.style.cursor = 'pointer';
				disposables.add(
					addDisposableListener(a, 'click', e => {
						e.stopPropagation();
						e.preventDefault();
						if (this._openerService) {
							this._openerService
								.open(resource, {
									fromUserGesture: true,
									editorOptions: {
										selection: {
											startLineNumber,
											startColumn
										}
									}
								})
								.catch(onUnexpectedError);
						}
					})
				);
				const messageElement2 = append(relatedInfoContainer, $('span'));
				messageElement2.innerText = message2;
				this._editor.applyFontInfo(messageElement2);
			}
		}
		return hoverElement;
	}
	renderMarkerStatusbar(context, markerHover, disposables) {
		if (markerHover.marker.severity === 8 || markerHover.marker.severity === 4 || markerHover.marker.severity === 2) {
			const markerController = MarkerController.get(this._editor);
			if (markerController) {
				context.statusBar.addAction({
					label: localize('View Problem'),
					commandId: nextMarkerAction_id,
					run: () => {
						context.hide();
						markerController.showAtMarker(markerHover.marker);
						this._editor.focus();
					}
				});
			}
		}
		if (
			!this._editor.getOption(
				91 // readOnly
			)
		) {
			const quickfixPlaceholderElement = context.statusBar.append($('div'));
			if (this.recentMarkerCodeActionsInfo) {
				function _makeMarkerDataKey(markerData) {
					const result = [''];
					if (markerData.source) {
						result.push(markerData.source.replace('\xA6', '\\\xA6'));
					} else {
						result.push('');
					}
					if (markerData.code) {
						if (typeof markerData.code === 'string') {
							result.push(markerData.code.replace('\xA6', '\\\xA6'));
						} else {
							result.push(markerData.code.value.replace('\xA6', '\\\xA6'));
						}
					} else {
						result.push('');
					}
					if (markerData.severity !== undefined && markerData.severity !== null) {
						const _markerSeverityDisplayStrings = Object.create(null);
						_markerSeverityDisplayStrings[8] = localize('Error');
						_markerSeverityDisplayStrings[4] = localize('Warning');
						_markerSeverityDisplayStrings[2] = localize('Info');
						result.push(_markerSeverityDisplayStrings[markerData.severity] || '');
					} else {
						result.push('');
					}
					if (markerData.message) {
						result.push(markerData.message.replace('\xA6', '\\\xA6'));
					} else {
						result.push('');
					}
					if (markerData.startLineNumber !== undefined && markerData.startLineNumber !== null) {
						result.push(markerData.startLineNumber.toString());
					} else {
						result.push('');
					}
					if (markerData.startColumn !== undefined && markerData.startColumn !== null) {
						result.push(markerData.startColumn.toString());
					} else {
						result.push('');
					}
					if (markerData.endLineNumber !== undefined && markerData.endLineNumber !== null) {
						result.push(markerData.endLineNumber.toString());
					} else {
						result.push('');
					}
					if (markerData.endColumn !== undefined && markerData.endColumn !== null) {
						result.push(markerData.endColumn.toString());
					} else {
						result.push('');
					}
					result.push('');
					return result.join('\xA6');
				}
				if (_makeMarkerDataKey(this.recentMarkerCodeActionsInfo.marker) === _makeMarkerDataKey(markerHover.marker)) {
					if (!this.recentMarkerCodeActionsInfo.hasCodeActions) {
						quickfixPlaceholderElement.textContent = localize('No quick fixes available');
					}
				} else {
					this.recentMarkerCodeActionsInfo = undefined;
				}
			}
			const updatePlaceholderDisposable =
				this.recentMarkerCodeActionsInfo && !this.recentMarkerCodeActionsInfo.hasCodeActions
					? disposableNone
					: disposableTimeout(
							() => (quickfixPlaceholderElement.textContent = localize('Checking for quick fixes...')),
							200,
							disposables
						);
			if (!quickfixPlaceholderElement.textContent) {
				quickfixPlaceholderElement.textContent = String.fromCharCode(160);
			}
			const codeActionsPromise = this.getCodeActions(markerHover.marker);
			disposables.add(toDisposable(() => codeActionsPromise.cancel()));
			codeActionsPromise.then(actions => {
				updatePlaceholderDisposable.dispose();
				this.recentMarkerCodeActionsInfo = {
					marker: markerHover.marker,
					hasCodeActions: actions.validActions.length > 0
				};
				if (!this.recentMarkerCodeActionsInfo.hasCodeActions) {
					actions.dispose();
					quickfixPlaceholderElement.textContent = localize('No quick fixes available');
					return;
				}
				quickfixPlaceholderElement.style.display = 'none';
				let showing = false;
				disposables.add(
					toDisposable(() => {
						if (!showing) {
							actions.dispose();
						}
					})
				);
				context.statusBar.addAction({
					label: localize('Quick Fix...'),
					commandId: quickFixCommandId,
					run: target => {
						showing = true;
						const controller = CodeActionController.get(this._editor);
						const elementPosition = getDomNodePagePosition(target);
						context.hide();
						controller === null || controller === undefined
							? undefined
							: controller.showCodeActions(markerCodeActionTrigger, actions, {
									x: elementPosition.left,
									y: elementPosition.top,
									width: elementPosition.width,
									height: elementPosition.height
								});
					}
				});
			}, onUnexpectedError);
		}
	}
	getCodeActions(marker) {
		return createCancelablePromise(cancellationToken => {
			return getCodeActions(
				this._languageFeaturesService.codeActionProvider,
				this._editor.getModel(),
				new Range(marker.startLineNumber, marker.startColumn, marker.endLineNumber, marker.endColumn),
				markerCodeActionTrigger,
				Progress.None,
				cancellationToken
			);
		});
	}
}
__decorate(
	[
		__param(1, IMarkerDecorationsService),
		__param(2, IOpenerService),
		__param(3, ILanguageFeaturesService) //
	],
	MarkerHoverParticipant
);
hoverParticipantRegistry.register(MarkerHoverParticipant);