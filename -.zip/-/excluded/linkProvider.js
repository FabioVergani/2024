		this.linkProvider = new LanguageFeatureRegistry(this._score.bind(this));


		this._register(
			languageFeaturesService.linkProvider.register(
				{ language: '*', hasAccessToAllModels: true },
				{
					provideLinks: (model, token) => {
						if (!canSyncModel(this._modelService, model.uri)) {
							return Promise.resolve({ links: [] });
						}
						return this._workerManager
							.withWorker()
							.then(client => client.computeLinks(model.uri))
							.then(links => {
								return links && { links };
							});
					}
				}
			)
		);


	if (modeConfiguration.links) {
		const registerLinkProvider = (languageSelector, provider) => {
			return getService_LanguageFeatures().linkProvider.register(languageSelector, provider);
		};
		class DocumentLinkAdapter {
			constructor(_worker) {
				this._worker = _worker;
			}
			provideLinks(model, token) {
				const resource = model.uri;
				return this._worker(resource)
					.then(worker2 => worker2.findDocumentLinks(resource.toString()))
					.then(items => {
						if (!items) {
							return;
						}
						return {
							links: items.map(item => ({
								range: toRange0(item.range),
								url: item.target
							}))
						};
					});
			}
		}
		providers.push(registerLinkProvider(languageId, new DocumentLinkAdapter(wk)));
	}