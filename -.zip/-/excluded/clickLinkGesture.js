function hasModifier(e, modifier) {
	return !!e[modifier];
}
class ClickLinkMouseEvent {
	constructor(source, opts) {
		this.target = source.target;
		this.isLeftClick = source.event.leftButton;
		this.isMiddleClick = source.event.middleButton;
		this.isRightClick = source.event.rightButton;
		this.hasTriggerModifier = hasModifier(source.event, opts.triggerModifier);
		this.hasSideBySideModifier = hasModifier(source.event, opts.triggerSideBySideModifier);
		this.isNoneOrSingleMouseDown = source.event.detail <= 1;
	}
}
class ClickLinkKeyboardEvent {
	constructor(source, opts) {
		this.keyCodeIsTriggerKey = source.keyCode === opts.triggerKey;
		this.keyCodeIsSideBySideKey = source.keyCode === opts.triggerSideBySideKey;
		this.hasTriggerModifier = hasModifier(source, opts.triggerModifier);
	}
}
class ClickLinkOptions {
	constructor(triggerKey, triggerModifier, triggerSideBySideKey, triggerSideBySideModifier) {
		this.triggerKey = triggerKey;
		this.triggerModifier = triggerModifier;
		this.triggerSideBySideKey = triggerSideBySideKey;
		this.triggerSideBySideModifier = triggerSideBySideModifier;
	}
	equals(other) {
		return (
			this.triggerKey === other.triggerKey &&
			this.triggerModifier === other.triggerModifier &&
			this.triggerSideBySideKey === other.triggerSideBySideKey &&
			this.triggerSideBySideModifier === other.triggerSideBySideModifier
		);
	}
}
function createOptions(multiCursorModifier) {
	if (multiCursorModifier === 'altKey') {
		if (isMacintosh) {
			return new ClickLinkOptions(57, 'metaKey', 6, 'altKey');
		}
		return new ClickLinkOptions(5, 'ctrlKey', 6, 'altKey');
	}
	if (isMacintosh) {
		return new ClickLinkOptions(6, 'altKey', 57, 'metaKey');
	}
	return new ClickLinkOptions(6, 'altKey', 5, 'ctrlKey');
}
class ClickLinkGesture extends Disposable {
	constructor(editor2, opts) {
		super();
		this._onMouseMoveOrRelevantKeyDown = this._register(new Emitter());
		this.onMouseMoveOrRelevantKeyDown = this._onMouseMoveOrRelevantKeyDown.event;
		this._onExecute = this._register(new Emitter());
		this.onExecute = this._onExecute.event;
		this._onCancel = this._register(new Emitter());
		this.onCancel = this._onCancel.event;
		this._editor = editor2;
		this._extractLineNumberFromMouseEvent =
			opts?.extractLineNumberFromMouseEvent ?? (e => (e.target.position ? e.target.position.lineNumber : 0));
		this._opts = createOptions(
			this._editor.getOption(
				78 // multiCursorModifier
			)
		);
		this._lastMouseMoveEvent = null;
		this._hasTriggerKeyOnMouseDown = false;
		this._lineNumberOnMouseDown = 0;
		this._register(
			this._editor.onDidChangeConfiguration(e => {
				if (
					e.hasChanged(
						78 // multiCursorModifier
					)
				) {
					const newOpts = createOptions(
						this._editor.getOption(
							78 // multiCursorModifier
						)
					);
					if (this._opts.equals(newOpts)) {
						return;
					}
					this._opts = newOpts;
					this._lastMouseMoveEvent = null;
					this._hasTriggerKeyOnMouseDown = false;
					this._lineNumberOnMouseDown = 0;
					this._onCancel.fire();
				}
			})
		);
		this._register(this._editor.onMouseMove(e => this._onEditorMouseMove(new ClickLinkMouseEvent(e, this._opts))));
		this._register(this._editor.onMouseDown(e => this._onEditorMouseDown(new ClickLinkMouseEvent(e, this._opts))));
		this._register(this._editor.onMouseUp(e => this._onEditorMouseUp(new ClickLinkMouseEvent(e, this._opts))));
		this._register(this._editor.onKeyDown(e => this._onEditorKeyDown(new ClickLinkKeyboardEvent(e, this._opts))));
		this._register(this._editor.onKeyUp(e => this._onEditorKeyUp(new ClickLinkKeyboardEvent(e, this._opts))));
		this._register(this._editor.onMouseDrag(() => this._resetHandler()));
		this._register(this._editor.onDidChangeCursorSelection(e => this._onDidChangeCursorSelection(e)));
		this._register(this._editor.onDidChangeModel(e => this._resetHandler()));
		this._register(this._editor.onDidChangeModelContent(() => this._resetHandler()));
		this._register(
			this._editor.onDidScrollChange(e => {
				if (e.scrollTopChanged || e.scrollLeftChanged) {
					this._resetHandler();
				}
			})
		);
	}
	_onDidChangeCursorSelection(e) {
		if (e.selection && e.selection.startColumn !== e.selection.endColumn) {
			this._resetHandler();
		}
	}
	_onEditorMouseMove(mouseEvent) {
		this._lastMouseMoveEvent = mouseEvent;
		this._onMouseMoveOrRelevantKeyDown.fire([mouseEvent, null]);
	}
	_onEditorMouseDown(mouseEvent) {
		this._hasTriggerKeyOnMouseDown = mouseEvent.hasTriggerModifier;
		this._lineNumberOnMouseDown = this._extractLineNumberFromMouseEvent(mouseEvent);
	}
	_onEditorMouseUp(mouseEvent) {
		const currentLineNumber = this._extractLineNumberFromMouseEvent(mouseEvent);
		if (this._hasTriggerKeyOnMouseDown && this._lineNumberOnMouseDown && this._lineNumberOnMouseDown === currentLineNumber) {
			this._onExecute.fire(mouseEvent);
		}
	}
	_onEditorKeyDown(e) {
		if (this._lastMouseMoveEvent && (e.keyCodeIsTriggerKey || (e.keyCodeIsSideBySideKey && e.hasTriggerModifier))) {
			this._onMouseMoveOrRelevantKeyDown.fire([this._lastMouseMoveEvent, e]);
		} else if (e.hasTriggerModifier) {
			this._onCancel.fire();
		}
	}
	_onEditorKeyUp(e) {
		if (e.keyCodeIsTriggerKey) {
			this._onCancel.fire();
		}
	}
	_resetHandler() {
		this._lastMouseMoveEvent = null;
		this._hasTriggerKeyOnMouseDown = false;
		this._onCancel.fire();
	}
}

		/*
		const gesture = this._register(
			new ClickLinkGesture(this._editor, {
				extractLineNumberFromMouseEvent: e => {
					const position = this._stickyScrollWidget.getEditorPositionFromNode(e.target.element);
					return position ? position.lineNumber : 0;
				}
			})
		);
		this._register(
			gesture.onMouseMoveOrRelevantKeyDown(([mouseEvent, _keyboardEvent]) => {
				const mouseTarget = getMouseEventTarget(mouseEvent);
				if (!mouseTarget || !mouseEvent.hasTriggerModifier || !this._editor.hasModel()) {
					sessionStore.clear();
					return;
				}
				const { range: range2, textElement } = mouseTarget;
				if (!range2.equalsRange(this._stickyRangeProjectedOnEditor)) {
					this._stickyRangeProjectedOnEditor = range2;
					sessionStore.clear();
				} else if (textElement.style.textDecoration === 'underline') {
					return;
				}
				const cancellationToken = new CancellationTokenSource();
				sessionStore.add(toDisposable(() => cancellationToken.dispose(true)));
				let currentHTMLChild;
				getDefinitionsAtPosition(
					this._languageFeaturesService.definitionProvider,
					this._editor.getModel(),
					new Position(range2.startLineNumber, range2.startColumn + 1),
					cancellationToken.token
				).then(candidateDefinitions => {
					if (cancellationToken.token.isCancellationRequested) {
						return;
					}
					if (candidateDefinitions.length !== 0) {
						this._candidateDefinitionsLength = candidateDefinitions.length;
						const childHTML = textElement;
						if (currentHTMLChild !== childHTML) {
							sessionStore.clear();
							currentHTMLChild = childHTML;
							currentHTMLChild.style.textDecoration = 'underline';
							sessionStore.add(
								toDisposable(() => {
									currentHTMLChild.style.textDecoration = 'none';
								})
							);
						} else if (!currentHTMLChild) {
							currentHTMLChild = childHTML;
							currentHTMLChild.style.textDecoration = 'underline';
							sessionStore.add(
								toDisposable(() => {
									currentHTMLChild.style.textDecoration = 'none';
								})
							);
						}
					} else {
						sessionStore.clear();
					}
				});
			})
		);
		this._register(
			gesture.onCancel(() => {
				sessionStore.clear();
			})
		);
		this._register(
			gesture.onExecute(async e => {
				if (e.target.type !== 12 || e.target.detail !== this._stickyScrollWidget.getId()) {
					return;
				}
				const position = this._stickyScrollWidget.getEditorPositionFromNode(e.target.element);
				if (!position) {
					return;
				}
				if (!this._editor.hasModel() || !this._stickyRangeProjectedOnEditor) {
					return;
				}
				if (this._candidateDefinitionsLength > 1) {
					if (this._focused) {
						this._disposeFocusStickyScrollStore();
					}
					this._revealPosition({
						lineNumber: position.lineNumber,
						column: 1
					});
				}
			})
		);
		*/