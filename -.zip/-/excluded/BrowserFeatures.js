const BrowserFeatures = {
	clipboard: {
		writeText: (document.queryCommandSupported && document.queryCommandSupported('copy')) || !!navigator?.clipboard?.writeText,
		readText: !!navigator?.clipboard?.readText
	},
	keyboard: (() => {
		if (isStandalone()) {
			return 0;
		}
		if (navigator.keyboard || isSafari) {
			return 1;
		}
		return 2;
	})(),
	touch: 'ontouchstart' in mainWindow || navigator.maxTouchPoints > 0,

};