


class EmbeddedCodeEditorWidget extends CodeEditorWidget {
	constructor(
		domElement,
		options2,
		codeEditorWidgetOptions,
		parentEditor,
		instantiationService,
		codeEditorService,
		commandService,
		contextKeyService,
		themeService,
		notificationService,
		languageConfigurationService,
		languageFeaturesService
	) {
		super(
			domElement,
			{
				...parentEditor.getRawOptions(),
				overflowWidgetsDomNode: parentEditor.getOverflowWidgetsDomNode()
			},
			codeEditorWidgetOptions,
			instantiationService,
			codeEditorService,
			commandService,
			contextKeyService,
			themeService,
			notificationService,
			languageConfigurationService,
			languageFeaturesService
		);
		this._parentEditor = parentEditor;
		this._overwriteOptions = options2;
		super.updateOptions(this._overwriteOptions);
		this._register(parentEditor.onDidChangeConfiguration(e => this._onParentConfigurationChanged(e)));
	}
	getParentEditor() {
		return this._parentEditor;
	}
	_onParentConfigurationChanged(e) {
		super.updateOptions(this._parentEditor.getRawOptions());
		super.updateOptions(this._overwriteOptions);
	}
	updateOptions(newOptions) {
		mixin(this._overwriteOptions, newOptions);
		super.updateOptions(this._overwriteOptions);
	}
}
__decorate(
	[
		__param(4, IInstantiationService),
		__param(5, ICodeEditorService),
		__param(6, ICommandService),
		__param(7, IContextKeyService),
		__param(8, IThemeService),
		__param(9, INotificationService),
		__param(10, ILanguageConfigurationService),
		__param(11, ILanguageFeaturesService)
	],
	EmbeddedCodeEditorWidget
);