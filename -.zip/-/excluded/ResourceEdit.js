class ResourceFileEdit extends ResourceEdit {
	static is(candidate) {
		if (candidate instanceof ResourceFileEdit) {
			return true;
		} else {
			return isLiteralObject(candidate) && (Boolean(candidate.newResource) || Boolean(candidate.oldResource));
		}
	}
	static lift(edit) {
		if (edit instanceof ResourceFileEdit) {
			return edit;
		} else {
			return new ResourceFileEdit(edit.oldResource, edit.newResource, edit.options, edit.metadata);
		}
	}
	constructor(oldResource, newResource, options2 = {}, metadata) {
		super(metadata);
		this.oldResource = oldResource;
		this.newResource = newResource;
		this.options = options2;
	}
}

class ResourceTextEdit extends ResourceEdit {
	static is(candidate) {
		if (candidate instanceof ResourceTextEdit) {
			return true;
		}
		return isLiteralObject(candidate) && URI.isUri(candidate.resource) && isLiteralObject(candidate.textEdit);
	}
	static lift(edit) {
		if (edit instanceof ResourceTextEdit) {
			return edit;
		} else {
			return new ResourceTextEdit(edit.resource, edit.textEdit, edit.versionId, edit.metadata);
		}
	}
	constructor(resource, textEdit, versionId = undefined, metadata) {
		super(metadata);
		this.resource = resource;
		this.textEdit = textEdit;
		this.versionId = versionId;
	}
}

class ResourceEdit {
	constructor(metadata) {
		this.metadata = metadata;
	}
	static convert(edit) {
		return edit.edits.map(edit2 => {
			if (ResourceTextEdit.is(edit2)) {
				return ResourceTextEdit.lift(edit2);
			}
			if (ResourceFileEdit.is(edit2)) {
				return ResourceFileEdit.lift(edit2);
			}
			throw new Error('Unsupported edit');
		});
	}
}


class RemovedResources {
	constructor() {
		this.elements = new Map();
	}
	createMessage() {
		const externalRemoval = [];
		const noParallelUniverses = [];
		for (const [, element] of this.elements) {
			const dest = element.reason === 0 ? externalRemoval : noParallelUniverses;
			dest.push(element.resourceLabel);
		}
		const messages = [];
		if (externalRemoval.length > 0) {
			messages.push(
				localize(
					{
						key: 'externalRemoval',
						comment: ['{0} is a list of filenames']
					},
					'The following files have been closed and modified on disk: {0}.',
					externalRemoval.join(', ')
				)
			);
		}
		if (noParallelUniverses.length > 0) {
			messages.push(
				localize(
					{
						key: 'noParallelUniverses',
						comment: ['{0} is a list of filenames']
					},
					'The following files have been modified in an incompatible way: {0}.',
					noParallelUniverses.join(', ')
				)
			);
		}
		return messages.join('\n');
	}
	get size() {
		return this.elements.size;
	}
	has(strResource) {
		return this.elements.has(strResource);
	}
	set(strResource, value) {
		this.elements.set(strResource, value);
	}
	delete(strResource) {
		return this.elements.delete(strResource);
	}
}



class ResourceReasonPair {
	constructor(resourceLabel, reason) {
		this.resourceLabel = resourceLabel;
		this.reason = reason;
	}
}
