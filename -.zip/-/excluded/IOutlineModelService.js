const IOutlineModelService = createEditorServiceDecorator('IOutlineModelService');
registerSingleton(
	IOutlineModelService,
	OutlineModelService,
	1 //.Delayed
);