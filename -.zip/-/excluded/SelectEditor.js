class SelectEditor extends EditorAction2 {
	constructor() {
		super({
			id: 'editor.action.selectEditor',
			title: localize('Select Editor'),
			precondition: ck_stickyScroll_focused.isEqualTo(true),
			keybinding: {
				weight: 100,
				primary: 9 // Escape
			}
		});
	}
	runEditorCommand(_accessor, editor) {
		StickyScrollController2.get(editor)?.selectEditor();
	}
}
registerEditorAction2(SelectEditor);