const IWorkspaceContextService = createEditorServiceDecorator('contextService');

class WorkspaceFolder {
	constructor(data, raw) {
		this.raw = raw;
		this.uri = data.uri;
		this.index = data.index;
		this.name = data.name;
	}
	toJSON() {
		return { uri: this.uri, name: this.name, index: this.index };
	}
}


class StandaloneWorkspaceContextService {
	constructor() {
		const resource = URI.from({
			scheme: 'inmemory',
			authority: 'model',
			path: '/'
		});
		this.workspace = {
			folders: [new WorkspaceFolder({ uri: resource, name: '', index: 0 })]
		};
	}
	getWorkspace() {
		return this.workspace;
	}
	getWorkspaceFolder(resource) {
		return resource && resource.scheme === 'inmemory' ? this.workspace.folders[0] : null;
	}
}

registerSingleton(
	IWorkspaceContextService,
	StandaloneWorkspaceContextService,
	0 //Eager
);

function createCombinedWorkspaceEdit(uri, ranges, edit) {
	if (typeof edit.insertText === 'string' ? edit.insertText === '' : edit.insertText.snippet === '') {
		return {
			edits: edit.additionalEdit?.edits || []
		};
	}
	return {
		edits: [
			...ranges.map(
				range2 =>
					new ResourceTextEdit(uri, {
						range: range2,
						text: typeof edit.insertText === 'string' ? SnippetParser.escape(edit.insertText) + '$0' : edit.insertText.snippet,
						insertAsSnippet: true
					})
			),
			...(edit.additionalEdit?.edits || [])
		]
	};
}


class WorkspaceBasedVariableResolver {
	constructor(_workspaceService) {
		this._workspaceService = _workspaceService;
	}
	resolve(variable) {
		if (!this._workspaceService) {
			return;
		}
		function _toWorkspaceIdentifier(arg0) {
			if (typeof arg0 === 'string' || typeof arg0 === 'undefined') {
				if (typeof arg0 === 'string') {
					return {
						id: basename(arg0)
					};
				}

				return { id: 'empty-window' };
			}
			const workspace = arg0;
			if (workspace.configuration) {
				return {
					id: workspace.id,
					configPath: workspace.configuration
				};
			}
			if (workspace.folders.length === 1) {
				return {
					id: workspace.id,
					uri: workspace.folders[0].uri
				};
			}
			return {
				id: workspace.id
			};
		}

		const workspaceIdentifier = _toWorkspaceIdentifier(this._workspaceService.getWorkspace());

		if (
			typeof workspaceIdentifier?.id === 'string' &&
			!URI.isUri(workspaceIdentifier.uri) &&
			!URI.isUri(workspaceIdentifier.configPath)
		) {
			return;
		}

		if (variable.name === 'WORKSPACE_NAME') {
			return this._resolveWorkspaceName(workspaceIdentifier);
		} else if (variable.name === 'WORKSPACE_FOLDER') {
			return this._resoveWorkspacePath(workspaceIdentifier);
		}
		return;
	}
	_resolveWorkspaceName(workspaceIdentifier) {
		if (typeof workspaceIdentifier?.id === 'string' && URI.isUri(workspaceIdentifier.uri)) {
			return basename(workspaceIdentifier.uri.path);
		}
		let filename = basename(workspaceIdentifier.configPath.path);
		if (filename.endsWith(WORKSPACE_EXTENSION)) {
			filename = filename.substr(0, filename.length - WORKSPACE_EXTENSION.length - 1);
		}
		return filename;
	}
	_resoveWorkspacePath(workspaceIdentifier) {
		const normalizeDriveLetter = path =>
			isWindows && isWindowsDriveLetter(path.charCodeAt(0)) && 58 === path.charCodeAt(1)
				? path.charAt(0).toUpperCase() + path.slice(1)
				: path;
		if (typeof workspaceIdentifier?.id === 'string' && URI.isUri(workspaceIdentifier.uri)) {
			return normalizeDriveLetter(workspaceIdentifier.uri.fsPath);
		}
		const filename = basename(workspaceIdentifier.configPath.path);
		let folderpath = workspaceIdentifier.configPath.fsPath;
		if (folderpath.endsWith(filename)) {
			folderpath = folderpath.substr(0, folderpath.length - filename.length - 1);
		}
		return folderpath ? normalizeDriveLetter(folderpath) : '/';
	}
}

const WORKSPACE_EXTENSION = 'code-workspace';

class RelativePathProvider extends SimplePasteAndDropProvider {
	constructor(_workspaceContextService) {
		super();
		this._workspaceContextService = _workspaceContextService;
		this.kind = new HierarchicalKind('uri.relative');
		this.dropMimeTypes = ['text/uri-list'];
		this.pasteMimeTypes = ['text/uri-list'];
	}
	async getEdit(dataTransfer, token) {
		const entries2 = await extractUriList(dataTransfer);
		if (!entries2.length || token.isCancellationRequested) {
			return;
		}
		const relativeUris = entries2
			.map(({ uri }) => {
				const root = this._workspaceContextService.getWorkspaceFolder(uri);
				return root ? relativePath(root.uri, uri) : undefined;
			})
			.filter(e => !!e);
		if (!relativeUris.length) {
			return;
		}
		return {
			handledMimeType: 'text/uri-list',
			insertText: relativeUris.join(' '),
			title: entries2.length > 1 ? localize('Insert Relative Paths') : localize('Insert Relative Path'),
			kind: this.kind
		};
	}
}
__decorate(
	[
		__param(0, IWorkspaceContextService)
		//...
	],
	RelativePathProvider
);



this._register(languageFeaturesService.documentDropEditProvider.register('*', new RelativePathProvider(workspaceContextService)));


class DefaultDropProvidersFeature extends Disposable {
	constructor(languageFeaturesService, workspaceContextService) {
		super();
		this._register(languageFeaturesService.documentDropEditProvider.register('*', new DefaultTextPasteOrDropEditProvider()));
		this._register(languageFeaturesService.documentDropEditProvider.register('*', new PathProvider()));

	}
}
__decorate(
	[
		__param(0, ILanguageFeaturesService),
		__param(1, IWorkspaceContextService)
		//..
	],
	DefaultDropProvidersFeature
);


				new WorkspaceBasedVariableResolver(workspaceService),
		new WorkspaceBasedVariableResolver(editor2.invokeWithinContext(accessor => accessor.get(IWorkspaceContextService))),


						const workspaceService = editor2.invokeWithinContext(accessor => accessor.get(IWorkspaceContextService));





class WorkspaceStackElement {
	constructor(actual, resourceLabels, strResources, groupId, groupOrder, sourceId, sourceOrder) {
		this.id = ++stackElementCounter;
		this.type = 1;
		this.actual = actual;
		this.label = actual.label;
		this.confirmBeforeUndo = actual.confirmBeforeUndo || false;
		this.resourceLabels = resourceLabels;
		this.strResources = strResources;
		this.groupId = groupId;
		this.groupOrder = groupOrder;
		this.sourceId = sourceId;
		this.sourceOrder = sourceOrder;
		this.removedResources = null;
		this.invalidatedResources = null;
	}
	canSplit() {
		return typeof this.actual.split === 'function';
	}
	removeResource(resourceLabel, strResource, reason) {
		if (!this.removedResources) {
			this.removedResources = new RemovedResources();
		}
		if (!this.removedResources.has(strResource)) {
			this.removedResources.set(strResource, new ResourceReasonPair(resourceLabel, reason));
		}
	}
	setValid(resourceLabel, strResource, isValid2) {
		if (isValid2) {
			if (this.invalidatedResources) {
				this.invalidatedResources.delete(strResource);
				if (this.invalidatedResources.size === 0) {
					this.invalidatedResources = null;
				}
			}
		} else {
			if (!this.invalidatedResources) {
				this.invalidatedResources = new RemovedResources();
			}
			if (!this.invalidatedResources.has(strResource)) {
				this.invalidatedResources.set(
					strResource,
					new ResourceReasonPair(
						resourceLabel,
						0 //RemovedResourceReason.ExternalRemoval
					)
				);
			}
		}
	}
	toString() {
		return `[id:${this.id}] [group:${this.groupId}] [${this.invalidatedResources ? 'INVALID' : '  VALID'}] ${this.actual.constructor.name} - ${this.actual}`;
	}
}











