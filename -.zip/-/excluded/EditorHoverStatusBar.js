class EditorHoverStatusBar extends Disposable {
	get hasContent() {
		return this._hasContent;
	}
	constructor(_keybindingService) {
		super();
		this._keybindingService = _keybindingService;
		this._hasContent = false;
		this.hoverElement = createDomElement('div.hover-row.status-bar');
		this.hoverElement.tabIndex = 0;
		this.actionsElement = append(this.hoverElement, createDomElement('div.actions'));
	}
	addAction(actionOptions) {
		const keybinding = this._keybindingService.lookupKeybinding(actionOptions.commandId);
		const keybindingLabel = keybinding ? keybinding.getLabel() : null;
		this._hasContent = true;
		return this._register(HoverAction.render(this.actionsElement, actionOptions, keybindingLabel));
	}
	append(element) {
		const result = append(this.actionsElement, element);
		this._hasContent = true;
		return result;
	}
}
__decorate([__param(0, IKeybindingService)], EditorHoverStatusBar);


//const statusBar = disposables.add(new EditorHoverStatusBar(this._keybindingService));
		//if (statusBar.hasContent) {fragment.appendChild(statusBar.hoverElement);}
