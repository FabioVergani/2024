







// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const showGoToContextMenu = async (accessor, editor, anchor, part) => {
	await part.item.resolve(cancellationToken_none);
	const partLocation = part.part.location;
	if (partLocation) {
		const contextMenuService = accessor.get(IContextMenuService);
		const resolverService = accessor.get(ITextModelService);
		const commandService = accessor.get(ICommandService);
		const instaService = accessor.get(IInstantiationService);
		const notificationService = accessor.get(INotificationService);
		const menuActions = [];
		const filter = new Set(menuRegistry.getMenuItems(editorContext_menuId).map(item => item.command?.id ?? generateUuid()));
		for (const delegate of SymbolNavigationAction.all()) {
			if (filter.has(delegate.desc.id)) {
				menuActions.push(
					new Action(
						delegate.desc.id,
						MenuItemAction.label(delegate.desc, {
							renderShortTitle: true
						}),
						undefined,
						true,
						async () => {
							const ref = await resolverService.createModelReference(partLocation.uri);
							try {
								const symbolAnchor = new SymbolNavigationAnchor(
									ref.object.textEditorModel,
									Range.getStartPosition(partLocation.range)
								);
								const range2 = part.item.anchor.range;
								await instaService.invokeFunction(delegate.runEditorCommand.bind(delegate), editor, symbolAnchor, range2);
							} finally {
								ref.dispose();
							}
						}
					)
				);
			}
		}
		if (part.part.command) {
			const partCommand = part.part.command;
			menuActions.push(
				new Separator(),
				new Action(partCommand.id, partCommand.title, undefined, true, async () => {
					try {
						await commandService.executeCommand(partCommand.id, ...(partCommand.arguments || []));
					} catch (err) {
						notificationService.notify({
							severity: Severity.Error,
							source: part.item.provider.displayName,
							message: err
						});
					}
				})
			);
		}
		const useShadowDOM = editor.getOption(
			127 // useShadowDOM
		);
		contextMenuService.showContextMenu({
			domForShadowRoot: useShadowDOM ? editor.getDomNode() : undefined,
			getAnchor: () => {
				const box = getDomNodePagePosition(anchor);
				return { x: box.left, y: box.top + box.height + 8 };
			},
			getActions: () => menuActions,
			onHide: () => {
				editor.focus();
			},
			autoSelectFirstItem: true
		});
	}
};
const goToDefinitionWithLocation = async (accessor, event, editor, location) => {
	const resolverService = accessor.get(ITextModelService);
	const ref = await resolverService.createModelReference(location.uri);
	await editor.invokeWithinContext(async accessor2 => {
		const openToSide = event.hasSideBySideModifier;
		const contextKeyService = accessor2.get(IContextKeyService);
		const isInPeek = ck_inPeekEditor.getValue(contextKeyService);
		const canPeek =
			!openToSide &&
			editor.getOption(
				88 // definitionLinkOpensInPeek
			) &&
			!isInPeek;
		const action = new DefinitionAction(
			{ openToSide, openInPeek: canPeek, muteMessage: true },
			{ title: { value: '', original: '' }, id: '' }
		);
		return action.run(
			accessor2,
			new SymbolNavigationAnchor(ref.object.textEditorModel, Range.getStartPosition(location.range)),
			Range.lift(location.range)
		);
	});
	ref.dispose();
};
/*
this._instaService.invokeFunction(goToDefinitionWithLocation, e, this._editor, {
	uri: this._editor.getModel().uri,
	range: this._stickyRangeProjectedOnEditor
});
*/

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class ErrorInvalidArgType extends Error {
	constructor(name, expected, actual) {
		let determiner;
		if (typeof expected === 'string' && expected.indexOf('not ') === 0) {
			determiner = 'must not be';
			expected = expected.replace(/^not /, '');
		} else {
			determiner = 'must be';
		}
		const type = name.indexOf('.') !== -1 ? 'property' : 'argument';
		let msg = `The "${name}" ${type} ${determiner} of type ${expected}`;
		msg += `. Received type ${typeof actual}`;
		super(msg);
		this.code = 'ERR_INVALID_ARG_TYPE';
	}
}



const OverviewRulerLane = {
	Left: 1,
	Center: 2,
	Right: 4,
	Full: 7,
	1: 'Left',
	2: 'Center',
	4: 'Right',
	7: 'Full'
};
var NO_ITEM_SCORE = freeze({ score: 0 });

// node_modules/monaco-editor/esm/vs/editor/common/services/editorBaseApi.js
function createMonacoBaseAPI() {
	return {
		editor: undefined,
		// undefined override expected here
		languages: undefined,
		// undefined override expected here
		CancellationTokenSource,
		Emitter,
		KeyCode,
		KeyMod,
		Position,
		Range,
		Selection: EditorSelection,
		SelectionDirection,
		MarkerSeverity,
		MarkerTag,
		Uri: URI,
		Token
	};
}

var CONTEXT_RENAME_INPUT_FOCUSED = new RawContextKey(
	'renameInputFocused',
	false,
	localize('renameInputFocused', 'Whether the rename input widget is focused')
);

const forEachListener = (listeners, fn) => {
	if (listeners instanceof UniqueContainer) {
		fn(listeners);
	} else {
		for (let i = 0; i < listeners.length; i++) {
			const l = listeners[i];
			if (l) {
				fn(l);
			}
		}
	}
};











// node_modules/monaco-editor/esm/vs/editor/standalone/browser/iPadShowKeyboard/iPadShowKeyboard.js
class IPadShowKeyboard extends Disposable {
	constructor(editor2) {
		super();
		this.editor = editor2;
		this.widget = null;
		if (isIOS) {
			this._register(editor2.onDidChangeConfiguration(() => this.update()));
			this.update();
		}
	}
	update() {
		const shouldHaveWidget = !this.editor.getOption(
			91
			/* EditorOption.readOnly */
		);
		if (!this.widget && shouldHaveWidget) {
			this.widget = new ShowKeyboardWidget(this.editor);
		} else if (this.widget && !shouldHaveWidget) {
			this.widget.dispose();
			this.widget = null;
		}
	}
	dispose() {
		super.dispose();
		if (this.widget) {
			this.widget.dispose();
			this.widget = null;
		}
	}
}
IPadShowKeyboard.ID = 'editor.contrib.iPadShowKeyboard';

class ShowKeyboardWidget extends Disposable {
	constructor(editor2) {
		super();
		this.editor = editor2;
		this._domNode = document.createElement('textarea');
		this._domNode.className = 'iPadShowKeyboard';
		this._register(
			addDisposableListener(this._domNode, 'touchstart', e => {
				this.editor.focus();
			})
		);
		this._register(
			addDisposableListener(this._domNode, 'focus', e => {
				this.editor.focus();
			})
		);
		this.editor.addOverlayWidget(this);
	}
	dispose() {
		this.editor.removeOverlayWidget(this);
		super.dispose();
	}
	// ----- IOverlayWidget API
	getId() {
		return ShowKeyboardWidget.ID;
	}
	getDomNode() {
		return this._domNode;
	}
	getPosition() {
		return {
			preference: 1
			/* OverlayWidgetPositionPreference.BOTTOM_RIGHT_CORNER */
		};
	}
}
ShowKeyboardWidget.ID = 'editor.contrib.ShowKeyboardWidget';
registerEditorContribution(
	IPadShowKeyboard.ID,
	IPadShowKeyboard,
	3
	/* EditorContributionInstantiation.Eventually */
);