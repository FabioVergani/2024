

class MenuEntryActionViewItem extends ActionViewItem {
	constructor(action, options2, _keybindingService, _notificationService, _contextKeyService, _themeService, _contextMenuService) {
		super(undefined, action, {
			icon: !!(action.class || action.item.icon),
			label: !action.class && !action.item.icon,
			keybinding: options2?.keybinding,
			hoverDelegate: options2?.hoverDelegate
		});
		this._keybindingService = _keybindingService;
		this._notificationService = _notificationService;
		this._contextKeyService = _contextKeyService;
		this._themeService = _themeService;
		this._contextMenuService = _contextMenuService;
		this._wantsAltCommand = false;
		this._itemClassDispose = this._register(new MutableDisposable());
		this._altKey = ModifierKeyEmitter.getInstance();
	}
	get _menuItemAction() {
		return this._action;
	}
	get _commandAction() {
		return (this._wantsAltCommand && this._menuItemAction.alt) || this._menuItemAction;
	}
	async onClick(event) {
		event.preventDefault();
		event.stopPropagation();
		try {
			await this.actionRunner.run(this._commandAction, this._context);
		} catch (err) {
			this._notificationService.error(err);
		}
	}
	render(container) {
		super.render(container);
		container.classList.add('menu-entry');
		if (this.options.icon) {
			this._updateItemClass(this._menuItemAction.item);
		}
		if (this._menuItemAction.alt) {
			let isMouseOver = false;
			const updateAltState = () => {
				const wantsAltCommand = !!this._menuItemAction.alt?.enabled && isMouseOver && (this._altKey.keyStatus.altKey || (this._altKey.keyStatus.shiftKey && isMouseOver));
				if (wantsAltCommand !== this._wantsAltCommand) {
					this._wantsAltCommand = wantsAltCommand;
					this.updateLabel();
					this.updateTooltip();
					this.updateClass();
				}
			};
			this._register(this._altKey.event(updateAltState));
			this._register(
				addDisposableListener(container, 'mouseleave', _ => {
					isMouseOver = false;
					updateAltState();
				})
			);
			this._register(
				addDisposableListener(container, 'mouseenter', _ => {
					isMouseOver = true;
					updateAltState();
				})
			);
			updateAltState();
		}
	}
	updateLabel() {
		if (this.options.label && this.label) {
			this.label.textContent = this._commandAction.label;
		}
	}
	getTooltip() {
		const keybinding = this._keybindingService.lookupKeybinding(this._commandAction.id, this._contextKeyService);
		const keybindingLabel = keybinding && keybinding.getLabel();
		const tooltip = this._commandAction.tooltip || this._commandAction.label;
		let title = keybindingLabel ? localize(tooltip, keybindingLabel) : tooltip;
		if (!this._wantsAltCommand && this._menuItemAction.alt?.enabled) {
			const altTooltip = this._menuItemAction.alt.tooltip || this._menuItemAction.alt.label;
			const altKeybinding = this._keybindingService.lookupKeybinding(this._menuItemAction.alt.id, this._contextKeyService);
			const altKeybindingLabel = altKeybinding && altKeybinding.getLabel();
			const altTitleSection = altKeybindingLabel ? localize(altTooltip, altKeybindingLabel) : altTooltip;
			title = localize(title, UILabelProvider.modifierLabels[OS].altKey, altTitleSection);
		}
		return title;
	}
	updateClass() {
		if (this.options.icon) {
			if (this._commandAction !== this._menuItemAction) {
				if (this._menuItemAction.alt) {
					this._updateItemClass(this._menuItemAction.alt.item);
				}
			} else {
				this._updateItemClass(this._menuItemAction.item);
			}
		}
	}
	_updateItemClass(item) {
		this._itemClassDispose.value = undefined;
		const { element, label } = this;
		if (!element || !label) {
			return;
		}

		const icon = this._commandAction.checked && (item.toggled.condition ?? false) && item.toggled.icon ? item.toggled.icon : item.icon;
		if (!icon) {
			return;
		}
		if (icon?.id) {
			const iconClasses = asThemeIconClassNameArray(icon);
			label.classList.add(...iconClasses);
			this._itemClassDispose.value = toDisposable(() => {
				label.classList.remove(...iconClasses);
			});
		} else {
			label.style.backgroundImage = asCSSUrl(icon.light);
			label.classList.add('icon');
			this._itemClassDispose.value = combinedDisposable(
				toDisposable(() => {
					label.style.backgroundImage = '';
					label.classList.remove('icon');
				}),
				this._themeService.onDidColorThemeChange(() => {
					this.updateClass();
				})
			);
		}
	}
}
__decorate(
	[
		__param(2, IKeybindingService),
		__param(3, INotificationService),
		__param(4, IContextKeyService),
		__param(5, IThemeService),
		__param(6, IContextMenuService)
		//...
	],
	MenuEntryActionViewItem
);


const wholeWordEnterRE = /\benter\b/gi;
class StatusBarViewItem2 extends MenuEntryActionViewItem {
	updateLabel() {
		const kb = this._keybindingService.lookupKeybinding(this._action.id, this._contextKeyService);
		if (kb) {
			if (this.label) {
				this.label.textContent = localize(this._action.label, kb.getLabel()?.replace(wholeWordEnterRE, '\u23CE'));
			}
		} else {
			return super.updateLabel();
		}
	}
}
