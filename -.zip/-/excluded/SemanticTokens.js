





class SemanticTokensProviderStyling {
	constructor(_legend, _themeService, _languageService) {
		this._legend = _legend;
		this._themeService = _themeService;
		this._languageService = _languageService;
		this._hasWarnedOverlappingTokens = false;
		this._hasWarnedInvalidLengthTokens = false;
		this._hasWarnedInvalidEditStart = false;
		this._hashTable = new HashTable();
	}
	getMetadata(tokenTypeIndex, tokenModifierSet, languageId) {
		const encodedLanguageId = this._languageService.languageIdCodec.encodeLanguageId(languageId);
		const entry = this._hashTable.get(tokenTypeIndex, tokenModifierSet, encodedLanguageId);
		let metadata;
		if (entry) {
			metadata = entry.metadata;
		} else {
			let tokenType = this._legend.tokenTypes[tokenTypeIndex];
			const tokenModifiers = [];
			if (tokenType) {
				let modifierSet = tokenModifierSet;
				for (let modifierIndex = 0; modifierSet > 0 && modifierIndex < this._legend.tokenModifiers.length; modifierIndex++) {
					if (modifierSet & 1) {
						tokenModifiers.push(this._legend.tokenModifiers[modifierIndex]);
					}
					modifierSet = modifierSet >> 1;
				}
				const tokenStyle = this._themeService.getColorTheme().getTokenStyleMetadata(tokenType, tokenModifiers, languageId);
				if (typeof tokenStyle === 'undefined') {
					metadata = 2147483647;
				} else {
					metadata = 0;
					if (typeof tokenStyle.italic !== 'undefined') {
						const italicBit = (tokenStyle.italic ? 1 : 0) << 11;
						metadata |= italicBit | 1;
					}
					if (typeof tokenStyle.bold !== 'undefined') {
						const boldBit = (tokenStyle.bold ? 2 : 0) << 11;
						metadata |= boldBit | 2;
					}
					if (typeof tokenStyle.underline !== 'undefined') {
						const underlineBit = (tokenStyle.underline ? 4 : 0) << 11;
						metadata |= underlineBit | 4;
					}
					if (typeof tokenStyle.strikethrough !== 'undefined') {
						const strikethroughBit = (tokenStyle.strikethrough ? 8 : 0) << 11;
						metadata |= strikethroughBit | 8;
					}
					if (tokenStyle.foreground) {
						const foregroundBits = tokenStyle.foreground << 15;
						metadata |= foregroundBits | 16;
					}
					if (metadata === 0) {
						metadata = 2147483647;
					}
				}
			} else {
				metadata = 2147483647;
				tokenType = 'not-in-legend';
			}
			this._hashTable.add(tokenTypeIndex, tokenModifierSet, encodedLanguageId, metadata);
		}
		return metadata;
	}
	warnOverlappingSemanticTokens(lineNumber, startColumn) {
		if (!this._hasWarnedOverlappingTokens) {
			this._hasWarnedOverlappingTokens = true;
		}
	}
	warnInvalidLengthSemanticTokens(lineNumber, startColumn) {
		if (!this._hasWarnedInvalidLengthTokens) {
			this._hasWarnedInvalidLengthTokens = true;
		}
	}
	warnInvalidEditStart(previousResultId, resultId, editIndex, editStart, maxExpectedStart) {
		if (!this._hasWarnedInvalidEditStart) {
			this._hasWarnedInvalidEditStart = true;
		}
	}
}
__decorate([__param(1, IThemeService), __param(2, ILanguageService)], SemanticTokensProviderStyling);





const ISemanticTokensStylingService = createEditorServiceDecorator('semanticTokensStylingService');

class SemanticTokensStylingService extends Disposable {
	constructor(_themeService, _languageService) {
		super();
		this._themeService = _themeService;
		this._languageService = _languageService;
		this._caches = new WeakMap();
		this._register(
			this._themeService.onDidColorThemeChange(() => {
				this._caches = new WeakMap();
			})
		);
	}
	getStyling(provider) {
		if (!this._caches.has(provider)) {
			this._caches.set(provider, new SemanticTokensProviderStyling(provider.getLegend(), this._themeService, this._languageService));
		}
		return this._caches.get(provider);
	}
}
__decorate([__param(0, IThemeService), __param(1, ILanguageService)], SemanticTokensStylingService);
registerSingleton(
	ISemanticTokensStylingService,
	SemanticTokensStylingService,
	1 // Delayed
);