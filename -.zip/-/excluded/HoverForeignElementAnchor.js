




var SHOW_DEFINITION_PREVIEW_HOVER_ACTION_ID = 'editor.action.showDefinitionPreviewHover';
var SCROLL_UP_HOVER_ACTION_ID = 'editor.action.scrollUpHover';
var SCROLL_DOWN_HOVER_ACTION_ID = 'editor.action.scrollDownHover';
var SCROLL_LEFT_HOVER_ACTION_ID = 'editor.action.scrollLeftHover';
var SCROLL_RIGHT_HOVER_ACTION_ID = 'editor.action.scrollRightHover';
var PAGE_UP_HOVER_ACTION_ID = 'editor.action.pageUpHover';
var PAGE_DOWN_HOVER_ACTION_ID = 'editor.action.pageDownHover';
var GO_TO_TOP_HOVER_ACTION_ID = 'editor.action.goToTopHover';

var GO_TO_BOTTOM_HOVER_ACTION_ID = 'editor.action.goToBottomHover';








registerModelAndPositionCommand('_executeHoverProvider', (accessor, model, position) => {
	const languageFeaturesService = accessor.get(ILanguageFeaturesService);
	function _getHoversPromise(registry, model, position, token) {
		return getHoverProviderResultsAsAsyncIterable(registry, model, position, token)
			.map(item => item.hover)
			.toPromise();
	}
	return _getHoversPromise(languageFeaturesService.hoverProvider, model, position, cancellationToken_none);
});




function renderMarkdownHovers(context, hoverParts, editor2, languageService, openerService) {
	hoverParts.sort((a, b) => a.ordinal - b.ordinal);
	const disposables = new DisposableStore();
	for (const hoverPart of hoverParts) {
		disposables.add(
			renderMarkdownInContainer(
				editor2,
				context.fragment,
				hoverPart.contents,
				languageService,
				openerService,
				context.onContentsChanged
			)
		);
	}
	return disposables;
}





class HoverForeignElementAnchor {
	constructor(priority, owner, range2, initialMousePosX, initialMousePosY, supportsMarkerHover) {
		this.priority = priority;
		this.owner = owner;
		this.range = range2;
		this.initialMousePosX = initialMousePosX;
		this.initialMousePosY = initialMousePosY;
		this.supportsMarkerHover = supportsMarkerHover;
		this.type = 2;
	}
	equals(other) {
		return other.type === 2 && this.owner === other.owner;
	}
	canAdoptVisibleHover(lastAnchor, showAtPosition) {
		return lastAnchor.type === 2 && this.owner === lastAnchor.owner;
	}
}
