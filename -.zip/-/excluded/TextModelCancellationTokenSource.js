class TextModelCancellationTokenSource extends CancellationTokenSource {
	constructor(model, parent) {
		super(parent);
		this._listener = model.onDidChangeContent(() => this.cancel());
	}
	dispose() {
		this._listener.dispose();
		super.dispose();
	}
}
