/*
	setInlayHintsOptions(options2) {
		this._inlayHintsOptions = options2 || Object.create(null);
		this._onDidChange.fire(undefined);
	}
		get inlayHintsOptions() {
		return this._inlayHintsOptions;
	}

	const ck_editorHasProvider_inlayHints = new RawContextKey(
	'editorHasInlayHintsProvider',
	false,
	localize('Whether the editor has an inline hints provider')
);
*/

class EditorInlayHints extends BaseEditorOption {
	constructor() {
		const defaults = {
			enabled: 'on',
			fontSize: 0,
			fontFamily: '',
			padding: false
		};
		super(141, 'inlayHints', defaults, {
			'editor.inlayHints.enabled': {
				type: 'string',
				default: defaults.enabled,
				enum: [
					'on', //Inlay hints are enabled
					'onUnlessPressed', //Inlay hints are showing by default and hide when holding {0}', isMacintosh ? `Ctrl+Option` : `Ctrl+Alt
					'offUnlessPressed', //Inlay hints are hidden by default and show when holding {0}', isMacintosh ? `Ctrl+Option` : `Ctrl+Alt`
					'off' //Inlay hints are disabled
				]
			},
			'editor.inlayHints.fontSize': {
				type: 'number',
				default: defaults.fontSize
			},
			'editor.inlayHints.fontFamily': {
				type: 'string',
				default: defaults.fontFamily
			},
			'editor.inlayHints.padding': {
				type: 'boolean',
				default: defaults.padding
			}
		});
	}
	validate(_input) {
		if (!_input || typeof _input !== 'object') {
			return this.defaultValue;
		}
		const input = _input;
		if (typeof input.enabled === 'boolean') {
			input.enabled = input.enabled ? 'on' : 'off';
		}
		return {
			enabled: stringSet(input.enabled, this.defaultValue.enabled, ['on', 'off', 'offUnlessPressed', 'onUnlessPressed']),
			fontSize: EditorIntOption.clampedInt(input.fontSize, this.defaultValue.fontSize, 0, 100),
			fontFamily: EditorStringOption.string(input.fontFamily, this.defaultValue.fontFamily),
			padding: boolean(input.padding, this.defaultValue.padding)
		};
	}
}
const colorId_inlayHint_backgroud = 'editorInlayHint.background';
const colorId_inlayHint_foreground = 'editorInlayHint.foreground';
const colorId_inlayHintType_backgroud = 'editorInlayHint.typeBackground';
const colorId_inlayHintType_foreground = 'editorInlayHint.typeForeground';
const colorId_inlayHintParameter_backgroud = 'editorInlayHint.parameterBackground';
const colorId_inlayHintParameter_foreground = 'editorInlayHint.parameterForeground';

	registerColor(
		colorId_inlayHint_foreground,
		{ dark: '#969696', light: '#969696', hcDark: colorWhite, hcLight: colorBlack },
		localize('Foreground color of inline hints')
	);
	registerColor(
		colorId_inlayHint_backgroud,
		{
			dark: transparent(colorId_badge_background, 0.1),
			light: transparent(colorId_badge_background, 0.1),
			hcDark: transparent(colorWhite, 0.1),
			hcLight: transparent(colorId_badge_background, 0.1)
		},
		localize('Background color of inline hints')
	);
	registerColor(
		colorId_inlayHintType_foreground,
		{
			dark: colorId_inlayHint_foreground,
			light: colorId_inlayHint_foreground,
			hcDark: colorId_inlayHint_foreground,
			hcLight: colorId_inlayHint_foreground
		},
		localize('Foreground color of inline hints for types')
	);
	registerColor(
		colorId_inlayHintType_backgroud,
		{
			dark: colorId_inlayHint_backgroud,
			light: colorId_inlayHint_backgroud,
			hcDark: colorId_inlayHint_backgroud,
			hcLight: colorId_inlayHint_backgroud
		},
		localize('Background color of inline hints for types')
	);
	registerColor(
		colorId_inlayHintParameter_foreground,
		{
			dark: colorId_inlayHint_foreground,
			light: colorId_inlayHint_foreground,
			hcDark: colorId_inlayHint_foreground,
			hcLight: colorId_inlayHint_foreground
		},
		localize('Foreground color of inline hints for parameters')
	);
	registerColor(
		colorId_inlayHintParameter_backgroud,
		{
			dark: colorId_inlayHint_backgroud,
			light: colorId_inlayHint_backgroud,
			hcDark: colorId_inlayHint_backgroud,
			hcLight: colorId_inlayHint_backgroud
		},
		localize('Background color of inline hints for parameters')
	);
	registerColor(
		colorId_editorLightBulb_foreground,
		{ dark: '#FFCC00', light: '#DDB100', hcDark: '#FFCC00', hcLight: '#007ACC' },
		localize('The color used for the lightbulb actions icon.')
	);
	registerColor(
		'editorLightBulbAutoFix.foreground',
		{ dark: '#75BEFF', light: '#007ACC', hcDark: '#75BEFF', hcLight: '#007ACC' },
		localize('The color used for the lightbulb auto fix actions icon.')
	);
	registerColor(
		'editorLightBulbAi.foreground',
		{
			dark: colorId_editorLightBulb_foreground,
			light: colorId_editorLightBulb_foreground,
			hcDark: colorId_editorLightBulb_foreground,
			hcLight: colorId_editorLightBulb_foreground
		},
		localize('The color used for the lightbulb AI icon.')
	);

class InlayHintsAdapterTS extends AdapterTS {
	async provideInlayHints(model, range2, token) {
		const resource = model.uri;
		const fileName = resource.toString();
		const start = model.getOffsetAt({
			lineNumber: range2.startLineNumber,
			column: range2.startColumn
		});
		const end = model.getOffsetAt({
			lineNumber: range2.endLineNumber,
			column: range2.endColumn
		});
		const worker2 = await this._worker(resource);
		if (model.isDisposed()) {
			return null;
		}
		const tsHints = await worker2.provideInlayHints(fileName, start, end);
		const hints = tsHints.map(hint => {
			return {
				...hint,
				label: hint.text,
				position: model.getPositionAt(hint.position),
				kind: this._convertHintKind(hint.kind)
			};
		});
		return { hints, dispose: dummyArrowFn };
	}
	_convertHintKind(kind) {
		switch (kind) {
			case 'Parameter':
				return 2;
			case 'Type':
			default:
				return 1;
		}
	}
}


const registerInlayHintsProvider = (languageSelector, provider) => {
	return getService_LanguageFeatures().inlayHintsProvider.register(languageSelector, provider);
};

var inlineSuggestCommitId = 'editor.action.inlineSuggest.commit';
var showPreviousInlineSuggestionActionId = 'editor.action.inlineSuggest.showPrevious';
var showNextInlineSuggestionActionId = 'editor.action.inlineSuggest.showNext';



class InlineCompletionsHintsWidget extends Disposable {
	constructor(editor2, model, instantiationService) {
		super();
		this.editor = editor2;
		this.model = model;
		this.instantiationService = instantiationService;
		this.alwaysShowToolbar = observableFromEvent(
			this.editor.onDidChangeConfiguration,
			() =>
				this.editor.getOption(
					62 // inlineSuggest
				).showToolbar === 'always'
		);
		this.sessionPosition = undefined;
		this.position = derived(this, reader => {
			const ghostText = this.model.read(reader)?.primaryGhostText.read(reader);
			if (!this.alwaysShowToolbar.read(reader) || !ghostText || ghostText.parts.length === 0) {
				this.sessionPosition = undefined;
				return null;
			}
			const firstColumn = ghostText.parts[0].column;
			if (this.sessionPosition && this.sessionPosition.lineNumber !== ghostText.lineNumber) {
				this.sessionPosition = undefined;
			}
			const position = new Position(
				ghostText.lineNumber,
				Math.min(firstColumn, this.sessionPosition?.column ?? Number.MAX_SAFE_INTEGER)
			);
			this.sessionPosition = position;
			return position;
		});
		this._register(
			autorunWithStore((reader, store) => {
				const model2 = this.model.read(reader);
				if (!model2 || !this.alwaysShowToolbar.read(reader)) {
					return;
				}
				const contentWidget = store.add(
					this.instantiationService.createInstance(
						InlineSuggestionHintsContentWidget,
						this.editor,
						true,
						this.position,
						model2.selectedInlineCompletionIndex,
						model2.inlineCompletionsCount,
						model2.activeCommands
					)
				);
				editor2.addContentWidget(contentWidget);
				store.add(toDisposable(() => editor2.removeContentWidget(contentWidget)));
				store.add(
					autorun(reader2 => {
						const position = this.position.read(reader2);
						if (!position) {
							return;
						}
						if (
							model2.lastTriggerKind.read(reader2) !== 1 //Explicit
						) {
							model2.triggerExplicitly();
						}
					})
				);
			})
		);
	}
}
__decorate([__param(2, IInstantiationService)], InlineCompletionsHintsWidget);
var inlineSuggestionHintsNextIcon = iconRegistry.registerIcon(
	'inline-suggestion-hints-next',
	codicon_chevronRight,
);
var inlineSuggestionHintsPreviousIcon = iconRegistry.registerIcon(
	'inline-suggestion-hints-previous',
	codicon_chevronLeft,
);
class InlineSuggestionHintsContentWidget extends Disposable {
	static get dropDownVisible() {
		return this._dropDownVisible;
	}
	createCommandAction(commandId, label, iconClassName) {
		const action = new Action(commandId, label, iconClassName, true, () => this._commandService.executeCommand(commandId));
		const kb = this.keybindingService.lookupKeybinding(commandId, this._contextKeyService);
		let tooltip = label;
		if (kb) {
			tooltip = localize('{0} ({1})', label, kb.getLabel());
		}
		action.tooltip = tooltip;
		return action;
	}
	constructor(
		editor2,
		withBorder,
		_position,
		_currentSuggestionIdx,
		_suggestionCount,
		_extraCommands,
		_commandService,
		instantiationService,
		keybindingService,
		_contextKeyService,
		_menuService
	) {
		super();
		this.editor = editor2;
		this.withBorder = withBorder;
		this._position = _position;
		this._currentSuggestionIdx = _currentSuggestionIdx;
		this._suggestionCount = _suggestionCount;
		this._extraCommands = _extraCommands;
		this._commandService = _commandService;
		this.keybindingService = keybindingService;
		this._contextKeyService = _contextKeyService;
		this._menuService = _menuService;
		this.id = `InlineSuggestionHintsContentWidget${InlineSuggestionHintsContentWidget.id++}`;
		this.allowEditorOverflow = true;
		this.suppressMouseDown = false;
		this.nodes = h('div.inlineSuggestionsHints', { className: this.withBorder ? '.withBorder' : '' }, [h('div@toolBar')]);
		this.previousAction = this.createCommandAction(
			showPreviousInlineSuggestionActionId,
			localize('Previous'),
			asThemeIconClassNameString(inlineSuggestionHintsPreviousIcon)
		);
		this.availableSuggestionCountAction = new Action('inlineSuggestionHints.availableSuggestionCount', '', undefined, false);
		this.nextAction = this.createCommandAction(
			showNextInlineSuggestionActionId,
			localize('Next'),
			asThemeIconClassNameString(inlineSuggestionHintsNextIcon)
		);
		this.inlineCompletionsActionsMenus = this._register(
			this._menuService.createMenu(inlineCompletionsActions_menuId, this._contextKeyService)
		);
		this.clearAvailableSuggestionCountLabelDebounced = this._register(
			new RunOnceScheduler(() => {
				this.availableSuggestionCountAction.label = '';
			}, 100)
		);
		this.disableButtonsDebounced = this._register(
			new RunOnceScheduler(() => {
				this.previousAction.enabled = this.nextAction.enabled = false;
			}, 100)
		);
		this.toolBar = this._register(
			instantiationService.createInstance(CustomizedMenuWorkbenchToolBar, this.nodes.toolBar, inlineSuggestionToolbar_menuId, {
				menuOptions: { renderShortTitle: true },
				toolbarOptions: {
					primaryGroup: g => g.startsWith('primary')
				},
				actionViewItemProvider: (action, options2) => {
					if (action instanceof MenuItemAction) {
						return instantiationService.createInstance(StatusBarViewItem, action, undefined);
					}
					if (action === this.availableSuggestionCountAction) {
						const a = new ActionViewItemWithClassName(undefined, action, { label: true, icon: false });
						a.setClass('availableSuggestionCount');
						return a;
					}
					return;
				}
			})
		);
		this.toolBar.setPrependedPrimaryActions([this.previousAction, this.availableSuggestionCountAction, this.nextAction]);
		this._register(
			this.toolBar.onDidChangeDropdownVisibility(e => {
				InlineSuggestionHintsContentWidget._dropDownVisible = e;
			})
		);
		this._register(
			autorun(reader => {
				this._position.read(reader);
				this.editor.layoutContentWidget(this);
			})
		);
		this._register(
			autorun(reader => {
				const suggestionCount = this._suggestionCount.read(reader);
				const currentSuggestionIdx = this._currentSuggestionIdx.read(reader);
				if (suggestionCount !== undefined) {
					this.clearAvailableSuggestionCountLabelDebounced.cancel();
					this.availableSuggestionCountAction.label = `${currentSuggestionIdx + 1}/${suggestionCount}`;
				} else {
					this.clearAvailableSuggestionCountLabelDebounced.schedule();
				}
				if (suggestionCount !== undefined && suggestionCount > 1) {
					this.disableButtonsDebounced.cancel();
					this.previousAction.enabled = this.nextAction.enabled = true;
				} else {
					this.disableButtonsDebounced.schedule();
				}
			})
		);
		this._register(
			autorun(reader => {
				const extraCommands = this._extraCommands.read(reader);
				const extraActions = extraCommands.map(c => ({
					class: undefined,
					id: c.id,
					enabled: true,
					tooltip: c.tooltip || '',
					label: c.title,
					run: event => {
						return this._commandService.executeCommand(c.id);
					}
				}));
				for (const [_, group] of this.inlineCompletionsActionsMenus.getActions()) {
					for (const action of group) {
						if (action instanceof MenuItemAction) {
							extraActions.push(action);
						}
					}
				}
				if (extraActions.length > 0) {
					extraActions.unshift(new Separator());
				}
				this.toolBar.setAdditionalSecondaryActions(extraActions);
			})
		);
	}
	getId() {
		return this.id;
	}
	getDomNode() {
		return this.nodes.root;
	}
	getPosition() {
		return {
			position: this._position.get(),
			preference: [
				1,
				2 // BELOW
			],
			positionAffinity: 3
		};
	}
}
InlineSuggestionHintsContentWidget._dropDownVisible = false;
InlineSuggestionHintsContentWidget.id = 0;
__decorate(
	[
		__param(6, ICommandService),
		__param(7, IInstantiationService),
		__param(8, IKeybindingService),
		__param(9, IContextKeyService),
		__param(10, IMenuService)
	],
	InlineSuggestionHintsContentWidget
);
class ActionViewItemWithClassName extends ActionViewItem {
	constructor() {
		super(...arguments);
		this._className = undefined;
	}
	setClass(className) {
		this._className = className;
	}
	render(container) {
		super.render(container);
		if (this._className) {
			container.classList.add(this._className);
		}
	}
	updateTooltip() {}
}
class StatusBarViewItem extends MenuEntryActionViewItem {
	updateLabel() {
		const kb = this._keybindingService.lookupKeybinding(this._action.id, this._contextKeyService);
		if (!kb) {
			return super.updateLabel();
		}
		if (this.label) {
			const div = h('div.keybinding').root;
			const k = this._register(
				new KeybindingLabel(div, OS, {
					disableTitle: true,
					...unthemedKeybindingLabelOptions
				})
			);
			k.set(kb);
			this.label.textContent = this._action.label;
			this.label.appendChild(div);
			this.label.classList.add('inlineSuggestionStatusBarItemLabel');
		}
	}
	updateTooltip() {}
}
class CustomizedMenuWorkbenchToolBar extends WorkbenchToolBar {
	constructor(container, menuId, options2, menuService, contextKeyService, contextMenuService, keybindingService, commandService) {
		super(
			container,
			{ resetMenu: menuId, ...options2 },
			menuService,
			contextKeyService,
			contextMenuService,
			keybindingService,
			commandService
		);
		this.menuId = menuId;
		this.options2 = options2;
		this.menuService = menuService;
		this.contextKeyService = contextKeyService;
		this.menu = this._store.add(
			this.menuService.createMenu(this.menuId, this.contextKeyService, {
				emitEventsForSubmenuChanges: true
			})
		);
		this.additionalActions = [];
		this.prependedPrimaryActions = [];
		this._store.add(this.menu.onDidChange(() => this.updateToolbar()));
		this.updateToolbar();
	}
	updateToolbar() {
		const primary = [];
		const secondary = [];
		createAndFillInActionBarActions(
			this.menu,
			this.options2?.menuOptions,
			{ primary, secondary },
			this.options2?.toolbarOptions?.primaryGroup,
			this.options2?.toolbarOptions?.shouldInlineSubmenu,
			this.options2?.toolbarOptions?.useSeparatorsInPrimaryActions
		);
		secondary.push(...this.additionalActions);
		primary.unshift(...this.prependedPrimaryActions);
		this.setActions(primary, secondary);
	}
	setPrependedPrimaryActions(actions) {
		if (equals(this.prependedPrimaryActions, actions, (a, b) => a === b)) {
			return;
		}
		this.prependedPrimaryActions = actions;
		this.updateToolbar();
	}
	setAdditionalSecondaryActions(actions) {
		if (equals(this.additionalActions, actions, (a, b) => a === b)) {
			return;
		}
		this.additionalActions = actions;
		this.updateToolbar();
	}
}
__decorate(
	[
		__param(3, IMenuService),
		__param(4, IContextKeyService),
		__param(5, IContextMenuService),
		__param(6, IKeybindingService),
		__param(7, ICommandService)
	],
	CustomizedMenuWorkbenchToolBar
);