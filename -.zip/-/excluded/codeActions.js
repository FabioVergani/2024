

const registerCodeActionProvider = (languageSelector, provider, metadata) => {
	return getService_LanguageFeatures().codeActionProvider.register(languageSelector, {
		providedCodeActionKinds: metadata?.providedCodeActionKinds,
		documentation: metadata?.documentation,
		provideCodeActions: (model, range, context, token) => {
			const markers = getService_Marker()
				.read({ resource: model.uri })
				.filter(m => {
					return Range.areIntersectingOrTouching(m, range);
				});
			return provider.provideCodeActions(model, range, { markers, only: context.only, trigger: context.trigger }, token);
		},
		resolveCodeAction: provider.resolveCodeAction
	});
};


class CodeActionKind4 {
	constructor() {
		this.QuickFix = new HierarchicalKind('quickfix');
		this.Refactor = new HierarchicalKind('refactor');
		this.RefactorExtract = this.Refactor.append('extract');
		this.RefactorInline = this.Refactor.append('inline');
		this.RefactorMove = this.Refactor.append('move');
		this.RefactorRewrite = this.Refactor.append('rewrite');
		this.Notebook = new HierarchicalKind('notebook');
		this.Source = new HierarchicalKind('source');
		this.SourceOrganizeImports = this.Source.append('organizeImports');
		this.SourceFixAll = this.Source.append('fixAll');
		this.SurroundWith = this.Refactor.append('surround');
	}
}
const codeActionKind4 = new CodeActionKind4();
const CodeActionTriggerSource = {
	Refactor: 'refactor',
	RefactorPreview: 'refactor preview',
	Lightbulb: 'lightbulb',
	Default: 'other (default)',
	SourceAction: 'source action',
	QuickFix: 'quick fix action',
	FixAll: 'fix all',
	OrganizeImports: 'organize imports',
	AutoFix: 'auto fix',
	QuickFixHover: 'quick fix hover window',
	OnSave: 'save participants',
	ProblemsView: 'problems view'
};

function mayIncludeActionsOfKind(filter, providedKind) {
	if (filter.include && !filter.include.intersects(providedKind)) {
		return false;
	}
	if (filter.excludes) {
		if (filter.excludes.some(exclude => excludesAction(providedKind, exclude, filter.include))) {
			return false;
		}
	}
	if (!filter.includeSourceActions && codeActionKind4.Source.contains(providedKind)) {
		return false;
	}
	return true;
}
function filtersAction(filter, action) {
	const actionKind = action.kind ? new HierarchicalKind(action.kind) : undefined;
	if (filter.include) {
		if (!actionKind || !filter.include.contains(actionKind)) {
			return false;
		}
	}
	if (filter.excludes) {
		if (actionKind && filter.excludes.some(exclude => excludesAction(actionKind, exclude, filter.include))) {
			return false;
		}
	}
	if (!filter.includeSourceActions) {
		if (actionKind && codeActionKind4.Source.contains(actionKind)) {
			return false;
		}
	}
	if (filter.onlyIncludePreferredActions) {
		if (!action.isPreferred) {
			return false;
		}
	}
	return true;
}
function excludesAction(providedKind, exclude, include) {
	if (!exclude.contains(providedKind)) {
		return false;
	}
	if (include && exclude.contains(include)) {
		return false;
	}
	return true;
}
class CodeActionCommandArgs {
	static fromUser(arg, defaults) {
		if (!arg || typeof arg !== 'object') {
			return new CodeActionCommandArgs(defaults.kind, defaults.apply, false);
		}
		return new CodeActionCommandArgs(
			CodeActionCommandArgs.getKindFromUser(arg, defaults.kind),
			CodeActionCommandArgs.getApplyFromUser(arg, defaults.apply),
			CodeActionCommandArgs.getPreferredUser(arg)
		);
	}
	static getApplyFromUser(arg, defaultAutoApply) {
		switch (typeof arg.apply === 'string' ? arg.apply.toLowerCase() : '') {
			case 'first':
				return 'first';
			case 'never':
				return 'never';
			case 'ifsingle':
				return 'ifSingle';
			default:
				return defaultAutoApply;
		}
	}
	static getKindFromUser(arg, defaultKind) {
		return typeof arg.kind === 'string' ? new HierarchicalKind(arg.kind) : defaultKind;
	}
	static getPreferredUser(arg) {
		return typeof arg.preferred === 'boolean' ? arg.preferred : false;
	}
	constructor(kind, apply2, preferred) {
		this.kind = kind;
		this.apply = apply2;
		this.preferred = preferred;
	}
}
class CodeActionItem {
	constructor(action, provider, highlightRange) {
		this.action = action;
		this.provider = provider;
		this.highlightRange = highlightRange;
	}
	async resolve(token) {
		if (this.provider?.resolveCodeAction && !this.action.edit) {
			let action;
			try {
				action = await this.provider.resolveCodeAction(this.action, token);
			} catch (err) {
				onUnexpectedExternalError(err);
			}
			if (action) {
				this.action.edit = action.edit;
			}
		}
		return this;
	}
}


var codeActionCommandId = 'editor.action.codeAction';
var quickFixCommandId = 'editor.action.quickFix';
var autoFixCommandId = 'editor.action.autoFix';
var refactorCommandId = 'editor.action.refactor';
var sourceActionCommandId = 'editor.action.sourceAction';
var organizeImportsCommandId = 'editor.action.organizeImports';
var fixAllCommandId = 'editor.action.fixAll';

class ManagedCodeActionSet extends Disposable {
	static codeActionsPreferredComparator(a, b) {
		if (a.isPreferred && !b.isPreferred) {
			return -1;
		} else if (!a.isPreferred && b.isPreferred) {
			return 1;
		} else {
			return 0;
		}
	}
	static codeActionsComparator({ action: a }, { action: b }) {
		if (a.isAI && !b.isAI) {
			return 1;
		} else if (!a.isAI && b.isAI) {
			return -1;
		}
		if (isArrayAndHasLength(a.diagnostics)) {
			return isArrayAndHasLength(b.diagnostics) ? ManagedCodeActionSet.codeActionsPreferredComparator(a, b) : -1;
		} else if (isArrayAndHasLength(b.diagnostics)) {
			return 1;
		} else {
			return ManagedCodeActionSet.codeActionsPreferredComparator(a, b);
		}
	}
	constructor(actions, documentation, disposables) {
		super();
		this.documentation = documentation;
		this._register(disposables);
		this.allActions = [...actions].sort(ManagedCodeActionSet.codeActionsComparator);
		this.validActions = this.allActions.filter(({ action }) => !action.disabled);
	}
	get hasAutoFix() {
		return this.validActions.some(
			({ action: fix }) => !!fix.kind && codeActionKind4.QuickFix.contains(new HierarchicalKind(fix.kind)) && !!fix.isPreferred
		);
	}
	get hasAIFix() {
		return this.validActions.some(({ action: fix }) => !!fix.isAI);
	}
	get allAIFixes() {
		return this.validActions.every(({ action: fix }) => !!fix.isAI);
	}
}
var emptyCodeActionsResponse = { actions: [], documentation: undefined };
async function getCodeActions(registry, model, rangeOrSelection, trigger, progress, token) {
	const filter = trigger.filter || {};
	const notebookFilter = {
		...filter,
		excludes: [...(filter.excludes || []), codeActionKind4.Notebook]
	};
	const codeActionContext = {
		only: filter.includ?.value,
		trigger: trigger.type
	};
	const cts = new TextModelCancellationTokenSource(model, token);
	const excludeNotebookCodeActions = trigger.type === 2;
	const providers = getCodeActionProviders(registry, model, excludeNotebookCodeActions ? notebookFilter : filter);
	const disposables = new DisposableStore();
	const promises = providers.map(async provider => {
		try {
			progress.report(provider);
			const providedCodeActions = await provider.provideCodeActions(model, rangeOrSelection, codeActionContext, cts.token);
			if (providedCodeActions) {
				disposables.add(providedCodeActions);
			}
			if (cts.token.isCancellationRequested) {
				return emptyCodeActionsResponse;
			}
			const filteredActions = (providedCodeActions?.actions || []).filter(action => action && filtersAction(filter, action));
			const documentation = getDocumentationFromProvider(provider, filteredActions, filter.include);
			return {
				actions: filteredActions.map(action => new CodeActionItem(action, provider)),
				documentation
			};
		} catch (err) {
			if (isCancellationError(err)) {
				throw err;
			}
			onUnexpectedExternalError(err);
			return emptyCodeActionsResponse;
		}
	});
	const listener = registry.onDidChange(() => {
		const newProviders = registry.all(model);
		if (!equals(newProviders, providers)) {
			cts.cancel();
		}
	});
	try {
		const actions = await Promise.all(promises);
		const allActions = actions.map(x => x.actions).flat();
		const allDocumentation = [
			...actions.map(x => x.documentation).filter(e => !!e),
			...getAdditionalDocumentationForShowingActions(registry, model, trigger, allActions)
		];
		return new ManagedCodeActionSet(allActions, allDocumentation, disposables);
	} finally {
		listener.dispose();
		cts.dispose();
	}
}
function getCodeActionProviders(registry, model, filter) {
	return registry.all(model).filter(provider => {
		if (!provider.providedCodeActionKinds) {
			return true;
		}
		return provider.providedCodeActionKinds.some(kind => mayIncludeActionsOfKind(filter, new HierarchicalKind(kind)));
	});
}
function* getAdditionalDocumentationForShowingActions(registry, model, trigger, actionsToShow) {
	if (model && actionsToShow.length) {
		for (const provider of registry.all(model)) {
			if (provider._getAdditionalMenuItems) {
				yield* provider._getAdditionalMenuItems?.call(
					provider,
					{
						trigger: trigger.type,
						only: trigger.filter?.include?.value
					},
					actionsToShow.map(item => item.action)
				);
			}
		}
	}
}
function getDocumentationFromProvider(provider, providedCodeActions, only) {
	if (!provider.documentation) {
		return;
	}
	const documentation = provider.documentation.map(entry => ({
		kind: new HierarchicalKind(entry.kind),
		command: entry.command
	}));
	if (only) {
		let currentBest;
		for (const entry of documentation) {
			if (entry.kind.contains(only)) {
				if (!currentBest) {
					currentBest = entry;
				} else {
					if (currentBest.kind.contains(entry.kind)) {
						currentBest = entry;
					}
				}
			}
		}
		if (currentBest) {
			return currentBest?.command;
		}
	}
	for (const action of providedCodeActions) {
		if (!action.kind) {
			continue;
		}
		for (const entry of documentation) {
			if (entry.kind.contains(new HierarchicalKind(action.kind))) {
				return entry.command;
			}
		}
	}
	return;
}

const ApplyCodeActionReason = {
	OnSave: 'onSave',
	FromProblemsView: 'fromProblemsView',
	FromCodeActions: 'fromCodeActions',
	FromAILightbulb: 'fromAILightbulb'
};

async function applyCodeAction(accessor, item, codeActionReason, options2, token = cancellationToken_none) {
	const bulkEditService = accessor.get(IBulkEditService);
	const commandService = accessor.get(ICommandService);

	const notificationService = accessor.get(INotificationService);

	await item.resolve(token);
	if (token.isCancellationRequested) {
		return;
	}
	if (item.action.edit?.edits.length) {
		const result = await bulkEditService.apply(item.action.edit, {
			editor: options2?.editor,
			label: item.action.title,
			quotableLabel: item.action.title,
			code: 'undoredo.codeAction',
			respectAutoSaveConfig: codeActionReason !== ApplyCodeActionReason.OnSave,
			showPreview: options2?.preview
		});
		if (!result.isApplied) {
			return;
		}
	}
	if (item.action.command) {
		try {
			await commandService.executeCommand(item.action.command.id, ...(item.action.command.arguments || []));
		} catch (err) {
			const message = asMessage(err);
			notificationService.error(
				typeof message === 'string' ? message : localize('An unknown error occurred while applying the code action')
			);
		}
	}
}
function asMessage(err) {
	if (typeof err === 'string') {
		return err;
	} else if (err instanceof Error && typeof err.message === 'string') {
		return err.message;
	} else {
		return;
	}
}
commandsRegistry.registerCommand(
	'_executeCodeActionProvider',
	async function (accessor, resource, rangeOrSelection, kind, itemResolveCount) {
		if (!(resource instanceof URI)) {
			throw illegalArgument();
		}
		const { codeActionProvider } = accessor.get(ILanguageFeaturesService);
		const model = accessor.get(IModelService).getModel(resource);
		if (!model) {
			throw illegalArgument();
		}
		const validatedRangeOrSelection = EditorSelection.isISelection(rangeOrSelection)
			? EditorSelection.liftSelection(rangeOrSelection)
			: Range.isIRange(rangeOrSelection)
				? model.validateRange(rangeOrSelection)
				: undefined;
		if (!validatedRangeOrSelection) {
			throw illegalArgument();
		}
		const include = typeof kind === 'string' ? new HierarchicalKind(kind) : undefined;
		const codeActionSet = await getCodeActions(
			codeActionProvider,
			model,
			validatedRangeOrSelection,
			{
				type: 1,
				triggerAction: CodeActionTriggerSource.Default,
				filter: { includeSourceActions: true, include }
			},
			Progress.None,
			cancellationToken_none
		);
		const resolving = [];
		const resolveCount = Math.min(codeActionSet.validActions.length, typeof itemResolveCount === 'number' ? itemResolveCount : 0);
		for (let i = 0; i < resolveCount; i++) {
			resolving.push(codeActionSet.validActions[i].resolve(cancellationToken_none));
		}
		try {
			await Promise.all(resolving);
			return codeActionSet.validActions.map(item => item.action);
		} finally {
			setTimeout(() => codeActionSet.dispose(), 100);
		}
	}
);


class CodeActionKeybindingResolver {
	constructor(keybindingService) {
		this.keybindingService = keybindingService;
	}
	getResolver() {
		const allCodeActionBindings = new Lazy(() =>
			this.keybindingService
				.getKeybindings()
				.filter(item => CodeActionKeybindingResolver.codeActionCommands.indexOf(item.command) >= 0)
				.filter(item => item.resolvedKeybinding)
				.map(item => {
					let commandArgs = item.commandArgs;
					if (item.command === organizeImportsCommandId) {
						commandArgs = {
							kind: codeActionKind4.SourceOrganizeImports.value
						};
					} else if (item.command === fixAllCommandId) {
						commandArgs = {
							kind: codeActionKind4.SourceFixAll.value
						};
					}
					return {
						resolvedKeybinding: item.resolvedKeybinding,
						...CodeActionCommandArgs.fromUser(commandArgs, {
							kind: HierarchicalKind.None,
							apply: 'never' // CodeActionAutoApply.Never
						})
					};
				})
		);
		return action => {
			if (action.kind) {
				return this.bestKeybindingForCodeAction(action, allCodeActionBindings.value)?.resolvedKeybinding;
			}
		};
	}
	bestKeybindingForCodeAction(action, candidates) {
		if (!action.kind) {
			return;
		}
		const kind = new HierarchicalKind(action.kind);
		return candidates
			.filter(candidate => candidate.kind.contains(kind))
			.filter(candidate => {
				if (candidate.preferred) {
					return action.isPreferred;
				}
				return true;
			})
			.reduceRight((currentBest, candidate) => {
				if (!currentBest) {
					return candidate;
				}
				return currentBest.kind.contains(candidate.kind) ? candidate : currentBest;
			}, undefined);
	}
}
CodeActionKeybindingResolver.codeActionCommands = [
	refactorCommandId,
	codeActionCommandId,
	sourceActionCommandId,
	organizeImportsCommandId,
	fixAllCommandId
];
__decorate([__param(0, IKeybindingService)], CodeActionKeybindingResolver);


var uncategorizedCodeActionGroup = freeze({
	kind: HierarchicalKind.Empty,
	title: localize('More Actions...')
});
var codeActionGroups = freeze([
	{ kind: codeActionKind4.QuickFix, title: localize('Quick Fix') },
	{
		kind: codeActionKind4.RefactorExtract,
		title: localize('Extract'),
		icon: codicon_wrench
	},
	{
		kind: codeActionKind4.RefactorInline,
		title: localize('Inline'),
		icon: codicon_wrench
	},
	{
		kind: codeActionKind4.RefactorRewrite,
		title: localize('Rewrite'),
		icon: codicon_wrench
	},
	{
		kind: codeActionKind4.RefactorMove,
		title: localize('Move'),
		icon: codicon_wrench
	},
	{
		kind: codeActionKind4.SurroundWith,
		title: localize('Surround With'),
		icon: codicon_surroundWith
	},
	{
		kind: codeActionKind4.Source,
		title: localize('Source Action'),
		icon: codicon_symbolFile
	},
	uncategorizedCodeActionGroup
]);
function toMenuItems(inputCodeActions, showHeaders, keybindingResolver) {
	if (!showHeaders) {
		return inputCodeActions.map(action => {
			return {
				kind: 'action',
				item: action,
				group: uncategorizedCodeActionGroup,
				disabled: !!action.action.disabled,
				label: action.action.disabled || action.action.title,
				canPreview: !!action.action.edit?.edits.length
			};
		});
	}
	const menuEntries = codeActionGroups.map(group => ({ group, actions: [] }));
	for (const action of inputCodeActions) {
		const kind = action.action.kind ? new HierarchicalKind(action.action.kind) : HierarchicalKind.None;
		for (const menuEntry of menuEntries) {
			if (menuEntry.group.kind.contains(kind)) {
				menuEntry.actions.push(action);
				break;
			}
		}
	}
	const allMenuItems = [];
	for (const menuEntry of menuEntries) {
		if (menuEntry.actions.length) {
			allMenuItems.push({ kind: 'header', group: menuEntry.group });
			for (const action of menuEntry.actions) {
				const group = menuEntry.group;
				allMenuItems.push({
					kind: 'action',
					item: action,
					group: action.action.isAI
						? {
								title: group.title,
								kind: group.kind,
								icon: codicon_sparkle
							}
						: group,
					label: action.action.title,
					disabled: !!action.action.disabled,
					keybinding: keybindingResolver(action.action)
				});
			}
		}
	}
	return allMenuItems;
}


class LightBulbWidget extends Disposable {
	constructor(_editor, _keybindingService, commandService) {
		super();
		this._editor = _editor;
		this._keybindingService = _keybindingService;
		this._onClick = this._register(new Emitter());
		this.onClick = this._onClick.event;
		this._state = {
			type: 0 // Hidden
		};
		this._iconClasses = [];
		this._domNode = createDomElement('div.lightBulbWidget');
		this._domNode.role = 'listbox';
		this._register(Gesture.ignoreTarget(this._domNode));
		this._editor.addContentWidget(this);
		this._register(
			this._editor.onDidChangeModelContent(_ => {
				const editorModel = this._editor.getModel();
				if (this.state.type !== 1 || !editorModel || this.state.editorPosition.lineNumber >= editorModel.getLineCount()) {
					this.hide();
				}
			})
		);
		this._register(
			addStandardDisposableGenericMouseDownListener(this._domNode, e => {
				if (this.state.type !== 1) {
					return;
				}
				this._editor.focus();
				e.preventDefault();
				const { top, height } = getDomNodePagePosition(this._domNode);
				const lineHeight = this._editor.getOption(
					67 // lineHeight
				);
				let pad = Math.floor(lineHeight / 3);
				if (
					this.state.widgetPosition.position !== null &&
					this.state.widgetPosition.position.lineNumber < this.state.editorPosition.lineNumber
				) {
					pad += lineHeight;
				}
				this._onClick.fire({
					x: e.posx,
					y: top + height + pad,
					actions: this.state.actions,
					trigger: this.state.trigger
				});
			})
		);
		this._register(
			addDisposableListener(this._domNode, 'mouseenter', e => {
				if ((e.buttons & 1) !== 1) {
					return;
				}
				this.hide();
			})
		);
		this._register(
			editorEventRunAndSubscribe(this._keybindingService.onDidUpdateKeybindings, () => {
				this._preferredKbLabel = this._keybindingService.lookupKeybinding(autoFixCommandId)?.getLabel();
				this._quickFixKbLabel = this._keybindingService.lookupKeybinding(quickFixCommandId)?.getLabel();
				this._updateLightBulbTitleAndIcon();
			})
		);
	}
	dispose() {
		super.dispose();
		this._editor.removeContentWidget(this);
	}
	getId() {
		return 'LightBulbWidget';
	}
	getDomNode() {
		return this._domNode;
	}
	getPosition() {
		return this._state.type === 1 ? this._state.widgetPosition : null;
	}
	update(actions, trigger, atPosition) {
		if (actions.validActions.length <= 0) {
			return this.hide();
		}
		const options2 = this._editor.getOptions();
		if (
			!options2.get(
				65 // lightbulb
			).enabled
		) {
			return this.hide();
		}
		const model = this._editor.getModel();
		if (!model) {
			return this.hide();
		}
		const { lineNumber, column } = model.validatePosition(atPosition);
		const tabSize = model.getOptions().tabSize;
		const fontInfo = this._editor.getOptions().get(
			50 // fontInfo
		);
		const lineContent = model.getLineContent(lineNumber);
		const indent = computeIndentLevel(lineContent, tabSize);
		const lineHasSpace = fontInfo.spaceWidth * indent > 22;
		const isFolded = lineNumber2 => {
			return lineNumber2 > 2 && this._editor.getTopForLineNumber(lineNumber2) === this._editor.getTopForLineNumber(lineNumber2 - 1);
		};
		let effectiveLineNumber = lineNumber;
		let effectiveColumnNumber = 1;
		if (!lineHasSpace) {
			if (lineNumber > 1 && !isFolded(lineNumber - 1)) {
				effectiveLineNumber -= 1;
			} else if (lineNumber < model.getLineCount() && !isFolded(lineNumber + 1)) {
				effectiveLineNumber += 1;
			} else if (column * fontInfo.spaceWidth < 22) {
				return this.hide();
			}
			effectiveColumnNumber = /^\S\s*$/.test(model.getLineContent(effectiveLineNumber)) ? 2 : 1;
		}
		this.state = {
			type: 1, //Showing
			actions: actions,
			trigger: trigger,
			editorPosition: atPosition,
			widgetPosition: {
				position: {
					lineNumber: effectiveLineNumber,
					column: effectiveColumnNumber
				},
				preference: LightBulbWidget._posPref
			}
		};
		this._editor.layoutContentWidget(this);
	}
	hide() {
		if (0 === this.state.type) {
			return;
		}
		this.state = {
			type: 0 // Hidden
		};
		this._editor.layoutContentWidget(this);
	}
	get state() {
		return this._state;
	}
	set state(value) {
		this._state = value;
		this._updateLightBulbTitleAndIcon();
	}
	_updateLightBulbTitleAndIcon() {
		this._domNode.classList.remove(...this._iconClasses);
		this._iconClasses = [];
		if (this.state.type !== 1) {
			return;
		}
		let icon;
		let autoRun = false;
		if (this.state.actions.allAIFixes) {
			icon = codicon_sparkleFilled;
			if (this.state.actions.validActions.length === 1) {
				autoRun = true;
			}
		} else if (this.state.actions.hasAutoFix) {
			if (this.state.actions.hasAIFix) {
				icon = codicon_lightbulbSparkleAutofix;
			} else {
				icon = codicon_lightbulbAutofix;
			}
		} else if (this.state.actions.hasAIFix) {
			icon = codicon_lightbulbSparkle;
		} else {
			icon = codicon_lightBulb;
		}
		this._updateLightbulbTitle(this.state.actions.hasAutoFix, autoRun);
		this._iconClasses = asThemeIconClassNameArray(icon);
		this._domNode.classList.add(...this._iconClasses);
	}
	_updateLightbulbTitle(autoFix, autoRun) {
		if (this.state.type !== 1) {
			return;
		}
		if (autoRun) {
			this.title = localize(this.state.actions.validActions[0].action.title);
		} else if (autoFix && this._preferredKbLabel) {
			this.title = localize('Show Code Actions. Preferred Quick Fix Available ({0})', this._preferredKbLabel);
		} else if (!autoFix && this._quickFixKbLabel) {
			this.title = localize(this._quickFixKbLabel);
		} else if (!autoFix) {
			this.title = localize('Show Code Actions');
		}
	}
	set title(value) {
		this._domNode.title = value;
	}
}
LightBulbWidget.ID = 'editor.contrib.lightbulbWidget';
LightBulbWidget._posPref = [
	0 // EXACT
];
__decorate([__param(1, IKeybindingService), __param(2, ICommandService)], LightBulbWidget);


var acceptSelectedActionCommand = 'acceptSelectedCodeAction';
var previewSelectedActionCommand = 'previewSelectedCodeAction';
class HeaderRenderer {
	get templateId() {
		return 'header';
	}
	renderTemplate(container) {
		container.classList.add('group-header');
		const text2 = document.createElement('span');
		container.append(text2);
		return { container, text: text2 };
	}
	renderElement(element, _index, templateData) {
		templateData.text.textContent = element.group?.title ?? '';
	}
	disposeTemplate(_templateData) {}
}
class ActionItemRenderer {
	get templateId() {
		return 'action';
	}
	constructor(_supportsPreview, _keybindingService) {
		this._supportsPreview = _supportsPreview;
		this._keybindingService = _keybindingService;
	}
	renderTemplate(container) {
		container.classList.add(this.templateId);
		const icon = document.createElement('div');
		icon.className = 'icon';
		container.append(icon);
		const text2 = document.createElement('span');
		text2.className = 'title';
		container.append(text2);
		const keybinding = new KeybindingLabel(container, OS);
		return { container, icon, text: text2, keybinding };
	}
	renderElement(element, _index, data) {
		if (element.group?.icon) {
			data.icon.className = asThemeIconClassNameString(element.group.icon);
			if (element.group.icon.color) {
				data.icon.style.color = asCssVariable(element.group.icon.color.id);
			}
		} else {
			data.icon.className = asThemeIconClassNameString(codicon_lightBulb);
			data.icon.style.color = 'var(--vscode-editorLightBulb-foreground)';
		}
		if (!element.item || !element.label) {
			return;
		}
		data.text.textContent = stripNewlines(element.label);
		data.keybinding.set(element.keybinding);
		setVisibility(!!element.keybinding, data.keybinding.element);
		const actionTitle = this._keybindingService.lookupKeybinding(acceptSelectedActionCommand)?.getLabel();
		const previewTitle = this._keybindingService.lookupKeybinding(previewSelectedActionCommand)?.getLabel();
		data.container.classList.toggle('option-disabled', element.disabled);
		if (element.disabled) {
			data.container.title = element.label;
		} else if (actionTitle && previewTitle) {
			if (this._supportsPreview && element.canPreview) {
				data.container.title = localize(actionTitle, previewTitle);
			} else {
				data.container.title = localize(actionTitle);
			}
		} else {
			data.container.title = '';
		}
	}
	disposeTemplate(_templateData) {
		_templateData.keybinding.dispose();
	}
}
__decorate([__param(1, IKeybindingService)], ActionItemRenderer);

class AcceptSelectedEvent extends UIEvent {
	constructor() {
		super('acceptSelectedAction');
	}
}
class PreviewSelectedEvent extends UIEvent {
	constructor() {
		super('previewSelectedAction');
	}
}
function getKeyboardNavigationLabel(item) {
	if (item.kind === 'action') {
		return item.label;
	}
	return;
}

class ActionList extends Disposable {
	constructor(user, preview, items, _delegate, _contextViewService, _keybindingService) {
		super();
		this._delegate = _delegate;
		this._contextViewService = _contextViewService;
		this._keybindingService = _keybindingService;
		this._actionLineHeight = 24;
		this._headerLineHeight = 26;
		this.cts = this._register(new CancellationTokenSource());
		this.domNode = document.createElement('div');
		this.domNode.classList.add('actionList');
		const virtualDelegate = {
			getHeight: element => (element.kind === 'header' ? this._headerLineHeight : this._actionLineHeight),
			getTemplateId: element => element.kind
		};
		this._list = this._register(
			new List(
				user,
				this.domNode,
				virtualDelegate,
				[new ActionItemRenderer(preview, this._keybindingService), new HeaderRenderer()],
				{
					keyboardSupport: false,
					typeNavigationEnabled: true,
					keyboardNavigationLabelProvider: {
						getKeyboardNavigationLabel
					}
				}
			)
		);
		this._list.style(defaultStyle_list);
		this._register(this._list.onMouseClick(e => this.onListClick(e)));
		this._register(this._list.onMouseOver(e => this.onListHover(e)));
		this._register(this._list.onDidChangeFocus(() => this.onFocus()));
		this._register(this._list.onDidChangeSelection(e => this.onListSelection(e)));
		this._allMenuItems = items;
		this._list.splice(0, this._list.length, this._allMenuItems);
		if (this._list.length) {
			this.focusNext();
		}
	}
	focusCondition(element) {
		return !element.disabled && element.kind === 'action';
	}
	hide(didCancel) {
		this._delegate.onHide(didCancel);
		this.cts.cancel();
		this._contextViewService.hideContextView();
	}
	layout(minWidth) {
		const numHeaders = this._allMenuItems.filter(item => item.kind === 'header').length;
		const itemsHeight = this._allMenuItems.length * this._actionLineHeight;
		const heightWithHeaders = itemsHeight + numHeaders * this._headerLineHeight - numHeaders * this._actionLineHeight;
		this._list.layout(heightWithHeaders);
		let maxWidth = minWidth;
		if (this._allMenuItems.length >= 50) {
			maxWidth = 380;
		} else {
			const itemWidths = this._allMenuItems.map((_, index) => {
				const element = this.domNode.ownerDocument.getElementById(this._list.getElementID(index));
				if (element) {
					element.style.width = 'auto';
					const width2 = element.getBoundingClientRect().width;
					element.style.width = '';
					return width2;
				}
				return 0;
			});
			maxWidth = Math.max(...itemWidths, minWidth);
		}
		const maxVhPrecentage = 0.7;
		const height = Math.min(heightWithHeaders, this.domNode.ownerDocument.body.clientHeight * maxVhPrecentage);
		this._list.layout(height, maxWidth);
		this.domNode.style.height = `${height}px`;
		this._list.domFocus();
		return maxWidth;
	}
	focusPrevious() {
		this._list.focusPrevious(1, true, undefined, this.focusCondition);
	}
	focusNext() {
		this._list.focusNext(1, true, undefined, this.focusCondition);
	}
	acceptSelected(preview) {
		const focused = this._list.getFocus();
		if (focused.length) {
			const focusIndex = focused[0];
			const element = this._list.element(focusIndex);
			if (!this.focusCondition(element)) {
				return;
			}
			const event = preview ? new PreviewSelectedEvent() : new AcceptSelectedEvent();
			this._list.setSelection([focusIndex], event);
		}
	}
	onListSelection(e) {
		if (e.elements.length) {
			const element = e.elements[0];
			if (element.item && this.focusCondition(element)) {
				this._delegate.onSelect(element.item, e.browserEvent instanceof PreviewSelectedEvent);
			} else {
				this._list.setSelection([]);
			}
		}
	}
	onFocus() {
		const focused = this._list.getFocus();
		if (focused.length) {
			const focusIndex = focused[0];
			const element = this._list.element(focusIndex);
			const e = this._delegate;
			e.onFocus?.call(e, element.item);
		}
	}
	async onListHover(e) {
		const element = e.element;
		if (element && element.item && this.focusCondition(element)) {
			if (this._delegate.onHover && !element.disabled && element.kind === 'action') {
				const result = await this._delegate.onHover(element.item, this.cts.token);
				element.canPreview = result ? result.canPreview : undefined;
			}
			if (e.index) {
				this._list.splice(e.index, 1, [element]);
			}
		}
		this._list.setFocus(typeof e.index === 'number' ? [e.index] : []);
	}
	onListClick(e) {
		if (e.element && this.focusCondition(e.element)) {
			this._list.setFocus([]);
		}
	}
}
__decorate([__param(4, IContextViewService), __param(5, IKeybindingService)], ActionList);
function stripNewlines(str) {
	return str.replace(lineBreakRE2, ' ');
}


var ActionWidgetContextKeys = {
	Visible: new RawContextKey('codeActionMenuVisible', false, localize('Whether the action widget list is visible'))
};
var IActionWidgetService = createEditorServiceDecorator('actionWidgetService');
class ActionWidgetService extends Disposable {
	get isVisible() {
		return ActionWidgetContextKeys.Visible.getValue(this._contextKeyService) || false;
	}
	constructor(_contextViewService, _contextKeyService, _instantiationService) {
		super();
		this._contextViewService = _contextViewService;
		this._contextKeyService = _contextKeyService;
		this._instantiationService = _instantiationService;
		this._list = this._register(new MutableDisposable());
	}
	show(user, supportsPreview, items, delegate, anchor, container, actionBarActions) {
		const visibleContext = ActionWidgetContextKeys.Visible.bindTo(this._contextKeyService);
		const list = this._instantiationService.createInstance(ActionList, user, supportsPreview, items, delegate);
		this._contextViewService.showContextView(
			{
				getAnchor: () => anchor,
				render: container2 => {
					visibleContext.set(true);
					return this._renderWidget(
						container2,
						list,
						actionBarActions !== null && actionBarActions !== undefined ? actionBarActions : []
					);
				},
				onHide: didCancel => {
					visibleContext.reset();
					this._onWidgetClosed(didCancel);
				}
			},
			container,
			false
		);
	}
	acceptSelected(preview) {
		this._list.value?.acceptSelected(preview);
	}
	focusPrevious() {
		this._list?.value?.focusPrevious();
	}
	focusNext() {
		this._list?.value?.focusNext();
	}
	hide(didCancel) {
		this._list.value?.hide(didCancel);
		this._list.clear();
	}
	_renderWidget(element, list, actionBarActions) {
		const widget = document.createElement('div');
		widget.classList.add('action-widget');
		element.appendChild(widget);
		this._list.value = list;
		if (this._list.value) {
			widget.appendChild(this._list.value.domNode);
		} else {
			throw new Error('List has no value');
		}
		const renderDisposables = new DisposableStore();
		const menuBlock = document.createElement('div');
		const block = element.appendChild(menuBlock);
		block.classList.add('context-view-block');
		renderDisposables.add(addDisposableListener(block, EventType.MOUSE_DOWN, e => e.stopPropagation()));
		const pointerBlockDiv = document.createElement('div');
		const pointerBlock = element.appendChild(pointerBlockDiv);
		pointerBlock.classList.add('context-view-pointerBlock');
		renderDisposables.add(addDisposableListener(pointerBlock, EventType.POINTER_MOVE, () => pointerBlock.remove()));
		renderDisposables.add(addDisposableListener(pointerBlock, EventType.MOUSE_DOWN, () => pointerBlock.remove()));
		let actionBarWidth = 0;
		if (actionBarActions.length) {
			const actionBar = this._createActionBar('.action-widget-action-bar', actionBarActions);
			if (actionBar) {
				widget.appendChild(actionBar.getContainer().parentElement);
				renderDisposables.add(actionBar);
				actionBarWidth = actionBar.getContainer().offsetWidth;
			}
		}
		const width2 = this._list.value?.layout(actionBarWidth);
		widget.style.width = `${width2}px`;
		const focusTracker = renderDisposables.add(trackFocus(element));
		renderDisposables.add(focusTracker.onDidBlur(() => this.hide(true)));
		return renderDisposables;
	}
	_createActionBar(className, actions) {
		if (!actions.length) {
			return;
		}
		const container = createDomElement(className);
		const actionBar = new ActionBar(container);
		actionBar.push(actions, { icon: false, label: true });
		return actionBar;
	}
	_onWidgetClosed(didCancel) {
		this._list.value?.hide(didCancel);
	}
}
__decorate([__param(0, IContextViewService), __param(1, IContextKeyService), __param(2, IInstantiationService)], ActionWidgetService);
registerSingleton(
	IActionWidgetService,
	ActionWidgetService,
	1 // Delayed
);

var weight = 100 + 1e3;
registerEditorAction2(
	class extends Action2 {
		constructor() {
			super({
				id: 'hideCodeActionWidget',
				title: localize('Hide action widget'),
				precondition: ActionWidgetContextKeys.Visible,
				keybinding: {
					weight,
					primary: 9,
					secondary: [
						1024 | 9 // Escape
					]
				}
			});
		}
		run(accessor) {
			accessor.get(IActionWidgetService).hide(true);
		}
	}
);
registerEditorAction2(
	class extends Action2 {
		constructor() {
			super({
				id: 'selectPrevCodeAction',
				title: localize('Select previous action'),
				precondition: ActionWidgetContextKeys.Visible,
				keybinding: {
					weight,
					primary: 16,
					secondary: [
						2048 | 16 // UpArrow
					],
					mac: {
						primary: 16,
						secondary: [
							2048 | 16,
							256 | 46 // KeyP
						]
					}
				}
			});
		}
		run(accessor) {
			const widgetService = accessor.get(IActionWidgetService);
			if (widgetService instanceof ActionWidgetService) {
				widgetService.focusPrevious();
			}
		}
	}
);
registerEditorAction2(
	class extends Action2 {
		constructor() {
			super({
				id: 'selectNextCodeAction',
				title: localize('Select next action'),
				precondition: ActionWidgetContextKeys.Visible,
				keybinding: {
					weight,
					primary: 18,
					secondary: [
						2048 | 18 // DownArrow
					],
					mac: {
						primary: 18,
						secondary: [
							2048 | 18,
							256 | 44 // KeyN
						]
					}
				}
			});
		}
		run(accessor) {
			const widgetService = accessor.get(IActionWidgetService);
			if (widgetService instanceof ActionWidgetService) {
				widgetService.focusNext();
			}
		}
	}
);
registerEditorAction2(
	class extends Action2 {
		constructor() {
			super({
				id: acceptSelectedActionCommand,
				title: localize('Accept selected action'),
				precondition: ActionWidgetContextKeys.Visible,
				keybinding: {
					weight,
					primary: 3,
					secondary: [
						2048 | 89 // Period
					]
				}
			});
		}
		run(accessor) {
			const widgetService = accessor.get(IActionWidgetService);
			if (widgetService instanceof ActionWidgetService) {
				widgetService.acceptSelected();
			}
		}
	}
);
registerEditorAction2(
	class extends Action2 {
		constructor() {
			super({
				id: previewSelectedActionCommand,
				title: localize('Preview selected action'),
				precondition: ActionWidgetContextKeys.Visible,
				keybinding: { weight, primary: 2048 | 3 }
			});
		}
		run(accessor) {
			const widgetService = accessor.get(IActionWidgetService);
			if (widgetService instanceof ActionWidgetService) {
				widgetService.acceptSelected(true);
			}
		}
	}
);


var SUPPORTED_CODE_ACTIONS = new RawContextKey('supportedCodeAction', '');
var APPLY_FIX_ALL_COMMAND_ID = '_typescript.applyFixAllCodeAction';
class CodeActionOracle extends Disposable {
	constructor(_editor, _markerService, _signalChange, _delay = 250) {
		super();
		this._editor = _editor;
		this._markerService = _markerService;
		this._signalChange = _signalChange;
		this._delay = _delay;
		this._autoTriggerTimer = this._register(new TimeoutTimer());
		this._register(this._markerService.onMarkerChanged(e => this._onMarkerChanges(e)));
		this._register(this._editor.onDidChangeCursorPosition(() => this._tryAutoTrigger()));
	}
	trigger(trigger) {
		const selection = this._getRangeOfSelectionUnlessWhitespaceEnclosed(trigger);
		this._signalChange(selection ? { trigger, selection } : undefined);
	}
	_onMarkerChanges(resources) {
		const model = this._editor.getModel();
		if (model && resources.some(resource => isEqual(resource, model.uri))) {
			this._tryAutoTrigger();
		}
	}
	_tryAutoTrigger() {
		this._autoTriggerTimer.cancelAndSet(() => {
			this.trigger({
				type: 2,
				triggerAction: CodeActionTriggerSource.Default
			});
		}, this._delay);
	}
	_getRangeOfSelectionUnlessWhitespaceEnclosed(trigger) {
		if (!this._editor.hasModel()) {
			return;
		}
		const selection = this._editor.getSelection();
		if (trigger.type === 1) {
			return selection;
		}
		const enabled = this._editor.getOption(
			65 // lightbulb
		).enabled;
		if (enabled === 'off') {
			return;
		} else if (enabled === 'on') {
			return selection;
		} else if (enabled === 'onCode') {
			const isSelectionEmpty = selection.isEmpty();
			if (!isSelectionEmpty) {
				return selection;
			}
			const model = this._editor.getModel();
			const { lineNumber, column } = selection.getPosition();
			const line = model.getLineContent(lineNumber);
			if (line.length === 0) {
				return;
			} else if (column === 1) {
				if (/\s/.test(line[0])) {
					return;
				}
			} else if (column === model.getLineMaxColumn(lineNumber)) {
				if (/\s/.test(line[line.length - 1])) {
					return;
				}
			} else {
				if (/\s/.test(line[column - 2]) && /\s/.test(line[column - 1])) {
					return;
				}
			}
		}
		return selection;
	}
}
class Triggered {
	constructor(trigger, position, _cancellablePromise) {
		this.trigger = trigger;
		this.position = position;
		this._cancellablePromise = _cancellablePromise;
		this.type = 1;
		this.actions = _cancellablePromise.catch(e => {
			if (isCancellationError(e)) {
				return emptyCodeActionSet;
			}
			throw e;
		});
	}
	cancel() {
		this._cancellablePromise.cancel();
	}
}
var emptyCodeActionSet = freeze({
	allActions: [],
	validActions: [],
	dispose: dummyArrowFn,
	documentation: [],
	hasAutoFix: false,
	hasAIFix: false,
	allAIFixes: false
});
class CodeActionModel extends Disposable {
	constructor(_editor, _registry2, _markerService, contextKeyService, _progressService, _configurationService) {
		super();
		this._editor = _editor;
		this._registry = _registry2;
		this._markerService = _markerService;
		this._progressService = _progressService;
		this._configurationService = _configurationService;
		this._codeActionOracle = this._register(new MutableDisposable());
		this._state = {
			type: 0 //Empty
		};
		this._onDidChangeState = this._register(new Emitter());
		this.onDidChangeState = this._onDidChangeState.event;
		this._disposed = false;
		this._supportedCodeActions = SUPPORTED_CODE_ACTIONS.bindTo(contextKeyService);
		this._register(this._editor.onDidChangeModel(() => this._update()));
		this._register(this._editor.onDidChangeModelLanguage(() => this._update()));
		this._register(this._registry.onDidChange(() => this._update()));
		this._register(
			this._editor.onDidChangeConfiguration(e => {
				if (
					e.hasChanged(
						65 // lightbulb
					)
				) {
					this._update();
				}
			})
		);
		this._update();
	}
	dispose() {
		if (this._disposed) {
			return;
		}
		this._disposed = true;
		super.dispose();
		this.setState(
			{
				type: 0 //Empty
			},
			true
		);
	}
	_settingEnabledNearbyQuickfixes() {
		const model = this._editor?.getModel();
		return this._configurationService
			? this._configurationService.getValue('editor.codeActionWidget.includeNearbyQuickFixes', { resource: model?.uri })
			: false;
	}
	_update() {
		if (this._disposed) {
			return;
		}
		this._codeActionOracle.value = undefined;
		this.setState({
			type: 0 //Empty
		});
		const model = this._editor.getModel();
		if (
			model &&
			this._registry.has(model) &&
			!this._editor.getOption(
				91 // readOnly
			)
		) {
			const supportedActions = this._registry.all(model).flatMap(provider => {
				return provider.providedCodeActionKinds || [];
			});
			this._supportedCodeActions.set(supportedActions.join(' '));
			this._codeActionOracle.value = new CodeActionOracle(
				this._editor,
				this._markerService,
				trigger => {
					if (!trigger) {
						this.setState({
							type: 0 //Empty
						});
						return;
					}
					const startPosition = trigger.selection.getStartPosition();
					const actions = createCancelablePromise(async token => {
						if (
							this._settingEnabledNearbyQuickfixes() &&
							trigger.trigger.type === 1 &&
							(trigger.trigger.triggerAction === CodeActionTriggerSource.QuickFix ||
								trigger.trigger.filter?.include?.contains(codeActionKind4.QuickFix))
						) {
							const codeActionSet = await getCodeActions(
								this._registry,
								model,
								trigger.selection,
								trigger.trigger,
								Progress.None,
								token
							);
							const allCodeActions = [...codeActionSet.allActions];
							if (token.isCancellationRequested) {
								return emptyCodeActionSet;
							}
							const foundQuickfix = codeActionSet.validActions?.some(action =>
								action.action.kind ? codeActionKind4.QuickFix.contains(new HierarchicalKind(action.action.kind)) : false
							);
							const allMarkers = this._markerService.read({
								resource: model.uri
							});
							if (foundQuickfix) {
								for (const action of codeActionSet.validActions) {
									if (
										action.action.command?.arguments?.some(
											arg => typeof arg === 'string' && arg.includes(APPLY_FIX_ALL_COMMAND_ID)
										)
									) {
										action.action.diagnostics = [...allMarkers.filter(marker => marker.relatedInformation)];
									}
								}
								return {
									validActions: codeActionSet.validActions,
									allActions: allCodeActions,
									documentation: codeActionSet.documentation,
									hasAutoFix: codeActionSet.hasAutoFix,
									hasAIFix: codeActionSet.hasAIFix,
									allAIFixes: codeActionSet.allAIFixes,
									dispose: () => {
										codeActionSet.dispose();
									}
								};
							} else if (!foundQuickfix) {
								if (allMarkers.length > 0) {
									const currPosition = trigger.selection.getPosition();
									let trackedPosition = currPosition;
									let distance = Number.MAX_VALUE;
									const currentActions = [...codeActionSet.validActions];
									for (const marker of allMarkers) {
										const col = marker.endColumn;
										const row = marker.endLineNumber;
										const startRow = marker.startLineNumber;
										if (row === currPosition.lineNumber || startRow === currPosition.lineNumber) {
											trackedPosition = new Position(row, col);
											const newCodeActionTrigger = {
												type: trigger.trigger.type,
												triggerAction: trigger.trigger.triggerAction,
												filter: {
													include: trigger.trigger.filter?.include
														? trigger.trigger.filter?.include
														: codeActionKind4.QuickFix
												},
												autoApply: trigger.trigger.autoApply,
												context: {
													notAvailableMessage: trigger.trigger.context?.notAvailableMessage || '',
													position: trackedPosition
												}
											};
											const selectionAsPosition = new EditorSelection(
												trackedPosition.lineNumber,
												trackedPosition.column,
												trackedPosition.lineNumber,
												trackedPosition.column
											);
											const actionsAtMarker = await getCodeActions(
												this._registry,
												model,
												selectionAsPosition,
												newCodeActionTrigger,
												Progress.None,
												token
											);
											if (actionsAtMarker.validActions.length !== 0) {
												for (const action of actionsAtMarker.validActions) {
													if (
														action.action.command?.arguments?.some(
															arg => typeof arg === 'string' && arg.includes(APPLY_FIX_ALL_COMMAND_ID)
														)
													) {
														action.action.diagnostics = [
															...allMarkers.filter(marker2 => marker2.relatedInformation)
														];
													}
												}
												if (codeActionSet.allActions.length === 0) {
													allCodeActions.push(...actionsAtMarker.allActions);
												}
												if (Math.abs(currPosition.column - col) < distance) {
													currentActions.unshift(...actionsAtMarker.validActions);
												} else {
													currentActions.push(...actionsAtMarker.validActions);
												}
											}
											distance = Math.abs(currPosition.column - col);
										}
									}
									const filteredActions = currentActions.filter(
										(action, index, self2) => self2.findIndex(a => a.action.title === action.action.title) === index
									);
									filteredActions.sort((a, b) => {
										if (a.action.isPreferred && !b.action.isPreferred) {
											return -1;
										} else if (!a.action.isPreferred && b.action.isPreferred) {
											return 1;
										} else if (a.action.isAI && !b.action.isAI) {
											return 1;
										} else if (!a.action.isAI && b.action.isAI) {
											return -1;
										} else {
											return 0;
										}
									});
									return {
										validActions: filteredActions,
										allActions: allCodeActions,
										documentation: codeActionSet.documentation,
										hasAutoFix: codeActionSet.hasAutoFix,
										hasAIFix: codeActionSet.hasAIFix,
										allAIFixes: codeActionSet.allAIFixes,
										dispose: () => {
											codeActionSet.dispose();
										}
									};
								}
							}
						}
						return getCodeActions(this._registry, model, trigger.selection, trigger.trigger, Progress.None, token);
					});
					if (trigger.trigger.type === 1) {
						this._progressService?.showWhile(actions, 250);
					}
					const newState = new Triggered(trigger.trigger, startPosition, actions);
					let isManualToAutoTransition = false;
					if (this._state.type === 1) {
						isManualToAutoTransition =
							this._state.trigger.type === 1 &&
							newState.type === 1 &&
							newState.trigger.type === 2 &&
							this._state.position !== newState.position;
					}
					if (!isManualToAutoTransition) {
						this.setState(newState);
					} else {
						setTimeout(() => {
							this.setState(newState);
						}, 500);
					}
				},
				undefined
			);
			this._codeActionOracle.value.trigger({
				type: 2,
				triggerAction: CodeActionTriggerSource.Default
			});
		} else {
			this._supportedCodeActions.reset();
		}
	}
	trigger(trigger) {
		this._codeActionOracle.value?.trigger(trigger);
	}
	setState(newState, skipNotify) {
		if (newState === this._state) {
			return;
		}
		if (this._state.type === 1) {
			this._state.cancel();
		}
		this._state = newState;
		if (!skipNotify && !this._disposed) {
			this._onDidChangeState.fire(newState);
		}
	}
}

var DECORATION_CLASS_NAME = 'quickfix-edit-highlight';
class CodeActionController extends Disposable {
	static get(editor2) {
		return editor2.getContribution(CodeActionController.ID);
	}
	constructor(
		editor2,
		markerService,
		contextKeyService,
		instantiationService,
		languageFeaturesService,
		progressService,
		_commandService,
		_configurationService,
		_actionWidgetService,
		_instantiationService
	) {
		super();
		this._commandService = _commandService;
		this._configurationService = _configurationService;
		this._actionWidgetService = _actionWidgetService;
		this._instantiationService = _instantiationService;
		this._activeCodeActions = this._register(new MutableDisposable());
		this._showDisabled = false;
		this._disposed = false;
		this._editor = editor2;
		this._model = this._register(
			new CodeActionModel(
				this._editor,
				languageFeaturesService.codeActionProvider,
				markerService,
				contextKeyService,
				progressService,
				_configurationService
			)
		);
		this._register(this._model.onDidChangeState(newState => this.update(newState)));
		this._lightBulbWidget = new Lazy(() => {
			const widget = this._editor.getContribution(LightBulbWidget.ID);
			if (widget) {
				this._register(widget.onClick(e => this.showCodeActionsFromLightbulb(e.actions, e)));
			}
			return widget;
		});
		this._resolver = instantiationService.createInstance(CodeActionKeybindingResolver);
		this._register(this._editor.onDidLayoutChange(() => this._actionWidgetService.hide()));
	}
	dispose() {
		this._disposed = true;
		super.dispose();
	}
	async showCodeActionsFromLightbulb(actions, at) {
		if (actions.allAIFixes && actions.validActions.length === 1) {
			const actionItem = actions.validActions[0];
			const command = actionItem.action.command;
			if (command && command.id === 'inlineChat.start') {
				if (command.arguments && command.arguments.length >= 1) {
					command.arguments[0] = {
						...command.arguments[0],
						autoSend: false
					};
				}
			}
			await this._applyCodeAction(actionItem, false, false, ApplyCodeActionReason.FromAILightbulb);
			return;
		}
		await this.showCodeActionList(actions, at, {
			includeDisabledActions: false,
			fromLightbulb: true
		});
	}
	showCodeActions(_trigger, actions, at) {
		return this.showCodeActionList(actions, at, {
			includeDisabledActions: false,
			fromLightbulb: false
		});
	}
	manualTriggerAtCurrentPosition(notAvailableMessage, triggerAction, filter, autoApply) {
		if (this._editor.hasModel()) {
			MessageController.get(this._editor)?.closeMessage();
			const triggerPosition = this._editor.getPosition();
			this._trigger({
				type: 1,
				triggerAction,
				filter,
				autoApply,
				context: { notAvailableMessage, position: triggerPosition }
			});
		}
	}
	_trigger(trigger) {
		return this._model.trigger(trigger);
	}
	async _applyCodeAction(action, retrigger, preview, actionReason) {
		try {
			await this._instantiationService.invokeFunction(applyCodeAction, action, actionReason, {
				preview,
				editor: this._editor
			});
		} finally {
			if (retrigger) {
				this._trigger({
					type: 2,
					triggerAction: CodeActionTriggerSource.QuickFix,
					filter: {}
				});
			}
		}
	}
	async update(newState) {
		if (newState.type !== 1) {
			this._lightBulbWidget.rawValue?.hide();
			return;
		}
		let actions;
		try {
			actions = await newState.actions;
		} catch (e) {
			onUnexpectedError(e);
			return;
		}
		if (this._disposed) {
			return;
		}
		this._lightBulbWidget.value?.update(actions, newState.trigger, newState.position);
		if (newState.trigger.type === 1) {
			if (newState.trigger.filter?.include) {
				const validActionToApply = this.tryGetValidActionToApply(newState.trigger, actions);
				if (validActionToApply) {
					try {
						this._lightBulbWidget.value?.hide();
						await this._applyCodeAction(validActionToApply, false, false, ApplyCodeActionReason.FromCodeActions);
					} finally {
						actions.dispose();
					}
					return;
				}
				if (newState.trigger.context) {
					const invalidAction = this.getInvalidActionThatWouldHaveBeenApplied(newState.trigger, actions);
					if (invalidAction && invalidAction.action.disabled) {
						MessageController.get(this._editor)?.showMessage(invalidAction.action.disabled, newState.trigger.context.position);
						actions.dispose();
						return;
					}
				}
			}
			const includeDisabledActions = !!newState.trigger.filter?.include;
			if (newState.trigger.context) {
				if (!actions.allActions.length || (!includeDisabledActions && !actions.validActions.length)) {
					MessageController.get(this._editor)?.showMessage(
						newState.trigger.context.notAvailableMessage,
						newState.trigger.context.position
					);
					this._activeCodeActions.value = actions;
					actions.dispose();
					return;
				}
			}
			this._activeCodeActions.value = actions;
			await this.showCodeActionList(actions, this.toCoords(newState.position), {
				includeDisabledActions,
				fromLightbulb: false
			});
		} else {
			if (this._actionWidgetService.isVisible) {
				actions.dispose();
			} else {
				this._activeCodeActions.value = actions;
			}
		}
	}
	getInvalidActionThatWouldHaveBeenApplied(trigger, actions) {
		if (!actions.allActions.length) {
			if (
				(trigger.autoApply === 'first' && actions.validActions.length === 0) ||
				(trigger.autoApply === 'ifSingle' && actions.allActions.length === 1)
			) {
				return actions.allActions.find(({ action }) => action.disabled);
			}
		}
	}
	tryGetValidActionToApply(trigger, actions) {
		if (actions.validActions.length) {
			if (
				(trigger.autoApply === 'first' && actions.validActions.length > 0) ||
				(trigger.autoApply === 'ifSingle' && actions.validActions.length === 1)
			) {
				return actions.validActions[0];
			}
		}
	}
	async showCodeActionList(actions, at, options2) {
		const currentDecorations = this._editor.createDecorationsCollection();
		const editorDom = this._editor.getDomNode();
		if (!editorDom) {
			return;
		}
		const actionsToShow =
			options2.includeDisabledActions && (this._showDisabled || actions.validActions.length === 0)
				? actions.allActions
				: actions.validActions;
		if (!actionsToShow.length) {
			return;
		}
		const anchor = Position.isIPosition(at) ? this.toCoords(at) : at;
		const delegate = {
			onSelect: async (action, preview) => {
				await this._applyCodeAction(
					action,
					true,
					!!preview,
					options2.fromLightbulb ? ApplyCodeActionReason.FromAILightbulb : ApplyCodeActionReason.FromCodeActions
				);
				this._actionWidgetService.hide(false);
				currentDecorations.clear();
			},
			onHide: didCancel => {
				this._editor?.focus();
				currentDecorations.clear();
			},
			onHover: async (action, token) => {
				if (!token.isCancellationRequested) {
					let canPreview = false;
					const actionKind = action.action.kind;
					if (actionKind) {
						const hierarchicalKind = new HierarchicalKind(actionKind);
						const refactorKinds = [
							codeActionKind4.RefactorExtract,
							codeActionKind4.RefactorInline,
							codeActionKind4.RefactorRewrite,
							codeActionKind4.RefactorMove,
							codeActionKind4.Source
						];
						canPreview = refactorKinds.some(refactorKind => refactorKind.contains(hierarchicalKind));
					}
					return {
						canPreview: canPreview || !!action.action.edit?.edits.length
					};
				}
			},
			onFocus: action => {
				if (action && action.action) {
					const ranges = action.action.ranges;
					const diagnostics = action.action.diagnostics;
					currentDecorations.clear();
					if (ranges && ranges.length > 0) {
						const decorations =
							diagnostics && diagnostics?.length > 1
								? diagnostics.map(diagnostic => ({
										range: diagnostic,
										options: CodeActionController.DECORATION
									}))
								: ranges.map(range2 => ({
										range: range2,
										options: CodeActionController.DECORATION
									}));
						currentDecorations.set(decorations);
					} else if (diagnostics && diagnostics.length > 0) {
						const decorations = diagnostics.map(diagnostic2 => ({
							range: diagnostic2,
							options: CodeActionController.DECORATION
						}));
						currentDecorations.set(decorations);
					}
				} else {
					currentDecorations.clear();
				}
			}
		};
		this._actionWidgetService.show(
			'codeActionWidget',
			true,
			toMenuItems(actionsToShow, this._shouldShowHeaders(), this._resolver.getResolver()),
			delegate,
			anchor,
			editorDom,
			this._getActionBarActions(actions, at, options2)
		);
	}
	toCoords(position) {
		if (!this._editor.hasModel()) {
			return { x: 0, y: 0 };
		}
		this._editor.revealPosition(
			position,
			1 // Immediate
		);
		this._editor.render();
		const cursorCoords = this._editor.getScrolledVisiblePosition(position);
		const editorCoords = getDomNodePagePosition(this._editor.getDomNode());
		const x = editorCoords.left + cursorCoords.left;
		const y = editorCoords.top + cursorCoords.top + cursorCoords.height;
		return { x, y };
	}
	_shouldShowHeaders() {
		const model = this._editor?.getModel();
		return this._configurationService.getValue('editor.codeActionWidget.showHeaders', { resource: model?.uri });
	}
	_getActionBarActions(actions, at, options2) {
		if (options2.fromLightbulb) {
			return [];
		}
		const resultActions = actions.documentation.map(command => {
			return {
				id: command.id,
				label: command.title,
				tooltip: command.tooltip || '',
				class: undefined,
				enabled: true,
				run: () => {
					return this._commandService.executeCommand(command.id, ...(command.arguments || []));
				}
			};
		});
		if (
			options2.includeDisabledActions &&
			actions.validActions.length > 0 &&
			actions.allActions.length !== actions.validActions.length
		) {
			resultActions.push(
				this._showDisabled
					? {
							id: 'hideMoreActions',
							label: localize('Hide Disabled'),
							enabled: true,
							tooltip: '',
							class: undefined,
							run: () => {
								this._showDisabled = false;
								return this.showCodeActionList(actions, at, options2);
							}
						}
					: {
							id: 'showMoreActions',
							label: localize('Show Disabled'),
							enabled: true,
							tooltip: '',
							class: undefined,
							run: () => {
								this._showDisabled = true;
								return this.showCodeActionList(actions, at, options2);
							}
						}
			);
		}
		return resultActions;
	}
}
CodeActionController.ID = 'editor.contrib.codeActionController';
CodeActionController.DECORATION = ModelDecorationOptions.register({
	description: 'quickfix-highlight',
	className: DECORATION_CLASS_NAME
});
__decorate(
	[
		__param(1, IMarkerService),
		__param(2, IContextKeyService),
		__param(3, IInstantiationService),
		__param(4, ILanguageFeaturesService),
		__param(5, IEditorProgressService),
		__param(6, ICommandService),
		__param(7, IConfigurationService),
		__param(8, IActionWidgetService),
		__param(9, IInstantiationService)
	],
	CodeActionController
);
registerThemingParticipant((theme, collector) => {
	const addBackgroundColorRule = (selector, color) => {
		if (color) {
			collector.addRule(`.monaco-editor ${selector} { background-color: ${color}; }`);
		}
	};
	addBackgroundColorRule('.quickfix-edit-highlight', theme.getColor(colorId_findMatchHighlight_background));
	const findMatchHighlightBorder = theme.getColor(colorId_findMatchHighlight_border);
	if (findMatchHighlightBorder) {
		collector.addRule(
			`.monaco-editor .quickfix-edit-highlight { border: 1px ${isHighContrast(theme.type) ? 'dotted' : 'solid'} ${findMatchHighlightBorder}; box-sizing: border-box; }`
		);
	}
});


function contextKeyForSupportedActions(kind) {
	return ContextKeyExpr.regex(SUPPORTED_CODE_ACTIONS.keys()[0], new RegExp('(\\s|^)' + escapeRegexChars(kind.value) + '\\b'));
}
var argsSchema = {
	type: 'object',
	defaultSnippets: [{ body: { kind: '' } }],
	properties: {
		kind: { type: 'string' },
		apply: {
			type: 'string',
			default: 'ifSingle',
			enum: ['first', 'ifSingle', 'never'],
			enumDescriptions: [
				localize('Always apply the first returned code action.'),
				localize('Apply the first returned code action if it is the only one.'),
				localize('Do not apply the returned code actions.')
			]
		},
		preferred: { type: 'boolean', default: false }
	}
};
function triggerCodeActionsForEditorSelection(
	editor2,
	notAvailableMessage,
	filter,
	autoApply,
	triggerAction = CodeActionTriggerSource.Default
) {
	if (editor2.hasModel()) {
		const controller = CodeActionController.get(editor2);
		controller === null || controller === undefined
			? undefined
			: controller.manualTriggerAtCurrentPosition(notAvailableMessage, triggerAction, filter, autoApply);
	}
}
class QuickFixAction extends EditorAction {
	constructor() {
		super({
			id: quickFixCommandId,
			label: localize('Quick Fix...'),
			alias: 'Quick Fix...',
			precondition: ContextKeyExpr.and(ck_writable, ck_editorHasProvider_codeActions),
			kbOpts: {
				kbExpr: ck_inputFocus_text,
				primary: 2048 | 89,
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2) {
		return triggerCodeActionsForEditorSelection(
			editor2,
			localize('No code actions available'),
			undefined,
			undefined,
			CodeActionTriggerSource.QuickFix
		);
	}
}
registerEditorAction(QuickFixAction);


class RefactorAction extends EditorAction {
	constructor() {
		super({
			id: refactorCommandId,
			label: localize('Refactor...'),
			alias: 'Refactor...',
			precondition: ContextKeyExpr.and(ck_writable, ck_editorHasProvider_codeActions),
			kbOpts: {
				kbExpr: ck_inputFocus_text,
				primary: 2048 | 1024 | 48,
				mac: {
					primary: 256 | 1024 | 48 // .KeyR
				},
				weight: 100 //editorContrib
			},
			contextMenuOpts: {
				group: '1_modification',
				order: 2,
				when: ContextKeyExpr.and(ck_writable, contextKeyForSupportedActions(codeActionKind4.Refactor))
			},
			metadata: {
				description: 'Refactor...',
				args: [{ name: 'args', schema: argsSchema }]
			}
		});
	}
	run(_accessor, editor2, userArgs) {
		const args = CodeActionCommandArgs.fromUser(userArgs, {
			kind: codeActionKind4.Refactor,
			apply: 'never' // CodeActionAutoApply.Never
		});
		return triggerCodeActionsForEditorSelection(
			editor2,
			typeof userArgs?.kind === 'string'
				? args.preferred
					? localize("No preferred refactorings for '{0}' available", userArgs.kind)
					: localize("No refactorings for '{0}' available", userArgs.kind)
				: args.preferred
					? localize('No preferred refactorings available')
					: localize('No refactorings available'),
			{
				include: codeActionKind4.Refactor.contains(args.kind) ? args.kind : HierarchicalKind.None,
				onlyIncludePreferredActions: args.preferred
			},
			args.apply,
			CodeActionTriggerSource.Refactor
		);
	}
}
registerEditorAction(RefactorAction);

class SourceAction extends EditorAction {
	constructor() {
		super({
			id: sourceActionCommandId,
			label: localize('Source Action...'),
			alias: 'Source Action...',
			precondition: ContextKeyExpr.and(ck_writable, ck_editorHasProvider_codeActions),
			contextMenuOpts: {
				group: '1_modification',
				order: 2.1,
				when: ContextKeyExpr.and(ck_writable, contextKeyForSupportedActions(codeActionKind4.Source))
			},
			metadata: {
				description: 'Source Action...',
				args: [{ name: 'args', schema: argsSchema }]
			}
		});
	}
	run(_accessor, editor2, userArgs) {
		const args = CodeActionCommandArgs.fromUser(userArgs, {
			kind: codeActionKind4.Source,
			apply: 'never' // CodeActionAutoApply.Never
		});
		return triggerCodeActionsForEditorSelection(
			editor2,
			typeof userArgs?.kind === 'string'
				? args.preferred
					? localize("No preferred source actions for '{0}' available", userArgs.kind)
					: localize("No source actions for '{0}' available", userArgs.kind)
				: args.preferred
					? localize('No preferred source actions available')
					: localize('No source actions available'),
			{
				include: codeActionKind4.Source.contains(args.kind) ? args.kind : HierarchicalKind.None,
				includeSourceActions: true,
				onlyIncludePreferredActions: args.preferred
			},
			args.apply,
			CodeActionTriggerSource.SourceAction
		);
	}
}
registerEditorAction(SourceAction);

class OrganizeImportsAction extends EditorAction {
	constructor() {
		super({
			id: organizeImportsCommandId,
			label: localize('Organize Imports'),
			alias: 'Organize Imports',
			precondition: ContextKeyExpr.and(ck_writable, contextKeyForSupportedActions(codeActionKind4.SourceOrganizeImports)),
			kbOpts: {
				kbExpr: ck_inputFocus_text,
				primary: 1024 | 512 | 45,
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2) {
		return triggerCodeActionsForEditorSelection(
			editor2,
			localize('No organize imports action available'),
			{
				include: codeActionKind4.SourceOrganizeImports,
				includeSourceActions: true
			},
			'ifSingle',
			CodeActionTriggerSource.OrganizeImports
		);
	}
}
registerEditorAction(OrganizeImportsAction);

class FixAllAction extends EditorAction {
	constructor() {
		super({
			id: fixAllCommandId,
			label: localize('Fix All'),
			alias: 'Fix All',
			precondition: ContextKeyExpr.and(ck_writable, contextKeyForSupportedActions(codeActionKind4.SourceFixAll))
		});
	}
	run(_accessor, editor2) {
		return triggerCodeActionsForEditorSelection(
			editor2,
			localize('No fix all action available'),
			{
				include: codeActionKind4.SourceFixAll,
				includeSourceActions: true
			},
			'ifSingle',
			CodeActionTriggerSource.FixAll
		);
	}
}
registerEditorAction(FixAllAction);

class AutoFixAction extends EditorAction {
	constructor() {
		super({
			id: autoFixCommandId,
			label: localize('Auto Fix...'),
			alias: 'Auto Fix...',
			precondition: ContextKeyExpr.and(ck_writable, contextKeyForSupportedActions(codeActionKind4.QuickFix)),
			kbOpts: {
				kbExpr: ck_inputFocus_text,
				primary: 512 | 1024 | 89,
				mac: {
					primary: 2048 | 512 | 89 // Period
				},
				weight: 100 //editorContrib
			}
		});
	}
	run(_accessor, editor2) {
		return triggerCodeActionsForEditorSelection(
			editor2,
			localize('No auto fixes available'),
			{
				include: codeActionKind4.QuickFix,
				onlyIncludePreferredActions: true
			},
			'ifSingle',
			CodeActionTriggerSource.AutoFix
		);
	}
}
registerEditorAction(AutoFixAction);


registerEditorContribution(
	CodeActionController.ID,
	CodeActionController,
	3 // Eventually
);
registerEditorContribution(
	LightBulbWidget.ID,
	LightBulbWidget,
	4 // Lazy
);

class CodeActionCommand extends EditorCommand {
	constructor() {
		super({
			id: codeActionCommandId,
			precondition: ContextKeyExpr.and(ck_writable, ck_editorHasProvider_codeActions),
			metadata: {
				description: 'Trigger a code action',
				args: [{ name: 'args', schema: argsSchema }]
			}
		});
	}
	runEditorCommand(_accessor, editor2, userArgs) {
		const args = CodeActionCommandArgs.fromUser(userArgs, {
			kind: HierarchicalKind.Empty,
			apply: 'ifSingle'
		});
		return triggerCodeActionsForEditorSelection(
			editor2,
			typeof userArgs?.kind === 'string'
				? args.preferred
					? localize("No preferred code actions for '{0}' available", userArgs.kind)
					: localize("No code actions for '{0}' available", userArgs.kind)
				: args.preferred
					? localize('No preferred code actions available')
					: localize('No code actions available'),
			{
				include: args.kind,
				includeSourceActions: true,
				onlyIncludePreferredActions: args.preferred
			},
			args.apply
		);
	}
}
registerEditorCommand(new CodeActionCommand());

registry.as(baseContributionId_Configuration).registerConfiguration({
	...editorConfigurationBaseNode,
	properties: {
		'editor.codeActionWidget.showHeaders': {
			type: 'boolean',
			scope: 5,
			default: true
		}
	}
});
registry.as(baseContributionId_Configuration).registerConfiguration({
	...editorConfigurationBaseNode,
	properties: {
		'editor.codeActionWidget.includeNearbyQuickFixes': {
			type: 'boolean',
			scope: 5,
			default: true
		}
	}
});