class MultiModelOccurenceRequest extends OccurenceAtPositionRequest {
	constructor(model, selection, wordSeparators2, providers, otherModels) {
		super(model, selection, wordSeparators2);
		this._providers = providers;
		this._otherModels = otherModels;
	}
	_compute(model, selection, wordSeparators, token) {
		const position = selection.getPosition();
		const orderedByScore = this._providers.ordered(model);
		return first(
			orderedByScore.map(provider => () => {
				const filteredModels = this._otherModels
					.filter(otherModel => {
						return shouldSynchronizeModel(otherModel);
					})
					.filter(otherModel => {
						return score2(provider.selector, otherModel.uri, otherModel.getLanguageId(), true, undefined, undefined) > 0;
					});
				return Promise.resolve(provider.provideMultiDocumentHighlights(model, position, filteredModels, token)).then(undefined, onUnexpectedExternalError);
			}),
			t => t instanceof ResourceMap && t.size > 0
		).then(value => {
			return value || new ResourceMap();
		});
	}
}
registerModelAndPositionCommand('_executeDocumentHighlights', async (accessor, model, position) => {
	const e = await getOccurrencesAtPosition(
		accessor.get(ILanguageFeaturesService).documentHighlightProvider, //
		model,
		position,
		cancellationToken_none
	);
	return e?.get(model.uri);
});