
class TreeViewsDnDService {
	constructor() {
		this._dragOperations = new Map();
	}
	removeDragOperationTransfer(uuid) {
		if (uuid && this._dragOperations.has(uuid)) {
			const operation = this._dragOperations.get(uuid);
			this._dragOperations.delete(uuid);
			return operation;
		}
		return;
	}
}
class DraggedTreeItemsIdentifier {
	constructor(identifier3) {
		this.identifier = identifier3;
	}
}

const ITreeViewsDnDService = createEditorServiceDecorator('treeViewsDndService');
registerSingleton(
	ITreeViewsDnDService,
	TreeViewsDnDService,
	1 // Delayed
);

const defaultProviderConfig = 'editor.experimental.dropIntoEditor.defaultProvider';
const changeDropTypeCommandId = 'editor.changeDropType';
const dropWidgetVisibleCtx = new RawContextKey('dropWidgetVisible', false, localize('Whether the drop widget is showing'));
class DropIntoEditorController extends Disposable {
	static get(editor2) {
		return editor2.getContribution(DropIntoEditorController.ID);
	}
	constructor(editor2, instantiationService, _configService, _languageFeaturesService, _treeViewsDragAndDropService) {
		super();
		this._configService = _configService;
		this._languageFeaturesService = _languageFeaturesService;
		this._treeViewsDragAndDropService = _treeViewsDragAndDropService;
		this.treeItemsTransfer = LocalSelectionTransfer.getInstance();
		this._dropProgressManager = this._register(instantiationService.createInstance(InlineProgressManager, 'dropIntoEditor', editor2));
		this._postDropWidgetManager = this._register(
			instantiationService.createInstance(PostEditWidgetManager, 'dropIntoEditor', editor2, dropWidgetVisibleCtx, {
				id: changeDropTypeCommandId,
				label: localize('Show drop options...')
			})
		);
		this._register(editor2.onDropIntoEditor(e => this.onDropIntoEditor(editor2, e.position, e.event)));
	}
	clearWidgets() {
		this._postDropWidgetManager.clear();
	}
	changeDropType() {
		this._postDropWidgetManager.tryShowSelector();
	}
	async onDropIntoEditor(editor2, position, dragEvent) {
		if (dragEvent.dataTransfer && editor2.hasModel()) {
			this._currentOperation?.cancel();
			editor2.focus();
			editor2.setPosition(position);
			const p = createCancelablePromise(async token => {
				const tokenSource = new EditorStateCancellationTokenSource(editor2, 1, undefined, token);
				try {
					const ourDataTransfer = await this.extractDataTransferData(dragEvent);
					if (ourDataTransfer.size === 0 || tokenSource.token.isCancellationRequested) {
						return;
					}
					const model = editor2.getModel();
					if (!model) {
						return;
					}
					const providers = this._languageFeaturesService.documentDropEditProvider.ordered(model).filter(provider => {
						if (!provider.dropMimeTypes) {
							return true;
						}
						return provider.dropMimeTypes.some(mime => ourDataTransfer.matches(mime));
					});
					const edits = await this.getDropEdits(providers, model, position, ourDataTransfer, tokenSource);
					if (tokenSource.token.isCancellationRequested) {
						return;
					}
					if (edits.length) {
						const activeEditIndex = this.getInitialActiveEditIndex(model, edits);
						const canShowWidget =
							editor2.getOption(
								36 // dropIntoEditor
							).showDropSelector === 'afterDrop';
						await this._postDropWidgetManager.applyEditAndShowIfNeeded(
							[Range.fromPositions(position)],
							{ activeEditIndex, allEdits: edits },
							canShowWidget,
							async edit => edit,
							token
						);
					}
				} finally {
					tokenSource.dispose();
					if (this._currentOperation === p) {
						this._currentOperation = undefined;
					}
				}
			});
			this._dropProgressManager.showWhile(position, localize('Running drop handlers. Click to cancel'), p);
			this._currentOperation = p;
		}
	}
	async getDropEdits(providers, model, position, dataTransfer, tokenSource) {
		const results = await raceCancellation(
			Promise.all(
				providers.map(async provider => {
					try {
						const edits2 = await provider.provideDocumentDropEdits(model, position, dataTransfer, tokenSource.token);
						return edits2 === null || edits2 === undefined
							? undefined
							: edits2.map(edit => ({
									...edit,
									providerId: provider.id
								}));
					} catch (err) {
						console.error(err);
					}
					return;
				})
			),
			tokenSource.token
		);
		const edits = (results !== null && results !== undefined ? results : []).filter(e => !!e).flat();
		return sortEditsByYieldTo(edits);
	}
	getInitialActiveEditIndex(model, edits) {
		const preferredProviders = this._configService.getValue(defaultProviderConfig, { resource: model.uri });
		for (const [configMime, desiredKindStr] of entries(preferredProviders)) {
			const desiredKind = new HierarchicalKind(desiredKindStr);
			const editIndex = edits.findIndex(
				edit => desiredKind.value === edit.providerId && edit.handledMimeType && matchesMimeType(configMime, [edit.handledMimeType])
			);
			if (editIndex >= 0) {
				return editIndex;
			}
		}
		return 0;
	}
	async extractDataTransferData(dragEvent) {
		if (!dragEvent.dataTransfer) {
			return new VSDataTransfer();
		}
		const dataTransfer = toExternalVSDataTransfer(dragEvent.dataTransfer);
		if (this.treeItemsTransfer.hasData(DraggedTreeItemsIdentifier.prototype)) {
			const data = this.treeItemsTransfer.getData(DraggedTreeItemsIdentifier.prototype);
			if (isArray(data)) {
				for (const id of data) {
					const treeDataTransfer = await this._treeViewsDragAndDropService.removeDragOperationTransfer(id.identifier);
					if (treeDataTransfer) {
						for (const [type, value] of treeDataTransfer) {
							dataTransfer.replace(type, value);
						}
					}
				}
			}
		}
		return dataTransfer;
	}
}
DropIntoEditorController.ID = 'editor.contrib.dropIntoEditorController';
__decorate(
	[
		__param(1, IInstantiationService),
		__param(2, IConfigurationService),
		__param(3, ILanguageFeaturesService),
		__param(4, ITreeViewsDnDService)
	],
	DropIntoEditorController
);

// node_modules/monaco-editor/esm/vs/editor/contrib/dropOrPasteInto/browser/dropIntoEditorContribution.js
registerEditorContribution(
	DropIntoEditorController.ID,
	DropIntoEditorController,
	2 // BeforeFirstInteraction
);
registerEditorFeature(DefaultDropProvidersFeature);
class ChangeDropTypeCommandCmd extends EditorCommand {
	constructor() {
		super({
			id: changeDropTypeCommandId,
			precondition: dropWidgetVisibleCtx,
			kbOpts: { weight: 100, primary: 2048 | 89 }
		});
	}
	runEditorCommand(_accessor, editor2, _args) {
		ropIntoEditorController.get(editor2)?.changeDropType();
	}
}
registerEditorCommand(new ChangeDropTypeCommandCmd());
class HideDropWidgetCmd extends EditorCommand {
	constructor() {
		super({
			id: 'editor.hideDropWidget',
			precondition: dropWidgetVisibleCtx,
			kbOpts: { weight: 100, primary: 9 }
		});
	}
	runEditorCommand(_accessor, editor2, _args) {
		DropIntoEditorController.get(editor2)?.clearWidgets();
	}
}
registerEditorCommand(new HideDropWidgetCmd());
registry.as(baseContributionId_Configuration).registerConfiguration({
	...editorConfigurationBaseNode,
	properties: {
		[defaultProviderConfig]: {
			type: 'object',
			scope: 5,

			default: {},
			additionalProperties: {
				type: 'string'
			}
		}
	}
});