









class EditorFontVariations extends BaseEditorOption {
	constructor() {
		super(54, 'fontVariations', 'normal', {
			anyOf: [
				{
					type: 'boolean'
				},
				{
					type: 'string'
				}
			],
			default: false
		});
	}
	validate(input) {
		if (typeof input === 'undefined') {
			return this.defaultValue;
		}
		if (typeof input === 'string') {
			if (input === 'false') {
				return 'normal';
			}
			if (input === 'true') {
				return 'translate';
			}
			return input;
		}
		if (Boolean(input)) {
			return 'translate';
		}
		return 'normal';
	}
	compute(env2) {
		return env2.fontInfo.fontVariationSettings;
	}
}


class EditorFontLigatures extends BaseEditorOption {
	constructor() {
		super(51, 'fontLigatures', '"liga" off, "calt" off', {
			anyOf: [
				{
					type: 'boolean'
				},
				{
					type: 'string'
				}
			],
			default: false
		});
	}
	validate(input) {
		if (typeof input === 'undefined') {
			return this.defaultValue;
		}
		if (typeof input === 'string') {
			if (input === 'false' || input.length === 0) {
				return '"liga" off, "calt" off';
			}
			if (input === 'true') {
				return '"liga" on, "calt" on';
			}
			return input;
		}
		if (Boolean(input)) {
			return '"liga" on, "calt" on';
		}
		return '"liga" off, "calt" off';
	}
}

class EditorFontWeight extends BaseEditorOption {
	constructor() {
		super(53, 'fontWeight', defaultEditorFont_weight, {
			anyOf: [
				{
					type: 'number',
					minimum: 1,
					maximum: 1e3
				},
				{
					type: 'string',
					pattern: '^(normal|bold|1000|[1-9][0-9]{0,2})$'
				},
				{
					enum: ['normal', 'bold', '100', '200', '300', '400', '500', '600', '700', '800', '900']
				}
			],
			default: defaultEditorFont_weight
		});
	}
	validate(input) {
		if (input === 'normal' || input === 'bold') {
			return input;
		}
		return String(EditorIntOption.clampedInt(input, defaultEditorFont_weight, 1, 1e3));
	}
}

	fontFamily: registerEditorOption(new EditorStringOption(49, 'fontFamily', defaultEditorFont_family, {})),

	fontLigatures2: registerEditorOption(new EditorFontLigatures()),


	fontVariations: registerEditorOption(new EditorFontVariations()),

fontWeight: registerEditorOption(new EditorFontWeight()),