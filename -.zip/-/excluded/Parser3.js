




class Renderer {
	constructor(options3) {
		this.options = options3 || editorDefaults;
	}
	code(_code, infostring, escaped) {
		const lang = (infostring || '').match(/\S*/)[0];
		if (this.options.highlight) {
			const out = this.options.highlight(_code, lang);
			if (out != null && out !== _code) {
				escaped = true;
				_code = out;
			}
		}
		_code = `${_code.replace(/\n$/, '')}\n`;
		if (!lang) {
			return `<pre><code>${escaped ? _code : _escape(_code, true)}</code></pre>\n`;
		}
		return `<pre><code class="${this.options.langPrefix}${_escape(lang, true)}">${escaped ? _code : _escape(_code, true)}</code></pre>\n`;
	}
	blockquote(quote) {
		return `<blockquote>\n${quote}</blockquote>\n`;
	}
	html(_html) {
		return _html;
	}
	heading(text2, level, raw, slugger) {
		if (this.options.headerIds) {
			const id = this.options.headerPrefix + slugger.slug(raw);
			return `<h${level} id="${id}">${text2}</h${level}>\n`;
		}
		return `<h${level}>${text2}</h${level}>\n`;
	}
	hr() {
		return this.options.xhtml ? '<hr/>\n' : '<hr>\n';
	}
	list(body, ordered, start) {
		const type = ordered ? 'ol' : 'ul',
			startatt = ordered && start !== 1 ? ` start="${start}"` : '';
		return `<${type}${startatt}>\n${body}</${type}>\n`;
	}
	listitem(text2) {
		return `<li>${text2}</li>\n`;
	}
	checkbox(checked) {
		return `<input ${checked ? 'checked="" ' : ''}disabled="" type="checkbox"${this.options.xhtml ? ' /' : ''}> `;
	}
	paragraph(text2) {
		return `<p>${text2}</p>\n`;
	}
	table(header, body) {
		if (body) body = `<tbody>${body}</tbody>`;
		return `<table>\n<thead>\n${header}</thead>\n${body}</table>\n`;
	}
	tablerow(content) {
		return `<tr>\n${content}</tr>\n`;
	}
	tablecell(content, { header, align }) {
		const type = header ? 'th' : 'td';
		const tag = align ? `<${type} align="${align}">` : `<${type}>`;
		return `${tag + content}</${type}>\n`;
	}
	strong(text2) {
		return `<strong>${text2}</strong>`;
	}
	em(text2) {
		return `<em>${text2}</em>`;
	}
	codespan(text2) {
		return `<code>${text2}</code>`;
	}
	br() {
		return this.options.xhtml ? '<br/>' : '<br>';
	}
	del(text2) {
		return `<del>${text2}</del>`;
	}
	link(href, title, text2) {
		href = _cleanUrl(this.options.sanitize, this.options.baseUrl, href);
		if (href === null) {
			return text2;
		}
		let out = `<a href="${_escape(href)}"`;
		if (title) {
			out += ` title="${title}"`;
		}
		out += `>${text2}</a>`;
		return out;
	}
	image(href, title, text2) {
		href = _cleanUrl(this.options.sanitize, this.options.baseUrl, href);
		if (href === null) {
			return text2;
		}
		let out = `<img src="${href}" alt="${text2}"`;
		if (title) {
			out += ` title="${title}"`;
		}
		out += this.options.xhtml ? '/>' : '>';
		return out;
	}
	text(_text) {
		return _text;
	}
}


class TextRenderer {
	strong(text2) {
		return text2;
	}
	em(text2) {
		return text2;
	}
	codespan(text2) {
		return text2;
	}
	del(text2) {
		return text2;
	}
	html(text2) {
		return text2;
	}
	text(_text) {
		return _text;
	}
	link(href, title, text2) {
		return `${text2}`;
	}
	image(href, title, text2) {
		return `${text2}`;
	}
	br() {
		return '';
	}
}

class Slugger {
	constructor() {
		this.seen = {};
	}
	serialize(value) {
		return value
			.toLowerCase()
			.trim()
			.replace(/<[!\/a-z].*?>/gi, '')
			.replace(/[\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,./:;<=>?@[\]^`{|}~]/g, '')
			.replace(/\s/g, '-');
	}
	getNextSafeSlug(originalSlug, isDryRun) {
		let slug = originalSlug;
		let occurenceAccumulator = 0;
		if (this.seen.hasOwnProperty(slug)) {
			occurenceAccumulator = this.seen[originalSlug];
			do {
				occurenceAccumulator++;
				slug = `${originalSlug}-${occurenceAccumulator}`;
			} while (this.seen.hasOwnProperty(slug));
		}
		if (!isDryRun) {
			this.seen[originalSlug] = occurenceAccumulator;
			this.seen[slug] = 0;
		}
		return slug;
	}
	slug(value, options3) {
		if (options3 === undefined) {
			options3 = {};
		}
		const slug2 = this.serialize(value);
		return this.getNextSafeSlug(slug2, options3.dryrun);
	}
}


class Parser3 {
	constructor(options3) {
		this.options = options3 || editorDefaults; //todo
		this.options.renderer = this.options.renderer || new Renderer();
		this.renderer = this.options.renderer;
		this.renderer.options = this.options;
		this.textRenderer = new TextRenderer();
		this.slugger = new Slugger();
	}
	static parse(tokens, options3) {
		const parser3 = new Parser3(options3);
		return parser3.parse(tokens);
	}
	static parseInline(tokens, options3) {
		const parser3 = new Parser3(options3);
		return parser3.parseInline(tokens);
	}
	static parse(tokens, top) {
		if (top === undefined) {
			top = true;
		}
		let out = '',
			i,
			j,
			k,
			l2,
			l3,
			row,
			cell,
			header,
			body,
			token,
			ordered,
			start,
			loose,
			itemBody,
			item,
			checked,
			task,
			checkbox,
			ret;
		const l = tokens.length;
		for (i = 0; i < l; i++) {
			token = tokens[i];
			if (this.options?.extensions?.renderers?.[token.type]) {
				ret = this.options.extensions.renderers[token.type].call(
					{
						parser: this
					},
					token
				);
				if (ret !== false || !['space', 'hr', 'heading', 'code', 'table', 'blockquote', 'list', 'html', 'paragraph', 'text'].includes(token.type)) {
					out += ret || '';
					continue;
				}
			}
			switch (token.type) {
				case 'space': {
					continue;
				}
				case 'hr': {
					out += this.renderer.hr();
					continue;
				}
				case 'heading': {
					out += this.renderer.heading(this.parseInline(token.tokens), token.depth, _unescape(this.parseInline(token.tokens, this.textRenderer)), this.slugger);
					continue;
				}
				case 'code': {
					out += this.renderer.code(token.text, token.lang, token.escaped);
					continue;
				}
				case 'table': {
					header = '';
					cell = '';
					l2 = token.header.length;
					for (j = 0; j < l2; j++) {
						cell += this.renderer.tablecell(this.parseInline(token.header[j].tokens), {
							header: true,
							align: token.align[j]
						});
					}
					header += this.renderer.tablerow(cell);
					body = '';
					l2 = token.rows.length;
					for (j = 0; j < l2; j++) {
						row = token.rows[j];
						cell = '';
						l3 = row.length;
						for (k = 0; k < l3; k++) {
							cell += this.renderer.tablecell(this.parseInline(row[k].tokens), {
								header: false,
								align: token.align[k]
							});
						}
						body += this.renderer.tablerow(cell);
					}
					out += this.renderer.table(header, body);
					continue;
				}
				case 'blockquote': {
					body = this.parse(token.tokens);
					out += this.renderer.blockquote(body);
					continue;
				}
				case 'list': {
					ordered = token.ordered;
					start = token.start;
					loose = token.loose;
					l2 = token.items.length;
					body = '';
					for (j = 0; j < l2; j++) {
						item = token.items[j];
						checked = item.checked;
						task = item.task;
						itemBody = '';
						if (item.task) {
							checkbox = this.renderer.checkbox(checked);
							if (loose) {
								if (item.tokens.length > 0 && item.tokens[0].type === 'paragraph') {
									item.tokens[0].text = `${checkbox} ${item.tokens[0].text}`;
									if (item.tokens[0].tokens && item.tokens[0].tokens.length > 0 && item.tokens[0].tokens[0].type === 'text') {
										item.tokens[0].tokens[0].text = `${checkbox} ${item.tokens[0].tokens[0].text}`;
									}
								} else {
									item.tokens.unshift({
										type: 'text',
										text: checkbox
									});
								}
							} else {
								itemBody += checkbox;
							}
						}
						itemBody += this.parse(item.tokens, loose);
						body += this.renderer.listitem(itemBody, task, checked);
					}
					out += this.renderer.list(body, ordered, start);
					continue;
				}
				case 'html': {
					out += this.renderer.html(token.text);
					continue;
				}
				case 'paragraph': {
					out += this.renderer.paragraph(this.parseInline(token.tokens));
					continue;
				}
				case 'text': {
					body = token.tokens ? this.parseInline(token.tokens) : token.text;
					while (i + 1 < l && tokens[i + 1].type === 'text') {
						token = tokens[++i];
						body += `\n${token.tokens ? this.parseInline(token.tokens) : token.text}`;
					}
					out += top ? this.renderer.paragraph(body) : body;
					continue;
				}
				default: {
					const errMsg = `Token with "${token.type}" type was not found.`;
					if (this.options?.silent) {
						console.error(errMsg);
						return;
					}
				}
			}
		}
		return out;
	}
	static parseInline(tokens, renderer) {
		renderer = renderer || this.renderer;
		let out = '',
			i,
			token,
			ret;
		const l = tokens.length;
		for (i = 0; i < l; i++) {
			token = tokens[i];
			if (this.options?.extensions?.renderers?.[token.type]) {
				ret = this.options.extensions.renderers[token.type].call(
					{
						parser: this
					},
					token
				);
				if (ret !== false || !['escape', 'html', 'link', 'image', 'strong', 'em', 'codespan', 'br', 'del', 'text'].includes(token.type)) {
					out += ret || '';
					continue;
				}
			}
			switch (token.type) {
				case 'escape': {
					out += renderer.text(token.text);
					break;
				}
				case 'html': {
					out += renderer.html(token.text);
					break;
				}
				case 'link': {
					out += renderer.link(token.href, token.title, this.parseInline(token.tokens, renderer));
					break;
				}
				case 'image': {
					out += renderer.image(token.href, token.title, token.text);
					break;
				}
				case 'strong': {
					out += renderer.strong(this.parseInline(token.tokens, renderer));
					break;
				}
				case 'em': {
					out += renderer.em(this.parseInline(token.tokens, renderer));
					break;
				}
				case 'codespan': {
					out += renderer.codespan(token.text);
					break;
				}
				case 'br': {
					out += renderer.br();
					break;
				}
				case 'del': {
					out += renderer.del(this.parseInline(token.tokens, renderer));
					break;
				}
				case 'text': {
					out += renderer.text(token.text);
					break;
				}
				default: {
					const errMsg = `Token with "${token.type}" type was not found.`;
					if (this.options.silent) {
						console.error(errMsg);
						return;
					} else {
						throw new Error(errMsg);
					}
				}
			}
		}
		return out;
	}
}
