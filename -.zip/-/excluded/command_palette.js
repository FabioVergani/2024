
	registerColor(
		colorId_quickInput_background,
		{
			dark: colorId_widget_background,
			light: colorId_widget_background,
			hcDark: colorId_widget_background,
			hcLight: colorId_widget_background
		},
		localize(
			'Quick picker background color. The quick picker widget is the container for pickers like the command palette.'
		)
	);

	registerColor(
		colorId_quickInput_foreground,
		{
			dark: colorId_editorWidget_foreground,
			light: colorId_editorWidget_foreground,
			hcDark: colorId_editorWidget_foreground,
			hcLight: colorId_editorWidget_foreground
		},
		localize(
			'Quick picker foreground color. The quick picker widget is the container for pickers like the command palette.'
		)
	);

	registerColor(
		colorId_quickInputTitle_background,
		{
			dark: new Color(new RGBA(255, 255, 255, 0.105)),
			light: new Color(new RGBA(0, 0, 0, 0.06)),
			hcDark: '#000000',
			hcLight: colorWhite
		},
		localize(
			'Quick picker title background color. The quick picker widget is the container for pickers like the command palette.'
		)
	);



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
const QuickCommandNLS = {
	quickCommandActionLabel: localize('Command Palette'),
	quickCommandHelp: localize('Show And Run Commands')
};

class GotoLineAction2 extends EditorAction {
	constructor() {
		super({
			id: GotoLineAction2.ID,
			label: QuickCommandNLS.quickCommandActionLabel,
			alias: 'Command Palette',

			kbOpts: {
				kbExpr: ctxKeys_editorFocus,
				primary: 59,
				weight: 100 // EditorContrib
			},
			contextMenuOpts: {
				group: 'z_commands',
				order: 1
			}
		});
	}
	run(accessor) {
		accessor.get(IQuickInputService).quickAccess.show(StandaloneCommandsQuickAccessProvider.PREFIX);
	}
}
GotoLineAction2.ID = 'editor.action.quickCommand';

registerEditorAction(GotoLineAction2);

registry.as(quickAccessRegistry_extensionId).registerQuickAccessProvider({
	ctor: StandaloneCommandsQuickAccessProvider,
	prefix: StandaloneCommandsQuickAccessProvider.PREFIX,
	helpEntries: [{ description: QuickCommandNLS.quickCommandHelp, commandId: GotoLineAction2.ID }]
});
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


MenuId.CommandPalette = new MenuId('CommandPalette');