// node_modules/monaco-editor/esm/vs/editor/contrib/unicodeHighlighter/browser/unicodeHighlighter.js

const warningIcon = iconRegistry.registerIcon(
	'extensions-warning-message',
	codicon_warning,
	localize('Icon shown with a warning message in the extensions editor.')
);

class UnicodeHighlighter extends Disposable {
	constructor(_editor, _editorWorkerService, _workspaceTrustService, instantiationService) {
		super();
		this._editor = _editor;
		this._editorWorkerService = _editorWorkerService;
		this._workspaceTrustService = _workspaceTrustService;
		this._highlighter = null;
		this._bannerClosed = false;
		this._updateState = state => {
			if (state && state.hasMore) {
				if (this._bannerClosed) {
					return;
				}
				const max = Math.max(state.ambiguousCharacterCount, state.nonBasicAsciiCharacterCount, state.invisibleCharacterCount);
				let data;
				if (state.nonBasicAsciiCharacterCount >= max) {
					data = {
						message: localize('This document contains many non-basic ASCII unicode characters'),
						command: new DisableHighlightingOfNonBasicAsciiCharactersAction()
					};
				} else if (state.ambiguousCharacterCount >= max) {
					data = {
						message: localize('This document contains many ambiguous unicode characters'),
						command: new DisableHighlightingOfAmbiguousCharactersAction()
					};
				} else if (state.invisibleCharacterCount >= max) {
					data = {
						message: localize('This document contains many invisible unicode characters'),
						command: new DisableHighlightingOfInvisibleCharactersAction()
					};
				} else {
					throw new Error('Unreachable');
				}
				this._bannerController.show({
					id: 'unicodeHighlightBanner',
					message: data.message,
					icon: warningIcon,
					actions: [
						{
							label: data.command.shortLabel,
							href: `command:${data.command.id}`
						}
					],
					onClose: () => {
						this._bannerClosed = true;
					}
				});
			} else {
				this._bannerController.hide();
			}
		};
		this._bannerController = this._register(instantiationService.createInstance(BannerController, _editor));
		this._register(
			this._editor.onDidChangeModel(() => {
				this._bannerClosed = false;
				this._updateHighlighter();
			})
		);
		this._options = _editor.getOption(
			125
			// unicodeHighlighting
		);
		this._register(
			_workspaceTrustService.onDidChangeTrust(() => {
				this._updateHighlighter();
			})
		);
		this._register(
			_editor.onDidChangeConfiguration(e => {
				if (
					e.hasChanged(
						125
						// unicodeHighlighting
					)
				) {
					this._options = _editor.getOption(
						125
						// unicodeHighlighting
					);
					this._updateHighlighter();
				}
			})
		);
		this._updateHighlighter();
	}
	dispose() {
		if (this._highlighter) {
			this._highlighter.dispose();
			this._highlighter = null;
		}
		super.dispose();
	}
	_updateHighlighter() {
		this._updateState(null);
		if (this._highlighter) {
			this._highlighter.dispose();
			this._highlighter = null;
		}
		if (!this._editor.hasModel()) {
			return;
		}
		const options2 = resolveOptions2(this._workspaceTrustService.isWorkspaceTrusted(), this._options);
		if ([options2.nonBasicASCII, options2.ambiguousCharacters, options2.invisibleCharacters].every(option => option === false)) {
			return;
		}
		const highlightOptions = {
			nonBasicASCII: options2.nonBasicASCII,
			ambiguousCharacters: options2.ambiguousCharacters,
			invisibleCharacters: options2.invisibleCharacters,
			includeComments: options2.includeComments,
			includeStrings: options2.includeStrings,
			allowedCodePoints: Object.keys(options2.allowedCharacters).map(c => c.codePointAt(0)),
			allowedLocales: Object.keys(options2.allowedLocales).map(locale => {
				if (locale === '_os') {
					return new Intl.NumberFormat().resolvedOptions().locale;
				} else if (locale === '_vscode') {
					return editorDefault_locale;
				}
				return locale;
			})
		};
		if (this._editorWorkerService.canComputeUnicodeHighlights(this._editor.getModel().uri)) {
			this._highlighter = new DocumentUnicodeHighlighter(
				this._editor,
				highlightOptions,
				this._updateState,
				this._editorWorkerService
			);
		} else {
			this._highlighter = new ViewportUnicodeHighlighter(this._editor, highlightOptions, this._updateState);
		}
	}
	getDecorationInfo(decoration3) {
		if (this._highlighter) {
			return this._highlighter.getDecorationInfo(decoration3);
		}
		return null;
	}
}
UnicodeHighlighter.ID = 'editor.contrib.unicodeHighlighter';
__decorate(
	[
		__param(1, IEditorWorkerService),
		//__param(2, IWorkspaceTrustManagementService),
		__param(3, IInstantiationService)
	],
	UnicodeHighlighter
);

const resolveOptions2 = (trusted, options2) => {
	return {
		nonBasicASCII: options2.nonBasicASCII === inUntrustedWorkspace ? !trusted : options2.nonBasicASCII,
		ambiguousCharacters: options2.ambiguousCharacters,
		invisibleCharacters: options2.invisibleCharacters,
		includeComments: options2.includeComments === inUntrustedWorkspace ? !trusted : options2.includeComments,
		includeStrings: options2.includeStrings === inUntrustedWorkspace ? !trusted : options2.includeStrings,
		allowedCharacters: options2.allowedCharacters,
		allowedLocales: options2.allowedLocales
	};
};

class DocumentUnicodeHighlighter extends Disposable {
	constructor(_editor, _options, _updateState, _editorWorkerService) {
		super();
		this._editor = _editor;
		this._options = _options;
		this._updateState = _updateState;
		this._editorWorkerService = _editorWorkerService;
		this._model = this._editor.getModel();
		this._decorations = this._editor.createDecorationsCollection();
		this._updateSoon = this._register(new RunOnceScheduler(() => this._update(), 250));
		this._register(
			this._editor.onDidChangeModelContent(() => {
				this._updateSoon.schedule();
			})
		);
		this._updateSoon.schedule();
	}
	dispose() {
		this._decorations.clear();
		super.dispose();
	}
	_update() {
		if (this._model.isDisposed()) {
			return;
		}
		if (!this._model.mightContainNonBasicASCII()) {
			this._decorations.clear();
			return;
		}
		const modelVersionId = this._model.getVersionId();
		this._editorWorkerService.computedUnicodeHighlights(this._model.uri, this._options).then(info => {
			if (this._model.isDisposed()) {
				return;
			}
			if (this._model.getVersionId() !== modelVersionId) {
				return;
			}
			this._updateState(info);
			const decorations = [];
			if (!info.hasMore) {
				for (const range2 of info.ranges) {
					decorations.push({
						range: range2,
						options: Decorations.instance.getDecorationFromOptions(this._options)
					});
				}
			}
			this._decorations.set(decorations);
		});
	}
	getDecorationInfo(decoration3) {
		if (!this._decorations.has(decoration3)) {
			return null;
		}
		const model = this._editor.getModel();
		if (!isModelDecorationVisible(model, decoration3)) {
			return null;
		}
		const text2 = model.getValueInRange(decoration3.range);
		return {
			reason: computeReason(text2, this._options),
			inComment: isModelDecorationInComment(model, decoration3),
			inString: isModelDecorationInString(model, decoration3)
		};
	}
}
__decorate([__param(3, IEditorWorkerService)], DocumentUnicodeHighlighter);

class ViewportUnicodeHighlighter extends Disposable {
	constructor(_editor, _options, _updateState) {
		super();
		this._editor = _editor;
		this._options = _options;
		this._updateState = _updateState;
		this._model = this._editor.getModel();
		this._decorations = this._editor.createDecorationsCollection();
		this._updateSoon = this._register(new RunOnceScheduler(() => this._update(), 250));
		this._register(
			this._editor.onDidLayoutChange(() => {
				this._updateSoon.schedule();
			})
		);
		this._register(
			this._editor.onDidScrollChange(() => {
				this._updateSoon.schedule();
			})
		);
		this._register(
			this._editor.onDidChangeHiddenAreas(() => {
				this._updateSoon.schedule();
			})
		);
		this._register(
			this._editor.onDidChangeModelContent(() => {
				this._updateSoon.schedule();
			})
		);
		this._updateSoon.schedule();
	}
	dispose() {
		this._decorations.clear();
		super.dispose();
	}
	_update() {
		if (this._model.isDisposed()) {
			return;
		}
		if (!this._model.mightContainNonBasicASCII()) {
			this._decorations.clear();
			return;
		}
		const ranges = this._editor.getVisibleRanges();
		const decorations = [];
		const totalResult = {
			ranges: [],
			ambiguousCharacterCount: 0,
			invisibleCharacterCount: 0,
			nonBasicAsciiCharacterCount: 0,
			hasMore: false
		};
		for (const range2 of ranges) {
			const result = UnicodeTextModelHighlighter.computeUnicodeHighlights(this._model, this._options, range2);
			for (const r of result.ranges) {
				totalResult.ranges.push(r);
			}
			totalResult.ambiguousCharacterCount += totalResult.ambiguousCharacterCount;
			totalResult.invisibleCharacterCount += totalResult.invisibleCharacterCount;
			totalResult.nonBasicAsciiCharacterCount += totalResult.nonBasicAsciiCharacterCount;
			totalResult.hasMore = totalResult.hasMore || result.hasMore;
		}
		if (!totalResult.hasMore) {
			for (const range2 of totalResult.ranges) {
				decorations.push({
					range: range2,
					options: Decorations.instance.getDecorationFromOptions(this._options)
				});
			}
		}
		this._updateState(totalResult);
		this._decorations.set(decorations);
	}
	getDecorationInfo(decoration3) {
		if (!this._decorations.has(decoration3)) {
			return null;
		}
		const model = this._editor.getModel();
		const text2 = model.getValueInRange(decoration3.range);
		if (!isModelDecorationVisible(model, decoration3)) {
			return null;
		}
		return {
			reason: computeReason(text2, this._options),
			inComment: isModelDecorationInComment(model, decoration3),
			inString: isModelDecorationInString(model, decoration3)
		};
	}
}
const configureUnicodeHighlightOptionsStr = localize('Configure Unicode Highlight Options');

class UnicodeHighlighterHoverParticipant {
	constructor(_editor, _languageService, _openerService) {
		this._editor = _editor;
		this._languageService = _languageService;
		this._openerService = _openerService;
		this.hoverOrdinal = 5;
	}
	computeSync(anchor, lineDecorations) {
		if (!this._editor.hasModel() || anchor.type !== 1) {
			return [];
		}
		const model = this._editor.getModel();
		const unicodeHighlighter = this._editor.getContribution(UnicodeHighlighter.ID);
		if (!unicodeHighlighter) {
			return [];
		}
		const result = [];
		const existedReason = new Set();
		let index = 300;
		for (const d of lineDecorations) {
			const highlightInfo = unicodeHighlighter.getDecorationInfo(d);
			if (!highlightInfo) {
				continue;
			}
			const char = model.getValueInRange(d.range);
			const codePoint = char.codePointAt(0);
			const codePointStr = formatCodePointMarkdown(codePoint);
			let reason;
			switch (highlightInfo.reason.kind) {
				case 0: {
					if (isBasicASCII(highlightInfo.reason.confusableWith)) {
						reason = localize(
							'The character {0} could be confused with the ASCII character {1}, which is more common in source code.',
							codePointStr,
							formatCodePointMarkdown(highlightInfo.reason.confusableWith.codePointAt(0))
						);
					} else {
						reason = localize(
							'The character {0} could be confused with the character {1}, which is more common in source code.',
							codePointStr,
							formatCodePointMarkdown(highlightInfo.reason.confusableWith.codePointAt(0))
						);
					}
					break;
				}
				case 1:
					reason = localize(codePointStr);
					break;
				case 2:
					reason = localize('The character {0} is not a basic ASCII character.', codePointStr);
					break;
			}
			if (existedReason.has(reason)) {
				continue;
			}
			existedReason.add(reason);
			const adjustSettingsArgs = {
				codePoint,
				reason: highlightInfo.reason,
				inComment: highlightInfo.inComment,
				inString: highlightInfo.inString
			};
			const adjustSettings = localize('Adjust settings');
			const uri = `command:${ShowExcludeOptions.ID}?${encodeURIComponent(JSON.stringify(adjustSettingsArgs))}`;
			const markdown = new MarkdownString('', true)
				.appendMarkdown(reason)
				.appendText(' ')
				.appendLink(uri, adjustSettings, configureUnicodeHighlightOptionsStr);
			result.push(new MarkdownHover(this, d.range, [markdown], false, index++));
		}
		return result;
	}
	renderHoverParts(context, hoverParts) {
		return renderMarkdownHovers(context, hoverParts, this._editor, this._languageService, this._openerService);
	}
}
__decorate([__param(1, ILanguageService), __param(2, IOpenerService)], UnicodeHighlighterHoverParticipant);

const codePointToHex = codePoint => {
	return `U+${codePoint.toString(16).padStart(4, '0')}`;
};

const formatCodePointMarkdown = codePoint => {
	let value = `\`${codePointToHex(codePoint)}\``;
	if (!InvisibleCharacters.isInvisibleCharacter(codePoint)) {
		value += ` "${renderCodePointAsInlineCode(codePoint)}"`;
	}
	return value;
};

const renderCodePointAsInlineCode = codePoint => {
	if (codePoint === 96) {
		return '`` ` ``';
	}
	return '`' + String.fromCodePoint(codePoint) + '`';
};

const computeReason = (char, options2) => {
	return UnicodeTextModelHighlighter.computeUnicodeHighlightReason(char, options2);
};

class Decorations {
	constructor() {
		this.map = new Map();
	}
	getDecorationFromOptions(options2) {
		return this.getDecoration(!options2.includeComments, !options2.includeStrings);
	}
	getDecoration(hideInComments, hideInStrings) {
		const key = `${hideInComments}${hideInStrings}`;
		let options2 = this.map.get(key);
		if (!options2) {
			options2 = ModelDecorationOptions.createDynamic({
				description: 'unicode-highlight',
				stickiness: 1,
				className: 'unicode-highlight',
				showIfCollapsed: true,
				overviewRuler: null,
				minimap: null,
				hideInCommentTokens: hideInComments,
				hideInStringTokens: hideInStrings
			});
			this.map.set(key, options2);
		}
		return options2;
	}
}
Decorations.instance = new Decorations();

class DisableHighlightingInCommentsAction extends EditorAction {
	constructor() {
		super({
			id: DisableHighlightingOfAmbiguousCharactersAction.ID,
			label: localize('Disable highlighting of characters in comments'),
			alias: 'Disable highlighting of characters in comments',

		});
		this.shortLabel = localize('Disable Highlight In Comments');
	}
	async run(accessor) {
		const configurationService = accessor?.get(IConfigurationService);
		if (configurationService) {
			await this.runAction(configurationService);
		}
	}
	async runAction(configurationService) {
		await configurationService.updateValue(
			unicodeHighlightConfigKeys.includeComments,
			false,
			2
			/* ConfigurationTarget.USER */
		);
	}
}
class DisableHighlightingInStringsAction extends EditorAction {
	constructor() {
		super({
			id: DisableHighlightingOfAmbiguousCharactersAction.ID,
			label: localize('Disable highlighting of characters in strings'),
			alias: 'Disable highlighting of characters in strings',

		});
		this.shortLabel = localize('Disable Highlight In Strings');
	}
	async run(accessor) {
		const configurationService = accessor?.get(IConfigurationService);
		if (configurationService) {
			await this.runAction(configurationService);
		}
	}
	async runAction(configurationService) {
		await configurationService.updateValue(
			unicodeHighlightConfigKeys.includeStrings,
			false,
			2
			/* ConfigurationTarget.USER */
		);
	}
}

class DisableHighlightingOfAmbiguousCharactersAction extends EditorAction {
	constructor() {
		super({
			id: DisableHighlightingOfAmbiguousCharactersAction.ID,
			label: localize('Disable highlighting of ambiguous characters'),
			alias: 'Disable highlighting of ambiguous characters',

		});
		this.shortLabel = localize('Disable Ambiguous Highlight');
	}
	async run(accessor) {
		const configurationService = accessor?.get(IConfigurationService);
		if (configurationService) {
			await this.runAction(configurationService);
		}
	}
	async runAction(configurationService) {
		await configurationService.updateValue(
			unicodeHighlightConfigKeys.ambiguousCharacters,
			false,
			2
			/* ConfigurationTarget.USER */
		);
	}
}
DisableHighlightingOfAmbiguousCharactersAction.ID = 'editor.action.unicodeHighlight.disableHighlightingOfAmbiguousCharacters';

class DisableHighlightingOfInvisibleCharactersAction extends EditorAction {
	constructor() {
		super({
			id: DisableHighlightingOfInvisibleCharactersAction.ID,
			label: localize('Disable highlighting of invisible characters'),
			alias: 'Disable highlighting of invisible characters',

		});
		this.shortLabel = localize('Disable Invisible Highlight');
	}
	async run(accessor) {
		const configurationService = accessor?.get(IConfigurationService);
		if (configurationService) {
			await this.runAction(configurationService);
		}
	}
	async runAction(configurationService) {
		await configurationService.updateValue(
			unicodeHighlightConfigKeys.invisibleCharacters,
			false,
			2
			/* ConfigurationTarget.USER */
		);
	}
}
DisableHighlightingOfInvisibleCharactersAction.ID = 'editor.action.unicodeHighlight.disableHighlightingOfInvisibleCharacters';

class DisableHighlightingOfNonBasicAsciiCharactersAction extends EditorAction {
	constructor() {
		super({
			id: DisableHighlightingOfNonBasicAsciiCharactersAction.ID,
			label: localize('Disable highlighting of non basic ASCII characters'),
			alias: 'Disable highlighting of non basic ASCII characters',

		});
		this.shortLabel = localize('Disable Non ASCII Highlight');
	}
	async run(accessor) {
		const configurationService = accessor?.get(IConfigurationService);
		if (configurationService) {
			await this.runAction(configurationService);
		}
	}
	async runAction(configurationService) {
		await configurationService.updateValue(
			unicodeHighlightConfigKeys.nonBasicASCII,
			false,
			2
			/* ConfigurationTarget.USER */
		);
	}
}
DisableHighlightingOfNonBasicAsciiCharactersAction.ID = 'editor.action.unicodeHighlight.disableHighlightingOfNonBasicAsciiCharacters';

class ShowExcludeOptions extends EditorAction {
	constructor() {
		super({
			id: ShowExcludeOptions.ID,
			label: localize('Show Exclude Options'),
			alias: 'Show Exclude Options',

		});
	}
	async run(accessor, editor2, args) {
		const { codePoint, reason, inString, inComment } = args;
		const char = String.fromCodePoint(codePoint);
		//const quickPickService = accessor.get(IQuickInputService);
		const configurationService = accessor.get(IConfigurationService);

		const options2 = [];
		if (reason.kind === 0) {
			for (const locale of reason.notAmbiguousInLocales) {
				options2.push({
					label: localize('Allow unicode characters that are more common in the language "{0}".', locale),
					run: async () => {
						await excludeLocaleFromBeingHighlighted(configurationService, [locale]);
					}
				});
			}
		}

		options2.push({
			label: InvisibleCharacters.isInvisibleCharacter(codePoint)
				? localize('Exclude {0} (invisible character) from being highlighted', codePointToHex(codePoint))
				: localize('Exclude {0} from being highlighted', `${codePointToHex(codePoint)} "${char}"`),
			run: () => excludeCharFromBeingHighlighted(configurationService, [codePoint])
		});
		if (inComment) {
			const action = new DisableHighlightingInCommentsAction();
			options2.push({ label: action.label, run: async () => action.runAction(configurationService) });
		} else if (inString) {
			const action = new DisableHighlightingInStringsAction();
			options2.push({ label: action.label, run: async () => action.runAction(configurationService) });
		}
		if (reason.kind === 0) {
			const action = new DisableHighlightingOfAmbiguousCharactersAction();
			options2.push({ label: action.label, run: async () => action.runAction(configurationService) });
		} else if (reason.kind === 1) {
			const action = new DisableHighlightingOfInvisibleCharactersAction();
			options2.push({ label: action.label, run: async () => action.runAction(configurationService) });
		} else if (reason.kind === 2) {
			const action = new DisableHighlightingOfNonBasicAsciiCharactersAction();
			options2.push({ label: action.label, run: async () => action.runAction(configurationService) });
		} else {
			expectNever(reason);
		}
		const result = await quickPickService.pick(options2, { title: configureUnicodeHighlightOptionsStr });
		if (result) {
			await result.run();
		}
	}
}
ShowExcludeOptions.ID = 'editor.action.unicodeHighlight.showExcludeOptions';
async function excludeCharFromBeingHighlighted(configurationService, charCodes) {
	const existingValue = configurationService.getValue(unicodeHighlightConfigKeys.allowedCharacters);
	let value;
	if (typeof existingValue === 'object' && existingValue) {
		value = existingValue;
	} else {
		value = {};
	}
	for (const charCode of charCodes) {
		value[String.fromCodePoint(charCode)] = true;
	}
	await configurationService.updateValue(
		unicodeHighlightConfigKeys.allowedCharacters,
		value,
		2
		/* ConfigurationTarget.USER */
	);
}
async function excludeLocaleFromBeingHighlighted(configurationService, locales) {
	const existingValue = configurationService.inspect(unicodeHighlightConfigKeys.allowedLocales).user?.value;
	let value;
	if (typeof existingValue === 'object' && existingValue) {
		value = Object.assign({}, existingValue);
	} else {
		value = {};
	}
	for (const locale of locales) {
		value[locale] = true;
	}
	await configurationService.updateValue(
		unicodeHighlightConfigKeys.allowedLocales,
		value,
		2
		/* ConfigurationTarget.USER */
	);
}

const expectNever = value => {
	throw new Error(`Unexpected value: ${value}`);
};

registerEditorAction(DisableHighlightingOfAmbiguousCharactersAction);
registerEditorAction(DisableHighlightingOfInvisibleCharactersAction);
registerEditorAction(DisableHighlightingOfNonBasicAsciiCharactersAction);
registerEditorAction(ShowExcludeOptions);
registerEditorContribution(
	UnicodeHighlighter.ID,
	UnicodeHighlighter,
	1
	/* EditorContributionInstantiation.AfterFirstRender */
);
hoverParticipantRegistry.register(UnicodeHighlighterHoverParticipant);