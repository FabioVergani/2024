const QuickHelpNLS = {
	helpQuickAccessActionLabel: localize('Show all Quick Access Providers')
};
const GoToLineNLS = {
	gotoLineActionLabel: localize('Go to Line/Column...')
};

const StandaloneServicesNLS = {
	bulkEditServiceSummary: localize('Made {0} edits in {1} files')
};

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const QuickOutlineNLS = {
	quickOutlineActionLabel: localize('Go to Symbol...'),
	quickOutlineByCategoryActionLabel: localize('Go to Symbol by Category...')
};

class QuickInputBox extends Disposable {
	constructor(parent, inputBoxStyles, toggleStyles) {
		super();
		this.parent = parent;
		this.onKeyDown = handler => {
			return addStandardDisposableListener(this.findInput.inputBox.inputElement, EventType.KEY_DOWN, handler);
		};
		this.onDidChange = handler => {
			return this.findInput.onDidChange(handler);
		};
		this.container = append(this.parent, $('.quick-input-box'));
		this.findInput = this._register(new FindInput(this.container, undefined, { label: '', inputBoxStyles, toggleStyles }));
		const input = this.findInput.inputBox.inputElement;
		input.role = 'combobox';

	}
	get value() {
		return this.findInput.getValue();
	}
	set value(value) {
		this.findInput.setValue(value);
	}
	select(range2 = null) {
		this.findInput.inputBox.select(range2);
	}
	getSelection() {
		return this.findInput.inputBox.getSelection();
	}
	isSelectionAtEnd() {
		return this.findInput.inputBox.isSelectionAtEnd();
	}
	get placeholder() {
		return this.findInput.inputBox.inputElement.getAttribute('placeholder') || '';
	}
	set placeholder(placeholder) {
		this.findInput.inputBox.setPlaceHolder(placeholder);
	}
	get password() {
		return this.findInput.inputBox.inputElement.type === 'password';
	}
	set password(password) {
		this.findInput.inputBox.inputElement.type = password ? 'password' : 'text';
	}
	set enabled(enabled) {
		this.findInput.inputBox.inputElement.toggleAttribute('readonly', !enabled);
	}
	set toggles(toggles) {
		this.findInput.setAdditionalToggles(toggles);
	}
	setAttribute(name, value) {
		this.findInput.inputBox.inputElement.setAttribute(name, value);
	}
	showDecoration(decoration3) {
		if (decoration3 === 0) {
			this.findInput.clearMessage();
		} else {
			this.findInput.showMessage({
				type: decoration3 === 1 ? 1 : decoration3 === 2 ? 2 : 3,
				content: ''
			});
		}
	}
	stylesForType(decoration3) {
		return this.findInput.inputBox.stylesForType(
			decoration3 === 1 ? 1 : decoration3 === 2 ? 2 : 3
			/* MessageType.ERROR */
		);
	}
	setFocus() {
		this.findInput.focus();
	}
	layout() {
		this.findInput.inputBox.layout();
	}
}

class QuickInputController extends Disposable {
	get container() {
		return this._container;
	}
	constructor(options2, layoutService, instantiationService) {
		super();
		this.options = options2;
		this.layoutService = layoutService;
		this.instantiationService = instantiationService;
		this.enabled = true;
		this.onDidAcceptEmitter = this._register(new Emitter());
		this.onDidCustomEmitter = this._register(new Emitter());
		this.onDidTriggerButtonEmitter = this._register(new Emitter());
		this.keyMods = { ctrlCmd: false, alt: false };
		this.controller = null;
		this.onShowEmitter = this._register(new Emitter());
		this.onShow = this.onShowEmitter.event;
		this.onHideEmitter = this._register(new Emitter());
		this.onHide = this.onHideEmitter.event;
		this.idPrefix = options2.idPrefix;
		this._container = options2.container;
		this.styles = options2.styles;
		this._register(
			editorEventRunAndSubscribe(
				onDidRegisterWindow,
				({ window: window2, disposables }) => this.registerKeyModsListeners(window2, disposables),
				{
					window: mainWindow,
					disposables: this._store
				}
			)
		);
		this._register(
			onWillUnregisterWindow(window2 => {
				if (this.ui && getWindow(this.ui.container) === window2) {
					this.reparentUI(this.layoutService.mainContainer);
					this.layout(this.layoutService.mainContainerDimension, this.layoutService.mainContainerOffset.quickPickTop);
				}
			})
		);
	}
	registerKeyModsListeners(window2, disposables) {
		const listener = e => {
			this.keyMods.ctrlCmd = e.ctrlKey || e.metaKey;
			this.keyMods.alt = e.altKey;
		};
		for (const event of [EventType.KEY_DOWN, EventType.KEY_UP, EventType.MOUSE_DOWN]) {
			disposables.add(addDisposableListener(window2, event, listener, true));
		}
	}
	getUI(showInActiveContainer) {
		if (this.ui) {
			if (showInActiveContainer) {
				if (getWindow(this._container) !== getWindow(this.layoutService.activeContainer)) {
					this.reparentUI(this.layoutService.activeContainer);
					this.layout(this.layoutService.activeContainerDimension, this.layoutService.activeContainerOffset.quickPickTop);
				}
			}
			return this.ui;
		}
		const container = append(this._container, $('.quick-input-widget.show-file-icons'));
		container.tabIndex = -1;
		container.style.display = 'none';
		const styleSheet = createStyleSheet(container);
		const titleBar = append(container, $('.quick-input-titlebar'));
		const leftActionBar = this._register(new ActionBar(titleBar, { hoverDelegate: this.options.hoverDelegate }));
		leftActionBar.domNode.classList.add('quick-input-left-action-bar');
		const title = append(titleBar, $('.quick-input-title'));
		const rightActionBar = this._register(new ActionBar(titleBar, { hoverDelegate: this.options.hoverDelegate }));
		rightActionBar.domNode.classList.add('quick-input-right-action-bar');
		const headerContainer = append(container, $('.quick-input-header'));
		const checkAll = append(headerContainer, $('input.quick-input-check-all'));
		checkAll.type = 'checkbox';

		this._register(
			addStandardDisposableListener(checkAll, EventType.CHANGE, e => {
				const checked = checkAll.checked;
				list.setAllVisibleChecked(checked);
			})
		);
		this._register(
			addDisposableListener(checkAll, EventType.CLICK, e => {
				if (e.x || e.y) {
					inputBox.setFocus();
				}
			})
		);
		const description2 = append(headerContainer, $('.quick-input-description'));
		const inputContainer = append(headerContainer, $('.quick-input-and-message'));
		const filterContainer = append(inputContainer, $('.quick-input-filter'));
		const inputBox = this._register(new QuickInputBox(filterContainer, this.styles.inputBox, this.styles.toggle));

		const visibleCountContainer = append(filterContainer, $('.quick-input-visible-count'));

		const visibleCount = new CountBadge(
			visibleCountContainer,
			{
				countFormat: localize('{0} Results')
			},
			this.styles.countBadge
		);
		const countContainer = append(filterContainer, $('.quick-input-count'));

		const count = new CountBadge(
			countContainer,
			{
				countFormat: localize('{0} Selected')
			},
			this.styles.countBadge
		);
		const okContainer = append(headerContainer, $('.quick-input-action'));
		const ok2 = this._register(new Button(okContainer, this.styles.button));
		ok2.label = localize('OK');
		this._register(
			ok2.onDidClick(e => {
				this.onDidAcceptEmitter.fire();
			})
		);
		const customButtonContainer = append(headerContainer, $('.quick-input-action'));
		const customButton = this._register(new Button(customButtonContainer, { ...this.styles.button, supportIcons: true }));
		customButton.label = localize('Custom');
		this._register(
			customButton.onDidClick(e => {
				this.onDidCustomEmitter.fire();
			})
		);
		const message = append(inputContainer, $(`#${this.idPrefix}message.quick-input-message`));
		const progressBar = this._register(new ProgressBar(container, this.styles.progressBar));
		progressBar.getContainer().classList.add('quick-input-progress');
		const widget = append(container, $('.quick-input-html-widget'));
		widget.tabIndex = -1;
		const description1 = append(container, $('.quick-input-description'));
		const listId = this.idPrefix + 'list';
		const list = this._register(
			this.instantiationService.createInstance(
				QuickInputTree,
				container,
				this.options.hoverDelegate,
				this.options.linkOpenerDelegate,
				listId
			)
		);

		this._register(
			list.onDidChangeFocus(() => {
				inputBox.setAttribute('aria-activedescendant', list.getActiveDescendant() || '');
			})
		);
		this._register(
			list.onChangedAllVisibleChecked(checked => {
				checkAll.checked = checked;
			})
		);
		this._register(
			list.onChangedVisibleCount(c => {
				visibleCount.setCount(c);
			})
		);
		this._register(
			list.onChangedCheckedCount(c => {
				count.setCount(c);
			})
		);
		this._register(
			list.onLeave(() => {
				setTimeout(() => {
					if (!this.controller) {
						return;
					}
					inputBox.setFocus();
					if (this.controller instanceof QuickPick && this.controller.canSelectMany) {
						list.clearFocus();
					}
				}, 0);
			})
		);
		const focusTracker = trackFocus(container);
		this._register(focusTracker);
		this._register(
			addDisposableListener(
				container,
				EventType.FOCUS,
				e => {
					if (isAncestor(e.relatedTarget, container)) {
						return;
					}
					this.previousFocusElement = e.relatedTarget instanceof HTMLElement ? e.relatedTarget : undefined;
				},
				true
			)
		);
		this._register(
			focusTracker.onDidBlur(() => {
				if (!this.getUI().ignoreFocusOut && !this.options.ignoreFocusOut()) {
					this.hide(1);
				}
				this.previousFocusElement = undefined;
			})
		);
		this._register(
			addDisposableListener(container, EventType.FOCUS, e => {
				inputBox.setFocus();
			})
		);
		this._register(
			addStandardDisposableListener(container, EventType.KEY_DOWN, event => {
				if (isAncestor(event.target, widget)) {
					return;
				}
				switch (event.keyCode) {
					case 3:
						EventHelper.stop(event, true);
						if (this.enabled) {
							this.onDidAcceptEmitter.fire();
						}
						break;
					case 9:
						EventHelper.stop(event, true);
						this.hide(2); //gesture
						break;
					case 2:
						if (!event.altKey && !event.ctrlKey && !event.metaKey) {
							const selectors = [
								'.quick-input-list .monaco-action-bar .always-visible',
								'.quick-input-list-entry:hover .monaco-action-bar',
								'.monaco-list-row.focused .monaco-action-bar'
							];
							if (container.classList.contains('show-checkboxes')) {
								selectors.push('input');
							} else {
								selectors.push('input[type=text]');
							}
							if (this.getUI().list.isDisplayed()) {
								selectors.push('.monaco-list');
							}
							if (this.getUI().message) {
								selectors.push('.quick-input-message a');
							}
							if (this.getUI().widget) {
								if (isAncestor(event.target, this.getUI().widget)) {
									break;
								}
								selectors.push('.quick-input-html-widget');
							}
							const stops = container.querySelectorAll(selectors.join(', '));
							if (event.shiftKey && event.target === stops[0]) {
								EventHelper.stop(event, true);
								list.clearFocus();
							} else if (!event.shiftKey && isAncestor(event.target, stops[stops.length - 1])) {
								EventHelper.stop(event, true);
								stops[0].focus();
							}
						}
						break;
					case 10:
						if (event.ctrlKey) {
							EventHelper.stop(event, true);
							this.getUI().list.toggleHover();
						}
						break;
				}
			})
		);
		this.ui = {
			container,
			styleSheet,
			leftActionBar,
			titleBar,
			title,
			description1,
			description2,
			widget,
			rightActionBar,
			checkAll,
			inputContainer,
			filterContainer,
			inputBox,
			visibleCountContainer,
			visibleCount,
			countContainer,
			count,
			okContainer,
			ok: ok2,
			message,
			customButtonContainer,
			customButton,
			list,
			progressBar,
			onDidAccept: this.onDidAcceptEmitter.event,
			onDidCustom: this.onDidCustomEmitter.event,
			onDidTriggerButton: this.onDidTriggerButtonEmitter.event,
			ignoreFocusOut: false,
			keyMods: this.keyMods,
			show: controller => this.show(controller),
			hide: () => this.hide(),
			setVisibilities: visibilities => this.setVisibilities(visibilities),
			setEnabled: enabled => this.setEnabled(enabled),
			setContextKey: contextKey => this.options.setContextKey(contextKey),
			linkOpenerDelegate: content => this.options.linkOpenerDelegate(content)
		};
		this.updateStyles();
		return this.ui;
	}
	reparentUI(container) {
		if (this.ui) {
			this._container = container;
			append(this._container, this.ui.container);
		}
	}
	pick(picks, options2 = {}, token = cancellationToken_none) {
		return new Promise((doResolve, reject) => {
			let resolve2 = result => {
				resolve2 = doResolve;
				options2.onKeyMods?.call(options2, input.keyMods);
				doResolve(result);
			};
			if (token.isCancellationRequested) {
				resolve2(undefined);
				return;
			}
			const input = this.createQuickPick();
			let activeItem;
			const disposables = [
				input,
				input.onDidAccept(() => {
					if (input.canSelectMany) {
						resolve2(input.selectedItems.slice());
						input.hide();
					} else {
						const result = input.activeItems[0];
						if (result) {
							resolve2(result);
							input.hide();
						}
					}
				}),
				input.onDidChangeActive(items => {
					const focused = items[0];
					if (focused && options2.onDidFocus) {
						options2.onDidFocus(focused);
					}
				}),
				input.onDidChangeSelection(items => {
					if (!input.canSelectMany) {
						const result = items[0];
						if (result) {
							resolve2(result);
							input.hide();
						}
					}
				}),
				input.onDidTriggerItemButton(
					event =>
						options2.onDidTriggerItemButton &&
						options2.onDidTriggerItemButton({
							...event,
							removeItem: () => {
								const index = input.items.indexOf(event.item);
								if (index !== -1) {
									const items = input.items.slice();
									const removed = items.splice(index, 1);
									const activeItems = input.activeItems.filter(activeItem2 => activeItem2 !== removed[0]);
									const keepScrollPositionBefore = input.keepScrollPosition;
									input.keepScrollPosition = true;
									input.items = items;
									if (activeItems) {
										input.activeItems = activeItems;
									}
									input.keepScrollPosition = keepScrollPositionBefore;
								}
							}
						})
				),
				input.onDidTriggerSeparatorButton(event => {
					return options2.onDidTriggerSeparatorButton?.call(options2, event);
				}),
				input.onDidChangeValue(value => {
					if (activeItem && !value && (input.activeItems.length !== 1 || input.activeItems[0] !== activeItem)) {
						input.activeItems = [activeItem];
					}
				}),
				token.onCancellationRequested(() => {
					input.hide();
				}),
				input.onDidHide(() => {
					dispose(disposables);
					resolve2(undefined);
				})
			];
			input.title = options2.title;
			input.canSelectMany = !!options2.canPickMany;
			input.placeholder = options2.placeHolder;
			input.ignoreFocusOut = !!options2.ignoreFocusLost;
			input.matchOnDescription = !!options2.matchOnDescription;
			input.matchOnDetail = !!options2.matchOnDetail;
			input.matchOnLabel = options2.matchOnLabel === undefined || options2.matchOnLabel;
			input.quickNavigate = options2.quickNavigate;
			input.hideInput = !!options2.hideInput;
			input.contextKey = options2.contextKey;
			input.busy = true;
			Promise.all([picks, options2.activeItem]).then(([items, _activeItem]) => {
				activeItem = _activeItem;
				input.busy = false;
				input.items = items;
				if (input.canSelectMany) {
					input.selectedItems = items.filter(item => item.type !== 'separator' && item.picked);
				}
				if (activeItem) {
					input.activeItems = [activeItem];
				}
			});
			input.show();
			Promise.resolve(picks).then(undefined, err => {
				reject(err);
				input.hide();
			});
		});
	}
	createQuickPick() {
		const ui = this.getUI(true);
		return new QuickPick(ui);
	}
	createInputBox() {
		const ui = this.getUI(true);
		return new InputBox2(ui);
	}
	show(controller) {
		const ui = this.getUI(true);
		this.onShowEmitter.fire();
		const oldController = this.controller;
		this.controller = controller;
		oldController?.didHide();
		this.setEnabled(true);
		ui.leftActionBar.clear();
		ui.title.textContent = '';
		ui.description1.textContent = '';
		ui.description2.textContent = '';
		reset(ui.widget);
		ui.rightActionBar.clear();
		ui.checkAll.checked = false;
		ui.inputBox.placeholder = '';
		ui.inputBox.password = false;
		ui.inputBox.showDecoration(0);
		ui.visibleCount.setCount(0);
		ui.count.setCount(0);
		reset(ui.message);
		ui.progressBar.stop();
		ui.list.setElements([]);
		ui.list.matchOnDescription = false;
		ui.list.matchOnDetail = false;
		ui.list.matchOnLabel = true;
		ui.list.sortByLabel = true;
		ui.ignoreFocusOut = false;
		ui.inputBox.toggles = undefined;
		const backKeybindingLabel = this.options.backKeybindingLabel();
		backButton.tooltip = backKeybindingLabel ? localize(backKeybindingLabel) : localize('Back');
		ui.container.style.display = '';
		this.updateLayout();
		ui.inputBox.setFocus();
	}
	isVisible() {
		return !!this.ui && this.ui.container.style.display !== 'none';
	}
	setVisibilities(visibilities) {
		const ui = this.getUI();
		ui.title.style.display = visibilities.title ? '' : 'none';
		ui.description1.style.display = visibilities.description && (visibilities.inputBox || visibilities.checkAll) ? '' : 'none';
		ui.description2.style.display = visibilities.description && !(visibilities.inputBox || visibilities.checkAll) ? '' : 'none';
		ui.checkAll.style.display = visibilities.checkAll ? '' : 'none';
		ui.inputContainer.style.display = visibilities.inputBox ? '' : 'none';
		ui.filterContainer.style.display = visibilities.inputBox ? '' : 'none';
		ui.visibleCountContainer.style.display = visibilities.visibleCount ? '' : 'none';
		ui.countContainer.style.display = visibilities.count ? '' : 'none';
		ui.okContainer.style.display = visibilities.ok ? '' : 'none';
		ui.customButtonContainer.style.display = visibilities.customButton ? '' : 'none';
		ui.message.style.display = visibilities.message ? '' : 'none';
		ui.progressBar.getContainer().style.display = visibilities.progressBar ? '' : 'none';
		ui.list.display(!!visibilities.list);
		ui.container.classList.toggle('show-checkboxes', !!visibilities.checkBox);
		ui.container.classList.toggle('hidden-input', !visibilities.inputBox && !visibilities.description);
		this.updateLayout();
	}
	setEnabled(enabled) {
		if (enabled !== this.enabled) {
			this.enabled = enabled;
			for (const item of this.getUI().leftActionBar.viewItems) {
				item.action.enabled = enabled;
			}
			for (const item of this.getUI().rightActionBar.viewItems) {
				item.action.enabled = enabled;
			}
			this.getUI().checkAll.disabled = !enabled;
			this.getUI().inputBox.enabled = enabled;
			this.getUI().ok.enabled = enabled;
			this.getUI().list.enabled = enabled;
		}
	}
	hide(reason) {
		const controller = this.controller;
		if (!controller) {
			return;
		}
		controller.willHide(reason);

		const container = this.ui?.container;
		const focusChanged = container && !isAncestorOfActiveElement(container);
		this.controller = null;
		this.onHideEmitter.fire();
		if (container) {
			container.style.display = 'none';
		}
		if (!focusChanged) {
			let currentElement = this.previousFocusElement;
			while (currentElement && !currentElement.offsetParent) {
				currentElement = currentElement.parentElement;
			}
			if (ccurrentElement?.offsetParent) {
				currentElement.focus();
				this.previousFocusElement = undefined;
			} else {
				this.options.returnFocus();
			}
		}
		controller.didHide(reason);
	}
	layout(dimension, titleBarOffset) {
		this.dimension = dimension;
		this.titleBarOffset = titleBarOffset;
		this.updateLayout();
	}
	updateLayout() {
		if (this.ui && this.isVisible()) {
			this.ui.container.style.top = `${this.titleBarOffset}px`;
			const style = this.ui.container.style;
			const width2 = Math.min(this.dimension.width * 0.62, QuickInputController.MAX_WIDTH);
			style.width = width2 + 'px';
			style.marginLeft = '-' + width2 / 2 + 'px';
			this.ui.inputBox.layout();
			this.ui.list.layout(this.dimension && this.dimension.height * 0.4);
		}
	}
	applyStyles(styles) {
		this.styles = styles;
		this.updateStyles();
	}
	updateStyles() {
		if (this.ui) {
			const {
				quickInputTitleBackground: quickInputTitleBackground2,
				quickInputBackground: quickInputBackground2,
				quickInputForeground: quickInputForeground2,
				widgetBorder: widgetBorder2,
				widgetShadow: widgetShadow2
			} = this.styles.widget;
			this.ui.titleBar.style.backgroundColor =
				quickInputTitleBackground2 !== null && quickInputTitleBackground2 !== undefined ? quickInputTitleBackground2 : '';
			this.ui.container.style.backgroundColor =
				quickInputBackground2 !== null && quickInputBackground2 !== undefined ? quickInputBackground2 : '';
			this.ui.container.style.color =
				quickInputForeground2 !== null && quickInputForeground2 !== undefined ? quickInputForeground2 : '';
			this.ui.container.style.border = widgetBorder2 ? `1px solid ${widgetBorder2}` : '';
			this.ui.container.style.boxShadow = widgetShadow2 ? `0 0 8px 2px ${widgetShadow2}` : '';
			this.ui.list.style(this.styles.list);
			const content = [];
			if (this.styles.pickerGroup.pickerGroupBorder) {
				content.push(
					`.quick-input-list .quick-input-list-entry { border-top-color:  ${this.styles.pickerGroup.pickerGroupBorder}; }`
				);
			}
			if (this.styles.pickerGroup.pickerGroupForeground) {
				content.push(`.quick-input-list .quick-input-list-separator { color:  ${this.styles.pickerGroup.pickerGroupForeground}; }`);
			}
			if (this.styles.pickerGroup.pickerGroupForeground) {
				content.push(`.quick-input-list .quick-input-list-separator-as-item { color: var(--vscode-descriptionForeground); }`);
			}
			if (
				this.styles.keybindingLabel.keybindingLabelBackground ||
				this.styles.keybindingLabel.keybindingLabelBorder ||
				this.styles.keybindingLabel.keybindingLabelBottomBorder ||
				this.styles.keybindingLabel.keybindingLabelShadow ||
				this.styles.keybindingLabel.keybindingLabelForeground
			) {
				content.push('.quick-input-list .monaco-keybinding > .monaco-keybinding-key {');
				if (this.styles.keybindingLabel.keybindingLabelBackground) {
					content.push(`background-color: ${this.styles.keybindingLabel.keybindingLabelBackground};`);
				}
				if (this.styles.keybindingLabel.keybindingLabelBorder) {
					content.push(`border-color: ${this.styles.keybindingLabel.keybindingLabelBorder};`);
				}
				if (this.styles.keybindingLabel.keybindingLabelBottomBorder) {
					content.push(`border-bottom-color: ${this.styles.keybindingLabel.keybindingLabelBottomBorder};`);
				}
				if (this.styles.keybindingLabel.keybindingLabelShadow) {
					content.push(`box-shadow: inset 0 -1px 0 ${this.styles.keybindingLabel.keybindingLabelShadow};`);
				}
				if (this.styles.keybindingLabel.keybindingLabelForeground) {
					content.push(`color: ${this.styles.keybindingLabel.keybindingLabelForeground};`);
				}
				content.push('}');
			}
			const newStyles = content.join('\n');
			if (newStyles !== this.ui.styleSheet.textContent) {
				this.ui.styleSheet.textContent = newStyles;
			}
		}
	}
}
QuickInputController.MAX_WIDTH = 600;
__decorate([__param(1, ILayoutService), __param(2, IInstantiationService)], QuickInputController);

class QuickInputService extends Themable {
	get controller() {
		if (!this._controller) {
			this._controller = this._register(this.createController());
		}
		return this._controller;
	}
	get hasController() {
		return !!this._controller;
	}
	get quickAccess() {
		if (!this._quickAccess) {
			this._quickAccess = this._register(this.instantiationService.createInstance(QuickAccessController));
		}
		return this._quickAccess;
	}
	constructor(instantiationService, contextKeyService, themeService, layoutService, configurationService) {
		super(themeService);
		this.instantiationService = instantiationService;
		this.contextKeyService = contextKeyService;
		this.layoutService = layoutService;
		this.configurationService = configurationService;
		this._onShow = this._register(new Emitter());
		this._onHide = this._register(new Emitter());
		this.contexts = new Map();
	}
	createController(host = this.layoutService, options2) {
		const defaultOptions3 = {
			idPrefix: 'quickInput_',
			container: host.activeContainer,
			ignoreFocusOut: () => false,
			backKeybindingLabel: () => undefined,
			setContextKey: id => this.setContextKey(id),
			linkOpenerDelegate: content => {
				this.instantiationService.invokeFunction(accessor => {
					const openerService = accessor.get(IOpenerService);
					openerService.open(content, { allowCommands: true, fromUserGesture: true });
				});
			},
			returnFocus: () => host.focus(),
			styles: this.computeStyles(),
			hoverDelegate: this._register(this.instantiationService.createInstance(QuickInputHoverDelegate))
		};
		const controller = this._register(
			this.instantiationService.createInstance(QuickInputController, {
				...defaultOptions3,
				...options2
			})
		);
		controller.layout(host.activeContainerDimension, host.activeContainerOffset.quickPickTop);
		this._register(
			host.onDidLayoutActiveContainer(dimension => {
				if (getWindow(host.activeContainer) === getWindow(controller.container)) {
					controller.layout(dimension, host.activeContainerOffset.quickPickTop);
				}
			})
		);
		this._register(
			host.onDidChangeActiveContainer(() => {
				if (controller.isVisible()) {
					return;
				}
				controller.layout(host.activeContainerDimension, host.activeContainerOffset.quickPickTop);
			})
		);
		this._register(
			controller.onShow(() => {
				this.resetContextKeys();
				this._onShow.fire();
			})
		);
		this._register(
			controller.onHide(() => {
				this.resetContextKeys();
				this._onHide.fire();
			})
		);
		return controller;
	}
	setContextKey(id) {
		let key;
		if (id) {
			key = this.contexts.get(id);
			if (!key) {
				key = new RawContextKey(id, false).bindTo(this.contextKeyService);
				this.contexts.set(id, key);
			}
		}
		if (key && key.get()) {
			return;
		}
		this.resetContextKeys();
		key?.set(true);
	}
	resetContextKeys() {
		this.contexts.forEach(context => {
			if (context.get()) {
				context.reset();
			}
		});
	}
	pick(picks, options2 = {}, token = cancellationToken_none) {
		return this.controller.pick(picks, options2, token);
	}
	createQuickPick() {
		return this.controller.createQuickPick();
	}
	createInputBox() {
		return this.controller.createInputBox();
	}
	updateStyles() {
		if (this.hasController) {
			this.controller.applyStyles(this.computeStyles());
		}
	}
	computeStyles() {
		return {
			widget: {
				quickInputBackground: asCssVariable(colorId_quickInput_background),
				quickInputForeground: asCssVariable(colorId_quickInput_foreground),
				quickInputTitleBackground: asCssVariable(colorId_quickInputTitle_background),
				widgetBorder: asCssVariable(colorId_widget_border),
				widgetShadow: asCssVariable(colorId_widget_shadow)
			},
			inputBox: defaultStyle_inputbox,
			toggle: defaultStyle_toggle,
			countBadge: defaultStyle_countBadge,

			keybindingLabel: {
				keybindingLabelBackground: asCssVariable(colorId_keybindingLabel_background),
				keybindingLabelForeground: asCssVariable(colorId_keybindingLabel_foreground),
				keybindingLabelBorder: asCssVariable(colorId_keybindingLabel_border),
				keybindingLabelBottomBorder: asCssVariable(colorId_keybindingLabel_bottomBorder),
				keybindingLabelShadow: asCssVariable(colorId_widget_shadow)
			},
			progressBar: {
				progressBarBackground: asCssVariable(colorId_progressBar_background)
			},
			button: {
				buttonForeground: asCssVariable(colorId_button_foreground),
				buttonSeparator: asCssVariable(colorId_button_separator),
				buttonBackground: asCssVariable(colorId_button_background),
				buttonHoverBackground: asCssVariable(colorId_buttonHover_background),
				buttonSecondaryForeground: asCssVariable(colorId_buttonSecondary_foreground),
				buttonSecondaryBackground: asCssVariable(colorId_buttonSecondary_background),
				buttonSecondaryHoverBackground: asCssVariable(colorId_buttonSecondaryHover_background),
				buttonBorder: asCssVariable(colorId_button_border)
			},

			list: getListStyles({
				listBackground: colorId_quickInput_background,
				listFocusBackground: colorId_quickInputListFocus_background,
				listFocusForeground: colorId_quickInputListFocus_foreground,
				// Look like focused when inactive.
				listInactiveFocusForeground: colorId_quickInputListFocus_foreground,
				listInactiveSelectionIconForeground: colorId_quickInputListFocusIcon_background,
				listInactiveFocusBackground: colorId_quickInputListFocus_background,
				listFocusOutline: colorId_activeContrast_border,
				listInactiveFocusOutline: colorId_activeContrast_border
			}),
			pickerGroup: {
				pickerGroupBorder: asCssVariable(colorId_pickerGroup_border),
				pickerGroupForeground: asCssVariable(colorId_pickerGroup_foreground)
			}
		};
	}
}
__decorate(
	[
		__param(0, IInstantiationService),
		__param(1, IContextKeyService),
		__param(2, IThemeService),
		__param(3, ILayoutService),
		__param(4, IConfigurationService)
	],
	QuickInputService
);

class EditorScopedQuickInputService extends QuickInputService {
	constructor(editor2, instantiationService, contextKeyService, themeService, codeEditorService, configurationService) {
		super(
			instantiationService,
			contextKeyService,
			themeService,
			new EditorScopedLayoutService(editor2.getContainerDomNode(), codeEditorService),
			configurationService
		);
		this.host = undefined;
		const contribution = QuickInputEditorContribution.get(editor2);
		if (contribution) {
			const widget = contribution.widget;
			this.host = {
				_serviceBrand: undefined,
				get mainContainer() {
					return widget.getDomNode();
				},
				getContainer() {
					return widget.getDomNode();
				},
				whenContainerStylesLoaded() {
					return;
				},
				get containers() {
					return [widget.getDomNode()];
				},
				get activeContainer() {
					return widget.getDomNode();
				},
				get mainContainerDimension() {
					return editor2.getLayoutInfo();
				},
				get activeContainerDimension() {
					return editor2.getLayoutInfo();
				},
				get onDidLayoutMainContainer() {
					return editor2.onDidLayoutChange;
				},
				get onDidLayoutActiveContainer() {
					return editor2.onDidLayoutChange;
				},
				get onDidLayoutContainer() {
					return editorEventMap(editor2.onDidLayoutChange, dimension => ({
						container: widget.getDomNode(),
						dimension
					}));
				},
				get onDidChangeActiveContainer() {
					return editorEvent_none;
				},
				get onDidAddContainer() {
					return editorEvent_none;
				},
				get mainContainerOffset() {
					return { top: 0, quickPickTop: 0 };
				},
				get activeContainerOffset() {
					return { top: 0, quickPickTop: 0 };
				},
				focus: () => editor2.focus()
			};
		} else {
			this.host = undefined;
		}
	}
	createController() {
		return super.createController(this.host);
	}
}
__decorate(
	[
		__param(1, IInstantiationService),
		__param(2, IContextKeyService),
		__param(3, IThemeService),
		__param(4, ICodeEditorService),
		__param(5, IConfigurationService)
	],
	EditorScopedQuickInputService
);

class StandaloneQuickInputService {
	get activeService() {
		const editor2 = this.codeEditorService.getFocusedCodeEditor();
		if (!editor2) {
			throw new Error('Quick input service needs a focused editor to work.');
		}
		let quickInputService = this.mapEditorToService.get(editor2);
		if (!quickInputService) {
			const newQuickInputService = (quickInputService = this.instantiationService.createInstance(
				EditorScopedQuickInputService,
				editor2
			));
			this.mapEditorToService.set(editor2, quickInputService);
			createSingleCallFunction(editor2.onDidDispose)(() => {
				newQuickInputService.dispose();
				this.mapEditorToService.delete(editor2);
			});
		}
		return quickInputService;
	}
	get quickAccess() {
		return this.activeService.quickAccess;
	}
	constructor(instantiationService, codeEditorService) {
		this.instantiationService = instantiationService;
		this.codeEditorService = codeEditorService;
		this.mapEditorToService = new Map();
	}
	pick(picks, options2 = {}, token = cancellationToken_none) {
		return this.activeService.pick(picks, options2, token);
	}
	createQuickPick() {
		return this.activeService.createQuickPick();
	}
	createInputBox() {
		return this.activeService.createInputBox();
	}
}
__decorate([__param(0, IInstantiationService), __param(1, ICodeEditorService)], StandaloneQuickInputService);
registerSingleton(
	IQuickInputService,
	StandaloneQuickInputService,
	0
	/* InstantiationType.Eager */
);

class QuickInputEditorContribution {
	static get(editor) {
		const contribution = editor.getContribution(QuickInputEditorContribution.ID);
		console.log({ contribution });
		return contribution;
	}
	constructor(editor) {
		this.editor = editor;
		this.widget = new QuickInputEditorWidget(editor);
	}
	dispose() {
		this.widget.dispose();
	}
}
QuickInputEditorContribution.ID = 'editor.controller.quickInput';

class QuickInputEditorWidget {
	constructor(codeEditor) {
		this.codeEditor = codeEditor;
		this.domNode = document.createElement('div');
		this.codeEditor.addOverlayWidget(this);
	}
	getId() {
		return QuickInputEditorWidget.ID;
	}
	getDomNode() {
		return this.domNode;
	}
	getPosition() {
		return {
			preference: 2 //TOP_CENTER
		};
	}
	dispose() {
		this.codeEditor.removeOverlayWidget(this);
	}
}
QuickInputEditorWidget.ID = 'editor.contrib.quickInputWidget';

registerEditorContribution(
	QuickInputEditorContribution.ID,
	QuickInputEditorContribution,
	4
	/* EditorContributionInstantiation.Lazy */
);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const quickAccessRegistry_extensionId = 'workbench.contributions.quickaccess';

class QuickAccessRegistry {
	constructor() {
		this.providers = [];
		this.defaultProvider = undefined;
	}
	registerQuickAccessProvider(provider) {
		if (provider.prefix.length === 0) {
			this.defaultProvider = provider;
		} else {
			this.providers.push(provider);
		}
		this.providers.sort((providerA, providerB) => providerB.prefix.length - providerA.prefix.length);
		return toDisposable(() => {
			this.providers.splice(this.providers.indexOf(provider), 1);
			if (this.defaultProvider === provider) {
				this.defaultProvider = undefined;
			}
		});
	}
	getQuickAccessProviders() {
		return [this.defaultProvider, ...this.providers].filter(e => !!e);
	}
	getQuickAccessProvider(prefix) {
		const result = prefix ? this.providers.find(provider => prefix.startsWith(provider.prefix)) || undefined : undefined;
		return result || this.defaultProvider;
	}
}
registry.add(quickAccessRegistry_extensionId, new QuickAccessRegistry());

class QuickPickItemScorerAccessor {
	constructor(options2) {
		this.options = options2;
	}
}

const quickPickItemScorerAccessor = new QuickPickItemScorerAccessor();

const IQuickInputService = createEditorServiceDecorator('quickInputService');

class QuickAccessController extends Disposable {
	constructor(quickInputService, instantiationService) {
		super();
		this.quickInputService = quickInputService;
		this.instantiationService = instantiationService;
		this.registry = registry.as(quickAccessRegistry_extensionId);
		this.mapProviderToDescriptor = new Map();
		this.lastAcceptedPickerValues = new Map();
		this.visibleQuickAccess = undefined;
	}
	show(value = '', options2) {
		this.doShowOrPick(value, false, options2);
	}
	doShowOrPick(value, pick, options2) {
		const [provider, descriptor] = this.getOrInstantiateProvider(value);
		const visibleQuickAccess = this.visibleQuickAccess;
		const visibleDescriptor = visibleQuickAccess?.descriptor;
		if (visibleQuickAccess && descriptor && visibleDescriptor === descriptor) {
			if (value !== descriptor.prefix && !options2?.preserveValue) {
				visibleQuickAccess.picker.value = value;
			}
			this.adjustValueSelection(visibleQuickAccess.picker, descriptor, options2);
			return;
		}
		if (descriptor && !options2?.preserveValue) {
			let newValue = undefined;
			if (visibleQuickAccess && visibleDescriptor && visibleDescriptor !== descriptor) {
				const newValueCandidateWithoutPrefix = visibleQuickAccess.value.substr(visibleDescriptor.prefix.length);
				if (newValueCandidateWithoutPrefix) {
					newValue = `${descriptor.prefix}${newValueCandidateWithoutPrefix}`;
				}
			}
			if (!newValue) {
				const defaultFilterValue = provider?.defaultFilterValue;
				if (defaultFilterValue === 1) {
					newValue = this.lastAcceptedPickerValues.get(descriptor);
				} else if (typeof defaultFilterValue === 'string') {
					newValue = `${descriptor.prefix}${defaultFilterValue}`;
				}
			}
			if (typeof newValue === 'string') {
				value = newValue;
			}
		}
		const visibleSelection = visibleQuickAccess?.picker?.valueSelection;
		const visibleValue = visibleQuickAccess?.picker?.value;
		const disposables = new DisposableStore();
		const picker = disposables.add(this.quickInputService.createQuickPick());
		picker.value = value;
		this.adjustValueSelection(picker, descriptor, options2);
		picker.placeholder = descriptor?.placeholder;
		picker.quickNavigate = options2?.quickNavigateConfiguration;
		picker.hideInput = !!picker.quickNavigate && !visibleQuickAccess;
		if (typeof options2?.itemActivation === 'number' || options2?.quickNavigateConfiguration) {
			picker.itemActivation = options2?.itemActivation ?? 2;
		}
		picker.contextKey = descriptor?.contextKey;
		picker.filterValue = value2 => value2.substring(descriptor ? descriptor.prefix.length : 0);
		let pickPromise = undefined;
		if (pick) {
			pickPromise = new DeferredPromise();
			disposables.add(
				editorEventOnce(picker.onWillAccept)(e => {
					e.veto();
					picker.hide();
				})
			);
		}
		disposables.add(this.registerPickerListeners(picker, provider, descriptor, value, options2?.providerOptions));
		const cts = disposables.add(new CancellationTokenSource());
		if (provider) {
			disposables.add(provider.provide(picker, cts.token, options2?.providerOptions));
		}
		editorEventOnce(picker.onDidHide)(() => {
			if (picker.selectedItems.length === 0) {
				cts.cancel();
			}
			disposables.dispose();
			ppickPromise?.complete(picker.selectedItems.slice(0));
		});
		picker.show();
		if (visibleSelection && visibleValue === value) {
			picker.valueSelection = visibleSelection;
		}
		if (pick) {
			return pickPromise?.p;
		}
	}
	adjustValueSelection(picker, descriptor, options2) {
		let valueSelection;
		if (options2?.preserveValue) {
			valueSelection = [picker.value.length, picker.value.length];
		} else {
			valueSelection = [descriptor.prefix?.length ?? 0, picker.value.length];
		}
		picker.valueSelection = valueSelection;
	}
	registerPickerListeners(picker, provider, descriptor, value, providerOptions) {
		const disposables = new DisposableStore();
		const visibleQuickAccess = (this.visibleQuickAccess = { picker, descriptor, value });
		disposables.add(
			toDisposable(() => {
				if (visibleQuickAccess === this.visibleQuickAccess) {
					this.visibleQuickAccess = undefined;
				}
			})
		);
		disposables.add(
			picker.onDidChangeValue(value2 => {
				const [providerForValue] = this.getOrInstantiateProvider(value2);
				if (providerForValue !== provider) {
					this.show(value2, {
						// do not rewrite value from user typing!
						preserveValue: true,
						// persist the value of the providerOptions from the original showing
						providerOptions
					});
				} else {
					visibleQuickAccess.value = value2;
				}
			})
		);
		if (descriptor) {
			disposables.add(
				picker.onDidAccept(() => {
					this.lastAcceptedPickerValues.set(descriptor, picker.value);
				})
			);
		}
		return disposables;
	}
	getOrInstantiateProvider(value) {
		const providerDescriptor = this.registry.getQuickAccessProvider(value);
		if (!providerDescriptor) {
			return [undefined, undefined];
		}
		let provider = this.mapProviderToDescriptor.get(providerDescriptor);
		if (!provider) {
			provider = this.instantiationService.createInstance(providerDescriptor.ctor);
			this.mapProviderToDescriptor.set(providerDescriptor, provider);
		}
		return [provider, providerDescriptor];
	}
}
__decorate([__param(0, IQuickInputService), __param(1, IInstantiationService)], QuickAccessController);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

//#
class AbstractCommandsQuickAccessProvider extends PickerQuickAccessProvider {
	constructor(options, instantiationService, keybindingService, commandService, dialogService) {
		super(AbstractCommandsQuickAccessProvider.PREFIX, options);
		this.instantiationService = instantiationService;
		this.keybindingService = keybindingService;
		this.commandService = commandService;

		this.dialogService = dialogService;
		this.commandsHistory = this._register(this.instantiationService.createInstance(CommandsHistory));
		this.options = options;
	}
	async _getPicks(filter, _disposables, token, runOptions) {
		const allCommandPicks = await this.getCommandPicks(token);
		if (token.isCancellationRequested) {
			return [];
		}
		const runTfidf = createSingleCallFunction(() => {
			const tfidf = new TfIdfCalculator();
			tfidf.updateDocuments(
				allCommandPicks.map(commandPick => ({
					key: commandPick.commandId,
					textChunks: [this.getTfIdfChunk(commandPick)]
				}))
			);
			const result = tfidf.calculateScores(filter, token);

			function _normalizeTfIdfScores(scores) {
				const results = scores.slice(0);
				results.sort((a, b) => b.score - a.score);
				const max = results[0]?.score ?? 0;
				if (max > 0) {
					for (const result of results) {
						result.score /= max;
					}
				}
				return results;
			}

			return _normalizeTfIdfScores(result)
				.filter(
					result => result.score > 0.5 //THRESHOLD
				)
				.slice(
					0,
					5 // MAX RESULTS
				);
		});
		const filteredCommandPicks = [];
		for (const commandPick of allCommandPicks) {
			const labelHighlights = AbstractCommandsQuickAccessProvider.WORD_FILTER(filter, commandPick.label);
			const aliasHighlights = commandPick.commandAlias
				? AbstractCommandsQuickAccessProvider.WORD_FILTER(filter, commandPick.commandAlias)
				: undefined;
			if (labelHighlights || aliasHighlights) {
				commandPick.highlights = {
					label: labelHighlights,
					detail: this.options.showAlias ? aliasHighlights : undefined
				};
				filteredCommandPicks.push(commandPick);
			} else if (filter === commandPick.commandId) {
				filteredCommandPicks.push(commandPick);
			} else if (filter.length >= 3) {
				const tfidf = runTfidf();
				if (token.isCancellationRequested) {
					return [];
				}
				const tfidfScore = tfidf.find(score3 => score3.key === commandPick.commandId);
				if (tfidfScore) {
					commandPick.tfIdfScore = tfidfScore.score;
					filteredCommandPicks.push(commandPick);
				}
			}
		}
		const mapLabelToCommand = new Map();
		for (const commandPick of filteredCommandPicks) {
			const existingCommandForLabel = mapLabelToCommand.get(commandPick.label);
			if (existingCommandForLabel) {
				commandPick.description = commandPick.commandId;
				existingCommandForLabel.description = existingCommandForLabel.commandId;
			} else {
				mapLabelToCommand.set(commandPick.label, commandPick);
			}
		}
		filteredCommandPicks.sort((commandPickA, commandPickB) => {
			if (commandPickA.tfIdfScore && commandPickB.tfIdfScore) {
				if (commandPickA.tfIdfScore === commandPickB.tfIdfScore) {
					return commandPickA.label.localeCompare(commandPickB.label);
				}
				return commandPickB.tfIdfScore - commandPickA.tfIdfScore;
			} else if (commandPickA.tfIdfScore) {
				return 1;
			} else if (commandPickB.tfIdfScore) {
				return -1;
			}
			const commandACounter = this.commandsHistory.peek(commandPickA.commandId);
			const commandBCounter = this.commandsHistory.peek(commandPickB.commandId);
			if (commandACounter && commandBCounter) {
				return commandACounter > commandBCounter ? -1 : 1;
			}
			if (commandACounter) {
				return -1;
			}
			if (commandBCounter) {
				return 1;
			}
			if (this.options.suggestedCommandIds) {
				const commandASuggestion = this.options.suggestedCommandIds.has(commandPickA.commandId);
				const commandBSuggestion = this.options.suggestedCommandIds.has(commandPickB.commandId);
				if (commandASuggestion && commandBSuggestion) {
					return 0;
				}
				if (commandASuggestion) {
					return -1;
				}
				if (commandBSuggestion) {
					return 1;
				}
			}
			return commandPickA.label.localeCompare(commandPickB.label);
		});
		const commandPicks = [];
		let addOtherSeparator = false;
		let addSuggestedSeparator = true;
		let addCommonlyUsedSeparator = !!this.options.suggestedCommandIds;
		for (let i = 0; i < filteredCommandPicks.length; i++) {
			const commandPick = filteredCommandPicks[i];
			if (i === 0 && this.commandsHistory.peek(commandPick.commandId)) {
				commandPicks.push({ type: 'separator', label: localize('recently used') });
				addOtherSeparator = true;
			}
			if (addSuggestedSeparator && commandPick.tfIdfScore !== undefined) {
				commandPicks.push({ type: 'separator', label: localize('similar commands') });
				addSuggestedSeparator = false;
			}
			if (
				addCommonlyUsedSeparator &&
				commandPick.tfIdfScore === undefined &&
				!this.commandsHistory.peek(commandPick.commandId) &&
				this.options.suggestedCommandIds?.has(commandPick.commandId)
			) {
				commandPicks.push({ type: 'separator', label: localize('commonly used') });
				addOtherSeparator = true;
				addCommonlyUsedSeparator = false;
			}
			if (
				addOtherSeparator &&
				commandPick.tfIdfScore === undefined &&
				!this.commandsHistory.peek(commandPick.commandId) &&
				!this.options.suggestedCommandIds?.has(commandPick.commandId)
			) {
				commandPicks.push({ type: 'separator', label: localize('other commands') });
				addOtherSeparator = false;
			}
			commandPicks.push(this.toCommandPick(commandPick, runOptions));
		}
		if (!this.hasAdditionalCommandPicks(filter, token)) {
			return commandPicks;
		}
		return {
			picks: commandPicks,
			additionalPicks: (async () => {
				const additionalCommandPicks = await this.getAdditionalCommandPicks(allCommandPicks, filteredCommandPicks, filter, token);
				if (token.isCancellationRequested) {
					return [];
				}
				const commandPicks2 = additionalCommandPicks.map(commandPick => this.toCommandPick(commandPick, runOptions));
				if (addSuggestedSeparator && commandPicks2[0]?.type !== 'separator') {
					commandPicks2.unshift({ type: 'separator', label: localize('similar commands') });
				}
				return commandPicks2;
			})()
		};
	}
	toCommandPick(commandPick) {
		if (commandPick.type === 'separator') {
			return commandPick;
		}
		return {
			...commandPick,

			detail: this.options.showAlias && commandPick.commandAlias !== commandPick.label ? commandPick.commandAlias : undefined,
			keybinding: this.keybindingService.lookupKeybinding(commandPick.commandId),
			accept: async () => {
				this.commandsHistory.push(commandPick.commandId);

				try {
					commandPick.args?.length
						? await this.commandService.executeCommand(commandPick.commandId, ...commandPick.args)
						: await this.commandService.executeCommand(commandPick.commandId);
				} catch (error) {
					if (!isCancellationError(error)) {
						this.dialogService.error(localize("Command '{0}' resulted in an error", commandPick.label), toErrorMessage(error));
					}
				}
			}
		};
	}
	// TF-IDF string to be indexed
	getTfIdfChunk({ label, commandAlias, commandDescription }) {
		let chunk = label;
		if (commandAlias && commandAlias !== label) {
			chunk += ` - ${commandAlias}`;
		}
		if (commandDescription && commandDescription.value !== label) {
			chunk += ` - ${commandDescription.value === commandDescription.original ? commandDescription.value : `${commandDescription.value} (${commandDescription.original})`}`;
		}
		return chunk;
	}
}
AbstractCommandsQuickAccessProvider.PREFIX = '>';

AbstractCommandsQuickAccessProvider.WORD_FILTER = or(matchesPrefix, matchesWords, matchesContiguousSubString);
__decorate(
	[__param(1, IInstantiationService), __param(2, IKeybindingService), __param(3, ICommandService), __param(4, IDialogService)],
	AbstractCommandsQuickAccessProvider
);

//#
class AbstractEditorCommandsQuickAccessProvider extends AbstractCommandsQuickAccessProvider {
	constructor(options, instantiationService, keybindingService, commandService, dialogService) {
		super(options, instantiationService, keybindingService, commandService, dialogService);
	}
	getCodeEditorCommandPicks() {
		const activeTextEditorControl = this.activeTextEditorControl;
		if (!activeTextEditorControl) {
			return [];
		}
		const editorCommandPicks = [];
		for (const editorAction of activeTextEditorControl.getSupportedActions()) {
			let commandDescription;
			if (editorAction.metadata?.description) {
				if (isLocalizedString(editorAction.metadata.description)) {
					commandDescription = editorAction.metadata.description;
				} else {
					commandDescription = {
						original: editorAction.metadata.description,
						value: editorAction.metadata.description
					};
				}
			}
			editorCommandPicks.push({
				commandId: editorAction.id,
				commandAlias: editorAction.alias,
				commandDescription,
				label: stripIcons(editorAction.label) || editorAction.id
			});
		}
		return editorCommandPicks;
	}
}

//#
class StandaloneCommandsQuickAccessProvider extends AbstractEditorCommandsQuickAccessProvider {
	get activeTextEditorControl() {
		return this.codeEditorService.getFocusedCodeEditor();
	}
	constructor(instantiationService, codeEditorService, keybindingService, commandService, dialogService) {
		super({ showAlias: false }, instantiationService, keybindingService, commandService, dialogService);
		this.codeEditorService = codeEditorService;
	}
	async getCommandPicks() {
		return this.getCodeEditorCommandPicks();
	}
	hasAdditionalCommandPicks() {
		return false;
	}
	async getAdditionalCommandPicks() {
		return [];
	}
}
__decorate(
	[
		__param(0, IInstantiationService),
		__param(1, ICodeEditorService),
		__param(2, IKeybindingService),
		__param(3, ICommandService),
		__param(4, IDialogService)
	],
	StandaloneCommandsQuickAccessProvider
);


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class HelpQuickAccessProvider {
	constructor(quickInputService, keybindingService) {
		this.quickInputService = quickInputService;
		this.keybindingService = keybindingService;
		this.registry = registry.as(quickAccessRegistry_extensionId);
	}
	provide(picker) {
		const disposables = new DisposableStore();
		disposables.add(
			picker.onDidAccept(() => {
				const [item] = picker.selectedItems;
				if (item) {
					this.quickInputService.quickAccess.show(item.prefix, { preserveValue: true });
				}
			})
		);
		disposables.add(
			picker.onDidChangeValue(value => {
				const providerDescriptor = this.registry.getQuickAccessProvider(value.substr(HelpQuickAccessProvider.PREFIX.length));
				if (providerDescriptor && providerDescriptor.prefix && providerDescriptor.prefix !== HelpQuickAccessProvider.PREFIX) {
					this.quickInputService.quickAccess.show(providerDescriptor.prefix, { preserveValue: true });
				}
			})
		);
		picker.items = this.getQuickAccessProviders().filter(p => p.prefix !== HelpQuickAccessProvider.PREFIX);
		return disposables;
	}
	getQuickAccessProviders() {
		return this.registry
			.getQuickAccessProviders()
			.sort((providerA, providerB) => providerA.prefix.localeCompare(providerB.prefix))
			.flatMap(provider => this.createPicks(provider));
	}
	createPicks(provider) {
		return provider.helpEntries.map(helpEntry => {
			const prefix = helpEntry.prefix || provider.prefix;
			const label = prefix || '\u2026';
			return {
				prefix,
				label,
				keybinding: helpEntry.commandId ? this.keybindingService.lookupKeybinding(helpEntry.commandId) : undefined,

				description: helpEntry.description
			};
		});
	}
}
HelpQuickAccessProvider.PREFIX = '?';
__decorate([
	//__param(0, IQuickInputService),
	__param(1, IKeybindingService)
], HelpQuickAccessProvider);

registry.as(quickAccessRegistry_extensionId).registerQuickAccessProvider({
	ctor: HelpQuickAccessProvider,
	prefix: '',
	helpEntries: [{ description: QuickHelpNLS.helpQuickAccessActionLabel }]
});

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

class GotoLineAction1 extends EditorAction {
	constructor() {
		super({
			id: GotoLineAction1.ID,
			label: GoToLineNLS.gotoLineActionLabel,
			alias: 'Go to Line/Column...',

			kbOpts: {
				kbExpr: ctxKeys_editorFocus,
				primary: 2048 | 37,
				mac: {
					primary: 256 | 37
					/* KeyCode.KeyG */
				},
				weight: 100
				/* KeybindingWeight.EditorContrib */
			}
		});
	}
	run(accessor) {
		//accessor.get(IQuickInputService).quickAccess.show(StandaloneGotoLineQuickAccessProvider.PREFIX);
	}
}
GotoLineAction1.ID = 'editor.action.gotoLine';
registerEditorAction(GotoLineAction1);

registry.as(quickAccessRegistry_extensionId).registerQuickAccessProvider({
	ctor: StandaloneGotoLineQuickAccessProvider,
	prefix: StandaloneGotoLineQuickAccessProvider.PREFIX,
	helpEntries: [{ description: GoToLineNLS.gotoLineActionLabel, commandId: GotoLineAction1.ID }]
});


class GotoSymbolAction extends EditorAction {
	constructor() {
		super({
			id: GotoSymbolAction.ID,
			label: QuickOutlineNLS.quickOutlineActionLabel,
			alias: 'Go to Symbol...',
			precondition: ctxKeys_editorHasProvider_documentSymbol,
			kbOpts: {
				kbExpr: ctxKeys_editorFocus,
				primary: 2048 | 1024 | 45,
				weight: 100
				/* KeybindingWeight.EditorContrib */
			},
			contextMenuOpts: {
				group: 'navigation',
				order: 3
			}
		});
	}
	run(accessor) {
		accessor.get(IQuickInputService).quickAccess.show(AbstractGotoSymbolQuickAccessProvider.PREFIX, { itemActivation: 0 });
	}
}
GotoSymbolAction.ID = 'editor.action.quickOutline';
registerEditorAction(GotoSymbolAction);
registry.as(quickAccessRegistry_extensionId).registerQuickAccessProvider({
	ctor: StandaloneGotoSymbolQuickAccessProvider,
	prefix: AbstractGotoSymbolQuickAccessProvider.PREFIX,
	helpEntries: [
		{
			description: QuickOutlineNLS.quickOutlineActionLabel,
			prefix: AbstractGotoSymbolQuickAccessProvider.PREFIX,
			commandId: GotoSymbolAction.ID
		},
		{
			description: QuickOutlineNLS.quickOutlineByCategoryActionLabel,
			prefix: AbstractGotoSymbolQuickAccessProvider.PREFIX_BY_CATEGORY
		}
	]
});


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

//#

const symbolKindNames = {
	[17]: localize('array'),
	[16]: localize('boolean'),
	[4]: localize('class'),
	[13]: localize('constant'),
	[8]: localize('constructor'),
	[9]: localize('enumeration'),
	[21]: localize('enumeration member'),
	[23]: localize('event'),
	[7]: localize('field'),
	[0]: localize('file'),
	[11]: localize('function'),
	[10]: localize('interface'),
	[19]: localize('key'),
	[5]: localize('method'),
	[1]: localize('module'),
	[2]: localize('namespace'),
	[20]: localize('null'),
	[15]: localize('number'),
	[18]: localize('object'),
	[24]: localize('operator'),
	[3]: localize('package'),
	[6]: localize('property'),
	[14]: localize('string'),
	[22]: localize('struct'),
	[25]: localize('type parameter'),
	[12]: localize('variable')
};

class AbstractGotoSymbolQuickAccessProvider extends AbstractEditorNavigationQuickAccessProvider {
	constructor(_languageFeaturesService, _outlineModelService, options2 = Object.create(null)) {
		super(options2);
		this._languageFeaturesService = _languageFeaturesService;
		this._outlineModelService = _outlineModelService;
		this.options = options2;
		this.options.canAcceptInBackground = true;
	}
	provideWithoutTextEditor(picker) {
		this.provideLabelPick(picker, localize('To go to a symbol, first open a text editor with symbol information.'));
		return disposableNone;
	}
	provideWithTextEditor(context, picker, token) {
		const editor2 = context.editor;
		const model = this.getModel(editor2);
		if (!model) {
			return disposableNone;
		}
		if (this._languageFeaturesService.documentSymbolProvider.has(model)) {
			return this.doProvideWithEditorSymbols(context, model, picker, token);
		}
		return this.doProvideWithoutEditorSymbols(context, model, picker, token);
	}
	doProvideWithoutEditorSymbols(context, model, picker, token) {
		const disposables = new DisposableStore();
		this.provideLabelPick(picker, localize('The active text editor does not provide symbol information.'));
		(async () => {
			const result = await this.waitForLanguageSymbolRegistry(model, disposables);
			if (!result || token.isCancellationRequested) {
				return;
			}
			disposables.add(this.doProvideWithEditorSymbols(context, model, picker, token));
		})();
		return disposables;
	}
	provideLabelPick(picker, label) {
		picker.items = [
			{
				label,
				index: 0,
				kind: 14 //String
			}
		];

	}
	async waitForLanguageSymbolRegistry(model, disposables) {
		if (this._languageFeaturesService.documentSymbolProvider.has(model)) {
			return true;
		}
		const symbolProviderRegistryPromise = new DeferredPromise();
		const symbolProviderListener = disposables.add(
			this._languageFeaturesService.documentSymbolProvider.onDidChange(() => {
				if (this._languageFeaturesService.documentSymbolProvider.has(model)) {
					symbolProviderListener.dispose();
					symbolProviderRegistryPromise.complete(true);
				}
			})
		);
		disposables.add(toDisposable(() => symbolProviderRegistryPromise.complete(false)));
		return symbolProviderRegistryPromise.p;
	}
	doProvideWithEditorSymbols(context, model, picker, token) {
		const editor2 = context.editor;
		const disposables = new DisposableStore();
		disposables.add(
			picker.onDidAccept(event => {
				const [item] = picker.selectedItems;
				if (item && item.range) {
					this.gotoLocation(context, {
						range: item.range.selection,
						keyMods: picker.keyMods,
						preserveFocus: event.inBackground
					});
					if (!event.inBackground) {
						picker.hide();
					}
				}
			})
		);
		disposables.add(
			picker.onDidTriggerItemButton(({ item }) => {
				if (item && item.range) {
					this.gotoLocation(context, {
						range: item.range.selection,
						keyMods: picker.keyMods,
						forceSideBySide: true
					});
					picker.hide();
				}
			})
		);
		const symbolsPromise = this.getDocumentSymbols(model, token);
		let picksCts = undefined;
		const updatePickerItems = async positionToEnclose => {
			picksCts?.dispose(true);
			picker.busy = false;
			picksCts = new CancellationTokenSource(token);
			picker.busy = true;
			try {
				const query = prepareQuery(picker.value.substr(AbstractGotoSymbolQuickAccessProvider.PREFIX.length).trim());
				const items = await this.doGetSymbolPicks(symbolsPromise, query, undefined, picksCts.token);
				if (token.isCancellationRequested) {
					return;
				}
				if (items.length > 0) {
					picker.items = items;
					if (positionToEnclose && query.original.length === 0) {
						const candidate = findLast(items, item =>
							Boolean(
								item.type !== 'separator' && item.range && Range.containsPosition(item.range.decoration, positionToEnclose)
							)
						);
						if (candidate) {
							picker.activeItems = [candidate];
						}
					}
				} else {
					if (query.original.length > 0) {
						this.provideLabelPick(picker, localize('No matching editor symbols'));
					} else {
						this.provideLabelPick(picker, localize('No editor symbols'));
					}
				}
			} finally {
				if (!token.isCancellationRequested) {
					picker.busy = false;
				}
			}
		};
		disposables.add(picker.onDidChangeValue(() => updatePickerItems(undefined)));
		updatePickerItems(editor2.getSelection()?.getPosition());
		disposables.add(
			picker.onDidChangeActive(() => {
				const [item] = picker.activeItems;
				if (item && item.range) {
					editor2.revealRangeInCenter(
						item.range.selection,
						0
						// Smooth
					);
					this.addDecorations(editor2, item.range.decoration);
				}
			})
		);
		return disposables;
	}
	async doGetSymbolPicks(symbolsPromise, query, options2, token) {
		const symbols = await symbolsPromise;
		if (token.isCancellationRequested) {
			return [];
		}
		const filterBySymbolKind = query.original.indexOf(AbstractGotoSymbolQuickAccessProvider.SCOPE_PREFIX) === 0;
		const filterPos = filterBySymbolKind ? 1 : 0;
		let symbolQuery;
		let containerQuery;
		if (query.values && query.values.length > 1) {
			symbolQuery = pieceToQuery(query.values[0]);
			containerQuery = pieceToQuery(query.values.slice(1));
		} else {
			symbolQuery = query;
		}
		let buttons;
		const openSideBySideDirection = this.options?.openSideBySideDirection?.call(this.options);
		if (openSideBySideDirection) {
			buttons = [
				{
					iconClass:
						openSideBySideDirection === 'right'
							? asThemeIconClassNameString(codicon_splitHorizontal)
							: asThemeIconClassNameString(codicon_splitVertical),
					tooltip: openSideBySideDirection === 'right' ? localize('Open to the Side') : localize('Open to the Bottom')
				}
			];
		}
		const filteredSymbolPicks = [];
		for (let index = 0; index < symbols.length; index++) {
			const symbol = symbols[index];
			const symbolLabel = symbol.name.trim();
			const symbolLabelWithIcon = `$(${symbolKindsToIcon(symbol.kind).id}) ${symbolLabel}`;
			const symbolLabelIconOffset = symbolLabelWithIcon.length - symbolLabel.length;
			let containerLabel = symbol.containerName;
			if (options2?.extraContainerLabel) {
				if (containerLabel) {
					containerLabel = `${options2.extraContainerLabel} \u2022 ${containerLabel}`;
				} else {
					containerLabel = options2.extraContainerLabel;
				}
			}
			let symbolScore = undefined;
			let symbolMatches = undefined;
			let containerScore = undefined;
			let containerMatches = undefined;
			if (query.original.length > filterPos) {
				let skipContainerQuery = false;
				if (symbolQuery !== query) {
					[symbolScore, symbolMatches] = scoreFuzzy2(
						symbolLabelWithIcon,
						{
							...query,
							values: undefined
							/* disable multi-query support */
						},
						filterPos,
						symbolLabelIconOffset
					);
					if (typeof symbolScore === 'number') {
						skipContainerQuery = true;
					}
				}
				if (typeof symbolScore !== 'number') {
					[symbolScore, symbolMatches] = scoreFuzzy2(symbolLabelWithIcon, symbolQuery, filterPos, symbolLabelIconOffset);
					if (typeof symbolScore !== 'number') {
						continue;
					}
				}
				if (!skipContainerQuery && containerQuery) {
					if (containerLabel && containerQuery.original.length > 0) {
						[containerScore, containerMatches] = scoreFuzzy2(containerLabel, containerQuery);
					}
					if (typeof containerScore !== 'number') {
						continue;
					}

					symbolScore += containerScore;
				}
			}
			const deprecated =
				symbol.tags &&
				symbol.tags.indexOf(
					1 //Deprecated
				) >= 0;
			filteredSymbolPicks.push({
				index,
				kind: symbol.kind,
				score: symbolScore,
				label: symbolLabelWithIcon,

				description: containerLabel,
				highlights: deprecated
					? undefined
					: {
							label: symbolMatches,
							description: containerMatches
						},
				range: {
					selection: Range.collapseToStart(symbol.selectionRange),
					decoration: symbol.range
				},
				strikethrough: deprecated,
				buttons
			});
		}
		const sortedFilteredSymbolPicks = filteredSymbolPicks.sort((symbolA, symbolB) =>
			filterBySymbolKind ? this.compareByKindAndScore(symbolA, symbolB) : this.compareByScore(symbolA, symbolB)
		);
		let symbolPicks = [];
		if (filterBySymbolKind) {
			let updateLastSeparatorLabel = function () {
				if (lastSeparator && typeof lastSymbolKind === 'number' && lastSymbolKindCounter > 0) {
					lastSeparator.label = interpolateDigitsPlaceholders(
						NLS_SYMBOL_KIND_CACHE[lastSymbolKind] || FALLBACK_NLS_SYMBOL_KIND,
						lastSymbolKindCounter
					);
				}
			};
			let lastSymbolKind = undefined;
			let lastSeparator = undefined;
			let lastSymbolKindCounter = 0;
			for (const symbolPick of sortedFilteredSymbolPicks) {
				if (lastSymbolKind !== symbolPick.kind) {
					updateLastSeparatorLabel();
					lastSymbolKind = symbolPick.kind;
					lastSymbolKindCounter = 1;
					lastSeparator = { type: 'separator' };
					symbolPicks.push(lastSeparator);
				} else {
					lastSymbolKindCounter++;
				}
				symbolPicks.push(symbolPick);
			}
			updateLastSeparatorLabel();
		} else if (sortedFilteredSymbolPicks.length > 0) {
			symbolPicks = [{ label: localize(filteredSymbolPicks.length), type: 'separator' }, ...sortedFilteredSymbolPicks];
		}
		return symbolPicks;
	}
	compareByScore(symbolA, symbolB) {
		if (typeof symbolA.score !== 'number' && typeof symbolB.score === 'number') {
			return 1;
		} else if (typeof symbolA.score === 'number' && typeof symbolB.score !== 'number') {
			return -1;
		}
		if (typeof symbolA.score === 'number' && typeof symbolB.score === 'number') {
			if (symbolA.score > symbolB.score) {
				return -1;
			} else if (symbolA.score < symbolB.score) {
				return 1;
			}
		}
		if (symbolA.index < symbolB.index) {
			return -1;
		} else if (symbolA.index > symbolB.index) {
			return 1;
		}
		return 0;
	}
	compareByKindAndScore(symbolA, symbolB) {
		const kindA = NLS_SYMBOL_KIND_CACHE[symbolA.kind] || FALLBACK_NLS_SYMBOL_KIND;
		const kindB = NLS_SYMBOL_KIND_CACHE[symbolB.kind] || FALLBACK_NLS_SYMBOL_KIND;
		const result = kindA.localeCompare(kindB);
		if (result === 0) {
			return this.compareByScore(symbolA, symbolB);
		}
		return result;
	}
	async getDocumentSymbols(document2, token) {
		const model = await this._outlineModelService.getOrCreate(document2, token);
		return token.isCancellationRequested ? [] : model.asListOfDocumentSymbols();
	}
}
AbstractGotoSymbolQuickAccessProvider.PREFIX = '@';
AbstractGotoSymbolQuickAccessProvider.SCOPE_PREFIX = ':';
AbstractGotoSymbolQuickAccessProvider.PREFIX_BY_CATEGORY = `${AbstractGotoSymbolQuickAccessProvider.PREFIX}${AbstractGotoSymbolQuickAccessProvider.SCOPE_PREFIX}`;
__decorate([__param(0, ILanguageFeaturesService), __param(1, IOutlineModelService)], AbstractGotoSymbolQuickAccessProvider);


const FALLBACK_NLS_SYMBOL_KIND = localize('properties ({0})');
const NLS_SYMBOL_KIND_CACHE = {
	[5]: localize('methods ({0})'),
	[11]: localize('functions ({0})'),
	[8]: localize('constructors ({0})'),
	[12]: localize('variables ({0})'),
	[4]: localize('classes ({0})'),
	[22]: localize('structs ({0})'),
	[23]: localize('events ({0})'),
	[24]: localize('operators ({0})'),
	[10]: localize('interfaces ({0})'),
	[2]: localize('namespaces ({0})'),
	[3]: localize('packages ({0})'),
	[25]: localize('type parameters ({0})'),
	[1]: localize('modules ({0})'),
	[6]: localize('properties ({0})'),
	[9]: localize('enumerations ({0})'),
	[21]: localize('enumeration members ({0})'),
	[14]: localize('strings ({0})'),
	[0]: localize('files ({0})'),
	[17]: localize('arrays ({0})'),
	[15]: localize('numbers ({0})'),
	[16]: localize('booleans ({0})'),
	[18]: localize('objects ({0})'),
	[19]: localize('keys ({0})'),
	[7]: localize('fields ({0})'),
	[13]: localize('constants ({0})')
};

//#
class StandaloneGotoSymbolQuickAccessProvider extends AbstractGotoSymbolQuickAccessProvider {
	constructor(editorService, languageFeaturesService, outlineModelService) {
		super(languageFeaturesService, outlineModelService);
		this.editorService = editorService;
		this.onDidActiveTextEditorControlChange = editorEvent_none;
	}
	get activeTextEditorControl() {
		return this.editorService.getFocusedCodeEditor();
	}
}
__decorate(
	[__param(0, ICodeEditorService), __param(1, ILanguageFeaturesService), __param(2, IOutlineModelService)],
	StandaloneGotoSymbolQuickAccessProvider
);

const exceptionToErrorMessage = (exception, verbose) => {
	if (verbose && (exception.stack || exception.stacktrace)) {
		return localize(detectSystemErrorMessage(exception), stackToString(exception.stack) || stackToString(exception.stacktrace));
	}
	return detectSystemErrorMessage(exception);
};

const stackToString = stack => {
	if (isArray(stack)) {
		return stack.join('\n');
	}
	return stack;
};

const detectSystemErrorMessage = exception => {
	if (exception.code === 'ERR_UNC_HOST_NOT_ALLOWED') {
		return `${exception.message}. Please update the 'security.allowedUNCHosts' setting if you want to allow this host.`;
	}
	if (typeof exception.code === 'string' && typeof exception.errno === 'number' && typeof exception.syscall === 'string') {
		return localize(exception.message);
	}
	return exception.message || localize('An unknown error occurred. Please consult the log for more details.');
};

const toErrorMessage = (error = null, verbose = false) => {
	if (!error) {
		return localize('An unknown error occurred. Please consult the log for more details.');
	}
	if (isArray(error)) {
		const errors = error.filter(e => !!e);
		const msg = toErrorMessage(errors[0], verbose);
		if (errors.length > 1) {
			return localize(msg, errors.length);
		}
		return msg;
	}
	if ('string' === typeof error) {
		return error;
	}
	if (error.detail) {
		const detail = error.detail;
		if (detail.error) {
			return exceptionToErrorMessage(detail.error, verbose);
		}
		if (detail.exception) {
			return exceptionToErrorMessage(detail.exception, verbose);
		}
	}
	if (error.stack) {
		return exceptionToErrorMessage(error, verbose);
	}
	if (error.message) {
		return error.message;
	}
	return localize('An unknown error occurred. Please consult the log for more details.');
};



// node_modules/monaco-editor/esm/vs/editor/contrib/quickAccess/browser/editorNavigationQuickAccess.js
class AbstractEditorNavigationQuickAccessProvider {
	constructor(options2) {
		this.options = options2;
		this.rangeHighlightDecorationId = undefined;
	}
	provide(picker, token) {
		const disposables = new DisposableStore();
		picker.canAcceptInBackground = !!this.options?.canAcceptInBackground;
		picker.matchOnLabel = picker.matchOnDescription = picker.matchOnDetail = picker.sortByLabel = false;
		const pickerDisposable = disposables.add(new MutableDisposable());
		pickerDisposable.value = this.doProvide(picker, token);
		disposables.add(
			this.onDidActiveTextEditorControlChange(() => {
				pickerDisposable.value = undefined;
				pickerDisposable.value = this.doProvide(picker, token);
			})
		);
		return disposables;
	}
	doProvide(picker, token) {
		const disposables = new DisposableStore();
		const editor2 = this.activeTextEditorControl;
		if (editor2 && this.canProvideWithTextEditor(editor2)) {
			const context = { editor: editor2 };
			const codeEditor = getCodeEditor(editor2);
			if (codeEditor) {
				let lastKnownEditorViewState = editor2.saveViewState();
				disposables.add(
					codeEditor.onDidChangeCursorPosition(() => {
						lastKnownEditorViewState = editor2.saveViewState();
					})
				);
				context.restoreViewState = () => {
					if (lastKnownEditorViewState && editor2 === this.activeTextEditorControl) {
						editor2.restoreViewState(lastKnownEditorViewState);
					}
				};
				disposables.add(
					createSingleCallFunction(token.onCancellationRequested)(() => {
						return context.restoreViewState?.call(context);
					})
				);
			}
			disposables.add(toDisposable(() => this.clearDecorations(editor2)));
			disposables.add(this.provideWithTextEditor(context, picker, token));
		} else {
			disposables.add(this.provideWithoutTextEditor(picker, token));
		}
		return disposables;
	}

	canProvideWithTextEditor() {
		return true;
	}
	gotoLocation({ editor: editor2 }, options2) {
		editor2.setSelection(
			options2.range,
			'code.jump'
			/* TextEditorSelectionSource.JUMP */
		);
		editor2.revealRangeInCenter(
			options2.range,
			0
			// Smooth
		);
		if (!options2.preserveFocus) {
			editor2.focus();
		}
		const model = editor2.getModel();
		if (model && 'getLineContent' in model) {
			status(`${model.getLineContent(options2.range.startLineNumber)}`);
		}
	}
	getModel(editor) {
		return editor.getModel();
	}
	addDecorations(editor2, range2) {
		editor2.changeDecorations(changeAccessor => {
			const deleteDecorations = [];
			if (this.rangeHighlightDecorationId) {
				deleteDecorations.push(this.rangeHighlightDecorationId.overviewRulerDecorationId);
				deleteDecorations.push(this.rangeHighlightDecorationId.rangeHighlightId);
				this.rangeHighlightDecorationId = undefined;
			}
			const newDecorations = [
				// highlight the entire line on the range
				{
					range: range2,
					options: {
						description: 'quick-access-range-highlight',
						className: 'rangeHighlight',
						isWholeLine: true
					}
				},
				// also add overview ruler highlight
				{
					range: range2,
					options: {
						description: 'quick-access-range-highlight-overview',
						overviewRuler: {
							color: { id: colorId_overviewRuler_highlight_range_foreground },
							position: OverviewRulerLane2.Full
						}
					}
				}
			];
			const [rangeHighlightId, overviewRulerDecorationId] = changeAccessor.deltaDecorations(deleteDecorations, newDecorations);
			this.rangeHighlightDecorationId = { rangeHighlightId, overviewRulerDecorationId };
		});
	}
	clearDecorations(editor2) {
		const rangeHighlightDecorationId = this.rangeHighlightDecorationId;
		if (rangeHighlightDecorationId) {
			editor2.changeDecorations(changeAccessor => {
				changeAccessor.deltaDecorations(
					[rangeHighlightDecorationId.overviewRulerDecorationId, rangeHighlightDecorationId.rangeHighlightId],
					[]
				);
			});
			this.rangeHighlightDecorationId = undefined;
		}
	}
}

// node_modules/monaco-editor/esm/vs/editor/contrib/quickAccess/browser/gotoLineQuickAccess.js
class AbstractGotoLineQuickAccessProvider extends AbstractEditorNavigationQuickAccessProvider {
	constructor() {
		super({ canAcceptInBackground: true });
	}
	provideWithoutTextEditor(picker) {
		const label = localize('Open a text editor first to go to a line.');
		picker.items = [{ label }];

		return disposableNone;
	}
	provideWithTextEditor(context, picker) {
		const editor2 = context.editor;
		const disposables = new DisposableStore();
		disposables.add(
			picker.onDidAccept(event => {
				const [item] = picker.selectedItems;
				if (item) {
					if (!this.isValidLineNumber(editor2, item.lineNumber)) {
						return;
					}
					this.gotoLocation(context, {
						range: this.toRange(item.lineNumber, item.column),
						keyMods: picker.keyMods,
						preserveFocus: event.inBackground
					});
					if (!event.inBackground) {
						picker.hide();
					}
				}
			})
		);
		const updatePickerAndEditor = () => {
			const position = this.parsePosition(editor2, picker.value.trim().substr(AbstractGotoLineQuickAccessProvider.PREFIX.length));
			const label = this.getPickLabel(editor2, position.lineNumber, position.column);
			picker.items = [
				{
					lineNumber: position.lineNumber,
					column: position.column,
					label
				}
			];

			if (!this.isValidLineNumber(editor2, position.lineNumber)) {
				this.clearDecorations(editor2);
				return;
			}
			const range2 = this.toRange(position.lineNumber, position.column);
			editor2.revealRangeInCenter(
				range2,
				0
				// Smooth
			);
			this.addDecorations(editor2, range2);
		};
		updatePickerAndEditor();
		disposables.add(picker.onDidChangeValue(() => updatePickerAndEditor()));
		const codeEditor = getCodeEditor(editor2);
		if (codeEditor) {
			const options2 = codeEditor.getOptions();
			const lineNumbers = options2.get(
				68
				// lineNumbers
			);
			if (lineNumbers.renderType === 2) {
				codeEditor.updateOptions({ lineNumbers: 'on' });
				disposables.add(toDisposable(() => codeEditor.updateOptions({ lineNumbers: 'relative' })));
			}
		}
		return disposables;
	}
	toRange(lineNumber = 1, column = 1) {
		return {
			startLineNumber: lineNumber,
			startColumn: column,
			endLineNumber: lineNumber,
			endColumn: column
		};
	}
	parsePosition(editor2, value) {
		const numbers = value
			.split(/,|:|#/)
			.map(part => parseInt(part, 10))
			.filter(part => !isNaN(part));
		const endLine = this.lineCount(editor2) + 1;
		return {
			lineNumber: numbers[0] > 0 ? numbers[0] : endLine + numbers[0],
			column: numbers[1]
		};
	}
	getPickLabel(editor2, lineNumber, column) {
		if (this.isValidLineNumber(editor2, lineNumber)) {
			if (this.isValidColumn(editor2, lineNumber, column)) {
				return localize(lineNumber, column);
			}
			return localize(lineNumber);
		}
		const position = editor2.getPosition() || { lineNumber: 1, column: 1 };
		const lineCount = this.lineCount(editor2);
		if (lineCount > 1) {
			return localize(position.lineNumber, position.column, lineCount);
		}
		return localize(position.lineNumber, position.column);
	}
	isValidLineNumber(editor2, lineNumber) {
		if (!lineNumber || typeof lineNumber !== 'number') {
			return false;
		}
		return lineNumber > 0 && lineNumber <= this.lineCount(editor2);
	}
	isValidColumn(editor2, lineNumber, column) {
		if (!column || typeof column !== 'number') {
			return false;
		}
		const model = this.getModel(editor2);
		if (!model) {
			return false;
		}
		const positionCandidate = { lineNumber, column };
		return model.validatePosition(positionCandidate).equals(positionCandidate);
	}
	lineCount(editor) {
		return this.getModel(editor)?.getLineCount() ?? 0;
	}
}
AbstractGotoLineQuickAccessProvider.PREFIX = ':';

// node_modules/monaco-editor/esm/vs/editor/standalone/browser/quickAccess/standaloneGotoLineQuickAccess.js
class StandaloneGotoLineQuickAccessProvider extends AbstractGotoLineQuickAccessProvider {
	constructor(editorService) {
		super();
		this.editorService = editorService;
		this.onDidActiveTextEditorControlChange = editorEvent_none;
	}
	get activeTextEditorControl() {
		return this.editorService.getFocusedCodeEditor();
	}
}
__decorate([__param(0, ICodeEditorService)], StandaloneGotoLineQuickAccessProvider);


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

function matchesContiguous(word, wordToMatchAgainst) {
	const matchIndex = wordToMatchAgainst.toLowerCase().indexOf(word.toLowerCase());
	if (matchIndex !== -1) {
		return [{ start: matchIndex, end: matchIndex + word.length }];
	}
	return null;
}

class BaseQuickPickItemElement {
	constructor(index, hasCheckbox, mainItem) {
		this.index = index;
		this.hasCheckbox = hasCheckbox;
		this._hidden = false;
		this._init = new Lazy(() => {
			const saneLabel = mainItem.label || '';
			const saneSortLabel = parseLabelWithIcons(saneLabel).text.trim();

			return {
				saneLabel,
				saneSortLabel,

			};
		});
		this._saneDescription = mainItem.description;
		this._saneTooltip = mainItem.tooltip;
	}
	// #region Lazy Getters
	get saneLabel() {
		return this._init.value.saneLabel;
	}
	get saneSortLabel() {
		return this._init.value.saneSortLabel;
	}

	get element() {
		return this._element;
	}
	set element(value) {
		this._element = value;
	}
	get hidden() {
		return this._hidden;
	}
	set hidden(value) {
		this._hidden = value;
	}
	get saneDescription() {
		return this._saneDescription;
	}
	set saneDescription(value) {
		this._saneDescription = value;
	}
	get saneDetail() {
		return this._saneDetail;
	}
	set saneDetail(value) {
		this._saneDetail = value;
	}
	get saneTooltip() {
		return this._saneTooltip;
	}
	set saneTooltip(value) {
		this._saneTooltip = value;
	}
	get labelHighlights() {
		return this._labelHighlights;
	}
	set labelHighlights(value) {
		this._labelHighlights = value;
	}
	get descriptionHighlights() {
		return this._descriptionHighlights;
	}
	set descriptionHighlights(value) {
		this._descriptionHighlights = value;
	}
	get detailHighlights() {
		return this._detailHighlights;
	}
	set detailHighlights(value) {
		this._detailHighlights = value;
	}
}

class QuickPickItemElement extends BaseQuickPickItemElement {
	constructor(index, hasCheckbox, fireButtonTriggered, _onChecked, item, _separator) {
		super(index, hasCheckbox, item);
		this.fireButtonTriggered = fireButtonTriggered;
		this._onChecked = _onChecked;
		this.item = item;
		this._separator = _separator;
		this._checked = false;
		this.onChecked = hasCheckbox
			? editorEventMap(
					editorEventFilter(this._onChecked.event, e => e.element === this),
					e => e.checked
				)
			: editorEvent_none;
		this._saneDetail = item.detail;
		this._labelHighlights = item.highlights?.label;
		this._descriptionHighlights = item.highlights?.description;
		this._detailHighlights = item.highlights?.detail;
	}
	get separator() {
		return this._separator;
	}
	set separator(value) {
		this._separator = value;
	}
	get checked() {
		return this._checked;
	}
	set checked(value) {
		if (value !== this._checked) {
			this._checked = value;
			this._onChecked.fire({ element: this, checked: value });
		}
	}
	get checkboxDisabled() {
		return !!this.item.disabled;
	}
}

class QuickPickSeparatorElement extends BaseQuickPickItemElement {
	constructor(index, fireSeparatorButtonTriggered, separator) {
		super(index, false, separator);
		this.fireSeparatorButtonTriggered = fireSeparatorButtonTriggered;
		this.separator = separator;
		this.children = new Array();
		this.focusInsideSeparator = 0;
	}
}

class QuickInputItemDelegate {
	getHeight(element) {
		if (element instanceof QuickPickSeparatorElement) {
			return 30;
		}
		return element.saneDetail ? 44 : 22;
	}
	getTemplateId(element) {
		if (element instanceof QuickPickItemElement) {
			return QuickPickItemElementRenderer.ID;
		} else {
			return QuickPickSeparatorElementRenderer.ID;
		}
	}
}


class BaseQuickInputListRenderer {
	constructor(hoverDelegate) {
		this.hoverDelegate = hoverDelegate;
	}
	// TODO: only do the common stuff here and have a subclass handle their specific stuff
	renderTemplate(container) {
		const data = Object.create(null);
		data.toDisposeElement = new DisposableStore();
		data.toDisposeTemplate = new DisposableStore();
		data.entry = append(container, $('.quick-input-list-entry'));
		const label = append(data.entry, $('label.quick-input-list-label'));
		data.toDisposeTemplate.add(
			addStandardDisposableListener(label, EventType.CLICK, e => {
				if (!data.checkbox.offsetParent) {
					e.preventDefault();
				}
			})
		);
		data.checkbox = append(label, $('input.quick-input-list-checkbox'));
		data.checkbox.type = 'checkbox';
		const rows = append(label, $('.quick-input-list-rows'));
		const row1 = append(rows, $('.quick-input-list-row'));
		const row2 = append(rows, $('.quick-input-list-row'));
		data.label = new IconLabel(row1, {
			supportHighlights: true,
			supportDescriptionHighlights: true,
			supportIcons: true,
			hoverDelegate: this.hoverDelegate
		});
		data.toDisposeTemplate.add(data.label);
		data.icon = prepend(data.label.element, $('.quick-input-list-icon'));
		const keybindingContainer = append(row1, $('.quick-input-list-entry-keybinding'));
		data.keybinding = new KeybindingLabel(keybindingContainer, OS);
		data.toDisposeTemplate.add(data.keybinding);
		const detailContainer = append(row2, $('.quick-input-list-label-meta'));
		data.detail = new IconLabel(detailContainer, {
			supportHighlights: true,
			supportIcons: true,
			hoverDelegate: this.hoverDelegate
		});
		data.toDisposeTemplate.add(data.detail);
		data.separator = append(data.entry, $('.quick-input-list-separator'));
		data.actionBar = new ActionBar(data.entry, this.hoverDelegate ? { hoverDelegate: this.hoverDelegate } : undefined);
		data.actionBar.domNode.classList.add('quick-input-list-entry-action-bar');
		data.toDisposeTemplate.add(data.actionBar);
		return data;
	}
	disposeTemplate(data) {
		data.toDisposeElement.dispose();
		data.toDisposeTemplate.dispose();
	}
	disposeElement(_element, _index, data) {
		data.toDisposeElement.clear();
		data.actionBar.clear();
	}
}

class QuickPickItemElementRenderer extends BaseQuickInputListRenderer {
	constructor(hoverDelegate, themeService) {
		super(hoverDelegate);
		this.themeService = themeService;
		this._itemsWithSeparatorsFrequency = new Map();
	}
	get templateId() {
		return QuickPickItemElementRenderer.ID;
	}
	renderTemplate(container) {
		const data = super.renderTemplate(container);
		data.toDisposeTemplate.add(
			addStandardDisposableListener(data.checkbox, EventType.CHANGE, e => {
				data.element.checked = data.checkbox.checked;
			})
		);
		return data;
	}
	renderElement(node, index, data) {
		const element = node.element;
		data.element = element;
		element.element = data.entry;
		const mainItem = element.item;
		data.checkbox.checked = element.checked;
		data.toDisposeElement.add(element.onChecked(checked => (data.checkbox.checked = checked)));
		data.checkbox.disabled = element.checkboxDisabled;
		const { labelHighlights, descriptionHighlights, detailHighlights } = element;
		if (mainItem.iconPath) {
			const icon = isDark(this.themeService.getColorTheme().type)
				? mainItem.iconPath.dark
				: mainItem.iconPath.light ?? mainItem.iconPath.dark;
			const iconUrl = URI.revive(icon);
			data.icon.className = 'quick-input-list-icon';
			data.icon.style.backgroundImage = asCSSUrl(iconUrl);
		} else {
			data.icon.style.backgroundImage = '';
			data.icon.className = mainItem.iconClass ? `quick-input-list-icon ${mainItem.iconClass}` : '';
		}
		let descriptionTitle;
		if (!element.saneTooltip && element.saneDescription) {
			descriptionTitle = {
				markdown: {
					value: element.saneDescription,
					supportThemeIcons: true
				},
				markdownNotSupportedFallback: element.saneDescription
			};
		}
		const options2 = {
			matches: labelHighlights || [],
			// If we have a tooltip, we want that to be shown and not any other hover
			descriptionTitle,
			descriptionMatches: descriptionHighlights || [],
			labelEscapeNewLines: true
		};
		options2.extraClasses = mainItem.iconClasses;
		options2.italic = mainItem.italic;
		options2.strikethrough = mainItem.strikethrough;
		data.entry.classList.remove('quick-input-list-separator-as-item');
		data.label.setLabel(element.saneLabel, element.saneDescription, options2);
		data.keybinding.set(mainItem.keybinding);
		if (element.saneDetail) {
			let title;
			if (!element.saneTooltip) {
				title = {
					markdown: {
						value: element.saneDetail,
						supportThemeIcons: true
					},
					markdownNotSupportedFallback: element.saneDetail
				};
			}
			data.detail.element.style.display = '';
			data.detail.setLabel(element.saneDetail, undefined, {
				matches: detailHighlights,
				title,
				labelEscapeNewLines: true
			});
		} else {
			data.detail.element.style.display = 'none';
		}
		if (element.separator?.label) {
			data.separator.textContent = element.separator.label;
			data.separator.style.display = '';
			this.addItemWithSeparator(element);
		} else {
			data.separator.style.display = 'none';
		}
		data.entry.classList.toggle('quick-input-list-separator-border', !!element.separator);
		const buttons = mainItem.buttons;
		if (buttons && buttons.length) {
			data.actionBar.push(
				buttons.map((button, index2) =>
					quickInputButtonToAction(button, `id-${index2}`, () => element.fireButtonTriggered({ button, item: element.item }))
				),
				{ icon: true, label: false }
			);
			data.entry.classList.add('has-actions');
		} else {
			data.entry.classList.remove('has-actions');
		}
	}
	disposeElement(element, _index, data) {
		this.removeItemWithSeparator(element.element);
		super.disposeElement(element, _index, data);
	}
	isItemWithSeparatorVisible(item) {
		return this._itemsWithSeparatorsFrequency.has(item);
	}
	addItemWithSeparator(item) {
		this._itemsWithSeparatorsFrequency.set(item, (this._itemsWithSeparatorsFrequency.get(item) || 0) + 1);
	}
	removeItemWithSeparator(item) {
		const frequency = this._itemsWithSeparatorsFrequency.get(item) || 0;
		if (frequency > 1) {
			this._itemsWithSeparatorsFrequency.set(item, frequency - 1);
		} else {
			this._itemsWithSeparatorsFrequency.delete(item);
		}
	}
}
QuickPickItemElementRenderer.ID = 'quickpickitem';
__decorate([__param(1, IThemeService)], QuickPickItemElementRenderer);

class QuickPickSeparatorElementRenderer extends BaseQuickInputListRenderer {
	constructor() {
		super(...arguments);
		this._visibleSeparatorsFrequency = new Map();
	}
	get templateId() {
		return QuickPickSeparatorElementRenderer.ID;
	}
	get visibleSeparators() {
		return [...this._visibleSeparatorsFrequency.keys()];
	}
	isSeparatorVisible(separator) {
		return this._visibleSeparatorsFrequency.has(separator);
	}
	renderElement(node, index, data) {
		const element = node.element;
		data.element = element;
		element.element = data.entry;
		element.element.classList.toggle('focus-inside', !!element.focusInsideSeparator);
		const mainItem = element.separator;
		const { labelHighlights, descriptionHighlights, detailHighlights } = element;
		data.icon.style.backgroundImage = '';
		data.icon.className = '';
		let descriptionTitle;
		if (!element.saneTooltip && element.saneDescription) {
			descriptionTitle = {
				markdown: {
					value: element.saneDescription,
					supportThemeIcons: true
				},
				markdownNotSupportedFallback: element.saneDescription
			};
		}
		const options2 = {
			matches: labelHighlights || [],
			// If we have a tooltip, we want that to be shown and not any other hover
			descriptionTitle,
			descriptionMatches: descriptionHighlights || [],
			labelEscapeNewLines: true
		};
		data.entry.classList.add('quick-input-list-separator-as-item');
		data.label.setLabel(element.saneLabel, element.saneDescription, options2);
		if (element.saneDetail) {
			let title;
			if (!element.saneTooltip) {
				title = {
					markdown: {
						value: element.saneDetail,
						supportThemeIcons: true
					},
					markdownNotSupportedFallback: element.saneDetail
				};
			}
			data.detail.element.style.display = '';
			data.detail.setLabel(element.saneDetail, undefined, {
				matches: detailHighlights,
				title,
				labelEscapeNewLines: true
			});
		} else {
			data.detail.element.style.display = 'none';
		}
		data.separator.style.display = 'none';
		data.entry.classList.add('quick-input-list-separator-border');
		const buttons = mainItem.buttons;
		if (buttons && buttons.length) {
			data.actionBar.push(
				buttons.map((button, index2) =>
					quickInputButtonToAction(button, `id-${index2}`, () =>
						element.fireSeparatorButtonTriggered({ button, separator: element.separator })
					)
				),
				{ icon: true, label: false }
			);
			data.entry.classList.add('has-actions');
		} else {
			data.entry.classList.remove('has-actions');
		}
		this.addSeparator(element);
	}
	disposeElement(element, _index, data) {
		this.removeSeparator(element.element);
		if (!this.isSeparatorVisible(element.element)) {
			element.element.element?.classList.remove('focus-inside');
		}
		super.disposeElement(element, _index, data);
	}
	addSeparator(separator) {
		this._visibleSeparatorsFrequency.set(separator, (this._visibleSeparatorsFrequency.get(separator) || 0) + 1);
	}
	removeSeparator(separator) {
		const frequency = this._visibleSeparatorsFrequency.get(separator) || 0;
		if (frequency > 1) {
			this._visibleSeparatorsFrequency.set(separator, frequency - 1);
		} else {
			this._visibleSeparatorsFrequency.delete(separator);
		}
	}
}
QuickPickSeparatorElementRenderer.ID = 'quickpickseparator';

class QuickInputTree extends Disposable {
	constructor(parent, hoverDelegate, linkOpenerDelegate, id, instantiationService) {
		super();
		this.parent = parent;
		this.hoverDelegate = hoverDelegate;
		this.linkOpenerDelegate = linkOpenerDelegate;
		this._onKeyDown = new Emitter();
		this.onKeyDown = this._onKeyDown.event;
		this._onLeave = new Emitter();
		this.onLeave = this._onLeave.event;
		this._onChangedAllVisibleChecked = new Emitter();
		this.onChangedAllVisibleChecked = this._onChangedAllVisibleChecked.event;
		this._onChangedCheckedCount = new Emitter();
		this.onChangedCheckedCount = this._onChangedCheckedCount.event;
		this._onChangedVisibleCount = new Emitter();
		this.onChangedVisibleCount = this._onChangedVisibleCount.event;
		this._onChangedCheckedElements = new Emitter();
		this.onChangedCheckedElements = this._onChangedCheckedElements.event;
		this._onButtonTriggered = new Emitter();
		this.onButtonTriggered = this._onButtonTriggered.event;
		this._onSeparatorButtonTriggered = new Emitter();
		this.onSeparatorButtonTriggered = this._onSeparatorButtonTriggered.event;
		this._onTriggerEmptySelectionOrFocus = new Emitter();
		this._elementChecked = new Emitter();
		this._inputElements = new Array();
		this._elementTree = new Array();
		this._itemElements = new Array();
		this._elementDisposable = this._register(new DisposableStore());
		this._shouldFireCheckedEvents = true;
		this._matchOnDescription = false;
		this._matchOnDetail = false;
		this._matchOnLabel = true;
		this._matchOnLabelMode = 'fuzzy';
		this._sortByLabel = true;
		this._container = append(this.parent, $('.quick-input-list'));
		this._separatorRenderer = new QuickPickSeparatorElementRenderer(hoverDelegate);
		this._itemRenderer = instantiationService.createInstance(QuickPickItemElementRenderer, hoverDelegate);
		this._tree = this._register(
			instantiationService.createInstance(
				WorkbenchObjectTree,
				'QuickInput',
				this._container,
				new QuickInputItemDelegate(),
				[this._itemRenderer, this._separatorRenderer],
				{
					setRowLineHeight: false,
					multipleSelectionSupport: false,
					hideTwistiesOfChildlessElements: true,
					renderIndentGuides: RenderIndentGuides.None,
					findWidgetEnabled: false,
					indent: 0,
					horizontalScrolling: false,
					allowNonCollapsibleParents: true,
					identityProvider: {
						getId: element => {
							const mainItem = element.item || element.separator;
							if (mainItem === undefined) {
								return '';
							}
							if (mainItem.id !== undefined) {
								return mainItem.id;
							}
							let id2 = `label:${mainItem.label}`;
							id2 += `$$description:${mainItem.description}`;
							if (mainItem.type !== 'separator') {
								id2 += `$$detail:${mainItem.detail}`;
							}
							return id2;
						}
					},
					alwaysConsumeMouseWheel: true
				}
			)
		);
		this._tree.getHTMLElement().id = id;
		this._registerListeners();
	}

	get onDidChangeFocus() {
		return editorEventMap(editorEventAny(this._tree.onDidChangeFocus, this._onTriggerEmptySelectionOrFocus.event), e =>
			e.elements.filter(e2 => e2 instanceof QuickPickItemElement).map(e2 => e2.item)
		);
	}
	get onDidChangeSelection() {
		return editorEventMap(editorEventAny(this._tree.onDidChangeSelection, this._onTriggerEmptySelectionOrFocus.event), e => ({
			items: e.elements.filter(e2 => e2 instanceof QuickPickItemElement).map(e2 => e2.item),
			event: e.browserEvent
		}));
	}
	get scrollTop() {
		return this._tree.scrollTop;
	}
	set scrollTop(scrollTop) {
		this._tree.scrollTop = scrollTop;
	}

	set enabled(value) {
		this._tree.getHTMLElement().style.pointerEvents = value ? '' : 'none';
	}
	get matchOnDescription() {
		return this._matchOnDescription;
	}
	set matchOnDescription(value) {
		this._matchOnDescription = value;
	}
	get matchOnDetail() {
		return this._matchOnDetail;
	}
	set matchOnDetail(value) {
		this._matchOnDetail = value;
	}
	get matchOnLabel() {
		return this._matchOnLabel;
	}
	set matchOnLabel(value) {
		this._matchOnLabel = value;
	}
	get matchOnLabelMode() {
		return this._matchOnLabelMode;
	}
	set matchOnLabelMode(value) {
		this._matchOnLabelMode = value;
	}
	get sortByLabel() {
		return this._sortByLabel;
	}
	set sortByLabel(value) {
		this._sortByLabel = value;
	}

	_registerListeners() {
		this._registerOnKeyDown();
		this._registerOnContainerClick();
		this._registerOnMouseMiddleClick();
		this._registerOnElementChecked();
		this._registerOnContextMenu();
		this._registerHoverListeners();
		this._registerSelectionChangeListener();
		this._registerSeparatorActionShowingListeners();
	}
	_registerOnKeyDown() {
		this._register(
			this._tree.onKeyDown(e => {
				const event = new StandardKeyboardEvent(e);
				switch (event.keyCode) {
					case 10:
						this.toggleCheckbox();
						break;
					case 31:
						if (isMacintosh ? e.metaKey : e.ctrlKey) {
							this._tree.setFocus(this._itemElements);
						}
						break;
					case 16: {
						const focus1 = this._tree.getFocus();
						if (focus1.length === 1 && focus1[0] === this._itemElements[0]) {
							this._onLeave.fire();
						}
						break;
					}
					case 18: {
						const focus2 = this._tree.getFocus();
						if (focus2.length === 1 && focus2[0] === this._itemElements[this._itemElements.length - 1]) {
							this._onLeave.fire();
						}
						break;
					}
				}
				this._onKeyDown.fire(event);
			})
		);
	}
	_registerOnContainerClick() {
		this._register(
			addDisposableListener(this._container, EventType.CLICK, e => {
				if (e.x || e.y) {
					this._onLeave.fire();
				}
			})
		);
	}
	_registerOnMouseMiddleClick() {
		this._register(
			addDisposableListener(this._container, EventType.AUXCLICK, e => {
				if (e.button === 1) {
					this._onLeave.fire();
				}
			})
		);
	}
	_registerOnElementChecked() {
		this._register(this._elementChecked.event(_ => this._fireCheckedEvents()));
	}
	_registerOnContextMenu() {
		this._register(
			this._tree.onContextMenu(e => {
				if (e.element) {
					e.browserEvent.preventDefault();
					this._tree.setSelection([e.element]);
				}
			})
		);
	}
	_registerHoverListeners() {
		const delayer3 = this._register(new ThrottledDelayer(this.hoverDelegate.delay));
		this._register(
			this._tree.onMouseOver(async e => {
				if (e.browserEvent.target instanceof HTMLAnchorElement) {
					delayer3.cancel();
					return;
				}
				if (
					// anchors are an exception as called out above so we skip them here
					!(e.browserEvent.relatedTarget instanceof HTMLAnchorElement) && // check if the mouse is still over the same element
					isAncestor(e.browserEvent.relatedTarget, e.elemen?.element)
				) {
					return;
				}
				try {
					await delayer3.trigger(async () => {
						if (e.element instanceof QuickPickItemElement) {
							this.showHover(e.element);
						}
					});
				} catch (e2) {
					if (!isCancellationError(e2)) {
						throw e2;
					}
				}
			})
		);
		this._register(
			this._tree.onMouseOut(e => {
				if (isAncestor(e.browserEvent.relatedTarget, e.element?.element)) {
					return;
				}
				delayer3.cancel();
			})
		);
	}
	_registerSeparatorActionShowingListeners() {
		this._register(
			this._tree.onDidChangeFocus(e => {
				const parent = e.elements[0] ? this._tree.getParentElement(e.elements[0]) : null;
				for (const separator of this._separatorRenderer.visibleSeparators) {
					const value = separator === parent;
					const currentActive = !!(separator.focusInsideSeparator & 2);
					if (currentActive !== value) {
						if (value) {
							separator.focusInsideSeparator |= 2;
						} else {
							separator.focusInsideSeparator &= ~2;
						}
						this._tree.rerender(separator);
					}
				}
			})
		);
		this._register(
			this._tree.onMouseOver(e => {
				const parent = e.element ? this._tree.getParentElement(e.element) : null;
				for (const separator of this._separatorRenderer.visibleSeparators) {
					if (separator !== parent) {
						continue;
					}
					const currentMouse = !!(separator.focusInsideSeparator & 1);
					if (!currentMouse) {
						separator.focusInsideSeparator |= 1;
						this._tree.rerender(separator);
					}
				}
			})
		);
		this._register(
			this._tree.onMouseOut(e => {
				const parent = e.element ? this._tree.getParentElement(e.element) : null;
				for (const separator of this._separatorRenderer.visibleSeparators) {
					if (separator !== parent) {
						continue;
					}
					const currentMouse = !!(separator.focusInsideSeparator & 1);
					if (currentMouse) {
						separator.focusInsideSeparator &= ~1;
						this._tree.rerender(separator);
					}
				}
			})
		);
	}
	_registerSelectionChangeListener() {
		this._register(
			this._tree.onDidChangeSelection(e => {
				const elementsWithoutSeparators = e.elements.filter(e2 => e2 instanceof QuickPickItemElement);
				if (elementsWithoutSeparators.length !== e.elements.length) {
					if (e.elements.length === 1 && e.elements[0] instanceof QuickPickSeparatorElement) {
						this._tree.setFocus([e.elements[0].children[0]]);
						this._tree.reveal(e.elements[0], 0);
					}
					this._tree.setSelection(elementsWithoutSeparators);
				}
			})
		);
	}

	getAllVisibleChecked() {
		return this._allVisibleChecked(this._itemElements, false);
	}
	getCheckedCount() {
		return this._itemElements.filter(element => element.checked).length;
	}
	getVisibleCount() {
		return this._itemElements.filter(e => !e.hidden).length;
	}
	setAllVisibleChecked(checked) {
		try {
			this._shouldFireCheckedEvents = false;
			this._itemElements.forEach(element => {
				if (!element.hidden && !element.checkboxDisabled) {
					element.checked = checked;
				}
			});
		} finally {
			this._shouldFireCheckedEvents = true;
			this._fireCheckedEvents();
		}
	}
	setElements(inputElements) {
		this._elementDisposable.clear();
		this._inputElements = inputElements;
		const hasCheckbox = this.parent.classList.contains('show-checkboxes');
		let currentSeparatorElement;
		this._itemElements = new Array();
		this._elementTree = inputElements.reduce((result, item, index) => {
			let element;
			if (item.type === 'separator') {
				if (!item.buttons) {
					return result;
				}
				currentSeparatorElement = new QuickPickSeparatorElement(index, event => this.fireSeparatorButtonTriggered(event), item);
				element = currentSeparatorElement;
			} else {
				const previous = index > 0 ? inputElements[index - 1] : undefined;
				let separator;
				if (previous && previous.type === 'separator' && !previous.buttons) {
					currentSeparatorElement = undefined;
					separator = previous;
				}
				const qpi = new QuickPickItemElement(
					index,
					hasCheckbox,
					event => this.fireButtonTriggered(event),
					this._elementChecked,
					item,
					separator
				);
				this._itemElements.push(qpi);
				if (currentSeparatorElement) {
					currentSeparatorElement.children.push(qpi);
					return result;
				}
				element = qpi;
			}
			result.push(element);
			return result;
		}, new Array());
		const elements = new Array();
		let visibleCount = 0;
		for (const element of this._elementTree) {
			if (element instanceof QuickPickSeparatorElement) {
				elements.push({
					element,
					collapsible: false,
					collapsed: false,
					children: element.children.map(e => ({
						element: e,
						collapsible: false,
						collapsed: false
					}))
				});
				visibleCount += element.children.length + 1;
			} else {
				elements.push({
					element,
					collapsible: false,
					collapsed: false
				});
				visibleCount++;
			}
		}
		this._tree.setChildren(null, elements);
		this._onChangedVisibleCount.fire(visibleCount);
	}
	setFocusedElements(items) {
		const elements = items.map(item => this._itemElements.find(e => e.item === item)).filter(e => !!e);
		this._tree.setFocus(elements);
		if (items.length > 0) {
			const focused = this._tree.getFocus()[0];
			if (focused) {
				this._tree.reveal(focused);
			}
		}
	}

	setSelectedElements(items) {
		const elements = items.map(item => this._itemElements.find(e => e.item === item)).filter(e => !!e);
		this._tree.setSelection(elements);
	}
	getCheckedElements() {
		return this._itemElements.filter(e => e.checked).map(e => e.item);
	}
	setCheckedElements(items) {
		try {
			this._shouldFireCheckedEvents = false;
			const checked = new Set();
			for (const item of items) {
				checked.add(item);
			}
			for (const element of this._itemElements) {
				element.checked = checked.has(element.item);
			}
		} finally {
			this._shouldFireCheckedEvents = true;
			this._fireCheckedEvents();
		}
	}
	focus(what) {
		if (this._itemElements.length) {
			if (what === 2 && this._itemElements.length < 2) {
				what = 1;
			}
			switch (what) {
				case 1:
					this._tree.scrollTop = 0;
					this._tree.focusFirst(undefined, e => e.element instanceof QuickPickItemElement);
					break;
				case 2:
					this._tree.scrollTop = 0;
					this._tree.setFocus([this._itemElements[1]]);
					break;
				case 3:
					this._tree.scrollTop = this._tree.scrollHeight;
					this._tree.setFocus([this._itemElements[this._itemElements.length - 1]]);
					break;
				case 4:
					this._tree.focusNext(undefined, true, undefined, e => {
						if (!(e.element instanceof QuickPickItemElement)) {
							return false;
						}
						this._tree.reveal(e.element);
						return true;
					});
					break;
				case 5:
					this._tree.focusPrevious(undefined, true, undefined, e => {
						if (!(e.element instanceof QuickPickItemElement)) {
							return false;
						}
						const parent = this._tree.getParentElement(e.element);
						if (parent === null || parent.children[0] !== e.element) {
							this._tree.reveal(e.element);
						} else {
							this._tree.reveal(parent);
						}
						return true;
					});
					break;
				case 6:
					this._tree.focusNextPage(undefined, e => {
						if (!(e.element instanceof QuickPickItemElement)) {
							return false;
						}
						this._tree.reveal(e.element);
						return true;
					});
					break;
				case 7:
					this._tree.focusPreviousPage(undefined, e => {
						if (!(e.element instanceof QuickPickItemElement)) {
							return false;
						}
						const parent = this._tree.getParentElement(e.element);
						if (parent === null || parent.children[0] !== e.element) {
							this._tree.reveal(e.element);
						} else {
							this._tree.reveal(parent);
						}
						return true;
					});
					break;
				case 8: {
					let foundSeparatorAsItem = false;
					const before = this._tree.getFocus()[0];
					this._tree.focusNext(undefined, true, undefined, e => {
						if (foundSeparatorAsItem) {
							return true;
						}
						if (e.element instanceof QuickPickSeparatorElement) {
							foundSeparatorAsItem = true;
							if (this._separatorRenderer.isSeparatorVisible(e.element)) {
								this._tree.reveal(e.element.children[0]);
							} else {
								this._tree.reveal(e.element, 0);
							}
						} else if (e.element instanceof QuickPickItemElement) {
							if (e.element.separator) {
								if (this._itemRenderer.isItemWithSeparatorVisible(e.element)) {
									this._tree.reveal(e.element);
								} else {
									this._tree.reveal(e.element, 0);
								}
								return true;
							} else if (e.element === this._elementTree[0]) {
								this._tree.reveal(e.element, 0);
								return true;
							}
						}
						return false;
					});
					const after2 = this._tree.getFocus()[0];
					if (before === after2) {
						this._tree.scrollTop = this._tree.scrollHeight;
						this._tree.setFocus([this._itemElements[this._itemElements.length - 1]]);
					}
					break;
				}
				case 9: {
					let focusElement;
					let foundSeparator = !!this._tree.getFocus()[0]?.separator;
					this._tree.focusPrevious(undefined, true, undefined, e => {
						if (e.element instanceof QuickPickSeparatorElement) {
							if (foundSeparator) {
								if (!focusElement) {
									if (this._separatorRenderer.isSeparatorVisible(e.element)) {
										this._tree.reveal(e.element);
									} else {
										this._tree.reveal(e.element, 0);
									}
									focusElement = e.element.children[0];
								}
							} else {
								foundSeparator = true;
							}
						} else if (e.element instanceof QuickPickItemElement) {
							if (!focusElement) {
								if (e.element.separator) {
									if (this._itemRenderer.isItemWithSeparatorVisible(e.element)) {
										this._tree.reveal(e.element);
									} else {
										this._tree.reveal(e.element, 0);
									}
									focusElement = e.element;
								} else if (e.element === this._elementTree[0]) {
									this._tree.reveal(e.element, 0);
									return true;
								}
							}
						}
						return false;
					});
					if (focusElement) {
						this._tree.setFocus([focusElement]);
					}
					break;
				}
			}
		}
	}
	clearFocus() {
		this._tree.setFocus([]);
	}
	domFocus() {
		this._tree.domFocus();
	}
	layout(maxHeight) {
		this._tree.getHTMLElement().style.maxHeight = maxHeight
			? `${
					// Make sure height aligns with list item heights
					Math.floor(maxHeight / 44) * 44 + 6
				}px`
			: '';
		this._tree.layout();
	}
	filter(query) {
		if (!(this._sortByLabel || this._matchOnLabel || this._matchOnDescription || this._matchOnDetail)) {
			this._tree.layout();
			return false;
		}
		const queryWithWhitespace = query;
		query = query.trim();
		if (!query || !(this.matchOnLabel || this.matchOnDescription || this.matchOnDetail)) {
			this._itemElements.forEach(element => {
				element.labelHighlights = undefined;
				element.descriptionHighlights = undefined;
				element.detailHighlights = undefined;
				element.hidden = false;
				const previous = element.index && this._inputElements[element.index - 1];
				if (element.item) {
					element.separator = previous && previous.type === 'separator' && !previous.buttons ? previous : undefined;
				}
			});
		} else {
			let currentSeparator2;
			this._elementTree.forEach(element => {
				let labelHighlights;

				function _matchesContiguousIconAware(query, target) {
					const { text: text2, iconOffsets } = target;
					if (!iconOffsets || iconOffsets.length === 0) {
						return matchesContiguous(query, text2);
					}
					const wordToMatchAgainstWithoutIconsTrimmed = trimsTrailingOccurrencesFromStart(text2, ' ');
					const leadingWhitespaceOffset = text2.length - wordToMatchAgainstWithoutIconsTrimmed.length;
					const matches = matchesContiguous(query, wordToMatchAgainstWithoutIconsTrimmed);
					if (matches) {
						for (const match2 of matches) {
							const iconOffset = iconOffsets[match2.start + leadingWhitespaceOffset] + leadingWhitespaceOffset;
							match2.start += iconOffset;
							match2.end += iconOffset;
						}
					}
					return matches;
				}

				if (this.matchOnLabelMode === 'fuzzy') {
					labelHighlights = this.matchOnLabel ? matchesFuzzyIconAware(query, parseLabelWithIcons(element.saneLabel)) : undefined;
				} else {
					labelHighlights = this.matchOnLabel
						? _matchesContiguousIconAware(queryWithWhitespace, parseLabelWithIcons(element.saneLabel))
						: undefined;
				}
				const descriptionHighlights = this.matchOnDescription
					? matchesFuzzyIconAware(query, parseLabelWithIcons(element.saneDescription || ''))
					: undefined;
				const detailHighlights = this.matchOnDetail
					? matchesFuzzyIconAware(query, parseLabelWithIcons(element.saneDetail || ''))
					: undefined;
				if (labelHighlights || descriptionHighlights || detailHighlights) {
					element.labelHighlights = labelHighlights;
					element.descriptionHighlights = descriptionHighlights;
					element.detailHighlights = detailHighlights;
					element.hidden = false;
				} else {
					element.labelHighlights = undefined;
					element.descriptionHighlights = undefined;
					element.detailHighlights = undefined;
					element.hidden = element.item ? !element.item.alwaysShow : true;
				}
				if (element.item) {
					element.separator = undefined;
				} else if (element.separator) {
					element.hidden = true;
				}
				if (!this.sortByLabel) {
					const previous = element.index && this._inputElements[element.index - 1];
					currentSeparator2 = previous && previous.type === 'separator' ? previous : currentSeparator2;
					if (currentSeparator2 && !element.hidden) {
						element.separator = currentSeparator2;
						currentSeparator2 = undefined;
					}
				}
			});
		}
		const shownElements = this._elementTree.filter(e => !e.hidden);
		if (this.sortByLabel && query) {
			const normalizedSearchValue = query.toLowerCase();

			function _compareEntries(elementA, elementB, lookFor) {
				const labelHighlightsA = elementA.labelHighlights || [];
				const labelHighlightsB = elementB.labelHighlights || [];
				if (labelHighlightsA.length && !labelHighlightsB.length) {
					return -1;
				}
				if (!labelHighlightsA.length && labelHighlightsB.length) {
					return 1;
				}
				if (labelHighlightsA.length === 0 && labelHighlightsB.length === 0) {
					return 0;
				}

				function _compareAnything(one, other, lookFor) {
					const elementAName = one.toLowerCase();
					const elementBName = other.toLowerCase();

					function _compareByPrefix(one, other, lookFor) {
						const elementAName = one.toLowerCase();
						const elementBName = other.toLowerCase();
						const elementAPrefixMatch = elementAName.startsWith(lookFor);
						const elementBPrefixMatch = elementBName.startsWith(lookFor);
						if (elementAPrefixMatch !== elementBPrefixMatch) {
							return elementAPrefixMatch ? -1 : 1;
						} else if (elementAPrefixMatch && elementBPrefixMatch) {
							if (elementAName.length < elementBName.length) {
								return -1;
							}
							if (elementAName.length > elementBName.length) {
								return 1;
							}
						}
						return 0;
					}

					const prefixCompare = _compareByPrefix(one, other, lookFor);
					if (prefixCompare) {
						return prefixCompare;
					}
					const elementASuffixMatch = elementAName.endsWith(lookFor);
					const elementBSuffixMatch = elementBName.endsWith(lookFor);
					if (elementASuffixMatch !== elementBSuffixMatch) {
						return elementASuffixMatch ? -1 : 1;
					}
					function _compareFileNames(one, other, caseSensitive = false) {
						const a = one || '';
						const b = other || '';
						const result = intlFileNameCollatorBaseNumeric.value.collator.compare(a, b);
						if (intlFileNameCollatorBaseNumeric.value.collatorIsNumeric && result === 0 && a !== b) {
							return a < b ? -1 : 1;
						}
						return result;
					}
					const r = _compareFileNames(elementAName, elementBName);
					if (r !== 0) {
						return r;
					}
					return elementAName.localeCompare(elementBName);
				}

				return _compareAnything(elementA.saneSortLabel, elementB.saneSortLabel, lookFor);
			}

			shownElements.sort((a, b) => {
				return _compareEntries(a, b, normalizedSearchValue);
			});
		}
		let currentSeparator;
		const finalElements = shownElements.reduce((result, element, index) => {
			if (element instanceof QuickPickItemElement) {
				if (currentSeparator) {
					currentSeparator.children.push(element);
				} else {
					result.push(element);
				}
			} else if (element instanceof QuickPickSeparatorElement) {
				element.children = [];
				currentSeparator = element;
				result.push(element);
			}
			return result;
		}, new Array());
		const elements = new Array();
		for (const element of finalElements) {
			if (element instanceof QuickPickSeparatorElement) {
				elements.push({
					element,
					collapsible: false,
					collapsed: false,
					children: element.children.map(e => ({
						element: e,
						collapsible: false,
						collapsed: false
					}))
				});
			} else {
				elements.push({
					element,
					collapsible: false,
					collapsed: false
				});
			}
		}
		const before = this._tree.getFocus().length;
		this._tree.setChildren(null, elements);
		if (before > 0 && elements.length === 0) {
			this._onTriggerEmptySelectionOrFocus.fire({
				elements: []
			});
		}
		this._tree.layout();
		this._onChangedAllVisibleChecked.fire(this.getAllVisibleChecked());
		this._onChangedVisibleCount.fire(shownElements.length);
		return true;
	}
	toggleCheckbox() {
		try {
			this._shouldFireCheckedEvents = false;
			const elements = this._tree.getFocus().filter(e => e instanceof QuickPickItemElement);
			const allChecked = this._allVisibleChecked(elements);
			for (const element of elements) {
				if (!element.checkboxDisabled) {
					element.checked = !allChecked;
				}
			}
		} finally {
			this._shouldFireCheckedEvents = true;
			this._fireCheckedEvents();
		}
	}
	display(display) {
		this._container.style.display = display ? '' : 'none';
	}
	isDisplayed() {
		return this._container.style.display !== 'none';
	}
	style(styles) {
		this._tree.style(styles);
	}
	toggleHover() {
		const focused = this._tree.getFocus()[0];
		if (!focused?.saneTooltip || !(focused instanceof QuickPickItemElement)) {
			return;
		}
		if (this._lastHover && !this._lastHover.isDisposed) {
			this._lastHover.dispose();
			return;
		}
		this.showHover(focused);
		const store = new DisposableStore();
		store.add(
			this._tree.onDidChangeFocus(e => {
				if (e.elements[0] instanceof QuickPickItemElement) {
					this.showHover(e.elements[0]);
				}
			})
		);
		if (this._lastHover) {
			store.add(this._lastHover);
		}
		this._elementDisposable.add(store);
	}

	_allVisibleChecked(elements, whenNoneVisible = true) {
		for (let i = 0, n = elements.length; i < n; i++) {
			const element = elements[i];
			if (!element.hidden) {
				if (!element.checked) {
					return false;
				} else {
					whenNoneVisible = true;
				}
			}
		}
		return whenNoneVisible;
	}
	_fireCheckedEvents() {
		if (!this._shouldFireCheckedEvents) {
			return;
		}
		this._onChangedAllVisibleChecked.fire(this.getAllVisibleChecked());
		this._onChangedCheckedCount.fire(this.getCheckedCount());
		this._onChangedCheckedElements.fire(this.getCheckedElements());
	}
	fireButtonTriggered(event) {
		this._onButtonTriggered.fire(event);
	}
	fireSeparatorButtonTriggered(event) {
		this._onSeparatorButtonTriggered.fire(event);
	}
	showHover(element) {
		if (this._lastHover && !this._lastHover.isDisposed) {
			this.hoverDelegate.onDidHideHover?.call(this.hoverDelegate);
			this._lastHover?.dispose();
		}
		if (!element.element || !element.saneTooltip) {
			return;
		}
		this._lastHover = this.hoverDelegate.showHover(
			{
				content: element.saneTooltip,
				target: element.element,
				linkHandler: url => {
					this.linkOpenerDelegate(url);
				},
				appearance: {
					showPointer: true
				},
				container: this._container,
				position: {
					hoverPosition: 1
					/* HoverPosition.RIGHT */
				}
			},
			false
		);
	}
}
__decorate([memoizeMethod], QuickInputTree.prototype, 'onDidChangeFocus', null);
__decorate([memoizeMethod], QuickInputTree.prototype, 'onDidChangeSelection', null);
__decorate([__param(4, IInstantiationService)], QuickInputTree);