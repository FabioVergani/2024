class CommandOpener {
	constructor(_commandService) {
		this._commandService = _commandService;
	}
	async open(target, options2) {
		if (!matchesScheme(target, Schemas.command)) {
			return false;
		}
		if (!options2?.allowCommands) {
			return true;
		}
		if (typeof target === 'string') {
			target = URI.parse(target);
		}
		if (isArray(options2.allowCommands)) {
			if (!options2.allowCommands.includes(target.path)) {
				return true;
			}
		}
		let args = [];
		try {
			args = parseAsJson(decodeURIComponent(target.query));
		} catch (exception1) {
			try {
				args = parseAsJson(target.query);
			} catch (exception2) {
				//
			}
		}
		if (!isArray(args)) {
			args = [args];
		}
		await this._commandService.executeCommand(target.path, ...args);
		return true;
	}
}
__decorate(
	[
		__param(0, ICommandService)
		//...
	],
	CommandOpener
);

class EditorOpener {
	constructor(_editorService) {
		this._editorService = _editorService;
	}
	async open(target, options2) {
		if (typeof target === 'string') {
			target = URI.parse(target);
		}
		const { selection, uri } = extractSelection(target);
		target = uri;
		if (target.scheme === Schemas.file) {
			target = normalizePath(target);
		}
		await this._editorService.openCodeEditor(
			{
				resource: target,
				options: {
					selection,
					source: options2?.fromUserGesture
						? 1 //USER
						: 0, //API
					...options2?.editorOptions
				}
			},
			this._editorService.getFocusedCodeEditor(),
			options2?.openToSide
		);
		return true;
	}
}
__decorate(
	[
		__param(0, ICodeEditorService)
		//...
	],
	EditorOpener
);

class OpenerService {
	constructor(editorService, commandService) {
		this._openers = new LinkedList();
		this._validators = new LinkedList();
		this._resolvers = new LinkedList();
		this._resolvedUriTargets = new ResourceMap(uri => uri.with({ path: null, fragment: null, query: null }).toString());
		this._externalOpeners = new LinkedList();
		this._defaultExternalOpener = {
			openExternal: async href => {
				if (matchesSomeScheme(href, Schemas.http, Schemas.https)) {
					windowOpenNoOpener(href);
				} else {
					mainWindow.location.href = href;
				}
				return true;
			}
		};
		this._openers.push({
			open: async (target, options2) => {
				if (options2?.openExternal || matchesSomeScheme(target, Schemas.mailto, Schemas.http, Schemas.https)) {
					await this._doOpenExternal(target, options2);
					return true;
				}
				return false;
			}
		});
		this._openers.push(new CommandOpener(commandService));
		this._openers.push(new EditorOpener(editorService));
	}
	registerOpener(opener) {
		const remove = this._openers.unshift(opener);
		return { dispose: remove };
	}
	async open(target, options2) {
		const targetURI = typeof target === 'string' ? URI.parse(target) : target;
		const validationTarget = this._resolvedUriTargets.get(targetURI) ?? target;
		for (const validator of this._validators) {
			if (!(await validator.shouldOpen(validationTarget, options2))) {
				return false;
			}
		}
		for (const opener of this._openers) {
			const handled = await opener.open(target, options2);
			if (handled) {
				return true;
			}
		}
		return false;
	}
	async resolveExternalUri(resource, options2) {
		for (const resolver of this._resolvers) {
			try {
				const result = await resolver.resolveExternalUri(resource, options2);
				if (result) {
					if (!this._resolvedUriTargets.has(result.resolved)) {
						this._resolvedUriTargets.set(result.resolved, resource);
					}
					return result;
				}
			} catch (exception) {}
		}
		throw new Error('Could not resolve external URI: ' + resource.toString());
	}
	async _doOpenExternal(resource, options2) {
		const uri = typeof resource === 'string' ? URI.parse(resource) : resource;
		let externalUri;
		try {
			externalUri = (await this.resolveExternalUri(uri, options2)).resolved;
		} catch (exception) {
			externalUri = uri;
		}
		let href;
		if (typeof resource === 'string' && uri.toString() === externalUri.toString()) {
			href = resource;
		} else {
			href = encodeURI(externalUri.toString(true));
		}
		if (options2?.allowContributedOpeners) {
			const preferredOpenerId =
				typeof options2?.allowContributedOpeners === 'string'
					? options2 === null || options2 === undefined
						? undefined
						: options2.allowContributedOpeners
					: undefined;
			for (const opener of this._externalOpeners) {
				const didOpen = await opener.openExternal(
					href,
					{
						sourceUri: uri,
						preferredOpenerId
					},
					cancellationToken_none
				);
				if (didOpen) {
					return true;
				}
			}
		}
		return this._defaultExternalOpener.openExternal(href, { sourceUri: uri }, cancellationToken_none);
	}
	dispose() {
		this._validators.clear();
	}
}
__decorate(
	[
		__param(0, ICodeEditorService),
		__param(1, ICommandService)
		//...
	],
	OpenerService
);

registerSingleton(
	IOpenerService,
	OpenerService,
	0 //Eager
);