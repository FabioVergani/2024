

const unsupportedSchemas = new Set([
	Schemas.inMemory,
	Schemas.walkThrough,
	Schemas.walkThroughSnippet,
]);

class MarkerStats {
	constructor(service) {
		this.errors = 0;
		this.infos = 0;
		this.warnings = 0;
		this.unknowns = 0;
		this._data = new ResourceMap();
		this._service = service;
		this._subscription = service.onMarkerChanged(this._update, this);
	}
	dispose() {
		this._subscription.dispose();
	}
	_update(resources) {
		for (const resource of resources) {
			const oldStats = this._data.get(resource);
			if (oldStats) {
				this._substract(oldStats);
			}
			const newStats = this._resourceStats(resource);
			this._add(newStats);
			this._data.set(resource, newStats);
		}
	}
	_resourceStats(resource) {
		const result = { errors: 0, warnings: 0, infos: 0, unknowns: 0 };
		if (unsupportedSchemas.has(resource.scheme)) {
			return result;
		}
		for (const { severity } of this._service.read({ resource })) {
			if (severity === 8) {
				result.errors += 1;
			} else if (severity === 4) {
				result.warnings += 1;
			} else if (severity === 2) {
				result.infos += 1;
			} else {
				result.unknowns += 1;
			}
		}
		return result;
	}
	_substract(op) {
		this.errors -= op.errors;
		this.warnings -= op.warnings;
		this.infos -= op.infos;
		this.unknowns -= op.unknowns;
	}
	_add(op) {
		this.errors += op.errors;
		this.warnings += op.warnings;
		this.infos += op.infos;
		this.unknowns += op.unknowns;
	}
}

this._stats = new MarkerStats(this);