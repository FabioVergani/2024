class BlockCommentCommand {
	constructor(selection, insertSpace, languageConfigurationService) {
		this.languageConfigurationService = languageConfigurationService;
		this._selection = selection;
		this._insertSpace = insertSpace;
		this._usedEndToken = null;
	}
	static _haystackHasNeedleAtOffset(haystack, needle, offset) {
		if (offset < 0) {
			return false;
		}
		const needleLength = needle.length;
		const haystackLength = haystack.length;
		if (offset + needleLength > haystackLength) {
			return false;
		}
		for (let i = 0; i < needleLength; i++) {
			const codeA = haystack.charCodeAt(offset + i);
			const codeB = needle.charCodeAt(i);
			if (codeA === codeB) {
				continue;
			}
			if (codeA >= 65 && codeA <= 90 && codeA + 32 === codeB) {
				continue;
			}
			if (codeB >= 65 && codeB <= 90 && codeB + 32 === codeA) {
				continue;
			}
			return false;
		}
		return true;
	}
	_createOperationsForBlockComment(selection, startToken, endToken, insertSpace, model, builder) {
		const startLineNumber = selection.startLineNumber;
		const startColumn = selection.startColumn;
		const endLineNumber = selection.endLineNumber;
		const endColumn = selection.endColumn;
		const startLineText = model.getLineContent(startLineNumber);
		const endLineText = model.getLineContent(endLineNumber);
		let startTokenIndex = startLineText.lastIndexOf(startToken, startColumn - 1 + startToken.length);
		let endTokenIndex = endLineText.indexOf(endToken, endColumn - 1 - endToken.length);
		if (startTokenIndex !== -1 && endTokenIndex !== -1) {
			if (startLineNumber === endLineNumber) {
				const lineBetweenTokens = startLineText.substring(startTokenIndex + startToken.length, endTokenIndex);
				if (lineBetweenTokens.indexOf(endToken) >= 0) {
					startTokenIndex = -1;
					endTokenIndex = -1;
				}
			} else {
				const startLineAfterStartToken = startLineText.substring(startTokenIndex + startToken.length);
				const endLineBeforeEndToken = endLineText.substring(0, endTokenIndex);
				if (startLineAfterStartToken.indexOf(endToken) >= 0 || endLineBeforeEndToken.indexOf(endToken) >= 0) {
					startTokenIndex = -1;
					endTokenIndex = -1;
				}
			}
		}
		let ops;
		if (startTokenIndex !== -1 && endTokenIndex !== -1) {
			if (
				insertSpace &&
				startTokenIndex + startToken.length < startLineText.length &&
				startLineText.charCodeAt(startTokenIndex + startToken.length) === 32
			) {
				startToken = startToken + ' ';
			}
			if (insertSpace && endTokenIndex > 0 && endLineText.charCodeAt(endTokenIndex - 1) === 32) {
				endToken = ' ' + endToken;
				endTokenIndex -= 1;
			}
			ops = BlockCommentCommand._createRemoveBlockCommentOperations(
				new Range(startLineNumber, startTokenIndex + startToken.length + 1, endLineNumber, endTokenIndex + 1),
				startToken,
				endToken
			);
		} else {
			ops = BlockCommentCommand._createAddBlockCommentOperations(selection, startToken, endToken, this._insertSpace);
			this._usedEndToken = ops.length === 1 ? endToken : null;
		}
		for (const op of ops) {
			builder.addTrackedEditOperation(op.range, op.text);
		}
	}
	static _createRemoveBlockCommentOperations(r, startToken, endToken) {
		const res = [];
		if (!Range.isEmpty(r)) {
			res.push(
				EditOperation.delete(new Range(r.startLineNumber, r.startColumn - startToken.length, r.startLineNumber, r.startColumn))
			);
			res.push(EditOperation.delete(new Range(r.endLineNumber, r.endColumn, r.endLineNumber, r.endColumn + endToken.length)));
		} else {
			res.push(
				EditOperation.delete(
					new Range(r.startLineNumber, r.startColumn - startToken.length, r.endLineNumber, r.endColumn + endToken.length)
				)
			);
		}
		return res;
	}
	static _createAddBlockCommentOperations(r, startToken, endToken, insertSpace) {
		const res = [];
		if (!Range.isEmpty(r)) {
			res.push(EditOperation.insert(new Position(r.startLineNumber, r.startColumn), startToken + (insertSpace ? ' ' : '')));
			res.push(EditOperation.insert(new Position(r.endLineNumber, r.endColumn), (insertSpace ? ' ' : '') + endToken));
		} else {
			res.push(
				EditOperation.replace(
					new Range(r.startLineNumber, r.startColumn, r.endLineNumber, r.endColumn),
					startToken + '  ' + endToken
				)
			);
		}
		return res;
	}
	getEditOperations(model, builder) {
		const startLineNumber = this._selection.startLineNumber;
		const startColumn = this._selection.startColumn;
		model.tokenization.tokenizeIfCheap(startLineNumber);
		const languageId = model.getLanguageIdAtPosition(startLineNumber, startColumn);
		const config = this.languageConfigurationService.getLanguageConfiguration(languageId).comments;
		if (!config || !config.blockCommentStartToken || !config.blockCommentEndToken) {
			return;
		}
		this._createOperationsForBlockComment(
			this._selection,
			config.blockCommentStartToken,
			config.blockCommentEndToken,
			this._insertSpace,
			model,
			builder
		);
	}
	computeCursorState(model, helper) {
		const inverseEditOperations = helper.getInverseEditOperations();
		if (inverseEditOperations.length === 2) {
			const startTokenEditOperation = inverseEditOperations[0];
			const endTokenEditOperation = inverseEditOperations[1];
			return new EditorSelection(
				startTokenEditOperation.range.endLineNumber,
				startTokenEditOperation.range.endColumn,
				endTokenEditOperation.range.startLineNumber,
				endTokenEditOperation.range.startColumn
			);
		} else {
			const srcRange = inverseEditOperations[0].range;
			const deltaColumn = this._usedEndToken ? -this._usedEndToken.length - 1 : 0;
			return new EditorSelection(
				srcRange.endLineNumber,
				srcRange.endColumn + deltaColumn,
				srcRange.endLineNumber,
				srcRange.endColumn + deltaColumn
			);
		}
	}
}

class LineCommentCommand {
	constructor(languageConfigurationService, selection, indentSize, type, insertSpace, ignoreEmptyLines, ignoreFirstLine) {
		this.languageConfigurationService = languageConfigurationService;
		this._selection = selection;
		this._indentSize = indentSize;
		this._type = type;
		this._insertSpace = insertSpace;
		this._selectionId = null;
		this._deltaColumn = 0;
		this._moveEndPositionDown = false;
		this._ignoreEmptyLines = ignoreEmptyLines;
		this._ignoreFirstLine = ignoreFirstLine || false;
	}
	static _gatherPreflightCommentStrings(model, startLineNumber, endLineNumber, languageConfigurationService) {
		model.tokenization.tokenizeIfCheap(startLineNumber);
		const languageId = model.getLanguageIdAtPosition(startLineNumber, 1);
		const config = languageConfigurationService.getLanguageConfiguration(languageId).comments;
		const commentStr = config ? config.lineCommentToken : null;
		if (!commentStr) {
			return null;
		}
		const lines = [];
		for (let i = 0, lineCount = endLineNumber - startLineNumber + 1; i < lineCount; i++) {
			lines[i] = {
				ignore: false,
				commentStr,
				commentStrOffset: 0,
				commentStrLength: commentStr.length
			};
		}
		return lines;
	}
	static _analyzeLines(
		type,
		insertSpace,
		model,
		lines,
		startLineNumber,
		ignoreEmptyLines,
		ignoreFirstLine,
		languageConfigurationService
	) {
		let onlyWhitespaceLines = true;
		let shouldRemoveComments;
		if (type === 0) {
			shouldRemoveComments = true;
		} else if (type === 1) {
			shouldRemoveComments = false;
		} else {
			shouldRemoveComments = true;
		}
		for (let i = 0, lineCount = lines.length; i < lineCount; i++) {
			const lineData = lines[i];
			const lineNumber = startLineNumber + i;
			if (lineNumber === startLineNumber && ignoreFirstLine) {
				lineData.ignore = true;
				continue;
			}
			const lineContent = model.getLineContent(lineNumber);
			const lineContentStartOffset = firstNonWhitespaceIndex(lineContent);
			if (lineContentStartOffset === -1) {
				lineData.ignore = ignoreEmptyLines;
				lineData.commentStrOffset = lineContent.length;
				continue;
			}
			onlyWhitespaceLines = false;
			lineData.ignore = false;
			lineData.commentStrOffset = lineContentStartOffset;
			if (
				shouldRemoveComments &&
				!BlockCommentCommand._haystackHasNeedleAtOffset(lineContent, lineData.commentStr, lineContentStartOffset)
			) {
				if (type === 0) {
					shouldRemoveComments = false;
				} else if (!(type === 1)) {
					lineData.ignore = true;
				}
			}
			if (shouldRemoveComments && insertSpace) {
				const commentStrEndOffset = lineContentStartOffset + lineData.commentStrLength;
				if (commentStrEndOffset < lineContent.length && lineContent.charCodeAt(commentStrEndOffset) === 32) {
					lineData.commentStrLength += 1;
				}
			}
		}
		if (type === 0 && onlyWhitespaceLines) {
			shouldRemoveComments = false;
			for (let i = 0, lineCount = lines.length; i < lineCount; i++) {
				lines[i].ignore = false;
			}
		}
		return { supported: true, shouldRemoveComments, lines };
	}
	static _gatherPreflightData(
		type,
		insertSpace,
		model,
		startLineNumber,
		endLineNumber,
		ignoreEmptyLines,
		ignoreFirstLine,
		languageConfigurationService
	) {
		const lines = LineCommentCommand._gatherPreflightCommentStrings(
			model,
			startLineNumber,
			endLineNumber,
			languageConfigurationService
		);
		if (lines === null) {
			return { supported: false };
		}
		return LineCommentCommand._analyzeLines(
			type,
			insertSpace,
			model,
			lines,
			startLineNumber,
			ignoreEmptyLines,
			ignoreFirstLine,
			languageConfigurationService
		);
	}
	_executeLineComments(model, builder, data, s) {
		let ops;
		if (data.shouldRemoveComments) {
			ops = LineCommentCommand._createRemoveLineCommentsOperations(data.lines, s.startLineNumber);
		} else {
			LineCommentCommand._normalizeInsertionPoint(model, data.lines, s.startLineNumber, this._indentSize);
			ops = this._createAddLineCommentsOperations(data.lines, s.startLineNumber);
		}
		const cursorPosition = new Position(s.positionLineNumber, s.positionColumn);
		for (let i = 0, len = ops.length; i < len; i++) {
			builder.addEditOperation(ops[i].range, ops[i].text);
			if (Range.isEmpty(ops[i].range) && Range.getStartPosition(ops[i].range).equals(cursorPosition)) {
				const lineContent = model.getLineContent(cursorPosition.lineNumber);
				if (lineContent.length + 1 === cursorPosition.column) {
					this._deltaColumn = (ops[i].text || '').length;
				}
			}
		}
		this._selectionId = builder.trackSelection(s);
	}
	_attemptRemoveBlockComment(model, s, startToken, endToken) {
		let startLineNumber = s.startLineNumber;
		let endLineNumber = s.endLineNumber;
		const startTokenAllowedBeforeColumn =
			endToken.length + Math.max(model.getLineFirstNonWhitespaceColumn(s.startLineNumber), s.startColumn);
		let startTokenIndex = model.getLineContent(startLineNumber).lastIndexOf(startToken, startTokenAllowedBeforeColumn - 1);
		let endTokenIndex = model.getLineContent(endLineNumber).indexOf(endToken, s.endColumn - 1 - startToken.length);
		if (startTokenIndex !== -1 && endTokenIndex === -1) {
			endTokenIndex = model.getLineContent(startLineNumber).indexOf(endToken, startTokenIndex + startToken.length);
			endLineNumber = startLineNumber;
		}
		if (startTokenIndex === -1 && endTokenIndex !== -1) {
			startTokenIndex = model.getLineContent(endLineNumber).lastIndexOf(startToken, endTokenIndex);
			startLineNumber = endLineNumber;
		}
		if (s.isEmpty() && (startTokenIndex === -1 || endTokenIndex === -1)) {
			startTokenIndex = model.getLineContent(startLineNumber).indexOf(startToken);
			if (startTokenIndex !== -1) {
				endTokenIndex = model.getLineContent(startLineNumber).indexOf(endToken, startTokenIndex + startToken.length);
			}
		}
		if (startTokenIndex !== -1 && model.getLineContent(startLineNumber).charCodeAt(startTokenIndex + startToken.length) === 32) {
			startToken += ' ';
		}
		if (endTokenIndex !== -1 && model.getLineContent(endLineNumber).charCodeAt(endTokenIndex - 1) === 32) {
			endToken = ' ' + endToken;
			endTokenIndex -= 1;
		}
		if (startTokenIndex !== -1 && endTokenIndex !== -1) {
			return BlockCommentCommand._createRemoveBlockCommentOperations(
				new Range(startLineNumber, startTokenIndex + startToken.length + 1, endLineNumber, endTokenIndex + 1),
				startToken,
				endToken
			);
		}
		return null;
	}
	_executeBlockComment(model, builder, s) {
		model.tokenization.tokenizeIfCheap(s.startLineNumber);
		const languageId = model.getLanguageIdAtPosition(s.startLineNumber, 1);
		const config = this.languageConfigurationService.getLanguageConfiguration(languageId).comments;
		if (!config || !config.blockCommentStartToken || !config.blockCommentEndToken) {
			return;
		}
		const startToken = config.blockCommentStartToken;
		const endToken = config.blockCommentEndToken;
		let ops = this._attemptRemoveBlockComment(model, s, startToken, endToken);
		if (!ops) {
			if (s.isEmpty()) {
				const lineContent = model.getLineContent(s.startLineNumber);
				let firstNonWhitespaceIndex2 = firstNonWhitespaceIndex(lineContent);
				if (firstNonWhitespaceIndex2 === -1) {
					firstNonWhitespaceIndex2 = lineContent.length;
				}
				ops = BlockCommentCommand._createAddBlockCommentOperations(
					new Range(s.startLineNumber, firstNonWhitespaceIndex2 + 1, s.startLineNumber, lineContent.length + 1),
					startToken,
					endToken,
					this._insertSpace
				);
			} else {
				ops = BlockCommentCommand._createAddBlockCommentOperations(
					new Range(
						s.startLineNumber,
						model.getLineFirstNonWhitespaceColumn(s.startLineNumber),
						s.endLineNumber,
						model.getLineMaxColumn(s.endLineNumber)
					),
					startToken,
					endToken,
					this._insertSpace
				);
			}
			if (ops.length === 1) {
				this._deltaColumn = startToken.length + 1;
			}
		}
		this._selectionId = builder.trackSelection(s);
		for (const op of ops) {
			builder.addEditOperation(op.range, op.text);
		}
	}
	getEditOperations(model, builder) {
		let s = this._selection;
		this._moveEndPositionDown = false;
		if (s.startLineNumber === s.endLineNumber && this._ignoreFirstLine) {
			builder.addEditOperation(
				new Range(s.startLineNumber, model.getLineMaxColumn(s.startLineNumber), s.startLineNumber + 1, 1),
				s.startLineNumber === model.getLineCount() ? '' : '\n'
			);
			this._selectionId = builder.trackSelection(s);
			return;
		}
		if (s.startLineNumber < s.endLineNumber && s.endColumn === 1) {
			this._moveEndPositionDown = true;
			s = s.setEndPosition(s.endLineNumber - 1, model.getLineMaxColumn(s.endLineNumber - 1));
		}
		const data = LineCommentCommand._gatherPreflightData(
			this._type,
			this._insertSpace,
			model,
			s.startLineNumber,
			s.endLineNumber,
			this._ignoreEmptyLines,
			this._ignoreFirstLine,
			this.languageConfigurationService
		);
		if (data.supported) {
			return this._executeLineComments(model, builder, data, s);
		}
		return this._executeBlockComment(model, builder, s);
	}
	computeCursorState(model, helper) {
		let result = helper.getTrackedSelection(this._selectionId);
		if (this._moveEndPositionDown) {
			result = result.setEndPosition(result.endLineNumber + 1, 1);
		}
		return new EditorSelection(
			result.selectionStartLineNumber,
			result.selectionStartColumn + this._deltaColumn,
			result.positionLineNumber,
			result.positionColumn + this._deltaColumn
		);
	}
	static _createRemoveLineCommentsOperations(lines, startLineNumber) {
		const res = [];
		for (let i = 0, len = lines.length; i < len; i++) {
			const lineData = lines[i];
			if (lineData.ignore) {
				continue;
			}
			res.push(
				EditOperation.delete(
					new Range(
						startLineNumber + i,
						lineData.commentStrOffset + 1,
						startLineNumber + i,
						lineData.commentStrOffset + lineData.commentStrLength + 1
					)
				)
			);
		}
		return res;
	}
	_createAddLineCommentsOperations(lines, startLineNumber) {
		const res = [];
		const afterCommentStr = this._insertSpace ? ' ' : '';
		for (let i = 0, len = lines.length; i < len; i++) {
			const lineData = lines[i];
			if (lineData.ignore) {
				continue;
			}
			res.push(
				EditOperation.insert(
					new Position(startLineNumber + i, lineData.commentStrOffset + 1),
					lineData.commentStr + afterCommentStr
				)
			);
		}
		return res;
	}
	static nextVisibleColumn(currentVisibleColumn, indentSize, isTab, columnSize) {
		if (isTab) {
			return currentVisibleColumn + (indentSize - (currentVisibleColumn % indentSize));
		}
		return currentVisibleColumn + columnSize;
	}
	static _normalizeInsertionPoint(model, lines, startLineNumber, indentSize) {
		let minVisibleColumn = 1073741824;
		let j;
		let lenJ;
		for (let i = 0, len = lines.length; i < len; i++) {
			if (lines[i].ignore) {
				continue;
			}
			const lineContent = model.getLineContent(startLineNumber + i);
			let currentVisibleColumn = 0;
			for (let j2 = 0, lenJ2 = lines[i].commentStrOffset; currentVisibleColumn < minVisibleColumn && j2 < lenJ2; j2++) {
				currentVisibleColumn = LineCommentCommand.nextVisibleColumn(
					currentVisibleColumn,
					indentSize,
					lineContent.charCodeAt(j2) === 9,
					1
				);
			}
			if (currentVisibleColumn < minVisibleColumn) {
				minVisibleColumn = currentVisibleColumn;
			}
		}
		minVisibleColumn = Math.floor(minVisibleColumn / indentSize) * indentSize;
		for (let i = 0, len = lines.length; i < len; i++) {
			if (lines[i].ignore) {
				continue;
			}
			const lineContent = model.getLineContent(startLineNumber + i);
			let currentVisibleColumn = 0;
			for (j = 0, lenJ = lines[i].commentStrOffset; currentVisibleColumn < minVisibleColumn && j < lenJ; j++) {
				currentVisibleColumn = LineCommentCommand.nextVisibleColumn(
					currentVisibleColumn,
					indentSize,
					lineContent.charCodeAt(j) === 9,
					1
				);
			}
			if (currentVisibleColumn > minVisibleColumn) {
				lines[i].commentStrOffset = j - 1;
			} else {
				lines[i].commentStrOffset = j;
			}
		}
	}
}

class CommentLineAction extends EditorAction {
	constructor(type, opts) {
		super(opts);
		this._type = type;
	}
	run(accessor, editor2) {
		const languageConfigurationService = accessor.get(ILanguageConfigurationService);
		if (!editor2.hasModel()) {
			return;
		}
		const model = editor2.getModel();
		const commands = [];
		const modelOptions = model.getOptions();
		const commentsOptions = editor2.getOption(
			23 // comments
		);
		const selections = editor2.getSelections().map((selection, index) => ({
			selection,
			index,
			ignoreFirstLine: false
		}));
		selections.sort((a, b) => Range.compareRangesUsingStarts(a.selection, b.selection));
		let prev = selections[0];
		for (let i = 1; i < selections.length; i++) {
			const curr = selections[i];
			if (prev.selection.endLineNumber === curr.selection.startLineNumber) {
				if (prev.index < curr.index) {
					curr.ignoreFirstLine = true;
				} else {
					prev.ignoreFirstLine = true;
					prev = curr;
				}
			}
		}
		for (const selection of selections) {
			commands.push(
				new LineCommentCommand(
					languageConfigurationService,
					selection.selection,
					modelOptions.indentSize,
					this._type,
					commentsOptions.insertSpace,
					commentsOptions.ignoreEmptyLines,
					selection.ignoreFirstLine
				)
			);
		}
		editor2.pushUndoStop();
		editor2.executeCommands(this.id, commands);
		editor2.pushUndoStop();
	}
}

class ToggleCommentLineAction extends CommentLineAction {
	constructor() {
		super(0, {
			id: 'editor.action.commentLine',
			label: localize('Toggle Line Comment'),
			alias: 'Toggle Line Comment',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 2048 | 90,
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: menubarEditMenu_menuId,
				group: '5_insert',
				title: localize('&&Toggle Line Comment'),
				order: 1
			}
		});
	}
}
registerEditorAction(ToggleCommentLineAction);

class AddLineCommentAction extends CommentLineAction {
	constructor() {
		super(1, {
			id: 'editor.action.addCommentLine',
			label: localize('Add Line Comment'),
			alias: 'Add Line Comment',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 33 // KeyC
				),
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorAction(AddLineCommentAction);

class RemoveLineCommentAction extends CommentLineAction {
	constructor() {
		super(2, {
			id: 'editor.action.removeCommentLine',
			label: localize('Remove Line Comment'),
			alias: 'Remove Line Comment',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: KeyChord(
					2048 | 41,
					2048 | 51 // KeyU
				),
				weight: 100 //editorContrib
			}
		});
	}
}
registerEditorAction(RemoveLineCommentAction);

class BlockCommentAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.blockComment',
			label: localize('Toggle Block Comment'),
			alias: 'Toggle Block Comment',
			precondition: ck_writable,
			kbOpts: {
				kbExpr: ck_editorFocus_text,
				primary: 1024 | 512 | 31,
				linux: {
					primary: 2048 | 1024 | 31 // KeyA
				},
				weight: 100 //editorContrib
			},
			menuOpts: {
				menuId: menubarEditMenu_menuId,
				group: '5_insert',
				title: localize('Toggle &&Block Comment'),
				order: 2
			}
		});
	}
	run(accessor, editor2) {
		const languageConfigurationService = accessor.get(ILanguageConfigurationService);
		if (!editor2.hasModel()) {
			return;
		}
		const commentsOptions = editor2.getOption(
			23 // comments
		);
		const commands = [];
		const selections = editor2.getSelections();
		for (const selection of selections) {
			commands.push(new BlockCommentCommand(selection, commentsOptions.insertSpace, languageConfigurationService));
		}
		editor2.pushUndoStop();
		editor2.executeCommands(this.id, commands);
		editor2.pushUndoStop();
	}
}
registerEditorAction(BlockCommentAction);