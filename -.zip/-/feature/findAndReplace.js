





//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

const findDecorations_CURRENT_FIND_MATCH_DECORATION = ModelDecorationOptions.register({
	description: 'current-find-match',
	stickiness: 1,
	zIndex: 13,
	className: 'currentFindMatch',
	showIfCollapsed: true,
	overviewRuler: {
		color: { id: colorId_overviewRuler_match_find_foreground },
		position: OverviewRulerLane2.Center
	},
	minimap: {
		color: { id: colorId_minimap_highlight_findMatch },
		position: 1 // Inline
	}
});
const findDecorations_FIND_MATCH_DECORATION = ModelDecorationOptions.register({
	description: 'find-match',
	stickiness: 1,
	zIndex: 10,
	className: 'findMatch',
	showIfCollapsed: true,
	overviewRuler: {
		color: { id: colorId_overviewRuler_match_find_foreground },
		position: OverviewRulerLane2.Center
	},
	minimap: {
		color: { id: colorId_minimap_highlight_findMatch },
		position: 1 // Inline
	}
});
const findDecorations_FIND_MATCH_NO_OVERVIEW_DECORATION = ModelDecorationOptions.register({
	description: 'find-match-no-overview',
	stickiness: 1,
	className: 'findMatch',
	showIfCollapsed: true
});
const findDecorations_FIND_MATCH_ONLY_OVERVIEW_DECORATION = ModelDecorationOptions.register({
	description: 'find-match-only-overview',
	stickiness: 1,
	overviewRuler: {
		color: { id: colorId_overviewRuler_match_find_foreground },
		position: OverviewRulerLane2.Center
	}
});
const findDecorations_RANGE_HIGHLIGHT_DECORATION = ModelDecorationOptions.register({
	description: 'find-range-highlight',
	stickiness: 1,
	className: 'rangeHighlight',
	isWholeLine: true
});
const findDecorations_FIND_SCOPE_DECORATION = ModelDecorationOptions.register({
	description: 'find-scope',
	className: 'findScope',
	isWholeLine: true
});

class FindDecorations {
	constructor(editor2) {
		this._editor = editor2;
		this._decorations = [];
		this._overviewRulerApproximateDecorations = [];
		this._findScopeDecorationIds = [];
		this._rangeHighlightDecorationId = null;
		this._highlightedDecorationId = null;
		this._startPosition = this._editor.getPosition();
	}
	dispose() {
		this._editor.removeDecorations(this._allDecorations());
		this._decorations = [];
		this._overviewRulerApproximateDecorations = [];
		this._findScopeDecorationIds = [];
		this._rangeHighlightDecorationId = null;
		this._highlightedDecorationId = null;
	}
	reset() {
		this._decorations = [];
		this._overviewRulerApproximateDecorations = [];
		this._findScopeDecorationIds = [];
		this._rangeHighlightDecorationId = null;
		this._highlightedDecorationId = null;
	}
	getCount() {
		return this._decorations.length;
	}
	getFindScope() {
		if (this._findScopeDecorationIds[0]) {
			return this._editor.getModel().getDecorationRange(this._findScopeDecorationIds[0]);
		}
		return null;
	}
	getFindScopes() {
		if (this._findScopeDecorationIds.length) {
			const scopes = this._findScopeDecorationIds
				.map(findScopeDecorationId => this._editor.getModel().getDecorationRange(findScopeDecorationId))
				.filter(element => !!element);
			if (scopes.length) {
				return scopes;
			}
		}
		return null;
	}
	getStartPosition() {
		return this._startPosition;
	}
	setStartPosition(newStartPosition) {
		this._startPosition = newStartPosition;
		this.setCurrentFindMatch(null);
	}
	_getDecorationIndex(decorationId) {
		const index = this._decorations.indexOf(decorationId);
		if (index >= 0) {
			return index + 1;
		}
		return 1;
	}
	getDecorationRangeAt(index) {
		const decorationId = index < this._decorations.length ? this._decorations[index] : null;
		if (decorationId) {
			return this._editor.getModel().getDecorationRange(decorationId);
		}
		return null;
	}
	getCurrentMatchesPosition(desiredRange) {
		const candidates = this._editor.getModel().getDecorationsInRange(desiredRange);
		for (const candidate of candidates) {
			const candidateOpts = candidate.options;
			if (
				candidateOpts === findDecorations_FIND_MATCH_DECORATION ||
				candidateOpts === findDecorations_CURRENT_FIND_MATCH_DECORATION
			) {
				return this._getDecorationIndex(candidate.id);
			}
		}
		return 0;
	}
	setCurrentFindMatch(nextMatch) {
		let newCurrentDecorationId = null;
		let matchPosition = 0;
		if (nextMatch) {
			for (let i = 0, len = this._decorations.length; i < len; i++) {
				const range2 = this._editor.getModel().getDecorationRange(this._decorations[i]);
				if (nextMatch.equalsRange(range2)) {
					newCurrentDecorationId = this._decorations[i];
					matchPosition = i + 1;
					break;
				}
			}
		}
		if (this._highlightedDecorationId !== null || newCurrentDecorationId !== null) {
			this._editor.changeDecorations(changeAccessor => {
				if (this._highlightedDecorationId !== null) {
					changeAccessor.changeDecorationOptions(this._highlightedDecorationId, findDecorations_FIND_MATCH_DECORATION);
					this._highlightedDecorationId = null;
				}
				if (newCurrentDecorationId !== null) {
					this._highlightedDecorationId = newCurrentDecorationId;
					changeAccessor.changeDecorationOptions(this._highlightedDecorationId, findDecorations_CURRENT_FIND_MATCH_DECORATION);
				}
				if (this._rangeHighlightDecorationId !== null) {
					changeAccessor.removeDecoration(this._rangeHighlightDecorationId);
					this._rangeHighlightDecorationId = null;
				}
				if (newCurrentDecorationId !== null) {
					let rng = this._editor.getModel().getDecorationRange(newCurrentDecorationId);
					if (rng.startLineNumber !== rng.endLineNumber && rng.endColumn === 1) {
						const lineBeforeEnd = rng.endLineNumber - 1;
						const lineBeforeEndMaxColumn = this._editor.getModel().getLineMaxColumn(lineBeforeEnd);
						rng = new Range(rng.startLineNumber, rng.startColumn, lineBeforeEnd, lineBeforeEndMaxColumn);
					}
					this._rangeHighlightDecorationId = changeAccessor.addDecoration(rng, findDecorations_RANGE_HIGHLIGHT_DECORATION);
				}
			});
		}
		return matchPosition;
	}
	set(findMatches, findScopes) {
		this._editor.changeDecorations(accessor => {
			let findMatchesOptions = findDecorations_FIND_MATCH_DECORATION;
			const newOverviewRulerApproximateDecorations = [];
			if (findMatches.length > 1e3) {
				findMatchesOptions = findDecorations_FIND_MATCH_NO_OVERVIEW_DECORATION;
				const lineCount = this._editor.getModel().getLineCount();
				const height = this._editor.getLayoutInfo().height;
				const approxPixelsPerLine = height / lineCount;
				const mergeLinesDelta = Math.max(2, Math.ceil(3 / approxPixelsPerLine));
				let prevStartLineNumber = findMatches[0].range.startLineNumber;
				let prevEndLineNumber = findMatches[0].range.endLineNumber;
				for (let i = 1, len = findMatches.length; i < len; i++) {
					const range2 = findMatches[i].range;
					if (prevEndLineNumber + mergeLinesDelta >= range2.startLineNumber) {
						if (range2.endLineNumber > prevEndLineNumber) {
							prevEndLineNumber = range2.endLineNumber;
						}
					} else {
						newOverviewRulerApproximateDecorations.push({
							range: new Range(prevStartLineNumber, 1, prevEndLineNumber, 1),
							options: findDecorations_FIND_MATCH_ONLY_OVERVIEW_DECORATION
						});
						prevStartLineNumber = range2.startLineNumber;
						prevEndLineNumber = range2.endLineNumber;
					}
				}
				newOverviewRulerApproximateDecorations.push({
					range: new Range(prevStartLineNumber, 1, prevEndLineNumber, 1),
					options: findDecorations_FIND_MATCH_ONLY_OVERVIEW_DECORATION
				});
			}
			const newFindMatchesDecorations = new Array(findMatches.length);
			for (let i = 0, len = findMatches.length; i < len; i++) {
				newFindMatchesDecorations[i] = {
					range: findMatches[i].range,
					options: findMatchesOptions
				};
			}
			this._decorations = accessor.deltaDecorations(this._decorations, newFindMatchesDecorations);
			this._overviewRulerApproximateDecorations = accessor.deltaDecorations(
				this._overviewRulerApproximateDecorations,
				newOverviewRulerApproximateDecorations
			);
			if (this._rangeHighlightDecorationId) {
				accessor.removeDecoration(this._rangeHighlightDecorationId);
				this._rangeHighlightDecorationId = null;
			}
			if (this._findScopeDecorationIds.length) {
				this._findScopeDecorationIds.forEach(findScopeDecorationId => accessor.removeDecoration(findScopeDecorationId));
				this._findScopeDecorationIds = [];
			}
			if (findScopes?.length) {
				this._findScopeDecorationIds = findScopes.map(findScope =>
					accessor.addDecoration(findScope, findDecorations_FIND_SCOPE_DECORATION)
				);
			}
		});
	}
	matchBeforePosition(position) {
		if (this._decorations.length === 0) {
			return null;
		}
		for (let i = this._decorations.length - 1; i >= 0; i--) {
			const decorationId = this._decorations[i];
			const r = this._editor.getModel().getDecorationRange(decorationId);
			if (!r || r.endLineNumber > position.lineNumber) {
				continue;
			}
			if (r.endLineNumber < position.lineNumber) {
				return r;
			}
			if (r.endColumn > position.column) {
				continue;
			}
			return r;
		}
		return this._editor.getModel().getDecorationRange(this._decorations[this._decorations.length - 1]);
	}
	matchAfterPosition(position) {
		if (this._decorations.length === 0) {
			return null;
		}
		for (let i = 0, len = this._decorations.length; i < len; i++) {
			const decorationId = this._decorations[i];
			const r = this._editor.getModel().getDecorationRange(decorationId);
			if (!r || r.startLineNumber < position.lineNumber) {
				continue;
			}
			if (r.startLineNumber > position.lineNumber) {
				return r;
			}
			if (r.startColumn < position.column) {
				continue;
			}
			return r;
		}
		return this._editor.getModel().getDecorationRange(this._decorations[0]);
	}
	_allDecorations() {
		let result = [];
		result = result.concat(this._decorations);
		result = result.concat(this._overviewRulerApproximateDecorations);
		if (this._findScopeDecorationIds.length) {
			result.push(...this._findScopeDecorationIds);
		}
		if (this._rangeHighlightDecorationId) {
			result.push(this._rangeHighlightDecorationId);
		}
		return result;
	}
}



//  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

class ReplaceAllCommand {
	constructor(editorSelection, ranges, replaceStrings) {
		this._editorSelection = editorSelection;
		this._ranges = ranges;
		this._replaceStrings = replaceStrings;
		this._trackedEditorSelectionId = null;
	}
	getEditOperations(model, builder) {
		if (this._ranges.length > 0) {
			const ops = [];
			for (let i = 0; i < this._ranges.length; i++) {
				ops.push({
					range: this._ranges[i],
					text: this._replaceStrings[i]
				});
			}
			ops.sort((o1, o2) => {
				return Range.compareRangesUsingStarts(o1.range, o2.range);
			});
			const resultOps = [];
			let previousOp = ops[0];
			for (let i = 1; i < ops.length; i++) {
				if (
					previousOp.range.endLineNumber === ops[i].range.startLineNumber &&
					previousOp.range.endColumn === ops[i].range.startColumn
				) {
					previousOp.range = previousOp.range.plusRange(ops[i].range);
					previousOp.text = previousOp.text + ops[i].text;
				} else {
					resultOps.push(previousOp);
					previousOp = ops[i];
				}
			}
			resultOps.push(previousOp);
			for (const op of resultOps) {
				builder.addEditOperation(op.range, op.text);
			}
		}
		this._trackedEditorSelectionId = builder.trackSelection(this._editorSelection);
	}
	computeCursorState(model, helper) {
		return helper.getTrackedSelection(this._trackedEditorSelectionId);
	}
}

function buildReplaceStringForSpecificSpecialCharacter(matches, pattern, specialCharacter) {
	const splitPatternAtSpecialCharacter = pattern.split(specialCharacter);
	const splitMatchAtSpecialCharacter = matches[0].split(specialCharacter);
	let replaceString = '';
	splitPatternAtSpecialCharacter.forEach((splitValue, index) => {
		function _buildReplaceStringWithCasePreserved(matches, pattern) {
			if (matches && matches[0] !== '') {

				function _validateSpecificSpecialCharacter(matches, pattern, specialCharacter) {
	const doesContainSpecialCharacter = matches[0].indexOf(specialCharacter) !== -1 && pattern.indexOf(specialCharacter) !== -1;
	return doesContainSpecialCharacter && matches[0].split(specialCharacter).length === pattern.split(specialCharacter).length;
}

				const containsHyphens = validateSpecificSpecialCharacter(matches, pattern, '-');
				const containsUnderscores = validateSpecificSpecialCharacter(matches, pattern, '_');
				if (containsHyphens && !containsUnderscores) {
					return buildReplaceStringForSpecificSpecialCharacter(matches, pattern, '-');
				} else if (!containsHyphens && containsUnderscores) {
					return buildReplaceStringForSpecificSpecialCharacter(matches, pattern, '_');
				}
				if (matches[0].toUpperCase() === matches[0]) {
					return pattern.toUpperCase();
				} else if (matches[0].toLowerCase() === matches[0]) {
					return pattern.toLowerCase();
				} else if (containsUppercaseCharacter(matches[0][0]) && pattern.length > 0) {
					return pattern[0].toUpperCase() + pattern.substr(1);
				} else if (matches[0][0].toUpperCase() !== matches[0][0] && pattern.length > 0) {
					return pattern[0].toLowerCase() + pattern.substr(1);
				} else {
					return pattern;
				}
			} else {
				return pattern;
			}
		}

		replaceString += _buildReplaceStringWithCasePreserved([splitMatchAtSpecialCharacter[index]], splitValue) + specialCharacter;
	});
	return replaceString.slice(0, -1);
}




class ReplacePattern {
	static fromStaticValue(value) {
		return new ReplacePattern([ReplacePiece.staticValue(value)]);
	}
	get hasReplacementPatterns() {
		return this._state.kind === 1;
	}
	constructor(pieces) {
		if (!pieces || pieces.length === 0) {
			this._state = { staticValue: '', kind: 0 };
		} else if (pieces.length === 1 && pieces[0].staticValue !== null) {
			this._state = { staticValue: pieces[0].staticValue, kind: 0 };
		} else {
			this._state = { pieces: pieces, kind: 1 };
		}
	}
	buildReplaceString(matches, preserveCase) {
		if (this._state.kind === 0) {
			if (preserveCase) {
				return buildReplaceStringWithCasePreserved(matches, this._state.staticValue);
			} else {
				return this._state.staticValue;
			}
		}
		let result = '';
		for (let i = 0, len = this._state.pieces.length; i < len; i++) {
			const piece = this._state.pieces[i];
			if (piece.staticValue !== null) {
				result += piece.staticValue;
				continue;
			}
			let match2 = ReplacePattern._substitute(piece.matchIndex, matches);
			if (piece.caseOps !== null && piece.caseOps.length > 0) {
				const repl = [];
				const lenOps = piece.caseOps.length;
				let opIdx = 0;
				for (let idx = 0, len2 = match2.length; idx < len2; idx++) {
					if (opIdx >= lenOps) {
						repl.push(match2.slice(idx));
						break;
					}
					switch (piece.caseOps[opIdx]) {
						case 'U':
							repl.push(match2[idx].toUpperCase());
							break;
						case 'u':
							repl.push(match2[idx].toUpperCase());
							opIdx++;
							break;
						case 'L':
							repl.push(match2[idx].toLowerCase());
							break;
						case 'l':
							repl.push(match2[idx].toLowerCase());
							opIdx++;
							break;
						default:
							repl.push(match2[idx]);
					}
				}
				match2 = repl.join('');
			}
			result += match2;
		}
		return result;
	}
	static _substitute(matchIndex, matches) {
		if (matches === null) {
			return '';
		}
		if (matchIndex === 0) {
			return matches[0];
		}
		let remainder = '';
		while (matchIndex > 0) {
			if (matchIndex < matches.length) {
				const match2 = matches[matchIndex] || '';
				return match2 + remainder;
			}
			remainder = String(matchIndex % 10) + remainder;
			matchIndex = Math.floor(matchIndex / 10);
		}
		return '$' + remainder;
	}
}

class ReplacePiece {
	static staticValue(value) {
		return new ReplacePiece(value, -1, null);
	}
	static caseOps(index, caseOps) {
		return new ReplacePiece(null, index, caseOps);
	}
	constructor(staticValue, matchIndex, caseOps) {
		this.staticValue = staticValue;
		this.matchIndex = matchIndex;
		if (!caseOps || caseOps.length === 0) {
			this.caseOps = null;
		} else {
			this.caseOps = caseOps.slice(0);
		}
	}
}

class ReplacePieceBuilder {
	constructor(source) {
		this._source = source;
		this._lastCharIndex = 0;
		this._result = [];
		this._resultLen = 0;
		this._currentStaticPiece = '';
	}
	emitUnchanged(toCharIndex) {
		this._emitStatic(this._source.substring(this._lastCharIndex, toCharIndex));
		this._lastCharIndex = toCharIndex;
	}
	emitStatic(value, toCharIndex) {
		this._emitStatic(value);
		this._lastCharIndex = toCharIndex;
	}
	_emitStatic(value) {
		if (value.length === 0) {
			return;
		}
		this._currentStaticPiece += value;
	}
	emitMatchIndex(index, toCharIndex, caseOps) {
		if (this._currentStaticPiece.length !== 0) {
			this._result[this._resultLen++] = ReplacePiece.staticValue(this._currentStaticPiece);
			this._currentStaticPiece = '';
		}
		this._result[this._resultLen++] = ReplacePiece.caseOps(index, caseOps);
		this._lastCharIndex = toCharIndex;
	}
	finalize() {
		this.emitUnchanged(this._source.length);
		if (this._currentStaticPiece.length !== 0) {
			this._result[this._resultLen++] = ReplacePiece.staticValue(this._currentStaticPiece);
			this._currentStaticPiece = '';
		}
		return new ReplacePattern(this._result);
	}
}

const ck_findWidgetVisible = new RawContextKey('findWidgetVisible', false);
const ck_findWidgetNotVisible = ck_findWidgetVisible.toNegated();
const ck_findInputFocussed = new RawContextKey('findInputFocussed', false);
const ck_replaceInputFocussed = new RawContextKey('replaceInputFocussed', false);

const ToggleCaseSensitiveKeybinding = {
	primary: 512 | 33,
	mac: {
		primary: 2048 | 512 | 33 // KeyC
	}
};
const ToggleWholeWordKeybinding = {
	primary: 512 | 53,
	mac: {
		primary: 2048 | 512 | 53 // KeyW
	}
};
const ToggleRegexKeybinding = {
	primary: 512 | 48,
	mac: {
		primary: 2048 | 512 | 48 // KeyR
	}
};
const ToggleSearchScopeKeybinding = {
	primary: 512 | 42,
	mac: {
		primary: 2048 | 512 | 42 // KeyL
	}
};
const TogglePreserveCaseKeybinding = {
	primary: 512 | 46,
	mac: {
		primary: 2048 | 512 | 46 // KeyP
	}
};

const FIND_IDS = {
	StartFindAction: 'actions.find',
	StartFindWithSelection: 'actions.findWithSelection',
	StartFindWithArgs: 'editor.actions.findWithArgs',
	NextMatchFindAction: 'editor.action.nextMatchFindAction',
	PreviousMatchFindAction: 'editor.action.previousMatchFindAction',
	GoToMatchFindAction: 'editor.action.goToMatchFindAction',
	NextSelectionMatchFindAction: 'editor.action.nextSelectionMatchFindAction',
	PreviousSelectionMatchFindAction: 'editor.action.previousSelectionMatchFindAction',
	StartFindReplaceAction: 'editor.action.startFindReplaceAction',
	CloseFindWidgetCommand: 'closeFindWidget',
	ToggleCaseSensitiveCommand: 'toggleFindCaseSensitive',
	ToggleWholeWordCommand: 'toggleFindWholeWord',
	ToggleRegexCommand: 'toggleFindRegex',
	ToggleSearchScopeCommand: 'toggleFindInSelection',
	TogglePreserveCaseCommand: 'togglePreserveCase',
	ReplaceOneAction: 'editor.action.replaceOne',
	ReplaceAllAction: 'editor.action.replaceAll',
	SelectAllMatchesAction: 'editor.action.selectAllMatches'
};
const MATCHES_LIMIT = 19999;

class FindModelBoundToEditorModel {
	constructor(editor2, state) {
		this._toDispose = new DisposableStore();
		this._editor = editor2;
		this._state = state;
		this._isDisposed = false;
		this._startSearchingTimer = new TimeoutTimer();
		this._decorations = new FindDecorations(editor2);
		this._toDispose.add(this._decorations);
		this._updateDecorationsScheduler = new RunOnceScheduler(() => this.research(false), 100);
		this._toDispose.add(this._updateDecorationsScheduler);
		this._toDispose.add(
			this._editor.onDidChangeCursorPosition(e => {
				if (e.reason === 3 || e.reason === 5 || e.reason === 6) {
					this._decorations.setStartPosition(this._editor.getPosition());
				}
			})
		);
		this._ignoreModelContentChanged = false;
		this._toDispose.add(
			this._editor.onDidChangeModelContent(e => {
				if (this._ignoreModelContentChanged) {
					return;
				}
				if (e.isFlush) {
					this._decorations.reset();
				}
				this._decorations.setStartPosition(this._editor.getPosition());
				this._updateDecorationsScheduler.schedule();
			})
		);
		this._toDispose.add(this._state.onFindReplaceStateChange(e => this._onStateChanged(e)));
		this.research(false, this._state.searchScope);
	}
	dispose() {
		this._isDisposed = true;
		dispose(this._startSearchingTimer);
		this._toDispose.dispose();
	}
	_onStateChanged(e) {
		if (this._isDisposed) {
			return;
		}
		if (!this._editor.hasModel()) {
			return;
		}
		if (e.searchString || e.isReplaceRevealed || e.isRegex || e.wholeWord || e.matchCase || e.searchScope) {
			const model = this._editor.getModel();
			if (model.isTooLargeForSyncing()) {
				this._startSearchingTimer.cancel();
				this._startSearchingTimer.setIfNotSet(() => {
					if (e.searchScope) {
						this.research(e.moveCursor, this._state.searchScope);
					} else {
						this.research(e.moveCursor);
					}
				}, 240);
			} else {
				if (e.searchScope) {
					this.research(e.moveCursor, this._state.searchScope);
				} else {
					this.research(e.moveCursor);
				}
			}
		}
	}
	static _getSearchRange(model, findScope) {
		if (findScope) {
			return findScope;
		}
		return model.getFullModelRange();
	}
	research(moveCursor, newFindScope) {
		let findScopes = null;
		if (typeof newFindScope !== 'undefined') {
			if (newFindScope !== null) {
				if (!isArray(newFindScope)) {
					findScopes = [newFindScope];
				} else {
					findScopes = newFindScope;
				}
			}
		} else {
			findScopes = this._decorations.getFindScopes();
		}
		if (findScopes !== null) {
			findScopes = findScopes.map(findScope => {
				if (findScope.startLineNumber !== findScope.endLineNumber) {
					let endLineNumber = findScope.endLineNumber;
					if (findScope.endColumn === 1) {
						endLineNumber = endLineNumber - 1;
					}
					return new Range(findScope.startLineNumber, 1, endLineNumber, this._editor.getModel().getLineMaxColumn(endLineNumber));
				}
				return findScope;
			});
		}
		const findMatches = this._findMatches(findScopes, false, MATCHES_LIMIT);
		this._decorations.set(findMatches, findScopes);
		const editorSelection = this._editor.getSelection();
		let currentMatchesPosition = this._decorations.getCurrentMatchesPosition(editorSelection);
		if (currentMatchesPosition === 0 && findMatches.length > 0) {
			const matchAfterSelection = findFirstIdxMonotonousOrArrLen(
				findMatches.map(match2 => match2.range),
				range2 => Range.compareRangesUsingStarts(range2, editorSelection) >= 0
			);
			currentMatchesPosition = matchAfterSelection > 0 ? matchAfterSelection - 1 + 1 : currentMatchesPosition;
		}
		this._state.changeMatchInfo(currentMatchesPosition, this._decorations.getCount(), undefined);
		if (
			moveCursor &&
			this._editor.getOption(
				41 // find
			).cursorMoveOnType
		) {
			this._moveToNextMatch(this._decorations.getStartPosition());
		}
	}
	_hasMatches() {
		return this._state.matchesCount > 0;
	}
	_cannotFind() {
		if (!this._hasMatches()) {
			const findScope = this._decorations.getFindScope();
			if (findScope) {
				this._editor.revealRangeInCenterIfOutsideViewport(
					findScope,
					0 // Smooth
				);
			}
			return true;
		}
		return false;
	}
	_setCurrentFindMatch(match2) {
		const matchesPosition = this._decorations.setCurrentFindMatch(match2);
		this._state.changeMatchInfo(matchesPosition, this._decorations.getCount(), match2);
		this._editor.setSelection(match2);
		this._editor.revealRangeInCenterIfOutsideViewport(
			match2,
			0 // Smooth
		);
	}
	_prevSearchPosition(before) {
		const isUsingLineStops =
			this._state.isRegex && (this._state.searchString.indexOf('^') >= 0 || this._state.searchString.indexOf('$') >= 0);
		let { lineNumber, column } = before;
		const model = this._editor.getModel();
		if (isUsingLineStops || column === 1) {
			if (lineNumber === 1) {
				lineNumber = model.getLineCount();
			} else {
				lineNumber--;
			}
			column = model.getLineMaxColumn(lineNumber);
		} else {
			column--;
		}
		return new Position(lineNumber, column);
	}
	_moveToPrevMatch(before, isRecursed = false) {
		if (!this._state.canNavigateBack()) {
			const nextMatchRange = this._decorations.matchAfterPosition(before);
			if (nextMatchRange) {
				this._setCurrentFindMatch(nextMatchRange);
			}
			return;
		}
		if (this._decorations.getCount() < MATCHES_LIMIT) {
			let prevMatchRange = this._decorations.matchBeforePosition(before);
			if (prevMatchRange && prevMatchRange.isEmpty() && prevMatchRange.getStartPosition().equals(before)) {
				before = this._prevSearchPosition(before);
				prevMatchRange = this._decorations.matchBeforePosition(before);
			}
			if (prevMatchRange) {
				this._setCurrentFindMatch(prevMatchRange);
			}
			return;
		}
		if (this._cannotFind()) {
			return;
		}
		const findScope = this._decorations.getFindScope();
		const searchRange = FindModelBoundToEditorModel._getSearchRange(this._editor.getModel(), findScope);
		if (searchRange.getEndPosition().isBefore(before)) {
			before = searchRange.getEndPosition();
		}
		if (before.isBefore(searchRange.getStartPosition())) {
			before = searchRange.getEndPosition();
		}
		const { lineNumber, column } = before;
		const model = this._editor.getModel();
		let position = new Position(lineNumber, column);
		let prevMatch = model.findPreviousMatch(
			this._state.searchString,
			position,
			this._state.isRegex,
			this._state.matchCase,
			this._state.wholeWord
				? this._editor.getOption(
						131 // wordSeparators
					)
				: null,
			false
		);
		if (prevMatch && prevMatch.range.isEmpty() && prevMatch.range.getStartPosition().equals(position)) {
			position = this._prevSearchPosition(position);
			prevMatch = model.findPreviousMatch(
				this._state.searchString,
				position,
				this._state.isRegex,
				this._state.matchCase,
				this._state.wholeWord
					? this._editor.getOption(
							131 // wordSeparators
						)
					: null,
				false
			);
		}
		if (!prevMatch) {
			return;
		}
		if (!isRecursed && !searchRange.containsRange(prevMatch.range)) {
			return this._moveToPrevMatch(prevMatch.range.getStartPosition(), true);
		}
		this._setCurrentFindMatch(prevMatch.range);
	}
	moveToPrevMatch() {
		this._moveToPrevMatch(this._editor.getSelection().getStartPosition());
	}
	_nextSearchPosition(after2) {
		const isUsingLineStops =
			this._state.isRegex && (this._state.searchString.indexOf('^') >= 0 || this._state.searchString.indexOf('$') >= 0);
		let { lineNumber, column } = after2;
		const model = this._editor.getModel();
		if (isUsingLineStops || column === model.getLineMaxColumn(lineNumber)) {
			if (lineNumber === model.getLineCount()) {
				lineNumber = 1;
			} else {
				lineNumber++;
			}
			column = 1;
		} else {
			column++;
		}
		return new Position(lineNumber, column);
	}
	_moveToNextMatch(after2) {
		if (!this._state.canNavigateForward()) {
			const prevMatchRange = this._decorations.matchBeforePosition(after2);
			if (prevMatchRange) {
				this._setCurrentFindMatch(prevMatchRange);
			}
			return;
		}
		if (this._decorations.getCount() < MATCHES_LIMIT) {
			let nextMatchRange = this._decorations.matchAfterPosition(after2);
			if (nextMatchRange && nextMatchRange.isEmpty() && nextMatchRange.getStartPosition().equals(after2)) {
				after2 = this._nextSearchPosition(after2);
				nextMatchRange = this._decorations.matchAfterPosition(after2);
			}
			if (nextMatchRange) {
				this._setCurrentFindMatch(nextMatchRange);
			}
			return;
		}
		const nextMatch = this._getNextMatch(after2, false, true);
		if (nextMatch) {
			this._setCurrentFindMatch(nextMatch.range);
		}
	}
	_getNextMatch(after2, captureMatches, forceMove, isRecursed = false) {
		if (this._cannotFind()) {
			return null;
		}
		const findScope = this._decorations.getFindScope();
		const searchRange = FindModelBoundToEditorModel._getSearchRange(this._editor.getModel(), findScope);
		if (searchRange.getEndPosition().isBefore(after2)) {
			after2 = searchRange.getStartPosition();
		}
		if (after2.isBefore(searchRange.getStartPosition())) {
			after2 = searchRange.getStartPosition();
		}
		const { lineNumber, column } = after2;
		const model = this._editor.getModel();
		let position = new Position(lineNumber, column);
		let nextMatch = model.findNextMatch(
			this._state.searchString,
			position,
			this._state.isRegex,
			this._state.matchCase,
			this._state.wholeWord
				? this._editor.getOption(
						131 // wordSeparators
					)
				: null,
			captureMatches
		);
		if (forceMove && nextMatch && nextMatch.range.isEmpty() && nextMatch.range.getStartPosition().equals(position)) {
			position = this._nextSearchPosition(position);
			nextMatch = model.findNextMatch(
				this._state.searchString,
				position,
				this._state.isRegex,
				this._state.matchCase,
				this._state.wholeWord
					? this._editor.getOption(
							131 // wordSeparators
						)
					: null,
				captureMatches
			);
		}
		if (!nextMatch) {
			return null;
		}
		if (!isRecursed && !searchRange.containsRange(nextMatch.range)) {
			return this._getNextMatch(nextMatch.range.getEndPosition(), captureMatches, forceMove, true);
		}
		return nextMatch;
	}
	moveToNextMatch() {
		this._moveToNextMatch(this._editor.getSelection().getEndPosition());
	}
	_moveToMatch(index) {
		const decorationRange = this._decorations.getDecorationRangeAt(index);
		if (decorationRange) {
			this._setCurrentFindMatch(decorationRange);
		}
	}
	moveToMatch(index) {
		this._moveToMatch(index);
	}
	_getReplacePattern() {
		if (this._state.isRegex) {
			function _parseReplaceString(replaceString) {
	if (!replaceString || replaceString.length === 0) {
		return new ReplacePattern(null);
	}
	const caseOps = [];
	const result = new ReplacePieceBuilder(replaceString);
	for (let i = 0, len = replaceString.length; i < len; i++) {
		const chCode = replaceString.charCodeAt(i);
		if (chCode === 92) {
			i++;
			if (i >= len) {
				break;
			}
			const nextChCode = replaceString.charCodeAt(i);
			switch (nextChCode) {
				case 92:
					result.emitUnchanged(i - 1);
					result.emitStatic('\\', i + 1);
					break;
				case 110:
					result.emitUnchanged(i - 1);
					result.emitStatic('\n', i + 1);
					break;
				case 116:
					result.emitUnchanged(i - 1);
					result.emitStatic('	', i + 1);
					break;
				case 117:
				case 85:
				case 108:
				case 76:
					result.emitUnchanged(i - 1);
					result.emitStatic('', i + 1);
					caseOps.push(String.fromCharCode(nextChCode));
					break;
			}
			continue;
		}
		if (chCode === 36) {
			i++;
			if (i >= len) {
				break;
			}
			const nextChCode = replaceString.charCodeAt(i);
			if (nextChCode === 36) {
				result.emitUnchanged(i - 1);
				result.emitStatic('$', i + 1);
				continue;
			}
			if (nextChCode === 48 || nextChCode === 38) {
				result.emitUnchanged(i - 1);
				result.emitMatchIndex(0, i + 1, caseOps);
				caseOps.length = 0;
				continue;
			}
			if (49 <= nextChCode && nextChCode <= 57) {
				let matchIndex = nextChCode - 48;
				if (i + 1 < len) {
					const nextNextChCode = replaceString.charCodeAt(i + 1);
					if (48 <= nextNextChCode && nextNextChCode <= 57) {
						i++;
						matchIndex = matchIndex * 10 + (nextNextChCode - 48);
						result.emitUnchanged(i - 2);
						result.emitMatchIndex(matchIndex, i + 1, caseOps);
						caseOps.length = 0;
						continue;
					}
				}
				result.emitUnchanged(i - 1);
				result.emitMatchIndex(matchIndex, i + 1, caseOps);
				caseOps.length = 0;
				continue;
			}
		}
	}
	return result.finalize();
}
			return _parseReplaceString(this._state.replaceString);
		}
		return ReplacePattern.fromStaticValue(this._state.replaceString);
	}
	replace() {
		if (!this._hasMatches()) {
			return;
		}
		const replacePattern = this._getReplacePattern();
		const selection = this._editor.getSelection();
		const nextMatch = this._getNextMatch(selection.getStartPosition(), true, false);
		if (nextMatch) {
			if (selection.equalsRange(nextMatch.range)) {
				const replaceString = replacePattern.buildReplaceString(nextMatch.matches, this._state.preserveCase);
				const command = new ReplaceCommand(selection, replaceString);
				this._executeEditorCommand('replace', command);
				this._decorations.setStartPosition(new Position(selection.startLineNumber, selection.startColumn + replaceString.length));
				this.research(true);
			} else {
				this._decorations.setStartPosition(this._editor.getPosition());
				this._setCurrentFindMatch(nextMatch.range);
			}
		}
	}
	_findMatches(findScopes, captureMatches, limitResultCount) {
		const searchRanges = (findScopes || [null]).map(scope =>
			FindModelBoundToEditorModel._getSearchRange(this._editor.getModel(), scope)
		);
		return this._editor.getModel().findMatches(
			this._state.searchString,
			searchRanges,
			this._state.isRegex,
			this._state.matchCase,
			this._state.wholeWord
				? this._editor.getOption(
						131 // wordSeparators
					)
				: null,
			captureMatches,
			limitResultCount
		);
	}
	replaceAll() {
		if (!this._hasMatches()) {
			return;
		}
		const findScopes = this._decorations.getFindScopes();
		if (findScopes === null && this._state.matchesCount >= MATCHES_LIMIT) {
			this._largeReplaceAll();
		} else {
			this._regularReplaceAll(findScopes);
		}
		this.research(false);
	}
	_largeReplaceAll() {
		const searchParams = new SearchParams(
			this._state.searchString,
			this._state.isRegex,
			this._state.matchCase,
			this._state.wholeWord
				? this._editor.getOption(
						131 // wordSeparators
					)
				: null
		);
		const searchData = searchParams.parseSearchRequest();
		if (!searchData) {
			return;
		}
		let searchRegex = searchData.regex;
		if (!searchRegex.multiline) {
			let mod = 'mu';
			if (searchRegex.ignoreCase) {
				mod += 'i';
			}
			if (searchRegex.global) {
				mod += 'g';
			}
			searchRegex = new RegExp(searchRegex.source, mod);
		}
		const model = this._editor.getModel();
		const modelText = model.getValue(
			1 // LF
		);
		const fullModelRange = model.getFullModelRange();
		const replacePattern = this._getReplacePattern();
		let resultText;
		const preserveCase = this._state.preserveCase;
		if (replacePattern.hasReplacementPatterns || preserveCase) {
			resultText = modelText.replace(searchRegex, function () {
				return replacePattern.buildReplaceString(arguments, preserveCase);
			});
		} else {
			resultText = modelText.replace(searchRegex, replacePattern.buildReplaceString(null, preserveCase));
		}
		const command = new ReplaceCommandThatPreservesSelection(fullModelRange, resultText, this._editor.getSelection());
		this._executeEditorCommand('replaceAll', command);
	}
	_regularReplaceAll(findScopes) {
		const replacePattern = this._getReplacePattern();
		const matches = this._findMatches(
			findScopes,
			replacePattern.hasReplacementPatterns || this._state.preserveCase,
			1073741824 // MAX_SAFE_SMALL_INTEGER
		);
		const replaceStrings = [];
		for (let i = 0, len = matches.length; i < len; i++) {
			replaceStrings[i] = replacePattern.buildReplaceString(matches[i].matches, this._state.preserveCase);
		}
		const command = new ReplaceAllCommand(
			this._editor.getSelection(),
			matches.map(m => m.range),
			replaceStrings
		);
		this._executeEditorCommand('replaceAll', command);
	}
	selectAllMatches() {
		if (!this._hasMatches()) {
			return;
		}
		const findScopes = this._decorations.getFindScopes();
		const matches = this._findMatches(
			findScopes,
			false,
			1073741824 // MAX_SAFE_SMALL_INTEGER
		);
		let selections = matches.map(
			m => new EditorSelection(m.range.startLineNumber, m.range.startColumn, m.range.endLineNumber, m.range.endColumn)
		);
		const editorSelection = this._editor.getSelection();
		for (let i = 0, len = selections.length; i < len; i++) {
			const sel = selections[i];
			if (sel.equalsRange(editorSelection)) {
				selections = [editorSelection].concat(selections.slice(0, i)).concat(selections.slice(i + 1));
				break;
			}
		}
		this._editor.setSelections(selections);
	}
	_executeEditorCommand(source, command) {
		try {
			this._ignoreModelContentChanged = true;
			this._editor.pushUndoStop();
			this._editor.executeCommand(source, command);
			this._editor.pushUndoStop();
		} finally {
			this._ignoreModelContentChanged = false;
		}
	}
}

class FindOptionsWidget extends Widget {
	constructor(editor2, state, keybindingService) {
		super();
		this._hideSoon = this._register(new RunOnceScheduler(() => this._hide(), 2e3));
		this._isVisible = false;
		this._editor = editor2;
		this._state = state;
		this._keybindingService = keybindingService;
		this._domNode = document.createElement('div');
		this._domNode.className = 'findOptionsWidget';
		this._domNode.style.display = 'none';
		this._domNode.style.top = '10px';
		this._domNode.style.zIndex = '12';
		const toggleStyles = {
			inputActiveOptionBorder: asCssVariable(colorId_inputActiveOption_border),
			inputActiveOptionForeground: asCssVariable(colorId_inputActiveOption_foreground),
			inputActiveOptionBackground: asCssVariable(colorId_inputActiveOption_background)
		};
		const hoverDelegate = this._register(createInstantHoverDelegate());
		this.caseSensitive = this._register(
			new CaseSensitiveToggle({
				appendTitle: this._keybindingLabelFor(FIND_IDS.ToggleCaseSensitiveCommand),
				isChecked: this._state.matchCase,
				hoverDelegate,
				...toggleStyles
			})
		);
		this._domNode.appendChild(this.caseSensitive.domNode);
		this._register(
			this.caseSensitive.onChange(() => {
				this._state.change({ matchCase: this.caseSensitive.checked }, false);
			})
		);
		this.wholeWords = this._register(
			new WholeWordsToggle({
				appendTitle: this._keybindingLabelFor(FIND_IDS.ToggleWholeWordCommand),
				isChecked: this._state.wholeWord,
				hoverDelegate,
				...toggleStyles
			})
		);
		this._domNode.appendChild(this.wholeWords.domNode);
		this._register(
			this.wholeWords.onChange(() => {
				this._state.change({ wholeWord: this.wholeWords.checked }, false);
			})
		);
		this.regex = this._register(
			new RegexToggle({
				appendTitle: this._keybindingLabelFor(FIND_IDS.ToggleRegexCommand),
				isChecked: this._state.isRegex,
				hoverDelegate,
				...toggleStyles
			})
		);
		this._domNode.appendChild(this.regex.domNode);
		this._register(
			this.regex.onChange(() => {
				this._state.change({ isRegex: this.regex.checked }, false);
			})
		);
		this._editor.addOverlayWidget(this);
		this._register(
			this._state.onFindReplaceStateChange(e => {
				let somethingChanged = false;
				if (e.isRegex) {
					this.regex.checked = this._state.isRegex;
					somethingChanged = true;
				}
				if (e.wholeWord) {
					this.wholeWords.checked = this._state.wholeWord;
					somethingChanged = true;
				}
				if (e.matchCase) {
					this.caseSensitive.checked = this._state.matchCase;
					somethingChanged = true;
				}
				if (!this._state.isRevealed && somethingChanged) {
					this._revealTemporarily();
				}
			})
		);
		this._register(addDisposableListener(this._domNode, EventType.MOUSE_LEAVE, e => this._onMouseLeave()));
		this._register(addDisposableListener(this._domNode, 'mouseover', e => this._onMouseOver()));
	}
	_keybindingLabelFor(actionId) {
		const kb = this._keybindingService.lookupKeybinding(actionId);
		if (!kb) {
			return '';
		}
		return ` (${kb.getLabel()})`;
	}
	dispose() {
		this._editor.removeOverlayWidget(this);
		super.dispose();
	} // ----- IOverlayWidget API
	getId() {
		return 'editor.contrib.findOptionsWidget';
	}
	getDomNode() {
		return this._domNode;
	}
	getPosition() {
		return {
			preference: 0 //TOP_RIGHT_CORNER
		};
	}
	highlightFindOptions() {
		this._revealTemporarily();
	}
	_revealTemporarily() {
		this._show();
		this._hideSoon.schedule();
	}
	_onMouseLeave() {
		this._hideSoon.schedule();
	}
	_onMouseOver() {
		this._hideSoon.cancel();
	}
	_show() {
		if (this._isVisible) {
			return;
		}
		this._isVisible = true;
		this._domNode.style.display = 'block';
	}
	_hide() {
		if (!this._isVisible) {
			return;
		}
		this._isVisible = false;
		this._domNode.style.display = 'none';
	}
}


function effectiveOptionValue(override, value) {
	if (override === 1) {
		return true;
	}
	if (override === 2) {
		return false;
	}
	return value;
}
class FindReplaceState extends Disposable {
	get searchString() {
		return this._searchString;
	}
	get replaceString() {
		return this._replaceString;
	}
	get isRevealed() {
		return this._isRevealed;
	}
	get isReplaceRevealed() {
		return this._isReplaceRevealed;
	}
	get isRegex() {
		return effectiveOptionValue(this._isRegexOverride, this._isRegex);
	}
	get wholeWord() {
		return effectiveOptionValue(this._wholeWordOverride, this._wholeWord);
	}
	get matchCase() {
		return effectiveOptionValue(this._matchCaseOverride, this._matchCase);
	}
	get preserveCase() {
		return effectiveOptionValue(this._preserveCaseOverride, this._preserveCase);
	}
	get actualIsRegex() {
		return this._isRegex;
	}
	get actualWholeWord() {
		return this._wholeWord;
	}
	get actualMatchCase() {
		return this._matchCase;
	}
	get actualPreserveCase() {
		return this._preserveCase;
	}
	get searchScope() {
		return this._searchScope;
	}
	get matchesPosition() {
		return this._matchesPosition;
	}
	get matchesCount() {
		return this._matchesCount;
	}
	get currentMatch() {
		return this._currentMatch;
	}
	constructor() {
		super();
		this._onFindReplaceStateChange = this._register(new Emitter());
		this.onFindReplaceStateChange = this._onFindReplaceStateChange.event;
		this._searchString = '';
		this._replaceString = '';
		this._isRevealed = false;
		this._isReplaceRevealed = false;
		this._isRegex = false;
		this._isRegexOverride = 0;
		this._wholeWord = false;
		this._wholeWordOverride = 0;
		this._matchCase = false;
		this._matchCaseOverride = 0;
		this._preserveCase = false;
		this._preserveCaseOverride = 0;
		this._searchScope = null;
		this._matchesPosition = 0;
		this._matchesCount = 0;
		this._currentMatch = null;
		this._loop = true;
		this._isSearching = false;
		this._filters = null;
	}
	changeMatchInfo(matchesPosition, matchesCount, currentMatch) {
		const changeEvent = {
			moveCursor: false,
			updateHistory: false,
			searchString: false,
			replaceString: false,
			isRevealed: false,
			isReplaceRevealed: false,
			isRegex: false,
			wholeWord: false,
			matchCase: false,
			preserveCase: false,
			searchScope: false,
			matchesPosition: false,
			matchesCount: false,
			currentMatch: false,
			loop: false,
			isSearching: false,
			filters: false
		};
		let somethingChanged = false;
		if (matchesCount === 0) {
			matchesPosition = 0;
		}
		if (matchesPosition > matchesCount) {
			matchesPosition = matchesCount;
		}
		if (this._matchesPosition !== matchesPosition) {
			this._matchesPosition = matchesPosition;
			changeEvent.matchesPosition = true;
			somethingChanged = true;
		}
		if (this._matchesCount !== matchesCount) {
			this._matchesCount = matchesCount;
			changeEvent.matchesCount = true;
			somethingChanged = true;
		}
		if (typeof currentMatch !== 'undefined') {
			if (!Range.equalsRange(this._currentMatch, currentMatch)) {
				this._currentMatch = currentMatch;
				changeEvent.currentMatch = true;
				somethingChanged = true;
			}
		}
		if (somethingChanged) {
			this._onFindReplaceStateChange.fire(changeEvent);
		}
	}
	change(newState, moveCursor, updateHistory = true) {
		const changeEvent = {
			moveCursor,
			updateHistory,
			searchString: false,
			replaceString: false,
			isRevealed: false,
			isReplaceRevealed: false,
			isRegex: false,
			wholeWord: false,
			matchCase: false,
			preserveCase: false,
			searchScope: false,
			matchesPosition: false,
			matchesCount: false,
			currentMatch: false,
			loop: false,
			isSearching: false,
			filters: false
		};
		let somethingChanged = false;
		const oldEffectiveIsRegex = this.isRegex;
		const oldEffectiveWholeWords = this.wholeWord;
		const oldEffectiveMatchCase = this.matchCase;
		const oldEffectivePreserveCase = this.preserveCase;
		if (typeof newState.searchString !== 'undefined') {
			if (this._searchString !== newState.searchString) {
				this._searchString = newState.searchString;
				changeEvent.searchString = true;
				somethingChanged = true;
			}
		}
		if (typeof newState.replaceString !== 'undefined') {
			if (this._replaceString !== newState.replaceString) {
				this._replaceString = newState.replaceString;
				changeEvent.replaceString = true;
				somethingChanged = true;
			}
		}
		if (typeof newState.isRevealed !== 'undefined') {
			if (this._isRevealed !== newState.isRevealed) {
				this._isRevealed = newState.isRevealed;
				changeEvent.isRevealed = true;
				somethingChanged = true;
			}
		}
		if (typeof newState.isReplaceRevealed !== 'undefined') {
			if (this._isReplaceRevealed !== newState.isReplaceRevealed) {
				this._isReplaceRevealed = newState.isReplaceRevealed;
				changeEvent.isReplaceRevealed = true;
				somethingChanged = true;
			}
		}
		if (typeof newState.isRegex !== 'undefined') {
			this._isRegex = newState.isRegex;
		}
		if (typeof newState.wholeWord !== 'undefined') {
			this._wholeWord = newState.wholeWord;
		}
		if (typeof newState.matchCase !== 'undefined') {
			this._matchCase = newState.matchCase;
		}
		if (typeof newState.preserveCase !== 'undefined') {
			this._preserveCase = newState.preserveCase;
		}
		if (typeof newState.searchScope !== 'undefined') {
			if (
				!newState.searchScope?.every(newSearchScope => {
					return this._searchScope?.some(existingSearchScope => {
						return !Range.equalsRange(existingSearchScope, newSearchScope);
					});
				})
			) {
				this._searchScope = newState.searchScope;
				changeEvent.searchScope = true;
				somethingChanged = true;
			}
		}
		if (typeof newState.loop !== 'undefined') {
			if (this._loop !== newState.loop) {
				this._loop = newState.loop;
				changeEvent.loop = true;
				somethingChanged = true;
			}
		}
		if (typeof newState.isSearching !== 'undefined') {
			if (this._isSearching !== newState.isSearching) {
				this._isSearching = newState.isSearching;
				changeEvent.isSearching = true;
				somethingChanged = true;
			}
		}
		if (typeof newState.filters !== 'undefined') {
			if (this._filters) {
				this._filters.update(newState.filters);
			} else {
				this._filters = newState.filters;
			}
			changeEvent.filters = true;
			somethingChanged = true;
		}
		this._isRegexOverride = typeof newState.isRegexOverride !== 'undefined' ? newState.isRegexOverride : 0;
		this._wholeWordOverride = typeof newState.wholeWordOverride !== 'undefined' ? newState.wholeWordOverride : 0;
		this._matchCaseOverride = typeof newState.matchCaseOverride !== 'undefined' ? newState.matchCaseOverride : 0;
		this._preserveCaseOverride = typeof newState.preserveCaseOverride !== 'undefined' ? newState.preserveCaseOverride : 0;
		if (oldEffectiveIsRegex !== this.isRegex) {
			somethingChanged = true;
			changeEvent.isRegex = true;
		}
		if (oldEffectiveWholeWords !== this.wholeWord) {
			somethingChanged = true;
			changeEvent.wholeWord = true;
		}
		if (oldEffectiveMatchCase !== this.matchCase) {
			somethingChanged = true;
			changeEvent.matchCase = true;
		}
		if (oldEffectivePreserveCase !== this.preserveCase) {
			somethingChanged = true;
			changeEvent.preserveCase = true;
		}
		if (somethingChanged) {
			this._onFindReplaceStateChange.fire(changeEvent);
		}
	}
	canNavigateBack() {
		return this.canNavigateInLoop() || this.matchesPosition !== 1;
	}
	canNavigateForward() {
		return this.canNavigateInLoop() || this.matchesPosition < this.matchesCount;
	}
	canNavigateInLoop() {
		return this._loop || this.matchesCount >= MATCHES_LIMIT;
	}
}


class PreserveCaseToggle extends Toggle {
	constructor(opts) {
		super({
			icon: codicon_preserveCase,
			title: localize('Preserve Case') + opts.appendTitle,
			isChecked: opts.isChecked,
			hoverDelegate: opts.hoverDelegate ?? getDefaultHoverDelegate('element'),
			inputActiveOptionBorder: opts.inputActiveOptionBorder,
			inputActiveOptionForeground: opts.inputActiveOptionForeground,
			inputActiveOptionBackground: opts.inputActiveOptionBackground
		});
	}
}

class ReplaceInput extends Widget {
	constructor(parent, contextViewProvider, _showOptionButtons, options2) {
		super();
		this._showOptionButtons = _showOptionButtons;
		this.fixFocusOnOptionClickEnabled = true;
		this.cachedOptionsWidth = 0;
		this._onDidOptionChange = this._register(new Emitter());
		this.onDidOptionChange = this._onDidOptionChange.event;
		this._onKeyDown = this._register(new Emitter());
		this.onKeyDown = this._onKeyDown.event;
		this._onMouseDown = this._register(new Emitter());
		this._onInput = this._register(new Emitter());
		this._onKeyUp = this._register(new Emitter());
		this._onPreserveCaseKeyDown = this._register(new Emitter());
		this.onPreserveCaseKeyDown = this._onPreserveCaseKeyDown.event;
		this.contextViewProvider = contextViewProvider;
		this.placeholder = options2.placeholder || '';
		this.validation = options2.validation;
		this.label = options2.label || localize('input');
		const appendPreserveCaseLabel = options2.appendPreserveCaseLabel || '';
		const history = options2.history || [];
		const flexibleHeight = !!options2.flexibleHeight;
		const flexibleWidth = !!options2.flexibleWidth;
		const flexibleMaxHeight = options2.flexibleMaxHeight;
		this.domNode = document.createElement('div');
		this.domNode.classList.add('monaco-findInput');
		this.inputBox = this._register(
			new HistoryInputBox(this.domNode, this.contextViewProvider, {
				placeholder: this.placeholder || '',
				validationOptions: {
					validation: this.validation
				},
				history,
				showHistoryHint: options2.showHistoryHint,
				flexibleHeight,
				flexibleWidth,
				flexibleMaxHeight,
				inputBoxStyles: options2.inputBoxStyles
			})
		);
		this.preserveCase = this._register(
			new PreserveCaseToggle({
				appendTitle: appendPreserveCaseLabel,
				isChecked: false,
				...options2.toggleStyles
			})
		);
		this._register(
			this.preserveCase.onChange(viaKeyboard => {
				this._onDidOptionChange.fire(viaKeyboard);
				if (!viaKeyboard && this.fixFocusOnOptionClickEnabled) {
					this.inputBox.focus();
				}
				this.validate();
			})
		);
		this._register(
			this.preserveCase.onKeyDown(e => {
				this._onPreserveCaseKeyDown.fire(e);
			})
		);
		if (this._showOptionButtons) {
			this.cachedOptionsWidth = this.preserveCase.width();
		} else {
			this.cachedOptionsWidth = 0;
		}
		const indexes = [this.preserveCase.domNode];
		this.onkeydown(this.domNode, event => {
			if (
				event.equals(
					15 // LeftArrow
				) ||
				event.equals(
					17 // RightArrow
				) ||
				event.equals(
					9 // Escape
				)
			) {
				const index = indexes.indexOf(this.domNode.ownerDocument.activeElement);
				if (index >= 0) {
					let newIndex = -1;
					if (
						event.equals(
							17 // RightArrow
						)
					) {
						newIndex = (index + 1) % indexes.length;
					} else if (
						event.equals(
							15 // LeftArrow
						)
					) {
						if (index === 0) {
							newIndex = indexes.length - 1;
						} else {
							newIndex = index - 1;
						}
					}
					if (
						event.equals(
							9 // Escape
						)
					) {
						indexes[index].blur();
						this.inputBox.focus();
					} else if (newIndex >= 0) {
						indexes[newIndex].focus();
					}
					EventHelper.stop(event, true);
				}
			}
		});
		const controls = document.createElement('div');
		controls.className = 'controls';
		controls.style.display = this._showOptionButtons ? 'block' : 'none';
		controls.appendChild(this.preserveCase.domNode);
		this.domNode.appendChild(controls);
		parent?.appendChild(this.domNode);
		this.onkeydown(this.inputBox.inputElement, e => this._onKeyDown.fire(e));
		this.onkeyup(this.inputBox.inputElement, e => this._onKeyUp.fire(e));
		this.oninput(this.inputBox.inputElement, e => this._onInput.fire());
		this.onmousedown(this.inputBox.inputElement, e => this._onMouseDown.fire(e));
	}
	enable() {
		this.domNode.classList.remove('disabled');
		this.inputBox.enable();
		this.preserveCase.enable();
	}
	disable() {
		this.domNode.classList.add('disabled');
		this.inputBox.disable();
		this.preserveCase.disable();
	}
	setEnabled(enabled) {
		if (enabled) {
			this.enable();
		} else {
			this.disable();
		}
	}
	select() {
		this.inputBox.select();
	}
	focus() {
		this.inputBox.focus();
	}
	getPreserveCase() {
		return this.preserveCase.checked;
	}
	setPreserveCase(value) {
		this.preserveCase.checked = value;
	}
	focusOnPreserve() {
		this.preserveCase.focus();
	}
	validate() {
		this.inputBox?.validate();
	}
	set width(newWidth) {
		this.inputBox.paddingRight = this.cachedOptionsWidth;
		this.domNode.style.width = newWidth + 'px';
	}
	dispose() {
		super.dispose();
	}
}


var HistoryNavigationWidgetFocusContext = 'historyNavigationWidgetFocus';
var HistoryNavigationForwardsEnablementContext = 'historyNavigationForwardsEnabled';
var HistoryNavigationBackwardsEnablementContext = 'historyNavigationBackwardsEnabled';

var lastFocusedWidget;
var widgets = [];
function registerAndCreateHistoryNavigationContext(scopedContextKeyService, widget) {
	if (widgets.includes(widget)) {
		throw new Error('Cannot register the same widget multiple times');
	}
	widgets.push(widget);
	const disposableStore = new DisposableStore();
	const historyNavigationWidgetFocus = new RawContextKey(HistoryNavigationWidgetFocusContext, false).bindTo(scopedContextKeyService);
	const historyNavigationForwardsEnablement = new RawContextKey(HistoryNavigationForwardsEnablementContext, true).bindTo(
		scopedContextKeyService
	);
	const historyNavigationBackwardsEnablement = new RawContextKey(HistoryNavigationBackwardsEnablementContext, true).bindTo(
		scopedContextKeyService
	);
	const onDidFocus = () => {
		historyNavigationWidgetFocus.set(true);
		lastFocusedWidget = widget;
	};
	const onDidBlur = () => {
		historyNavigationWidgetFocus.set(false);
		if (lastFocusedWidget === widget) {
			lastFocusedWidget = undefined;
		}
	};
	if (isActiveElement(widget.element)) {
		onDidFocus();
	}
	disposableStore.add(widget.onDidFocus(() => onDidFocus()));
	disposableStore.add(widget.onDidBlur(() => onDidBlur()));
	disposableStore.add(
		toDisposable(() => {
			widgets.splice(widgets.indexOf(widget), 1);
			onDidBlur();
		})
	);
	return {
		historyNavigationForwardsEnablement,
		historyNavigationBackwardsEnablement,
		dispose() {
			disposableStore.dispose();
		}
	};
}

class ContextScopedFindInput extends FindInput {
	constructor(container, contextViewProvider, options2, contextKeyService) {
		super(container, contextViewProvider, options2);
		const scopedContextKeyService = this._register(contextKeyService.createScoped(this.inputBox.element));
		this._register(registerAndCreateHistoryNavigationContext(scopedContextKeyService, this.inputBox));
	}
}
__decorate([__param(3, IContextKeyService)], ContextScopedFindInput);

class ContextScopedReplaceInput extends ReplaceInput {
	constructor(container, contextViewProvider, options2, contextKeyService, showReplaceOptions = false) {
		super(container, contextViewProvider, showReplaceOptions, options2);
		const scopedContextKeyService = this._register(contextKeyService.createScoped(this.inputBox.element));
		this._register(registerAndCreateHistoryNavigationContext(scopedContextKeyService, this.inputBox));
	}
}
__decorate([__param(3, IContextKeyService)], ContextScopedReplaceInput);

keybindingsRegistry.registerCommandAndKeybindingRule({
	id: 'history.showPrevious',
	weight: 200,
	when: ContextKeyExpr.and(
		ContextKeyExpr.has(HistoryNavigationWidgetFocusContext),
		ContextKeyExpr.equals(HistoryNavigationBackwardsEnablementContext, true),
		ContextKeyExpr.not('isComposing'),
		ck_suggestWidgetVisible.isEqualTo(false)
	),
	primary: 16,
	secondary: [
		512 | 16 // UpArrow
	],
	handler: accessor => {
		lastFocusedWidget?.showPreviousValue();
	}
});
keybindingsRegistry.registerCommandAndKeybindingRule({
	id: 'history.showNext',
	weight: 200,
	when: ContextKeyExpr.and(
		ContextKeyExpr.has(HistoryNavigationWidgetFocusContext),
		ContextKeyExpr.equals(HistoryNavigationForwardsEnablementContext, true),
		ContextKeyExpr.not('isComposing'),
		ck_suggestWidgetVisible.isEqualTo(false)
	),
	primary: 18,
	secondary: [
		512 | 18 //DownArrow
	],
	handler: accessor => {
		lastFocusedWidget?.showNextValue();
	}
});


var findSelectionIcon = iconRegistry.registerIcon(
	'find-selection',
	codicon_selection,
	localize("Icon for 'Find in EditorSelection' in the editor find widget.")
);
var findCollapsedIcon = iconRegistry.registerIcon(
	'find-collapsed',
	codicon_chevronRight,
	localize('Icon to indicate that the editor find widget is collapsed.')
);
var findExpandedIcon = iconRegistry.registerIcon(
	'find-expanded',
	codicon_chevronDown,
	localize('Icon to indicate that the editor find widget is expanded.')
);
var findReplaceIcon = iconRegistry.registerIcon('find-replace', codicon_replace, localize("Icon for 'Replace' in the editor find widget."));
var findReplaceAllIcon = iconRegistry.registerIcon(
	'find-replace-all',
	codicon_replaceAll,
	localize("Icon for 'Replace All' in the editor find widget.")
);
var findPreviousMatchIcon = iconRegistry.registerIcon(
	'find-previous-match',
	codicon_arrowUp,
	localize("Icon for 'Find Previous' in the editor find widget.")
);
var findNextMatchIcon = iconRegistry.registerIcon(
	'find-next-match',
	codicon_arrowDown,
	localize("Icon for 'Find Next' in the editor find widget.")
);

var FIND_WIDGET_INITIAL_WIDTH = 419;
var PART_WIDTH = 275;
var FIND_INPUT_AREA_WIDTH = PART_WIDTH - 54;
var MAX_MATCHES_COUNT_WIDTH = 69;
var FIND_INPUT_AREA_HEIGHT = 33;
var ctrlEnterReplaceAllWarningPromptedKey = 'ctrlEnterReplaceAll.windows.donotask';
var ctrlKeyMod2 = isMacintosh ? 256 : 2048;

class FindWidgetViewZone {
	constructor(afterLineNumber) {
		this.afterLineNumber = afterLineNumber;
		this.heightInPx = FIND_INPUT_AREA_HEIGHT;
		this.suppressMouseDown = false;
		this.domNode = document.createElement('div');
		this.domNode.className = 'dock-find-viewzone';
	}
}

function stopPropagationForMultiLineUpwards(event, value, textarea) {
	const isMultiline = !!value.match(/\n/);
	if (textarea && isMultiline && textarea.selectionStart > 0) {
		event.stopPropagation();
		return;
	}
}
function stopPropagationForMultiLineDownwards(event, value, textarea) {
	const isMultiline = !!value.match(/\n/);
	if (textarea && isMultiline && textarea.selectionEnd < textarea.value.length) {
		event.stopPropagation();
		return;
	}
}

class FindWidget extends Widget {
	constructor(
		codeEditor,
		controller,
		state,
		contextViewProvider,
		keybindingService,
		contextKeyService,
		themeService,
		storageService,
		notificationService,
		_hoverService
	) {
		super();
		this._hoverService = _hoverService;
		this._cachedHeight = null;
		this._revealTimeouts = [];
		this._codeEditor = codeEditor;
		this._controller = controller;
		this._state = state;
		this._contextViewProvider = contextViewProvider;
		this._keybindingService = keybindingService;
		this._contextKeyService = contextKeyService;
		this._storageService = storageService;
		this._notificationService = notificationService;
		this._ctrlEnterReplaceAllWarningPrompted = !!storageService.getBoolean(
			ctrlEnterReplaceAllWarningPromptedKey,
			0 // StorageScope.PROFILE
		);
		this._isVisible = false;
		this._isReplaceVisible = false;
		this._ignoreChangeEvent = false;
		this._updateHistoryDelayer = new Delayer(500);
		this._register(toDisposable(() => this._updateHistoryDelayer.cancel()));
		this._register(this._state.onFindReplaceStateChange(e => this._onStateChanged(e)));
		this._buildDomNode();
		this._updateButtons();
		this._tryUpdateWidgetWidth();
		this._findInput.inputBox.layout();
		this._register(
			this._codeEditor.onDidChangeConfiguration(e => {
				if (
					e.hasChanged(
						91 // readOnly
					)
				) {
					if (
						this._codeEditor.getOption(
							91 // readOnly
						)
					) {
						this._state.change({ isReplaceRevealed: false }, false);
					}
					this._updateButtons();
				}
				if (
					e.hasChanged(
						145 // layoutInfo
					)
				) {
					this._tryUpdateWidgetWidth();
				}
				if (
					e.hasChanged(
						41 // find
					)
				) {
					const supportLoop = this._codeEditor.getOption(
						41 // find
					).loop;
					this._state.change({ loop: supportLoop }, false);
					const addExtraSpaceOnTop = this._codeEditor.getOption(
						41 // find
					).addExtraSpaceOnTop;
					if (addExtraSpaceOnTop && !this._viewZone) {
						this._viewZone = new FindWidgetViewZone(0);
						this._showViewZone();
					}
					if (!addExtraSpaceOnTop && this._viewZone) {
						this._removeViewZone();
					}
				}
			})
		);
		this._register(
			this._codeEditor.onDidChangeCursorSelection(() => {
				if (this._isVisible) {
					this._updateToggleSelectionFindButton();
				}
			})
		);
		this._register(
			this._codeEditor.onDidFocusEditorWidget(async () => {
				if (this._isVisible) {
					const globalBufferTerm = await this._controller.getGlobalBufferTerm();
					if (globalBufferTerm && globalBufferTerm !== this._state.searchString) {
						this._state.change({ searchString: globalBufferTerm }, false);
						this._findInput.select();
					}
				}
			})
		);
		this._findInputFocused = ck_findInputFocussed.bindTo(contextKeyService);
		this._findFocusTracker = this._register(trackFocus(this._findInput.inputBox.inputElement));
		this._register(
			this._findFocusTracker.onDidFocus(() => {
				this._findInputFocused.set(true);
				this._updateSearchScope();
			})
		);
		this._register(
			this._findFocusTracker.onDidBlur(() => {
				this._findInputFocused.set(false);
			})
		);
		this._replaceInputFocused = ck_replaceInputFocussed.bindTo(contextKeyService);
		this._replaceFocusTracker = this._register(trackFocus(this._replaceInput.inputBox.inputElement));
		this._register(
			this._replaceFocusTracker.onDidFocus(() => {
				this._replaceInputFocused.set(true);
				this._updateSearchScope();
			})
		);
		this._register(
			this._replaceFocusTracker.onDidBlur(() => {
				this._replaceInputFocused.set(false);
			})
		);
		this._codeEditor.addOverlayWidget(this);
		if (
			this._codeEditor.getOption(
				41 // find
			).addExtraSpaceOnTop
		) {
			this._viewZone = new FindWidgetViewZone(0);
		}
		this._register(
			this._codeEditor.onDidChangeModel(() => {
				if (!this._isVisible) {
					return;
				}
				this._viewZoneId = undefined;
			})
		);
		this._register(
			this._codeEditor.onDidScrollChange(e => {
				if (e.scrollTopChanged) {
					this._layoutViewZone();
					return;
				}
				setTimeout(() => {
					this._layoutViewZone();
				}, 0);
			})
		);
	}
	getId() {
		return 'editor.contrib.findWidget';
	}
	getDomNode() {
		return this._domNode;
	}
	getPosition() {
		if (this._isVisible) {
			return {
				preference: 0 //TOP_RIGHT_CORNER
			};
		}
		return null;
	}
	_onStateChanged(e) {
		if (e.searchString) {
			try {
				this._ignoreChangeEvent = true;
				this._findInput.setValue(this._state.searchString);
			} finally {
				this._ignoreChangeEvent = false;
			}
			this._updateButtons();
		}
		if (e.replaceString) {
			this._replaceInput.inputBox.value = this._state.replaceString;
		}
		if (e.isRevealed) {
			if (this._state.isRevealed) {
				this._reveal();
			} else {
				this._hide(true);
			}
		}
		if (e.isReplaceRevealed) {
			if (this._state.isReplaceRevealed) {
				if (
					!this._codeEditor.getOption(
						91 // readOnly
					) &&
					!this._isReplaceVisible
				) {
					this._isReplaceVisible = true;
					this._replaceInput.width = getTotalWidth(this._findInput.domNode);
					this._updateButtons();
					this._replaceInput.inputBox.layout();
				}
			} else {
				if (this._isReplaceVisible) {
					this._isReplaceVisible = false;
					this._updateButtons();
				}
			}
		}
		if ((e.isRevealed || e.isReplaceRevealed) && (this._state.isRevealed || this._state.isReplaceRevealed)) {
			if (this._tryUpdateHeight()) {
				this._showViewZone();
			}
		}
		if (e.isRegex) {
			this._findInput.setRegex(this._state.isRegex);
		}
		if (e.wholeWord) {
			this._findInput.setWholeWords(this._state.wholeWord);
		}
		if (e.matchCase) {
			this._findInput.setCaseSensitive(this._state.matchCase);
		}
		if (e.preserveCase) {
			this._replaceInput.setPreserveCase(this._state.preserveCase);
		}
		if (e.searchScope) {
			if (this._state.searchScope) {
				this._toggleSelectionFind.checked = true;
			} else {
				this._toggleSelectionFind.checked = false;
			}
			this._updateToggleSelectionFindButton();
		}
		if (e.searchString || e.matchesCount || e.matchesPosition) {
			const showRedOutline = this._state.searchString.length > 0 && this._state.matchesCount === 0;
			this._domNode.classList.toggle('no-results', showRedOutline);
			this._updateMatchesCount();
			this._updateButtons();
		}
		if (e.searchString || e.currentMatch) {
			this._layoutViewZone();
		}
		if (e.updateHistory) {
			this._delayedUpdateHistory();
		}
		if (e.loop) {
			this._updateButtons();
		}
	}
	_delayedUpdateHistory() {
		this._updateHistoryDelayer.trigger(this._updateHistory.bind(this)).then(undefined, onUnexpectedError);
	}
	_updateHistory() {
		if (this._state.searchString) {
			this._findInput.inputBox.addToHistory();
		}
		if (this._state.replaceString) {
			this._replaceInput.inputBox.addToHistory();
		}
	}
	_updateMatchesCount() {
		this._matchesCount.style.minWidth = MAX_MATCHES_COUNT_WIDTH + 'px';
		if (this._state.matchesCount >= MATCHES_LIMIT) {
			this._matchesCount.title = localize(MATCHES_LIMIT);
		} else {
			this._matchesCount.title = '';
		}
		if (this._matchesCount.firstChild) {
			this._matchesCount.removeChild(this._matchesCount.firstChild);
		}
		let label;
		if (this._state.matchesCount > 0) {
			let matchesCount = String(this._state.matchesCount);
			if (this._state.matchesCount >= MATCHES_LIMIT) {
				matchesCount += '+';
			}
			let matchesPosition = String(this._state.matchesPosition);
			if (matchesPosition === '0') {
				matchesPosition = '?';
			}
			label = interpolateDigitsPlaceholders(localize('{0} of {1}'), matchesPosition, matchesCount);
		} else {
			label = localize('No results');
		}
		this._matchesCount.appendChild(document.createTextNode(label));
		MAX_MATCHES_COUNT_WIDTH = Math.max(MAX_MATCHES_COUNT_WIDTH, this._matchesCount.clientWidth);
	}
	_updateToggleSelectionFindButton() {
		const selection = this._codeEditor.getSelection();
		const isSelection = selection
			? selection.startLineNumber !== selection.endLineNumber || selection.startColumn !== selection.endColumn
			: false;
		const isChecked = this._toggleSelectionFind.checked;
		if (this._isVisible && (isChecked || isSelection)) {
			this._toggleSelectionFind.enable();
		} else {
			this._toggleSelectionFind.disable();
		}
	}
	_updateButtons() {
		this._findInput.setEnabled(this._isVisible);
		this._replaceInput.setEnabled(this._isVisible && this._isReplaceVisible);
		this._updateToggleSelectionFindButton();
		this._closeBtn.setEnabled(this._isVisible);
		const findInputIsNonEmpty = this._state.searchString.length > 0;
		const matchesCount = this._state.matchesCount ? true : false;
		this._prevBtn.setEnabled(this._isVisible && findInputIsNonEmpty && matchesCount && this._state.canNavigateBack());
		this._nextBtn.setEnabled(this._isVisible && findInputIsNonEmpty && matchesCount && this._state.canNavigateForward());
		this._replaceBtn.setEnabled(this._isVisible && this._isReplaceVisible && findInputIsNonEmpty);
		this._replaceAllBtn.setEnabled(this._isVisible && this._isReplaceVisible && findInputIsNonEmpty);
		this._domNode.classList.toggle('replaceToggled', this._isReplaceVisible);
		this._toggleReplaceBtn.setExpanded(this._isReplaceVisible);
		const canReplace = !this._codeEditor.getOption(
			91 // readOnly
		);
		this._toggleReplaceBtn.setEnabled(this._isVisible && canReplace);
	}
	_reveal() {
		this._revealTimeouts.forEach(e => {
			clearTimeout(e);
		});
		this._revealTimeouts = [];
		if (!this._isVisible) {
			this._isVisible = true;
			const selection = this._codeEditor.getSelection();
			switch (
				this._codeEditor.getOption(
					41 // find
				).autoFindInSelection
			) {
				case 'always':
					this._toggleSelectionFind.checked = true;
					break;
				case 'never':
					this._toggleSelectionFind.checked = false;
					break;
				case 'multiline': {
					const isSelectionMultipleLine = !!selection && selection.startLineNumber !== selection.endLineNumber;
					this._toggleSelectionFind.checked = isSelectionMultipleLine;
					break;
				}
				default:
					break;
			}
			this._tryUpdateWidgetWidth();
			this._updateButtons();
			this._revealTimeouts.push(
				setTimeout(() => {
					this._findInput.validate();
				}, 200)
			);
			this._codeEditor.layoutOverlayWidget(this);
			let adjustEditorScrollTop = true;
			if (
				this._codeEditor.getOption(
					41 // find
				).seedSearchStringFromSelection &&
				selection
			) {
				const domNode = this._codeEditor.getDomNode();
				if (domNode) {
					const editorCoords = getDomNodePagePosition(domNode);
					const startCoords = this._codeEditor.getScrolledVisiblePosition(selection.getStartPosition());
					const startLeft = editorCoords.left + (startCoords ? startCoords.left : 0);
					const startTop = startCoords ? startCoords.top : 0;
					if (this._viewZone && startTop < this._viewZone.heightInPx) {
						if (selection.endLineNumber > selection.startLineNumber) {
							adjustEditorScrollTop = false;
						}
						const leftOfFindWidget = getTopLeftOffset(this._domNode).left;
						if (startLeft > leftOfFindWidget) {
							adjustEditorScrollTop = false;
						}
						const endCoords = this._codeEditor.getScrolledVisiblePosition(selection.getEndPosition());
						const endLeft = editorCoords.left + (endCoords ? endCoords.left : 0);
						if (endLeft > leftOfFindWidget) {
							adjustEditorScrollTop = false;
						}
					}
				}
			}
			this._showViewZone(adjustEditorScrollTop);
		}
	}
	_hide(focusTheEditor) {
		this._revealTimeouts.forEach(e => {
			clearTimeout(e);
		});
		this._revealTimeouts = [];
		if (this._isVisible) {
			this._isVisible = false;
			this._updateButtons();
			this._domNode.classList.remove('visible');
			this._findInput.clearMessage();
			if (focusTheEditor) {
				this._codeEditor.focus();
			}
			this._codeEditor.layoutOverlayWidget(this);
			this._removeViewZone();
		}
	}
	_layoutViewZone(targetScrollTop) {
		const addExtraSpaceOnTop = this._codeEditor.getOption(
			41 // find
		).addExtraSpaceOnTop;
		if (!addExtraSpaceOnTop) {
			this._removeViewZone();
			return;
		}
		if (!this._isVisible) {
			return;
		}
		const viewZone = this._viewZone;
		if (this._viewZoneId !== undefined || !viewZone) {
			return;
		}
		this._codeEditor.changeViewZones(accessor => {
			viewZone.heightInPx = this._getHeight();
			this._viewZoneId = accessor.addZone(viewZone);
			this._codeEditor.setScrollTop(targetScrollTop || this._codeEditor.getScrollTop() + viewZone.heightInPx);
		});
	}
	_showViewZone(adjustScroll = true) {
		if (!this._isVisible) {
			return;
		}
		const addExtraSpaceOnTop = this._codeEditor.getOption(
			41 // find
		).addExtraSpaceOnTop;
		if (!addExtraSpaceOnTop) {
			return;
		}
		if (this._viewZone === undefined) {
			this._viewZone = new FindWidgetViewZone(0);
		}
		const viewZone = this._viewZone;
		this._codeEditor.changeViewZones(accessor => {
			if (this._viewZoneId !== undefined) {
				const newHeight = this._getHeight();
				if (newHeight === viewZone.heightInPx) {
					return;
				}
				const scrollAdjustment = newHeight - viewZone.heightInPx;
				viewZone.heightInPx = newHeight;
				accessor.layoutZone(this._viewZoneId);
				if (adjustScroll) {
					this._codeEditor.setScrollTop(this._codeEditor.getScrollTop() + scrollAdjustment);
				}
				return;
			} else {
				let scrollAdjustment = this._getHeight();
				scrollAdjustment -= this._codeEditor.getOption(
					84 // padding
				).top;
				if (scrollAdjustment <= 0) {
					return;
				}
				viewZone.heightInPx = scrollAdjustment;
				this._viewZoneId = accessor.addZone(viewZone);
				if (adjustScroll) {
					this._codeEditor.setScrollTop(this._codeEditor.getScrollTop() + scrollAdjustment);
				}
			}
		});
	}
	_removeViewZone() {
		this._codeEditor.changeViewZones(accessor => {
			if (this._viewZoneId !== undefined) {
				accessor.removeZone(this._viewZoneId);
				this._viewZoneId = undefined;
				if (this._viewZone) {
					this._codeEditor.setScrollTop(this._codeEditor.getScrollTop() - this._viewZone.heightInPx);
					this._viewZone = undefined;
				}
			}
		});
	}
	_tryUpdateWidgetWidth() {
		if (!this._isVisible) {
			return;
		}
		if (!this._domNode.isConnected) {
			return;
		}
		const layoutInfo = this._codeEditor.getLayoutInfo();
		const editorContentWidth = layoutInfo.contentWidth;
		if (editorContentWidth <= 0) {
			this._domNode.classList.add('hiddenEditor');
			return;
		} else if (this._domNode.classList.contains('hiddenEditor')) {
			this._domNode.classList.remove('hiddenEditor');
		}
		const editorWidth = layoutInfo.width;
		const minimapWidth = layoutInfo.minimap.minimapWidth;
		let collapsedFindWidget = false;
		let reducedFindWidget = false;
		let narrowFindWidget = false;
		if (this._resized) {
			const widgetWidth = getTotalWidth(this._domNode);
			if (widgetWidth > FIND_WIDGET_INITIAL_WIDTH) {
				this._domNode.style.maxWidth = `${editorWidth - 28 - minimapWidth - 15}px`;
				this._replaceInput.width = getTotalWidth(this._findInput.domNode);
				return;
			}
		}
		if (FIND_WIDGET_INITIAL_WIDTH + 28 + minimapWidth >= editorWidth) {
			reducedFindWidget = true;
		}
		if (FIND_WIDGET_INITIAL_WIDTH + 28 + minimapWidth - MAX_MATCHES_COUNT_WIDTH >= editorWidth) {
			narrowFindWidget = true;
		}
		if (FIND_WIDGET_INITIAL_WIDTH + 28 + minimapWidth - MAX_MATCHES_COUNT_WIDTH >= editorWidth + 50) {
			collapsedFindWidget = true;
		}
		this._domNode.classList.toggle('collapsed-find-widget', collapsedFindWidget);
		this._domNode.classList.toggle('narrow-find-widget', narrowFindWidget);
		this._domNode.classList.toggle('reduced-find-widget', reducedFindWidget);
		if (!narrowFindWidget && !collapsedFindWidget) {
			this._domNode.style.maxWidth = `${editorWidth - 28 - minimapWidth - 15}px`;
		}
		this._findInput.layout({
			collapsedFindWidget,
			narrowFindWidget,
			reducedFindWidget
		});
		if (this._resized) {
			const findInputWidth = this._findInput.inputBox.element.clientWidth;
			if (findInputWidth > 0) {
				this._replaceInput.width = findInputWidth;
			}
		} else if (this._isReplaceVisible) {
			this._replaceInput.width = getTotalWidth(this._findInput.domNode);
		}
	}
	_getHeight() {
		let totalheight = 0;
		totalheight += 4;
		totalheight += this._findInput.inputBox.height + 2;
		if (this._isReplaceVisible) {
			totalheight += 4;
			totalheight += this._replaceInput.inputBox.height + 2;
		}
		totalheight += 4;
		return totalheight;
	}
	_tryUpdateHeight() {
		const totalHeight = this._getHeight();
		if (this._cachedHeight !== null && this._cachedHeight === totalHeight) {
			return false;
		}
		this._cachedHeight = totalHeight;
		this._domNode.style.height = `${totalHeight}px`;
		return true;
	}
	focusFindInput() {
		this._findInput.select();
		this._findInput.focus();
	}
	focusReplaceInput() {
		this._replaceInput.select();
		this._replaceInput.focus();
	}
	highlightFindOptions() {
		this._findInput.highlightFindOptions();
	}
	_updateSearchScope() {
		if (!this._codeEditor.hasModel()) {
			return;
		}
		if (this._toggleSelectionFind.checked) {
			const selections = this._codeEditor.getSelections();
			selections
				.map(selection => {
					if (selection.endColumn === 1 && selection.endLineNumber > selection.startLineNumber) {
						selection = selection.setEndPosition(
							selection.endLineNumber - 1,
							this._codeEditor.getModel().getLineMaxColumn(selection.endLineNumber - 1)
						);
					}
					const currentMatch = this._state.currentMatch;
					if (selection.startLineNumber !== selection.endLineNumber) {
						if (!Range.equalsRange(selection, currentMatch)) {
							return selection;
						}
					}
					return null;
				})
				.filter(element => !!element);
			if (selections.length) {
				this._state.change({ searchScope: selections }, true);
			}
		}
	}
	_onFindInputMouseDown(e) {
		if (e.middleButton) {
			e.stopPropagation();
		}
	}
	_onFindInputKeyDown(e) {
		if (
			e.equals(
				ctrlKeyMod2 | 3 // Enter
			)
		) {
			if (this._keybindingService.dispatchEvent(e, e.target)) {
				e.preventDefault();
				return;
			} else {
				this._findInput.inputBox.insertAtCursor('\n');
				e.preventDefault();
				return;
			}
		}
		if (
			e.equals(
				2 // Tab
			)
		) {
			if (this._isReplaceVisible) {
				this._replaceInput.focus();
			} else {
				this._findInput.focusOnCaseSensitive();
			}
			e.preventDefault();
			return;
		}
		if (
			e.equals(
				2048 | 18 // DownArrow
			)
		) {
			this._codeEditor.focus();
			e.preventDefault();
			return;
		}
		if (
			e.equals(
				16 // UpArrow
			)
		) {
			return stopPropagationForMultiLineUpwards(e, this._findInput.getValue(), this._findInput.domNode.querySelector('textarea'));
		}
		if (
			e.equals(
				18 // DownArrow
			)
		) {
			return stopPropagationForMultiLineDownwards(e, this._findInput.getValue(), this._findInput.domNode.querySelector('textarea'));
		}
	}
	_onReplaceInputKeyDown(e) {
		if (
			e.equals(
				ctrlKeyMod2 | 3 // Enter
			)
		) {
			if (this._keybindingService.dispatchEvent(e, e.target)) {
				e.preventDefault();
				return;
			} else {
				this._replaceInput.inputBox.insertAtCursor('\n');
				e.preventDefault();
				return;
			}
		}
		if (
			e.equals(
				2 // Tab
			)
		) {
			this._findInput.focusOnCaseSensitive();
			e.preventDefault();
			return;
		}
		if (
			e.equals(
				1024 | 2 // Tab
			)
		) {
			this._findInput.focus();
			e.preventDefault();
			return;
		}
		if (
			e.equals(
				2048 | 18 // DownArrow
			)
		) {
			this._codeEditor.focus();
			e.preventDefault();
			return;
		}
		if (
			e.equals(
				16 // UpArrow
			)
		) {
			return stopPropagationForMultiLineUpwards(
				e,
				this._replaceInput.inputBox.value,
				this._replaceInput.inputBox.element.querySelector('textarea')
			);
		}
		if (
			e.equals(
				18 // DownArrow
			)
		) {
			return stopPropagationForMultiLineDownwards(
				e,
				this._replaceInput.inputBox.value,
				this._replaceInput.inputBox.element.querySelector('textarea')
			);
		}
	}
	getVerticalSashLeft(_sash) {
		return 0;
	}
	_keybindingLabelFor(actionId) {
		const kb = this._keybindingService.lookupKeybinding(actionId);
		if (!kb) {
			return '';
		}
		return ` (${kb.getLabel()})`;
	}
	_buildDomNode() {
		const flexibleHeight = true;
		const flexibleWidth = true;
		this._findInput = this._register(
			new ContextScopedFindInput(
				null,
				this._contextViewProvider,
				{
					width: FIND_INPUT_AREA_WIDTH,
					label: localize('Find'),
					placeholder: localize('Find'),
					appendCaseSensitiveLabel: this._keybindingLabelFor(FIND_IDS.ToggleCaseSensitiveCommand),
					appendWholeWordsLabel: this._keybindingLabelFor(FIND_IDS.ToggleWholeWordCommand),
					appendRegexLabel: this._keybindingLabelFor(FIND_IDS.ToggleRegexCommand),
					validation: value => {
						if (value.length === 0 || !this._findInput.getRegex()) {
							return null;
						}
						try {
							new RegExp(value, 'gu');
							return null;
						} catch (e) {
							return { content: e.message };
						}
					},
					flexibleHeight,
					flexibleWidth,
					flexibleMaxHeight: 118,
					showCommonFindToggles: true,
					showHistoryHint: () => {},
					inputBoxStyles: defaultStyle_inputbox,
					toggleStyles: defaultStyle_toggle
				},
				this._contextKeyService
			)
		);
		this._findInput.setRegex(!!this._state.isRegex);
		this._findInput.setCaseSensitive(!!this._state.matchCase);
		this._findInput.setWholeWords(!!this._state.wholeWord);
		this._register(this._findInput.onKeyDown(e => this._onFindInputKeyDown(e)));
		this._register(
			this._findInput.inputBox.onDidChange(() => {
				if (this._ignoreChangeEvent) {
					return;
				}
				this._state.change({ searchString: this._findInput.getValue() }, true);
			})
		);
		this._register(
			this._findInput.onDidOptionChange(() => {
				this._state.change(
					{
						isRegex: this._findInput.getRegex(),
						wholeWord: this._findInput.getWholeWords(),
						matchCase: this._findInput.getCaseSensitive()
					},
					true
				);
			})
		);
		this._register(
			this._findInput.onCaseSensitiveKeyDown(e => {
				if (
					e.equals(
						1024 | 2 // Tab
					)
				) {
					if (this._isReplaceVisible) {
						this._replaceInput.focus();
						e.preventDefault();
					}
				}
			})
		);
		this._register(
			this._findInput.onRegexKeyDown(e => {
				if (
					e.equals(
						2 // Tab
					)
				) {
					if (this._isReplaceVisible) {
						this._replaceInput.focusOnPreserve();
						e.preventDefault();
					}
				}
			})
		);
		this._register(
			this._findInput.inputBox.onDidHeightChange(e => {
				if (this._tryUpdateHeight()) {
					this._showViewZone();
				}
			})
		);
		if (isLinux) {
			this._register(this._findInput.onMouseDown(e => this._onFindInputMouseDown(e)));
		}
		this._matchesCount = document.createElement('div');
		this._matchesCount.className = 'matchesCount';
		this._updateMatchesCount();
		const hoverDelegate = this._register(createInstantHoverDelegate());
		this._prevBtn = this._register(
			new SimpleButton(
				{
					label: localize('Previous Match') + this._keybindingLabelFor(FIND_IDS.PreviousMatchFindAction),
					icon: findPreviousMatchIcon,
					hoverDelegate,
					onTrigger: () => {
						this._codeEditor.getAction(FIND_IDS.PreviousMatchFindAction)?.run().then(undefined, onUnexpectedError);
					}
				},
				this._hoverService
			)
		);
		this._nextBtn = this._register(
			new SimpleButton(
				{
					label: localize('Next Match') + this._keybindingLabelFor(FIND_IDS.NextMatchFindAction),
					icon: findNextMatchIcon,
					hoverDelegate,
					onTrigger: () => {
						this._codeEditor.getAction(FIND_IDS.NextMatchFindAction)?.run().then(undefined, onUnexpectedError);
					}
				},
				this._hoverService
			)
		);
		const findPart = document.createElement('div');
		findPart.className = 'find-part';
		findPart.appendChild(this._findInput.domNode);
		const actionsContainer = document.createElement('div');
		actionsContainer.className = 'find-actions';
		findPart.appendChild(actionsContainer);
		actionsContainer.appendChild(this._matchesCount);
		actionsContainer.appendChild(this._prevBtn.domNode);
		actionsContainer.appendChild(this._nextBtn.domNode);
		this._toggleSelectionFind = this._register(
			new Toggle({
				icon: findSelectionIcon,
				title: localize('Find in EditorSelection') + this._keybindingLabelFor(FIND_IDS.ToggleSearchScopeCommand),
				isChecked: false,
				hoverDelegate,
				inputActiveOptionBackground: asCssVariable(colorId_inputActiveOption_background),
				inputActiveOptionBorder: asCssVariable(colorId_inputActiveOption_border),
				inputActiveOptionForeground: asCssVariable(colorId_inputActiveOption_foreground)
			})
		);
		this._register(
			this._toggleSelectionFind.onChange(() => {
				if (this._toggleSelectionFind.checked) {
					if (this._codeEditor.hasModel()) {
						let selections = this._codeEditor.getSelections();
						selections = selections
							.map(selection => {
								if (selection.endColumn === 1 && selection.endLineNumber > selection.startLineNumber) {
									selection = selection.setEndPosition(
										selection.endLineNumber - 1,
										this._codeEditor.getModel().getLineMaxColumn(selection.endLineNumber - 1)
									);
								}
								if (!selection.isEmpty()) {
									return selection;
								}
								return null;
							})
							.filter(element => !!element);
						if (selections.length) {
							this._state.change({ searchScope: selections }, true);
						}
					}
				} else {
					this._state.change({ searchScope: null }, true);
				}
			})
		);
		actionsContainer.appendChild(this._toggleSelectionFind.domNode);
		this._closeBtn = this._register(
			new SimpleButton(
				{
					label: localize('Close') + this._keybindingLabelFor(FIND_IDS.CloseFindWidgetCommand),
					icon: registeredIcon_widgetClose,
					hoverDelegate,
					onTrigger: () => {
						this._state.change({ isRevealed: false, searchScope: null }, false);
					},
					onKeyDown: e => {
						if (
							e.equals(
								2 // Tab
							)
						) {
							if (this._isReplaceVisible) {
								if (this._replaceBtn.isEnabled()) {
									this._replaceBtn.focus();
								} else {
									this._codeEditor.focus();
								}
								e.preventDefault();
							}
						}
					}
				},
				this._hoverService
			)
		);
		this._replaceInput = this._register(
			new ContextScopedReplaceInput(
				null,
				undefined,
				{
					label: localize('Replace'),
					placeholder: localize('Replace'),
					appendPreserveCaseLabel: this._keybindingLabelFor(FIND_IDS.TogglePreserveCaseCommand),
					history: [],
					flexibleHeight,
					flexibleWidth,
					flexibleMaxHeight: 118,
					showHistoryHint: () => showHistoryKeybindingHint(this._keybindingService),
					inputBoxStyles: defaultStyle_inputbox,
					toggleStyles: defaultStyle_toggle
				},
				this._contextKeyService,
				true
			)
		);
		this._replaceInput.setPreserveCase(!!this._state.preserveCase);
		this._register(this._replaceInput.onKeyDown(e => this._onReplaceInputKeyDown(e)));
		this._register(
			this._replaceInput.inputBox.onDidChange(() => {
				this._state.change({ replaceString: this._replaceInput.inputBox.value }, false);
			})
		);
		this._register(
			this._replaceInput.inputBox.onDidHeightChange(e => {
				if (this._isReplaceVisible && this._tryUpdateHeight()) {
					this._showViewZone();
				}
			})
		);
		this._register(
			this._replaceInput.onDidOptionChange(() => {
				this._state.change(
					{
						preserveCase: this._replaceInput.getPreserveCase()
					},
					true
				);
			})
		);
		this._register(
			this._replaceInput.onPreserveCaseKeyDown(e => {
				if (
					e.equals(
						2 // Tab
					)
				) {
					if (this._prevBtn.isEnabled()) {
						this._prevBtn.focus();
					} else if (this._nextBtn.isEnabled()) {
						this._nextBtn.focus();
					} else if (this._toggleSelectionFind.enabled) {
						this._toggleSelectionFind.focus();
					} else if (this._closeBtn.isEnabled()) {
						this._closeBtn.focus();
					}
					e.preventDefault();
				}
			})
		);
		const replaceHoverDelegate = this._register(createInstantHoverDelegate());
		this._replaceBtn = this._register(
			new SimpleButton(
				{
					label: localize('Replace') + this._keybindingLabelFor(FIND_IDS.ReplaceOneAction),
					icon: findReplaceIcon,
					hoverDelegate: replaceHoverDelegate,
					onTrigger: () => {
						this._controller.replace();
					},
					onKeyDown: e => {
						if (
							e.equals(
								1024 | 2 // Tab
							)
						) {
							this._closeBtn.focus();
							e.preventDefault();
						}
					}
				},
				this._hoverService
			)
		);
		this._replaceAllBtn = this._register(
			new SimpleButton(
				{
					label: localize('Replace All') + this._keybindingLabelFor(FIND_IDS.ReplaceAllAction),
					icon: findReplaceAllIcon,
					hoverDelegate: replaceHoverDelegate,
					onTrigger: () => {
						this._controller.replaceAll();
					}
				},
				this._hoverService
			)
		);
		const replacePart = document.createElement('div');
		replacePart.className = 'replace-part';
		replacePart.appendChild(this._replaceInput.domNode);
		const replaceActionsContainer = document.createElement('div');
		replaceActionsContainer.className = 'replace-actions';
		replacePart.appendChild(replaceActionsContainer);
		replaceActionsContainer.appendChild(this._replaceBtn.domNode);
		replaceActionsContainer.appendChild(this._replaceAllBtn.domNode);
		this._toggleReplaceBtn = this._register(
			new SimpleButton(
				{
					label: localize('Toggle Replace'),
					className: 'codicon toggle left',
					onTrigger: () => {
						this._state.change({ isReplaceRevealed: !this._isReplaceVisible }, false);
						if (this._isReplaceVisible) {
							this._replaceInput.width = getTotalWidth(this._findInput.domNode);
							this._replaceInput.inputBox.layout();
						}
						this._showViewZone();
					}
				},
				this._hoverService
			)
		);
		this._toggleReplaceBtn.setExpanded(this._isReplaceVisible);
		this._domNode = document.createElement('div');
		this._domNode.className = 'editor-widget find-widget';
		this._domNode.role = 'dialog';
		this._domNode.style.width = `${FIND_WIDGET_INITIAL_WIDTH}px`;
		this._domNode.appendChild(this._toggleReplaceBtn.domNode);
		this._domNode.appendChild(findPart);
		this._domNode.appendChild(this._closeBtn.domNode);
		this._domNode.appendChild(replacePart);
		this._resizeSash = this._register(new Sash(this._domNode, this, { orientation: 0, size: 2 }));
		this._resized = false;
		let originalWidth = FIND_WIDGET_INITIAL_WIDTH;
		this._register(
			this._resizeSash.onDidStart(() => {
				originalWidth = getTotalWidth(this._domNode);
			})
		);
		this._register(
			this._resizeSash.onDidChange(evt => {
				this._resized = true;
				const width2 = originalWidth + evt.startX - evt.currentX;
				if (width2 < FIND_WIDGET_INITIAL_WIDTH) {
					return;
				}
				const maxWidth = parseFloat(getComputedStyle(this._domNode).maxWidth) || 0;
				if (width2 > maxWidth) {
					return;
				}
				this._domNode.style.width = `${width2}px`;
				if (this._isReplaceVisible) {
					this._replaceInput.width = getTotalWidth(this._findInput.domNode);
				}
				this._findInput.inputBox.layout();
				this._tryUpdateHeight();
			})
		);
		this._register(
			this._resizeSash.onDidReset(() => {
				const currentWidth = getTotalWidth(this._domNode);
				if (currentWidth < FIND_WIDGET_INITIAL_WIDTH) {
					return;
				}
				let width2 = FIND_WIDGET_INITIAL_WIDTH;
				if (!this._resized || currentWidth === FIND_WIDGET_INITIAL_WIDTH) {
					const layoutInfo = this._codeEditor.getLayoutInfo();
					width2 = layoutInfo.width - 28 - layoutInfo.minimap.minimapWidth - 15;
					this._resized = true;
				}
				this._domNode.style.width = `${width2}px`;
				if (this._isReplaceVisible) {
					this._replaceInput.width = getTotalWidth(this._findInput.domNode);
				}
				this._findInput.inputBox.layout();
			})
		);
	}
}

class SimpleButton extends Widget {
	constructor(opts, hoverService) {
		super();
		this._opts = opts;
		let className = 'button';
		if (this._opts.className) {
			className = className + ' ' + this._opts.className;
		}
		if (this._opts.icon) {
			className = className + ' ' + asThemeIconClassNameString(this._opts.icon);
		}
		this._domNode = document.createElement('div');
		this._domNode.tabIndex = 0;
		this._domNode.className = className;
		this._register(
			hoverService.setupUpdatableHover(opts.hoverDelegate ?? getDefaultHoverDelegate('element'), this._domNode, this._opts.label)
		);
		this.onclick(this._domNode, e => {
			this._opts.onTrigger();
			e.preventDefault();
		});
		this.onkeydown(this._domNode, e => {
			if (
				e.equals(
					10 // Space
				) ||
				e.equals(
					3 // Enter
				)
			) {
				this._opts.onTrigger();
				e.preventDefault();
				return;
			}
			this._opts?.onKeyDown?.call(this._opts, e);
		});
	}
	get domNode() {
		return this._domNode;
	}
	isEnabled() {
		return this._domNode.tabIndex >= 0;
	}
	focus() {
		this._domNode.focus();
	}
	setEnabled(enabled) {
		this._domNode.tabIndex = enabled ? 0 : -1;
	}
	setExpanded(expanded2) {
		if (expanded2) {
			this._domNode.classList.remove(...asThemeIconClassNameArray(findCollapsedIcon));
			this._domNode.classList.add(...asThemeIconClassNameArray(findExpandedIcon));
		} else {
			this._domNode.classList.remove(...asThemeIconClassNameArray(findExpandedIcon));
			this._domNode.classList.add(...asThemeIconClassNameArray(findCollapsedIcon));
		}
	}
}
registerThemingParticipant((theme, collector) => {
	const findMatchHighlightBorder = theme.getColor(colorId_findMatchHighlight_border);
	if (findMatchHighlightBorder) {
		collector.addRule(
			`.monaco-editor .findMatch { border: 1px ${isHighContrast(theme.type) ? 'dotted' : 'solid'} ${findMatchHighlightBorder}; box-sizing: border-box; }`
		);
	}
	const findRangeHighlightBorder = theme.getColor(colorId_findRangeHighlight_border);
	if (findRangeHighlightBorder) {
		collector.addRule(
			`.monaco-editor .findScope { border: 1px ${isHighContrast(theme.type) ? 'dashed' : 'solid'} ${findRangeHighlightBorder}; }`
		);
	}
	const hcBorder = theme.getColor(colorId_contrast_border);
	if (hcBorder) {
		collector.addRule(`.monaco-editor .find-widget { border: 1px solid ${hcBorder}; }`);
	}
});


function getSelectionSearchString(editor2, seedSearchStringFromSelection = 'single', seedSearchStringFromNonEmptySelection = false) {
	if (!editor2.hasModel()) {
		return null;
	}
	const selection = editor2.getSelection();
	if (
		(seedSearchStringFromSelection === 'single' && selection.startLineNumber === selection.endLineNumber) ||
		seedSearchStringFromSelection === 'multiple'
	) {
		if (selection.isEmpty()) {
			const wordAtPosition = editor2.getConfiguredWordAtPosition(selection.getStartPosition());
			if (wordAtPosition && false === seedSearchStringFromNonEmptySelection) {
				return wordAtPosition.word;
			}
		} else {
			if (editor2.getModel().getValueLengthInRange(selection) < 524288) {
				return editor2.getModel().getValueInRange(selection);
			}
		}
	}
	return null;
}

const commonFindController_id = 'editor.contrib.findController';
class CommonFindController extends Disposable {
	get editor() {
		return this._editor;
	}
	static get(editor2) {
		return editor2.getContribution(commonFindController_id);
	}
	constructor(editor2, contextKeyService, storageService, clipboardService, notificationService, hoverService) {
		super();
		this._editor = editor2;
		this._findWidgetVisible = ck_findWidgetVisible.bindTo(contextKeyService);
		this._contextKeyService = contextKeyService;
		this._storageService = storageService;
		this._clipboardService = clipboardService;
		this._notificationService = notificationService;
		this._hoverService = hoverService;
		this._updateHistoryDelayer = new Delayer(500);
		this._state = this._register(new FindReplaceState());
		this.loadQueryState();
		this._register(this._state.onFindReplaceStateChange(e => this._onStateChanged(e)));
		this._model = null;
		this._register(
			this._editor.onDidChangeModel(() => {
				const shouldRestartFind = this._editor.getModel() && this._state.isRevealed;
				this.disposeModel();
				this._state.change(
					{
						searchScope: null,
						matchCase: this._storageService.getBoolean('editor.matchCase', 1, false),
						wholeWord: this._storageService.getBoolean('editor.wholeWord', 1, false),
						isRegex: this._storageService.getBoolean('editor.isRegex', 1, false),
						preserveCase: this._storageService.getBoolean('editor.preserveCase', 1, false)
					},
					false
				);
				if (shouldRestartFind) {
					this._start({
						forceRevealReplace: false,
						seedSearchStringFromSelection: 'none',
						seedSearchStringFromNonEmptySelection: false,
						seedSearchStringFromGlobalClipboard: false,
						shouldFocus: 0,
						shouldAnimate: false,
						updateSearchScope: false,
						loop: this._editor.getOption(
							41 // find
						).loop
					});
				}
			})
		);
	}
	dispose() {
		this.disposeModel();
		super.dispose();
	}
	disposeModel() {
		if (this._model) {
			this._model.dispose();
			this._model = null;
		}
	}
	_onStateChanged(e) {
		this.saveQueryState(e);
		if (e.isRevealed) {
			if (this._state.isRevealed) {
				this._findWidgetVisible.set(true);
			} else {
				this._findWidgetVisible.reset();
				this.disposeModel();
			}
		}
		if (e.searchString) {
			this.setGlobalBufferTerm(this._state.searchString);
		}
	}
	saveQueryState(e) {
		if (e.isRegex) {
			this._storageService.store(
				'editor.isRegex',
				this._state.actualIsRegex,
				1,
				1 // StorageTarget.MACHINE
			);
		}
		if (e.wholeWord) {
			this._storageService.store(
				'editor.wholeWord',
				this._state.actualWholeWord,
				1,
				1 // StorageTarget.MACHINE
			);
		}
		if (e.matchCase) {
			this._storageService.store(
				'editor.matchCase',
				this._state.actualMatchCase,
				1,
				1 // StorageTarget.MACHINE
			);
		}
		if (e.preserveCase) {
			this._storageService.store(
				'editor.preserveCase',
				this._state.actualPreserveCase,
				1,
				1 // StorageTarget.MACHINE
			);
		}
	}
	loadQueryState() {
		this._state.change(
			{
				matchCase: this._storageService.getBoolean('editor.matchCase', 1, this._state.matchCase),
				wholeWord: this._storageService.getBoolean('editor.wholeWord', 1, this._state.wholeWord),
				isRegex: this._storageService.getBoolean('editor.isRegex', 1, this._state.isRegex),
				preserveCase: this._storageService.getBoolean('editor.preserveCase', 1, this._state.preserveCase)
			},
			false
		);
	}
	isFindInputFocused() {
		return !!ck_findInputFocussed.getValue(this._contextKeyService);
	}
	getState() {
		return this._state;
	}
	closeFindWidget() {
		this._state.change({ isRevealed: false, searchScope: null }, false);
		this._editor.focus();
	}
	toggleCaseSensitive() {
		this._state.change({ matchCase: !this._state.matchCase }, false);
		if (!this._state.isRevealed) {
			this.highlightFindOptions();
		}
	}
	toggleWholeWords() {
		this._state.change({ wholeWord: !this._state.wholeWord }, false);
		if (!this._state.isRevealed) {
			this.highlightFindOptions();
		}
	}
	toggleRegex() {
		this._state.change({ isRegex: !this._state.isRegex }, false);
		if (!this._state.isRevealed) {
			this.highlightFindOptions();
		}
	}
	togglePreserveCase() {
		this._state.change({ preserveCase: !this._state.preserveCase }, false);
		if (!this._state.isRevealed) {
			this.highlightFindOptions();
		}
	}
	toggleSearchScope() {
		if (this._state.searchScope) {
			this._state.change({ searchScope: null }, true);
		} else {
			if (this._editor.hasModel()) {
				let selections = this._editor.getSelections();
				selections = selections
					.map(selection => {
						if (selection.endColumn === 1 && selection.endLineNumber > selection.startLineNumber) {
							selection = selection.setEndPosition(
								selection.endLineNumber - 1,
								this._editor.getModel().getLineMaxColumn(selection.endLineNumber - 1)
							);
						}
						if (!selection.isEmpty()) {
							return selection;
						}
						return null;
					})
					.filter(element => !!element);
				if (selections.length) {
					this._state.change({ searchScope: selections }, true);
				}
			}
		}
	}
	setSearchString(searchString) {
		if (this._state.isRegex) {
			searchString = escapeRegexChars(searchString);
		}
		this._state.change({ searchString }, false);
	}
	highlightFindOptions(ignoreWhenVisible = false) {}
	async _start(opts, newState) {
		this.disposeModel();
		if (!this._editor.hasModel()) {
			return;
		}
		const stateChanges = { ...newState, isRevealed: true };
		if (opts.seedSearchStringFromSelection === 'single') {
			const selectionSearchString = getSelectionSearchString(
				this._editor,
				opts.seedSearchStringFromSelection,
				opts.seedSearchStringFromNonEmptySelection
			);
			if (selectionSearchString) {
				if (this._state.isRegex) {
					stateChanges.searchString = escapeRegexChars(selectionSearchString);
				} else {
					stateChanges.searchString = selectionSearchString;
				}
			}
		} else if (opts.seedSearchStringFromSelection === 'multiple' && !opts.updateSearchScope) {
			const selectionSearchString = getSelectionSearchString(this._editor, opts.seedSearchStringFromSelection);
			if (selectionSearchString) {
				stateChanges.searchString = selectionSearchString;
			}
		}
		if (!stateChanges.searchString && opts.seedSearchStringFromGlobalClipboard) {
			const selectionSearchString = await this.getGlobalBufferTerm();
			if (!this._editor.hasModel()) {
				return;
			}
			if (selectionSearchString) {
				stateChanges.searchString = selectionSearchString;
			}
		}
		if (opts.forceRevealReplace || stateChanges.isReplaceRevealed) {
			stateChanges.isReplaceRevealed = true;
		} else if (!this._findWidgetVisible.get()) {
			stateChanges.isReplaceRevealed = false;
		}
		if (opts.updateSearchScope) {
			const currentSelections = this._editor.getSelections();
			if (currentSelections.some(selection => !selection.isEmpty())) {
				stateChanges.searchScope = currentSelections;
			}
		}
		stateChanges.loop = opts.loop;
		this._state.change(stateChanges, false);
		if (!this._model) {
			this._model = new FindModelBoundToEditorModel(this._editor, this._state);
		}
	}
	start(opts, newState) {
		return this._start(opts, newState);
	}
	moveToNextMatch() {
		if (this._model) {
			this._model.moveToNextMatch();
			return true;
		}
		return false;
	}
	moveToPrevMatch() {
		if (this._model) {
			this._model.moveToPrevMatch();
			return true;
		}
		return false;
	}
	goToMatch(index) {
		if (this._model) {
			this._model.moveToMatch(index);
			return true;
		}
		return false;
	}
	replace() {
		if (this._model) {
			this._model.replace();
			return true;
		}
		return false;
	}
	replaceAll() {
		if (this._model) {
			if (this._editor.getModel()?.isTooLargeForHeapOperation()) {
				this._notificationService.warn(localize('The file is too large to perform a replace all operation.'));
				return false;
			}
			this._model.replaceAll();
			return true;
		}
		return false;
	}
	selectAllMatches() {
		if (this._model) {
			this._model.selectAllMatches();
			this._editor.focus();
			return true;
		}
		return false;
	}
	async getGlobalBufferTerm() {
		if (
			this._editor.getOption(
				41 // find
			).globalFindClipboard &&
			this._editor.hasModel() &&
			!this._editor.getModel().isTooLargeForSyncing()
		) {
			return this._clipboardService.readFindText();
		}
		return '';
	}
	setGlobalBufferTerm(text2) {
		if (
			this._editor.getOption(
				41 // find
			).globalFindClipboard &&
			this._editor.hasModel() &&
			!this._editor.getModel().isTooLargeForSyncing()
		) {
			this._clipboardService.writeFindText(text2);
		}
	}
}
__decorate(
	[
		__param(1, IContextKeyService),
		__param(2, IStorageService),
		__param(3, IClipboardService),
		__param(4, INotificationService),
		__param(5, IHoverService)
	],
	CommonFindController
);

class FindController2 extends CommonFindController {
	constructor(
		editor2,
		_contextViewService,
		_contextKeyService,
		_keybindingService,
		_themeService,
		notificationService,
		_storageService,
		clipboardService,
		hoverService
	) {
		super(editor2, _contextKeyService, _storageService, clipboardService, notificationService, hoverService);
		this._contextViewService = _contextViewService;
		this._keybindingService = _keybindingService;
		this._themeService = _themeService;
		this._widget = null;
		this._findOptionsWidget = null;
	}
	async _start(opts, newState) {
		if (!this._widget) {
			this._createFindWidget();
		}
		const selection = this._editor.getSelection();
		let updateSearchScope = false;
		switch (
			this._editor.getOption(
				41 // find
			).autoFindInSelection
		) {
			case 'always':
				updateSearchScope = true;
				break;
			case 'never':
				updateSearchScope = false;
				break;
			case 'multiline': {
				const isSelectionMultipleLine = !!selection && selection.startLineNumber !== selection.endLineNumber;
				updateSearchScope = isSelectionMultipleLine;
				break;
			}
			default:
				break;
		}
		opts.updateSearchScope = opts.updateSearchScope || updateSearchScope;
		await super._start(opts, newState);
		if (this._widget) {
			if (opts.shouldFocus === 2) {
				this._widget.focusReplaceInput();
			} else if (opts.shouldFocus === 1) {
				this._widget.focusFindInput();
			}
		}
	}
	highlightFindOptions(ignoreWhenVisible = false) {
		if (!this._widget) {
			this._createFindWidget();
		}
		if (this._state.isRevealed && !ignoreWhenVisible) {
			this._widget.highlightFindOptions();
		} else {
			this._findOptionsWidget.highlightFindOptions();
		}
	}
	_createFindWidget() {
		this._widget = this._register(
			new FindWidget(
				this._editor,
				this,
				this._state,
				this._contextViewService,
				this._keybindingService,
				this._contextKeyService,
				this._themeService,
				this._storageService,
				this._notificationService,
				this._hoverService
			)
		);
		this._findOptionsWidget = this._register(new FindOptionsWidget(this._editor, this._state, this._keybindingService));
	}
}
__decorate(
	[
		__param(1, IContextViewService),
		__param(2, IContextKeyService),
		__param(3, IKeybindingService),
		__param(4, IThemeService),
		__param(5, INotificationService),
		__param(6, IStorageService),
		__param(7, IClipboardService),
		__param(8, IHoverService)
	],
	FindController2
);



class StartFindWithArgsAction extends EditorAction {
	constructor() {
		super({
			id: FIND_IDS.StartFindWithArgs,
			label: localize('Find With Arguments'),
			alias: 'Find With Arguments',
			kbOpts: {
				kbExpr: null,
				primary: 0,
				weight: 100 //editorContrib
			},
			metadata: {
				description: 'Open a new In-Editor Find Widget.',
				args: [
					{
						name: 'Open a new In-Editor Find Widget args',
						schema: {
							properties: {
								searchString: { type: 'string' },
								replaceString: { type: 'string' },
								isRegex: { type: 'boolean' },
								matchWholeWord: { type: 'boolean' },
								isCaseSensitive: { type: 'boolean' },
								preserveCase: { type: 'boolean' },
								findInSelection: { type: 'boolean' }
							}
						}
					}
				]
			}
		});
	}
	async run(accessor, editor2, args) {
		const controller = CommonFindController.get(editor2);
		if (controller) {
			const newState = args
				? {
						searchString: args.searchString,
						replaceString: args.replaceString,
						isReplaceRevealed: args.replaceString !== undefined,
						isRegex: args.isRegex, // isRegexOverride: args.regexOverride,
						wholeWord: args.matchWholeWord, // wholeWordOverride: args.wholeWordOverride,
						matchCase: args.isCaseSensitive, // matchCaseOverride: args.matchCaseOverride,
						preserveCase: args.preserveCase // preserveCaseOverride: args.preserveCaseOverride,
					}
				: {};
			await controller.start(
				{
					forceRevealReplace: false,
					seedSearchStringFromSelection:
						controller.getState().searchString.length === 0 &&
						editor2.getOption(
							41 // find
						).seedSearchStringFromSelection !== 'never'
							? 'single'
							: 'none',
					seedSearchStringFromNonEmptySelection:
						editor2.getOption(
							41 // find
						).seedSearchStringFromSelection === 'selection',
					seedSearchStringFromGlobalClipboard: true,
					shouldFocus: 1,
					shouldAnimate: true,
					updateSearchScope: args?.findInSelection || false,
					loop: editor2.getOption(
						41 // find
					).loop
				},
				newState
			);
			controller.setGlobalBufferTerm(controller.getState().searchString);
		}
	}
}
registerEditorAction(StartFindWithArgsAction);

class StartFindWithSelectionAction extends EditorAction {
	constructor() {
		super({
			id: FIND_IDS.StartFindWithSelection,
			label: localize('Find With EditorSelection'),
			alias: 'Find With EditorSelection',
			kbOpts: {
				kbExpr: null,
				primary: 0,
				mac: { primary: 2048 | 35 },
				weight: 100 //editorContrib
			}
		});
	}
	async run(accessor, editor2) {
		const controller = CommonFindController.get(editor2);
		if (controller) {
			await controller.start({
				forceRevealReplace: false,
				seedSearchStringFromSelection: 'multiple',
				seedSearchStringFromNonEmptySelection: false,
				seedSearchStringFromGlobalClipboard: false,
				shouldFocus: 0,
				shouldAnimate: true,
				updateSearchScope: false,
				loop: editor2.getOption(
					41 // find
				).loop
			});
			controller.setGlobalBufferTerm(controller.getState().searchString);
		}
	}
}
registerEditorAction(StartFindWithSelectionAction);

class MatchFindAction extends EditorAction {
	async run(accessor, editor2) {
		const controller = CommonFindController.get(editor2);
		if (controller && !this._run(controller)) {
			await controller.start({
				forceRevealReplace: false,
				seedSearchStringFromSelection:
					controller.getState().searchString.length === 0 &&
					editor2.getOption(
						41 // find
					).seedSearchStringFromSelection !== 'never'
						? 'single'
						: 'none',
				seedSearchStringFromNonEmptySelection:
					editor2.getOption(
						41 // find
					).seedSearchStringFromSelection === 'selection',
				seedSearchStringFromGlobalClipboard: true,
				shouldFocus: 0,
				shouldAnimate: true,
				updateSearchScope: false,
				loop: editor2.getOption(
					41 // find
				).loop
			});
			this._run(controller);
		}
	}
}
class NextMatchFindAction extends MatchFindAction {
	constructor() {
		super({
			id: FIND_IDS.NextMatchFindAction,
			label: localize('Find Next'),
			alias: 'Find Next',
			kbOpts: [
				{
					kbExpr: ck_editorFocus,
					primary: 61,
					mac: {
						primary: 2048 | 37,
						secondary: [
							61 // F3
						]
					},
					weight: 100 // KeybindingWeight.EditorContrib
				},
				{
					kbExpr: ContextKeyExpr.and(ck_editorFocus, ck_findInputFocussed),
					primary: 3,
					weight: 100 // KeybindingWeight.EditorContrib
				}
			]
		});
	}
	_run(controller) {
		const result = controller.moveToNextMatch();
		if (result) {
			controller.editor.pushUndoStop();
			return true;
		}
		return false;
	}
}
registerEditorAction(NextMatchFindAction);

class PreviousMatchFindAction extends MatchFindAction {
	constructor() {
		super({
			id: FIND_IDS.PreviousMatchFindAction,
			label: localize('Find Previous'),
			alias: 'Find Previous',
			kbOpts: [
				{
					kbExpr: ck_editorFocus,
					primary: 1024 | 61,
					mac: {
						primary: 2048 | 1024 | 37,
						secondary: [
							1024 | 61 // F3
						]
					},
					weight: 100 // KeybindingWeight.EditorContrib
				},
				{
					kbExpr: ContextKeyExpr.and(ck_editorFocus, ck_findInputFocussed),
					primary: 1024 | 3,
					weight: 100 // KeybindingWeight.EditorContrib
				}
			]
		});
	}
	_run(controller) {
		return controller.moveToPrevMatch();
	}
}
registerEditorAction(PreviousMatchFindAction);

class MoveToMatchFindAction extends EditorAction {
	constructor() {
		super({
			id: FIND_IDS.GoToMatchFindAction,
			label: localize('Go to Match...'),
			alias: 'Go to Match...',
			precondition: ck_findWidgetVisible
		});
		this._highlightDecorations = [];
	}
	run(accessor, editor2, args) {
		const controller = CommonFindController.get(editor2);
		if (!controller) {
			return;
		}
		const matchesCount = controller.getState().matchesCount;
		if (matchesCount < 1) {
			const notificationService = accessor.get(INotificationService);
			notificationService.notify({
				severity: Severity.Warning,
				message: localize('No matches. Try searching for something else.')
			});
			return;
		}
		//const quickInputService = accessor.get(IQuickInputService);
		const inputBox = quickInputService.createInputBox();
		inputBox.placeholder = localize(matchesCount);
		const toFindMatchIndex = value => {
			const index = parseInt(value);
			if (isNaN(index)) {
				return;
			}
			const matchCount = controller.getState().matchesCount;
			if (index > 0 && index <= matchCount) {
				return index - 1;
			} else if (index < 0 && index >= -matchCount) {
				return matchCount + index;
			}
			return;
		};
		const updatePickerAndEditor = value => {
			const index = toFindMatchIndex(value);
			if (typeof index === 'number') {
				inputBox.validationMessage = undefined;
				controller.goToMatch(index);
				const currentMatch = controller.getState().currentMatch;
				if (currentMatch) {
					this.addDecorations(editor2, currentMatch);
				}
			} else {
				inputBox.validationMessage = localize(controller.getState().matchesCount);
				this.clearDecorations(editor2);
			}
		};
		inputBox.onDidChangeValue(value => {
			updatePickerAndEditor(value);
		});
		inputBox.onDidAccept(() => {
			const index = toFindMatchIndex(inputBox.value);
			if (typeof index === 'number') {
				controller.goToMatch(index);
				inputBox.hide();
			} else {
				inputBox.validationMessage = localize(controller.getState().matchesCount);
			}
		});
		inputBox.onDidHide(() => {
			this.clearDecorations(editor2);
			inputBox.dispose();
		});
		inputBox.show();
	}
	clearDecorations(editor2) {
		editor2.changeDecorations(changeAccessor => {
			this._highlightDecorations = changeAccessor.deltaDecorations(this._highlightDecorations, []);
		});
	}
	addDecorations(editor2, range2) {
		editor2.changeDecorations(changeAccessor => {
			this._highlightDecorations = changeAccessor.deltaDecorations(this._highlightDecorations, [
				{
					range: range2,
					options: {
						description: 'find-match-quick-access-range-highlight',
						className: 'rangeHighlight',
						isWholeLine: true
					}
				},
				{
					range: range2,
					options: {
						description: 'find-match-quick-access-range-highlight-overview',
						overviewRuler: {
							color: {
								id: colorId_overviewRuler_highlight_range_foreground
							},
							position: OverviewRulerLane2.Full
						}
					}
				}
			]);
		});
	}
}
registerEditorAction(MoveToMatchFindAction);

class SelectionMatchFindAction extends EditorAction {
	async run(accessor, editor2) {
		const controller = CommonFindController.get(editor2);
		if (!controller) {
			return;
		}
		const selectionSearchString = getSelectionSearchString(editor2, 'single', false);
		if (selectionSearchString) {
			controller.setSearchString(selectionSearchString);
		}
		if (!this._run(controller)) {
			await controller.start({
				forceRevealReplace: false,
				seedSearchStringFromSelection: 'none',
				seedSearchStringFromNonEmptySelection: false,
				seedSearchStringFromGlobalClipboard: false,
				shouldFocus: 0,
				shouldAnimate: true,
				updateSearchScope: false,
				loop: editor2.getOption(
					41 // find
				).loop
			});
			this._run(controller);
		}
	}
}
class NextSelectionMatchFindAction extends SelectionMatchFindAction {
	constructor() {
		super({
			id: FIND_IDS.NextSelectionMatchFindAction,
			label: localize('Find Next EditorSelection'),
			alias: 'Find Next EditorSelection',
			kbOpts: {
				kbExpr: ck_editorFocus,
				primary: 2048 | 61,
				weight: 100 //editorContrib
			}
		});
	}
	_run(controller) {
		return controller.moveToNextMatch();
	}
}
registerEditorAction(NextSelectionMatchFindAction);

class PreviousSelectionMatchFindAction extends SelectionMatchFindAction {
	constructor() {
		super({
			id: FIND_IDS.PreviousSelectionMatchFindAction,
			label: localize('Find Previous EditorSelection'),
			alias: 'Find Previous EditorSelection',
			kbOpts: {
				kbExpr: ck_editorFocus,
				primary: 2048 | 1024 | 61,
				weight: 100 //editorContrib
			}
		});
	}
	_run(controller) {
		return controller.moveToPrevMatch();
	}
}
registerEditorAction(PreviousSelectionMatchFindAction);



const StartFindAction = registerMultiEditorAction(
	new MultiEditorAction({
		id: FIND_IDS.StartFindAction,
		label: localize('Find'),
		alias: 'Find',
		precondition: ContextKeyExpr.or(ck_editorFocus, ContextKeyExpr.has('editorIsOpen')),
		kbOpts: {
			kbExpr: null,
			primary: 2048 | 36,
			weight: 100 // EditorContrib
		},
		menuOpts: {
			menuId: menubarEditMenu_menuId,
			group: '3_find',
			title: localize('&&Find'),
			order: 1
		}
	})
);
StartFindAction.addImplementation(0, (accessor, editor2, args) => {
	const controller = CommonFindController.get(editor2);
	if (!controller) {
		return false;
	}
	return controller.start({
		forceRevealReplace: false,
		seedSearchStringFromSelection:
			editor2.getOption(
				41 // find
			).seedSearchStringFromSelection !== 'never'
				? 'single'
				: 'none',
		seedSearchStringFromNonEmptySelection:
			editor2.getOption(
				41 // find
			).seedSearchStringFromSelection === 'selection',
		seedSearchStringFromGlobalClipboard: editor2.getOption(
			41 // find
		).globalFindClipboard,
		shouldFocus: 1,
		shouldAnimate: true,
		updateSearchScope: false,
		loop: editor2.getOption(
			41 // find
		).loop
	});
});


const StartFindReplaceAction = registerMultiEditorAction(
	new MultiEditorAction({
		id: FIND_IDS.StartFindReplaceAction,
		label: localize('Replace'),
		alias: 'Replace',
		precondition: ContextKeyExpr.or(ck_editorFocus, ContextKeyExpr.has('editorIsOpen')),
		kbOpts: {
			kbExpr: null,
			primary: 2048 | 38,
			mac: {
				primary: 2048 | 512 | 36 // KeyF
			},
			weight: 100 // /KeybindingWeight.EditorContrib
		},
		menuOpts: {
			menuId: menubarEditMenu_menuId,
			group: '3_find',
			title: localize('&&Replace'),
			order: 2
		}
	})
);
StartFindReplaceAction.addImplementation(0, (accessor, editor2, args) => {
	if (
		!editor2.hasModel() ||
		editor2.getOption(
			91 // readOnly
		)
	) {
		return false;
	}
	const controller = CommonFindController.get(editor2);
	if (!controller) {
		return false;
	}
	const currentSelection = editor2.getSelection();
	const findInputFocused = controller.isFindInputFocused();
	const seedSearchStringFromSelection =
		!currentSelection.isEmpty() &&
		currentSelection.startLineNumber === currentSelection.endLineNumber &&
		editor2.getOption(
			41 // find
		).seedSearchStringFromSelection !== 'never' &&
		!findInputFocused;
	const shouldFocus = findInputFocused || seedSearchStringFromSelection ? 2 : 1;
	return controller.start({
		forceRevealReplace: true,
		seedSearchStringFromSelection: seedSearchStringFromSelection ? 'single' : 'none',
		seedSearchStringFromNonEmptySelection:
			editor2.getOption(
				41 // find
			).seedSearchStringFromSelection === 'selection',
		seedSearchStringFromGlobalClipboard:
			editor2.getOption(
				41 // find
			).seedSearchStringFromSelection !== 'never',
		shouldFocus,
		shouldAnimate: true,
		updateSearchScope: false,
		loop: editor2.getOption(
			41 // find
		).loop
	});
});
registerEditorContribution(
	commonFindController_id,
	FindController2,
	0 // Eager
);

const FindCommand = EditorCommand.bindToContribution(CommonFindController.get);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.CloseFindWidgetCommand,
		precondition: ck_findWidgetVisible,
		handler: x => x.closeFindWidget(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ContextKeyExpr.and(ck_editorFocus, ContextKeyExpr.not('isComposing')),
			primary: 9,
			secondary: [
				1024 | 9 // /Escape
			]
		}
	})
);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.ToggleCaseSensitiveCommand,
		handler: x => x.toggleCaseSensitive(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ck_editorFocus,
			primary: ToggleCaseSensitiveKeybinding.primary,
			mac: ToggleCaseSensitiveKeybinding.mac,
			win: ToggleCaseSensitiveKeybinding.win,
			linux: ToggleCaseSensitiveKeybinding.linux
		}
	})
);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.ToggleWholeWordCommand,
		handler: x => x.toggleWholeWords(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ck_editorFocus,
			primary: ToggleWholeWordKeybinding.primary,
			mac: ToggleWholeWordKeybinding.mac,
			win: ToggleWholeWordKeybinding.win,
			linux: ToggleWholeWordKeybinding.linux
		}
	})
);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.ToggleRegexCommand,
		handler: x => x.toggleRegex(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ck_editorFocus,
			primary: ToggleRegexKeybinding.primary,
			mac: ToggleRegexKeybinding.mac,
			win: ToggleRegexKeybinding.win,
			linux: ToggleRegexKeybinding.linux
		}
	})
);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.ToggleSearchScopeCommand,
		handler: x => x.toggleSearchScope(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ck_editorFocus,
			primary: ToggleSearchScopeKeybinding.primary,
			mac: ToggleSearchScopeKeybinding.mac,
			win: ToggleSearchScopeKeybinding.win,
			linux: ToggleSearchScopeKeybinding.linux
		}
	})
);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.TogglePreserveCaseCommand,
		handler: x => x.togglePreserveCase(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ck_editorFocus,
			primary: TogglePreserveCaseKeybinding.primary,
			mac: TogglePreserveCaseKeybinding.mac,
			win: TogglePreserveCaseKeybinding.win,
			linux: TogglePreserveCaseKeybinding.linux
		}
	})
);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.ReplaceOneAction,
		precondition: ck_findWidgetVisible,
		handler: x => x.replace(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ck_editorFocus,
			primary: 2048 | 1024 | 22 // Digit1
		}
	})
);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.ReplaceOneAction,
		precondition: ck_findWidgetVisible,
		handler: x => x.replace(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ContextKeyExpr.and(ck_editorFocus, ck_replaceInputFocussed),
			primary: 3 // /Enter
		}
	})
);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.ReplaceAllAction,
		precondition: ck_findWidgetVisible,
		handler: x => x.replaceAll(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ck_editorFocus,
			primary: 2048 | 512 | 3 // Enter
		}
	})
);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.ReplaceAllAction,
		precondition: ck_findWidgetVisible,
		handler: x => x.replaceAll(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ContextKeyExpr.and(ck_editorFocus, ck_replaceInputFocussed),
			primary: undefined,
			mac: { primary: 2048 | 3 }
		}
	})
);
registerEditorCommand(
	new FindCommand({
		id: FIND_IDS.SelectAllMatchesAction,
		precondition: ck_findWidgetVisible,
		handler: x => x.selectAllMatches(),
		kbOpts: {
			weight: 100 + 5,
			kbExpr: ck_editorFocus,
			primary: 512 | 3 // Enter
		}
	})
);
