registerEditorContribution(
	copyPasteController_id,
	CopyPasteController,
	0 // Eager
);

class PasteHtmlProvider {
	constructor() {
		this.kind = new HierarchicalKind('html');
		this.pasteMimeTypes = ['text/html'];
		this._yieldTo = [{ mimeType: 'text/plain' }];
	}
	async provideDocumentPasteEdits(_model, _ranges, dataTransfer, context, token) {
		if (
			context.triggerKind !== 1 && //PasteAs
			!context.only?.contains(this.kind)
		) {
			return;
		}
		const entry = dataTransfer.get('text/html');
		const htmlText = await entry?.asString();
		if (!htmlText || token.isCancellationRequested) {
			return;
		}
		return {
			dispose() {},
			edits: [
				{
					insertText: htmlText,
					yieldTo: this._yieldTo,
					title: localize('Insert HTML'),
					kind: this.kind
				}
			]
		};
	}
}

class DefaultPasteProvidersFeature extends Disposable {
	constructor(languageFeaturesService, workspaceContextService) {
		super();
		this._register(languageFeaturesService.documentPasteEditProvider.register('*', new DefaultTextPasteOrDropEditProvider()));
		this._register(languageFeaturesService.documentPasteEditProvider.register('*', new PathProvider()));
		this._register(languageFeaturesService.documentPasteEditProvider.register('*', new RelativePathProvider(workspaceContextService)));
		this._register(languageFeaturesService.documentPasteEditProvider.register('*', new PasteHtmlProvider()));
	}
}
__decorate(
	[
		__param(0, ILanguageFeaturesService),
		__param(1, IWorkspaceContextService)
		//...
	],
	DefaultPasteProvidersFeature
);
registerEditorFeature(DefaultPasteProvidersFeature);

class ChangePasteTypeCmd extends EditorCommand {
	constructor() {
		super({
			id: changePasteTypeCommand_id,
			precondition: ck_pasteWidgetVisible,
			kbOpts: {
				weight: 100,
				primary: 2048 | 89
			}
		});
	}
	runEditorCommand(_accessor, editor) {
		return CopyPasteController.get(editor)?.changePasteType();
	}
}
registerEditorCommand(new ChangePasteTypeCmd());

class HidePasteWidgetCmd extends EditorCommand {
	constructor() {
		super({
			id: 'editor.hidePasteWidget',
			precondition: ck_pasteWidgetVisible,
			kbOpts: { weight: 100, primary: 9 }
		});
	}
	runEditorCommand(_accessor, editor) {
		CopyPasteController.get(editor)?.clearWidgets();
	}
}
registerEditorCommand(new HidePasteWidgetCmd());

class PasteAsTextAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.pasteAsText',
			label: localize('Paste as Text'),
			alias: 'Paste as Text',
			precondition: ck_writable
		});
	}
	run(_accessor, editor) {
		return CopyPasteController.get(editor)?.pasteAs({
			providerId: DefaultTextPasteOrDropEditProvider.id
		});
	}
}
registerEditorAction(PasteAsTextAction);

class PasteAsAction extends EditorAction {
	constructor() {
		super({
			id: 'editor.action.pasteAs',
			label: localize('Paste As...'),
			alias: 'Paste As...',
			precondition: ck_writable,
			metadata: {
				description: 'Paste as',
				args: [
					{
						name: 'args',
						schema: {
							type: 'object',
							properties: {
								kind: {
									type: 'string'
								}
							}
						}
					}
				]
			}
		});
	}
	run(_accessor, editor, args) {
		let kind = typeof args?.kind === 'string' ? args.kind : undefined;
		if (!kind && args) {
			kind = typeof args.id === 'string' ? args.id : undefined;
		}
		return CopyPasteController.get(editor)?.pasteAs(kind ? new HierarchicalKind(kind) : undefined);
	}
}
registerEditorAction(PasteAsAction);