



// node_modules/monaco-editor/esm/vs/editor/contrib/inlineEdit/browser/commandIds.js
var inlineEditAcceptId = 'editor.action.inlineEdit.accept';
var inlineEditRejectId = 'editor.action.inlineEdit.reject';
var inlineEditJumpToId = 'editor.action.inlineEdit.jumpTo';
var inlineEditJumpBackId = 'editor.action.inlineEdit.jumpBack';
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


class GhostTextWidget3 extends Disposable {
	constructor(editor2, model, languageService) {
		super();
		this.editor = editor2;
		this.model = model;
		this.languageService = languageService;
		this.isDisposed = observableValue(this, false);
		this.currentTextModel = observableFromEvent(this.editor.onDidChangeModel, () => this.editor.getModel());
		this.uiState = derived(this, reader => {
			if (this.isDisposed.read(reader)) {
				return;
			}
			const textModel = this.currentTextModel.read(reader);
			if (textModel !== this.model.targetTextModel.read(reader)) {
				return;
			}
			const ghostText = this.model.ghostText.read(reader);
			if (!ghostText) {
				return;
			}
			let range2 = this.model.range?.read(reader);
			if (range2 && range2.startLineNumber === range2.endLineNumber && range2.startColumn === range2.endColumn) {
				range2 = undefined;
			}
			const isSingleLine =
				(range2 ? range2.startLineNumber === range2.endLineNumber : true) &&
				ghostText.parts.length === 1 &&
				ghostText.parts[0].lines.length === 1;
			const isPureRemove = ghostText.parts.length === 1 && ghostText.parts[0].lines.every(l => l.length === 0);
			const inlineTexts = [];
			const additionalLines = [];
			const addToAdditionalLines = (lines, className) => {
				if (additionalLines.length > 0) {
					const lastLine = additionalLines[additionalLines.length - 1];
					if (className) {
						lastLine.decorations.push(
							new LineDecoration(
								lastLine.content.length + 1,
								lastLine.content.length + 1 + lines[0].length,
								className,
								0
								/* InlineDecorationType.Regular */
							)
						);
					}
					lastLine.content += lines[0];
					lines = lines.slice(1);
				}
				for (const line of lines) {
					additionalLines.push({
						content: line,
						decorations: className
							? [
									new LineDecoration(
										1,
										line.length + 1,
										className,
										0
										/* InlineDecorationType.Regular */
									)
								]
							: []
					});
				}
			};
			const textBufferLine = textModel.getLineContent(ghostText.lineNumber);
			let hiddenTextStartColumn = undefined;
			let lastIdx = 0;
			if (!isPureRemove) {
				for (const part of ghostText.parts) {
					let lines = part.lines;
					if (range2 && !isSingleLine) {
						addToAdditionalLines(lines, 'inline-edit');
						lines = [];
					}
					if (hiddenTextStartColumn === undefined) {
						inlineTexts.push({
							column: part.column,
							text: lines[0],
							preview: part.preview
						});
						lines = lines.slice(1);
					} else {
						addToAdditionalLines([textBufferLine.substring(lastIdx, part.column - 1)], undefined);
					}
					if (lines.length > 0) {
						addToAdditionalLines(lines, 'inline-edit');
						if (hiddenTextStartColumn === undefined && part.column <= textBufferLine.length) {
							hiddenTextStartColumn = part.column;
						}
					}
					lastIdx = part.column - 1;
				}
				if (hiddenTextStartColumn !== undefined) {
					addToAdditionalLines([textBufferLine.substring(lastIdx)], undefined);
				}
			}
			const hiddenRange =
				hiddenTextStartColumn !== undefined ? new ColumnRange(hiddenTextStartColumn, textBufferLine.length + 1) : undefined;
			const lineNumber = isSingleLine || !range2 ? ghostText.lineNumber : range2.endLineNumber - 1;
			return {
				inlineTexts,
				additionalLines,
				hiddenRange,
				lineNumber,
				additionalReservedLineCount: this.model.minReservedLineCount.read(reader),
				targetTextModel: textModel,
				range: range2,
				isSingleLine,
				isPureRemove,
				backgroundColoring: this.model.backgroundColoring.read(reader)
			};
		});
		this.decorations = derived(this, reader => {
			const uiState = this.uiState.read(reader);
			if (!uiState) {
				return [];
			}
			const decorations = [];
			if (uiState.hiddenRange) {
				decorations.push({
					range: uiState.hiddenRange.toRange(uiState.lineNumber),
					options: { inlineClassName: 'inline-edit-hidden', description: 'inline-edit-hidden' }
				});
			}
			if (uiState.range) {
				const ranges = [];
				if (uiState.isSingleLine) {
					ranges.push(uiState.range);
				} else if (uiState.isPureRemove) {
					const lines = uiState.range.endLineNumber - uiState.range.startLineNumber;
					for (let i = 0; i < lines; i++) {
						const line = uiState.range.startLineNumber + i;
						const firstNonWhitespace = uiState.targetTextModel.getLineFirstNonWhitespaceColumn(line);
						const lastNonWhitespace = uiState.targetTextModel.getLineLastNonWhitespaceColumn(line);
						const range2 = new Range(line, firstNonWhitespace, line, lastNonWhitespace);
						ranges.push(range2);
					}
				} else {
					const lines = uiState.range.endLineNumber - uiState.range.startLineNumber;
					for (let i = 0; i < lines; i++) {
						const line = uiState.range.startLineNumber + i;
						const firstNonWhitespace = uiState.targetTextModel.getLineFirstNonWhitespaceColumn(line);
						const lastNonWhitespace = uiState.targetTextModel.getLineLastNonWhitespaceColumn(line);
						const range2 = new Range(line, firstNonWhitespace, line, lastNonWhitespace);
						ranges.push(range2);
					}
				}
				const className = uiState.backgroundColoring ? 'inline-edit-remove backgroundColoring' : 'inline-edit-remove';
				for (const range2 of ranges) {
					decorations.push({
						range: range2,
						options: { inlineClassName: className, description: 'inline-edit-remove' }
					});
				}
			}
			for (const p of uiState.inlineTexts) {
				decorations.push({
					range: Range.fromPositions(new Position(uiState.lineNumber, p.column)),
					options: {
						description: 'inline-edit',
						after: {
							content: p.text,
							inlineClassName: p.preview ? 'inline-edit-decoration-preview' : 'inline-edit-decoration',
							cursorStops: InjectedTextCursorStops2.Left
						},
						showIfCollapsed: true
					}
				});
			}
			return decorations;
		});
		this.additionalLinesWidget = this._register(
			new AdditionalLinesWidget(
				this.editor,
				this.languageService.languageIdCodec,
				derived(reader => {
					const uiState = this.uiState.read(reader);
					return uiState && !uiState.isPureRemove
						? {
								lineNumber: uiState.lineNumber,
								additionalLines: uiState.additionalLines,
								minReservedLineCount: uiState.additionalReservedLineCount,
								targetTextModel: uiState.targetTextModel
							}
						: undefined;
				})
			)
		);
		this._register(
			toDisposable(() => {
				this.isDisposed.set(true, undefined);
			})
		);
		this._register(applyObservableDecorations2(this.editor, this.decorations));
	}
	ownsViewZone(viewZoneId) {
		return this.additionalLinesWidget.viewZoneId === viewZoneId;
	}
}
__decorate([__param(2, ILanguageService)], GhostTextWidget3);


class InlineEditHintsWidget extends Disposable {
	constructor(editor2, model, instantiationService) {
		super();
		this.editor = editor2;
		this.model = model;
		this.instantiationService = instantiationService;
		this.alwaysShowToolbar = observableFromEvent(
			this.editor.onDidChangeConfiguration,
			() =>
				this.editor.getOption(
					63
					// inlineEdit
				).showToolbar === 'always'
		);
		this.sessionPosition = undefined;
		this.position = derived(this, reader => {
			const ghostText = this.model.read(reader)?.widget.model.ghostText.read(reader);
			if (!this.alwaysShowToolbar.read(reader) || !ghostText || ghostText.parts.length === 0) {
				this.sessionPosition = undefined;
				return null;
			}
			const firstColumn = ghostText.parts[0].column;
			if (this.sessionPosition && this.sessionPosition.lineNumber !== ghostText.lineNumber) {
				this.sessionPosition = undefined;
			}
			const position = new Position(
				ghostText.lineNumber,
				Math.min(firstColumn, this.sessionPosition?.column ?? Number.MAX_SAFE_INTEGER)
			);
			this.sessionPosition = position;
			return position;
		});
		this._register(
			autorunWithStore((reader, store) => {
				const model2 = this.model.read(reader);
				if (!model2 || !this.alwaysShowToolbar.read(reader)) {
					return;
				}
				const contentWidget = store.add(
					this.instantiationService.createInstance(InlineEditHintsContentWidget, this.editor, true, this.position)
				);
				editor2.addContentWidget(contentWidget);
				store.add(toDisposable(() => editor2.removeContentWidget(contentWidget)));
			})
		);
	}
}
__decorate([__param(2, IInstantiationService)], InlineEditHintsWidget);

InlineEditHintsContentWidget.id = -1;
class InlineEditHintsContentWidget extends Disposable {
	constructor(editor2, withBorder, _position, instantiationService, _contextKeyService, _menuService) {
		super();
		this.editor = editor2;
		this.withBorder = withBorder;
		this._position = _position;
		this._contextKeyService = _contextKeyService;
		this._menuService = _menuService;
		this.id = `InlineEditHintsContentWidget${++InlineEditHintsContentWidget.id}`;
		this.allowEditorOverflow = true;
		this.suppressMouseDown = false;
		this.nodes = h('div.inlineEditHints', { className: this.withBorder ? '.withBorder' : '' }, [h('div@toolBar')]);
		this.inlineCompletionsActionsMenus = this._register(
			this._menuService.createMenu(MenuId.InlineEditActions, this._contextKeyService)
		);
		this.toolBar = this._register(
			instantiationService.createInstance(
				CustomizedMenuWorkbenchToolBar3,
				this.nodes.toolBar,
				this.editor,
				MenuId.InlineEditToolbar,
				{
					menuOptions: { renderShortTitle: true },
					toolbarOptions: { primaryGroup: g => g.startsWith('primary') },
					actionViewItemProvider: action => {
						if (action instanceof MenuItemAction) {
							return instantiationService.createInstance(StatusBarViewItem3, action, undefined);
						}
					}
				}
			)
		);
		this._register(
			this.toolBar.onDidChangeDropdownVisibility(e => {
				InlineEditHintsContentWidget._dropDownVisible = e;
			})
		);
		this._register(
			autorun(reader => {
				this._position.read(reader);
				this.editor.layoutContentWidget(this);
			})
		);
		this._register(
			autorun(() => {
				const extraActions = [];
				for (const [_, group] of this.inlineCompletionsActionsMenus.getActions()) {
					for (const action of group) {
						if (action instanceof MenuItemAction) {
							extraActions.push(action);
						}
					}
				}
				if (extraActions.length > 0) {
					extraActions.unshift(new Separator());
				}
				this.toolBar.setAdditionalSecondaryActions(extraActions);
			})
		);
	}
	getId() {
		return this.id;
	}
	getDomNode() {
		return this.nodes.root;
	}
	getPosition() {
		return {
			position: this._position.get(),
			preference: [
				1, 2
				// BELOW
			],
			positionAffinity: 3
		};
	}
}
InlineEditHintsContentWidget._dropDownVisible = false;

__decorate([__param(3, IInstantiationService), __param(4, IContextKeyService), __param(5, IMenuService)], InlineEditHintsContentWidget);

class StatusBarViewItem3 extends MenuEntryActionViewItem {
	updateLabel() {
		const kb = this._keybindingService.lookupKeybinding(this._action.id, this._contextKeyService);
		if (!kb) {
			return super.updateLabel();
		}
		if (this.label) {
			const div = h('div.keybinding').root;
			const k = this._register(new KeybindingLabel(div, OS, { disableTitle: true, ...unthemedKeybindingLabelOptions }));
			k.set(kb);
			this.label.textContent = this._action.label;
			this.label.appendChild(div);
			this.label.classList.add('inlineEditStatusBarItemLabel');
		}
	}
	updateTooltip() {}
}

class CustomizedMenuWorkbenchToolBar3 extends WorkbenchToolBar {
	constructor(
		container,
		editor2,
		menuId,
		options2,
		menuService,
		contextKeyService,
		contextMenuService,
		keybindingService,
		commandService
	) {
		super(
			container,
			{ resetMenu: menuId, ...options2 },
			menuService,
			contextKeyService,
			contextMenuService,
			keybindingService,
			commandService
		);
		this.editor = editor2;
		this.menuId = menuId;
		this.options2 = options2;
		this.menuService = menuService;
		this.contextKeyService = contextKeyService;
		this.menu = this._store.add(
			this.menuService.createMenu(this.menuId, this.contextKeyService, { emitEventsForSubmenuChanges: true })
		);
		this.additionalActions = [];
		this.prependedPrimaryActions = [];
		this._store.add(this.menu.onDidChange(() => this.updateToolbar()));
		this._store.add(this.editor.onDidChangeCursorPosition(() => this.updateToolbar()));
		this.updateToolbar();
	}
	updateToolbar() {
		const primary = [];
		const secondary = [];
		createAndFillInActionBarActions(
			this.menu,
			this.options2?.menuOptions,
			{ primary, secondary },
			this.options2?.toolbarOptions?.primaryGroup,
			this.options2?.toolbarOptions?.shouldInlineSubmenu,
			this.options2?.toolbarOptions?.useSeparatorsInPrimaryActions
		);
		secondary.push(...this.additionalActions);
		primary.unshift(...this.prependedPrimaryActions);
		this.setActions(primary, secondary);
	}
	setAdditionalSecondaryActions(actions) {
		if (equals(this.additionalActions, actions, (a, b) => a === b)) {
			return;
		}
		this.additionalActions = actions;
		this.updateToolbar();
	}
}
__decorate(
	[
		__param(4, IMenuService),
		__param(5, IContextKeyService),
		__param(6, IContextMenuService),
		__param(7, IKeybindingService),
		__param(8, ICommandService)
	],
	CustomizedMenuWorkbenchToolBar3
);


class InlineEditWidget {
	constructor(widget, edit) {
		this.widget = widget;
		this.edit = edit;
	}
	dispose() {
		this.widget.dispose();
	}
}
class InlineEditController extends Disposable {
	static get(editor2) {
		return editor2.getContribution(InlineEditController.ID);
	}
	constructor(editor2, instantiationService, contextKeyService, languageFeaturesService, _commandService, _configurationService) {
		super();
		this.editor = editor2;
		this.instantiationService = instantiationService;
		this.contextKeyService = contextKeyService;
		this.languageFeaturesService = languageFeaturesService;
		this._commandService = _commandService;
		this._configurationService = _configurationService;
		this._isVisibleContext = InlineEditController.inlineEditVisibleContext.bindTo(this.contextKeyService);
		this._isCursorAtInlineEditContext = InlineEditController.cursorAtInlineEditContext.bindTo(this.contextKeyService);
		this._currentEdit = this._register(disposableObservableValue(this, undefined));
		this._isAccepting = observableValue(this, false);
		this._enabled = observableFromEvent(
			this.editor.onDidChangeConfiguration,
			() =>
				this.editor.getOption(
					63
					// inlineEdit
				).enabled
		);
		this._fontFamily = observableFromEvent(
			this.editor.onDidChangeConfiguration,
			() =>
				this.editor.getOption(
					63
					// inlineEdit
				).fontFamily
		);
		this._backgroundColoring = observableFromEvent(
			this.editor.onDidChangeConfiguration,
			() =>
				this.editor.getOption(
					63
					// inlineEdit
				).backgroundColoring
		);
		const modelChangedSignal = observableSignalFromEvent(
			'InlineEditController.modelContentChangedSignal',
			editor2.onDidChangeModelContent
		);
		this._register(
			autorun(reader => {
				if (!this._enabled.read(reader)) {
					return;
				}
				modelChangedSignal.read(reader);
				if (this._isAccepting.read(reader)) {
					return;
				}
				this.getInlineEdit(editor2, true);
			})
		);
		const cursorPosition = observableFromEvent(editor2.onDidChangeCursorPosition, () => editor2.getPosition());
		this._register(
			autorun(reader => {
				if (!this._enabled.read(reader)) {
					return;
				}
				const pos = cursorPosition.read(reader);
				if (pos) {
					this.checkCursorPosition(pos);
				}
			})
		);
		this._register(
			autorun(reader => {
				const currentEdit = this._currentEdit.read(reader);
				this._isCursorAtInlineEditContext.set(false);
				if (!currentEdit) {
					this._isVisibleContext.set(false);
					return;
				}
				this._isVisibleContext.set(true);
				const pos = editor2.getPosition();
				if (pos) {
					this.checkCursorPosition(pos);
				}
			})
		);
		const editorBlurSingal = observableSignalFromEvent('InlineEditController.editorBlurSignal', editor2.onDidBlurEditorWidget);
		this._register(
			autorun(async reader => {
				if (!this._enabled.read(reader)) {
					return;
				}
				editorBlurSingal.read(reader);
				if (
					this._configurationService.getValue('editor.experimentalInlineEdit.keepOnBlur') ||
					editor2.getOption(
						63
						// inlineEdit
					).keepOnBlur
				) {
					return;
				}
				this._currentRequestCts?.dispose(true);
				this._currentRequestCts = undefined;
				await this.clear(false);
			})
		);
		const editorFocusSignal = observableSignalFromEvent('InlineEditController.editorFocusSignal', editor2.onDidFocusEditorText);
		this._register(
			autorun(reader => {
				if (!this._enabled.read(reader)) {
					return;
				}
				editorFocusSignal.read(reader);
				this.getInlineEdit(editor2, true);
			})
		);
		const styleElement = this._register(createStyleSheet2());
		this._register(
			autorun(reader => {
				const fontFamily = this._fontFamily.read(reader);
				styleElement.setStyle(
					fontFamily === '' || fontFamily === 'default'
						? ``
						: `
.monaco-editor .inline-edit-decoration,
.monaco-editor .inline-edit-decoration-preview,
.monaco-editor .inline-edit {
	font-family: ${fontFamily};
}`
				);
			})
		);
		this._register(new InlineEditHintsWidget(this.editor, this._currentEdit, this.instantiationService));
	}
	checkCursorPosition(position) {
		if (!this._currentEdit) {
			this._isCursorAtInlineEditContext.set(false);
			return;
		}
		const gt = this._currentEdit.get()?.edit;
		if (!gt) {
			this._isCursorAtInlineEditContext.set(false);
			return;
		}
		this._isCursorAtInlineEditContext.set(Range.containsPosition(gt.range, position));
	}
	validateInlineEdit(editor2, edit) {
		if (
			edit.text.includes('\n') &&
			edit.range.startLineNumber !== edit.range.endLineNumber &&
			edit.range.startColumn !== edit.range.endColumn
		) {
			const firstColumn = edit.range.startColumn;
			if (firstColumn !== 1) {
				return false;
			}
			const lastLine = edit.range.endLineNumber;
			const lastColumn = edit.range.endColumn;

			const lineLength = editor2.getModel()?.getLineLength(lastLine) ?? 0;
			if (lastColumn !== lineLength + 1) {
				return false;
			}
		}
		return true;
	}
	async fetchInlineEdit(editor2, auto) {
		if (this._currentRequestCts) {
			this._currentRequestCts.dispose(true);
		}
		const model = editor2.getModel();
		if (!model) {
			return;
		}
		const modelVersion = model.getVersionId();
		const providers = this.languageFeaturesService.inlineEditProvider.all(model);
		if (providers.length === 0) {
			return;
		}
		const provider = providers[0];
		this._currentRequestCts = new CancellationTokenSource();
		const token = this._currentRequestCts.token;
		const triggerKind = auto
			? 1 //Automatic
			: 0; //Invoke
		if (auto) {
			await wait2(50, token);
		}
		if (token.isCancellationRequested || model.isDisposed() || model.getVersionId() !== modelVersion) {
			return;
		}
		const edit = await provider.provideInlineEdit(model, { triggerKind }, token);
		if (!edit) {
			return;
		}
		if (token.isCancellationRequested || model.isDisposed() || model.getVersionId() !== modelVersion) {
			return;
		}
		if (!this.validateInlineEdit(editor2, edit)) {
			return;
		}
		return edit;
	}
	async getInlineEdit(editor2, auto) {
		this._isCursorAtInlineEditContext.set(false);
		await this.clear();
		const edit = await this.fetchInlineEdit(editor2, auto);
		if (!edit) {
			return;
		}
		const line = edit.range.endLineNumber;
		const column = edit.range.endColumn;
		const textToDisplay =
			edit.text.endsWith('\n') &&
			!(edit.range.startLineNumber === edit.range.endLineNumber && edit.range.startColumn === edit.range.endColumn)
				? edit.text.slice(0, -1)
				: edit.text;
		const ghostText = new GhostText(line, [new GhostTextPart(column, textToDisplay, false)]);
		const instance = this.instantiationService.createInstance(GhostTextWidget3, this.editor, {
			ghostText: constObservable(ghostText),
			minReservedLineCount: constObservable(0),
			targetTextModel: constObservable(this.editor.getModel()),
			range: constObservable(edit.range),
			backgroundColoring: this._backgroundColoring
		});
		this._currentEdit.set(new InlineEditWidget(instance, edit), undefined);
	}
	async trigger() {
		await this.getInlineEdit(this.editor, false);
	}
	async jumpBack() {
		if (!this._jumpBackPosition) {
			return;
		}
		this.editor.setPosition(this._jumpBackPosition);
		this.editor.revealPositionInCenterIfOutsideViewport(this._jumpBackPosition);
	}
	async accept() {
		this._isAccepting.set(true, undefined);
		const data = this._currentEdit.get()?.edit;
		if (!data) {
			return;
		}
		let text2 = data.text;
		if (data.text.startsWith('\n')) {
			text2 = data.text.substring(1);
		}
		this.editor.pushUndoStop();
		this.editor.executeEdits('acceptCurrent', [EditOperation.replace(Range.lift(data.range), text2)]);
		if (data.accepted) {
			await this._commandService
				.executeCommand(data.accepted.id, ...(data.accepted.arguments || []))
				.then(undefined, onUnexpectedExternalError);
		}
		this.freeEdit(data);
		transaction(tx => {
			this._currentEdit.set(undefined, tx);
			this._isAccepting.set(false, tx);
		});
	}
	jumpToCurrent() {
		this._jumpBackPosition = this.editor.getSelection()?.getStartPosition();

		const data = this._currentEdit.get()?.edit;
		if (data) {
			const position = Position.lift({ lineNumber: data.range.startLineNumber, column: data.range.startColumn });
			this.editor.setPosition(position);
			this.editor.revealPositionInCenterIfOutsideViewport(position);
		}
	}
	async clear(sendRejection = true) {
		const edit = this._currentEdit.get()?.edit;
		if (edit && edit?.rejected && sendRejection) {
			await this._commandService
				.executeCommand(edit.rejected.id, ...(edit.rejected.arguments || []))
				.then(undefined, onUnexpectedExternalError);
		}
		if (edit) {
			this.freeEdit(edit);
		}
		this._currentEdit.set(undefined, undefined);
	}
	freeEdit(edit) {
		const model = this.editor.getModel();
		if (!model) {
			return;
		}
		const providers = this.languageFeaturesService.inlineEditProvider.all(model);
		if (providers.length === 0) {
			return;
		}
		providers[0].freeInlineEdit(edit);
	}
	shouldShowHoverAt(range2) {
		const currentEdit = this._currentEdit.get();
		if (!currentEdit) {
			return false;
		}
		const edit = currentEdit.edit;
		const model = currentEdit.widget.model;
		const overReplaceRange =
			Range.containsPosition(edit.range, range2.getStartPosition()) || Range.containsPosition(edit.range, range2.getEndPosition());
		if (overReplaceRange) {
			return true;
		}
		const ghostText = model.ghostText.get();
		if (ghostText) {
			return ghostText.parts.some(p => range2.containsPosition(new Position(ghostText.lineNumber, p.column)));
		}
		return false;
	}
	shouldShowHoverAtViewZone(viewZoneId) {
		return this._currentEdit.get()?.widget.ownsViewZone(viewZoneId) ?? false;
	}
}
InlineEditController.ID = 'editor.contrib.inlineEditController';
InlineEditController.inlineEditVisibleKey = 'inlineEditVisible';
InlineEditController.inlineEditVisibleContext = new RawContextKey(InlineEditController.inlineEditVisibleKey, false);
InlineEditController.cursorAtInlineEditKey = 'cursorAtInlineEdit';
InlineEditController.cursorAtInlineEditContext = new RawContextKey(InlineEditController.cursorAtInlineEditKey, false);
__decorate(
	[
		__param(1, IInstantiationService),
		__param(2, IContextKeyService),
		__param(3, ILanguageFeaturesService),
		__param(4, ICommandService),
		__param(5, IConfigurationService)
	],
	InlineEditController
);

function wait2(ms, cancellationToken) {
	return new Promise(resolve2 => {
		let d = undefined;
		const handle = setTimeout(() => {
			if (d) {
				d.dispose();
			}
			resolve2();
		}, ms);
		if (cancellationToken) {
			d = cancellationToken.onCancellationRequested(() => {
				clearTimeout(handle);
				if (d) {
					d.dispose();
				}
				resolve2();
			});
		}
	});
}

class AcceptInlineEdit extends EditorAction {
	constructor() {
		super({
			id: inlineEditAcceptId,
			label: 'Accept Inline Edit',
			alias: 'Accept Inline Edit',
			precondition: ContextKeyExpr.and(ctxKeys_writable, InlineEditController.inlineEditVisibleContext),
			kbOpts: [
				{
					weight: 100 + 1,
					primary: 2,
					kbExpr: ContextKeyExpr.and(
						ctxKeys_writable,
						InlineEditController.inlineEditVisibleContext,
						InlineEditController.cursorAtInlineEditContext
					)
				}
			],
			menuOpts: [
				{
					menuId: MenuId.InlineEditToolbar,
					title: 'Accept',
					group: 'primary',
					order: 1
				}
			]
		});
	}
	async run(accessor, editor2) {
		const controller = InlineEditController.get(editor2);
		await controller?.accept();
	}
}
registerEditorAction(AcceptInlineEdit);

class TriggerInlineEdit extends EditorAction {
	constructor() {
		const activeExpr = ContextKeyExpr.and(ctxKeys_writable, ContextKeyExpr.not(InlineEditController.inlineEditVisibleKey));
		super({
			id: 'editor.action.inlineEdit.trigger',
			label: 'Trigger Inline Edit',
			alias: 'Trigger Inline Edit',
			precondition: activeExpr,
			kbOpts: {
				weight: 100 + 1,
				primary: 2048 | 512 | 86,
				kbExpr: activeExpr
			}
		});
	}
	async run(accessor, editor2) {
		InlineEditController.get(editor2)?.trigger();
	}
}
registerEditorAction(TriggerInlineEdit);

class JumpToInlineEdit extends EditorAction {
	constructor() {
		const activeExpr = ContextKeyExpr.and(
			ctxKeys_writable,
			InlineEditController.inlineEditVisibleContext,
			ContextKeyExpr.not(InlineEditController.cursorAtInlineEditKey)
		);
		super({
			id: inlineEditJumpToId,
			label: 'Jump to Inline Edit',
			alias: 'Jump to Inline Edit',
			precondition: activeExpr,
			kbOpts: {
				weight: 100 + 1,
				primary: 2048 | 512 | 86,
				kbExpr: activeExpr
			},
			menuOpts: [
				{
					menuId: MenuId.InlineEditToolbar,
					title: 'Jump To Edit',
					group: 'primary',
					order: 3,
					when: activeExpr
				}
			]
		});
	}
	async run(accessor, editor) {
		InlineEditController.get(editor)?.jumpToCurrent();
	}
}
registerEditorAction(JumpToInlineEdit);

class JumpBackInlineEdit extends EditorAction {
	constructor() {
		const activeExpr = ContextKeyExpr.and(ctxKeys_writable, InlineEditController.cursorAtInlineEditContext);
		super({
			id: inlineEditJumpBackId,
			label: 'Jump Back from Inline Edit',
			alias: 'Jump Back from Inline Edit',
			precondition: activeExpr,
			kbOpts: {
				weight: 100 + 10,
				primary: 2048 | 512 | 86,
				kbExpr: activeExpr
			},
			menuOpts: [
				{
					menuId: MenuId.InlineEditToolbar,
					title: 'Jump Back',
					group: 'primary',
					order: 3,
					when: activeExpr
				}
			]
		});
	}
	async run(accessor, editor) {
		InlineEditController.get(editor)?.jumpBack();
	}
}
registerEditorAction(JumpBackInlineEdit);

class RejectInlineEdit extends EditorAction {
	constructor() {
		const activeExpr = ContextKeyExpr.and(ctxKeys_writable, InlineEditController.inlineEditVisibleContext);
		super({
			id: inlineEditRejectId,
			label: 'Reject Inline Edit',
			alias: 'Reject Inline Edit',
			precondition: activeExpr,
			kbOpts: {
				weight: 100,
				primary: 9,
				kbExpr: activeExpr
			},
			menuOpts: [
				{
					menuId: MenuId.InlineEditToolbar,
					title: 'Reject',
					group: 'secondary',
					order: 2
				}
			]
		});
	}
	async run(accessor, editor) {
		InlineEditController.get(editor)?.clear();
	}
}
registerEditorAction(RejectInlineEdit);

class InlineEditHover {
	constructor(owner, range2, controller) {
		this.owner = owner;
		this.range = range2;
		this.controller = controller;
	}
	isValidForHoverAnchor(anchor) {
		return anchor.type === 1 && this.range.startColumn <= anchor.range.startColumn && this.range.endColumn >= anchor.range.endColumn;
	}
}
class InlineEditHoverParticipant {
	constructor(_editor, _instantiationService) {
		this._editor = _editor;
		this._instantiationService = _instantiationService;

		this.hoverOrdinal = 5;
	}
	suggestHoverAnchor(mouseEvent) {
		const controller = InlineEditController.get(this._editor);
		if (!controller) {
			return null;
		}
		const target = mouseEvent.target;
		if (target.type === 8) {
			const viewZoneData = target.detail;
			if (controller.shouldShowHoverAtViewZone(viewZoneData.viewZoneId)) {
				const range2 = target.range;
				return new HoverForeignElementAnchor(1e3, this, range2, mouseEvent.event.posx, mouseEvent.event.posy, false);
			}
		}
		if (target.type === 7) {
			if (controller.shouldShowHoverAt(target.range)) {
				return new HoverForeignElementAnchor(1e3, this, target.range, mouseEvent.event.posx, mouseEvent.event.posy, false);
			}
		}
		if (target.type === 6) {
			const mightBeForeignElement = target.detail.mightBeForeignElement;
			if (mightBeForeignElement && controller.shouldShowHoverAt(target.range)) {
				return new HoverForeignElementAnchor(1e3, this, target.range, mouseEvent.event.posx, mouseEvent.event.posy, false);
			}
		}
		return null;
	}
	computeSync(anchor) {
		if (
			this._editor.getOption(
				63
				// inlineEdit
			).showToolbar !== 'onHover'
		) {
			return [];
		}
		const controller = InlineEditController.get(this._editor);
		if (controller && controller.shouldShowHoverAt(anchor.range)) {
			return [new InlineEditHover(this, anchor.range, controller)];
		}
		return [];
	}
	renderHoverParts(context) {
		const disposableStore = new DisposableStore();

		const w = this._instantiationService.createInstance(InlineEditHintsContentWidget, this._editor, false, constObservable(null));
		context.fragment.appendChild(w.getDomNode());
		disposableStore.add(w);
		return disposableStore;
	}
}
__decorate([__param(1, IInstantiationService)], InlineEditHoverParticipant);

registerEditorContribution(
	InlineEditController.ID,
	InlineEditController,
	3
	/* EditorContributionInstantiation.Eventually */
);
hoverParticipantRegistry.register(InlineEditHoverParticipant);

const Context3 = {
	Visible: new RawContextKey('parameterHintsVisible', false),
	MultipleSignatures: new RawContextKey('parameterHintsMultipleSignatures', false)
};
async function provideSignatureHelp(registry, model, position, context, token) {
	const supports = registry.ordered(model);
	for (const support of supports) {
		try {
			const result = await support.provideSignatureHelp(model, position, token, context);
			if (result) {
				return result;
			}
		} catch (err) {
			onUnexpectedExternalError(err);
		}
	}
}

commandsRegistry.registerCommand('_executeSignatureHelpProvider', async (accessor, uri, position, triggerCharacter) => {
	if ((typeof triggerCharacter === 'string' || !triggerCharacter) && URI.isUri(uri) && Position.isIPosition(position)) {
		const languageFeaturesService = accessor.get(ILanguageFeaturesService);
		const ref = await accessor.get(ITextModelService).createModelReference(uri);
		try {
			const result = await provideSignatureHelp(
				languageFeaturesService.signatureHelpProvider,
				ref.object.textEditorModel,
				Position.lift(position),
				{
					triggerKind: 1, //Invoke
					isRetrigger: false,
					triggerCharacter
				},
				cancellationToken_none
			);
			if (result) {
				setTimeout(result.dispose);
				return result.value;
			}
		} finally {
			ref.dispose();
		}
	}
});
