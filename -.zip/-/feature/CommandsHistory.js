let commandsHistoryCounter = 0;
let commandsHistoryHasChanges = false;

class CommandsHistory extends Disposable {
	constructor(storageService, configurationService) {
		super();
		this.storageService = storageService;
		this.configurationService = configurationService;
		this.configuredCommandsHistoryLength = 0;
		this.updateConfiguration();
		this.load();
		this.registerListeners();
	}
	registerListeners() {
		this._register(this.configurationService.onDidChangeConfiguration(e => this.updateConfiguration(e)));
		this._register(
			this.storageService.onWillSaveState(e => {
				if (1 === e.reason) {
					this.saveState();
				}
			})
		);
	}
	updateConfiguration(e) {
		this.configuredCommandsHistoryLength = 50;
		if (CommandsHistory.cache && CommandsHistory.cache.limit !== this.configuredCommandsHistoryLength) {
			CommandsHistory.cache.limit = this.configuredCommandsHistoryLength;
			commandsHistoryHasChanges = true;
		}
	}
	push(commandId) {
		if (CommandsHistory.cache) {
			CommandsHistory.cache.set(commandId, ++commandsHistoryCounter);
			commandsHistoryHasChanges = true;
		}
	}
	peek(commandId) {
		return CommandsHistory.cache?.peek(commandId);
	}
	saveState() {
		if (commandsHistoryHasChanges && CommandsHistory.cache) {
			const serializedCache = { usesLRU: true, entries: [] };
			CommandsHistory.cache.forEach((value, key) => serializedCache.entries.push({ key, value }));
			commandsHistoryHasChanges = false;
		}
	}
}

__decorate(
	[
		__param(0, IStorageService),
		__param(1, IConfigurationService)
		//...
	],
	CommandsHistory
);