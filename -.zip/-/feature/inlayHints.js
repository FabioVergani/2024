class InlayHintsCache {
	constructor() {
		this._entries = new LRUCache(50);
	}
	get(model) {
		const key = InlayHintsCache._key(model);
		return this._entries.get(key);
	}
	set(model, value) {
		const key = InlayHintsCache._key(model);
		this._entries.set(key, value);
	}
	static _key(model) {
		return `${model.uri.toString()}/${model.getVersionId()}`;
	}
}
var IInlayHintsCache = createEditorServiceDecorator('IInlayHintsCache');
registerSingleton(IInlayHintsCache, InlayHintsCache, 1 /* InstantiationType.Delayed */);
class RenderedInlayHintLabelPart {
	constructor(item, index) {
		this.item = item;
		this.index = index;
	}
	get part() {
		const label = this.item.hint.label;
		if (typeof label === 'string') {
			return { label };
		} else {
			return label[this.index];
		}
	}
}
class ActiveInlayHintInfo {
	constructor(part, hasTriggerModifier2) {
		this.part = part;
		this.hasTriggerModifier = hasTriggerModifier2;
	}
}
class InlayHintsController {
	static get(editor) {
		return editor.getContribution(InlayHintsController.ID);
	}
	constructor(
		_editor,
		_languageFeaturesService,
		_featureDebounce,
		_inlayHintsCache,
		_commandService,
		_notificationService,
		_instaService
	) {
		this._editor = _editor;
		this._languageFeaturesService = _languageFeaturesService;
		this._inlayHintsCache = _inlayHintsCache;
		this._commandService = _commandService;
		this._notificationService = _notificationService;
		this._instaService = _instaService;
		this._disposables = new DisposableStore();
		this._sessionDisposables = new DisposableStore();
		this._decorationsMetadata = new Map();
		this._ruleFactory = new DynamicCssRules(this._editor);
		this._activeRenderMode = 0;
		this._debounceInfo = _featureDebounce.for(_languageFeaturesService.inlayHintsProvider, 'InlayHint', { min: 25 });
		this._disposables.add(_languageFeaturesService.inlayHintsProvider.onDidChange(() => this._update()));
		this._disposables.add(_editor.onDidChangeModel(() => this._update()));
		this._disposables.add(_editor.onDidChangeModelLanguage(() => this._update()));
		this._disposables.add(
			_editor.onDidChangeConfiguration(e => {
				if (
					e.hasChanged(
						141 // inlayHints
					)
				) {
					this._update();
				}
			})
		);
		this._update();
	}
	dispose() {
		this._sessionDisposables.dispose();
		this._removeAllDecorations();
		this._disposables.dispose();
	}
	_update() {
		this._sessionDisposables.clear();
		this._removeAllDecorations();
		const options2 = this._editor.getOption(
			141 // inlayHints
		);
		if (options2.enabled === 'off') {
			return;
		}
		const model = this._editor.getModel();
		if (!model || !this._languageFeaturesService.inlayHintsProvider.has(model)) {
			return;
		}
		if (options2.enabled === 'on') {
			this._activeRenderMode = 0;
		} else {
			let defaultMode;
			let altMode;
			if (options2.enabled === 'onUnlessPressed') {
				defaultMode = 0;
				altMode = 1;
			} else {
				defaultMode = 1;
				altMode = 0;
			}
			this._activeRenderMode = defaultMode;
			this._sessionDisposables.add(
				ModifierKeyEmitter.getInstance().event(e => {
					if (!this._editor.hasModel()) {
						return;
					}
					const newRenderMode = e.altKey && e.ctrlKey && !(e.shiftKey || e.metaKey) ? altMode : defaultMode;
					if (newRenderMode !== this._activeRenderMode) {
						this._activeRenderMode = newRenderMode;
						const model2 = this._editor.getModel();
						const copies = this._copyInlayHintsWithCurrentAnchor(model2);
						this._updateHintsDecorators([model2.getFullModelRange()], copies);
						scheduler.schedule(0);
					}
				})
			);
		}
		const cached = this._inlayHintsCache.get(model);
		if (cached) {
			this._updateHintsDecorators([model.getFullModelRange()], cached);
		}
		this._sessionDisposables.add(
			toDisposable(() => {
				if (!model.isDisposed()) {
					this._cacheHintsForFastRestore(model);
				}
			})
		);
		let cts;
		const watchedProviders = new Set();
		const scheduler = new RunOnceScheduler(async () => {
			const t1 = Date.now();
			cts?.dispose(true);
			cts = new CancellationTokenSource();
			const listener = model.onWillDispose(() => cts?.cancel());
			try {
				const myToken = cts.token;
				const inlayHints = await InlayHintsFragments.create(
					this._languageFeaturesService.inlayHintsProvider,
					model,
					this._getHintsRanges(),
					myToken
				);
				scheduler.delay = this._debounceInfo.update(model, Date.now() - t1);
				if (myToken.isCancellationRequested) {
					inlayHints.dispose();
					return;
				}
				for (const provider of inlayHints.provider) {
					if (typeof provider.onDidChangeInlayHints === 'function' && !watchedProviders.has(provider)) {
						watchedProviders.add(provider);
						this._sessionDisposables.add(
							provider.onDidChangeInlayHints(() => {
								if (!scheduler.isScheduled()) {
									scheduler.schedule();
								}
							})
						);
					}
				}
				this._sessionDisposables.add(inlayHints);
				this._updateHintsDecorators(inlayHints.ranges, inlayHints.items);
				this._cacheHintsForFastRestore(model);
			} catch (err) {
				onUnexpectedError(err);
			} finally {
				cts.dispose();
				listener.dispose();
			}
		}, this._debounceInfo.get(model));
		this._sessionDisposables.add(scheduler);
		this._sessionDisposables.add(toDisposable(() => cts?.dispose(true)));
		scheduler.schedule(0);
		this._sessionDisposables.add(
			this._editor.onDidScrollChange(e => {
				if (e.scrollTopChanged || !scheduler.isScheduled()) {
					scheduler.schedule();
				}
			})
		);
		this._sessionDisposables.add(
			this._editor.onDidChangeModelContent(e => {
				cts?.cancel();
				const delay = Math.max(scheduler.delay, 1250);
				scheduler.schedule(delay);
			})
		);
		this._sessionDisposables.add(this._installDblClickGesture(() => scheduler.schedule(0)));
		this._sessionDisposables.add(this._installLinkGesture());
		this._sessionDisposables.add(this._installContextMenu());
	}
	_installLinkGesture() {
		const store = new DisposableStore();
		const gesture = store.add(new ClickLinkGesture(this._editor));
		const sessionStore = new DisposableStore();
		store.add(sessionStore);
		store.add(
			gesture.onMouseMoveOrRelevantKeyDown(e => {
				const [mouseEvent] = e;
				const labelPart = this._getInlayHintLabelPart(mouseEvent);
				const model = this._editor.getModel();
				if (!labelPart || !model) {
					sessionStore.clear();
					return;
				}
				const cts = new CancellationTokenSource();
				sessionStore.add(toDisposable(() => cts.dispose(true)));
				labelPart.item.resolve(cts.token);
				this._activeInlayHintPart =
					labelPart.part.command || labelPart.part.location
						? new ActiveInlayHintInfo(labelPart, mouseEvent.hasTriggerModifier)
						: undefined;
				const lineNumber = model.validatePosition(labelPart.item.hint.position).lineNumber;
				const range2 = new Range(lineNumber, 1, lineNumber, model.getLineMaxColumn(lineNumber));
				const lineHints = this._getInlineHintsForRange(range2);
				this._updateHintsDecorators([range2], lineHints);
				sessionStore.add(
					toDisposable(() => {
						this._activeInlayHintPart = undefined;
						this._updateHintsDecorators([range2], lineHints);
					})
				);
			})
		);
		store.add(gesture.onCancel(() => sessionStore.clear()));
		store.add(
			gesture.onExecute(async e => {
				const label = this._getInlayHintLabelPart(e);
				if (label) {
					const part = label.part;
					if (part.location) {
						this._instaService.invokeFunction(goToDefinitionWithLocation, e, this._editor, part.location);
					} else {
						const e = part.command;
						if (!e || typeof e !== 'object' ? false : typeof e.id === 'string' && typeof e.title === 'string') {
							await this._invokeCommand(e, label.item);
						}
					}
				}
			})
		);
		return store;
	}
	_getInlineHintsForRange(range2) {
		const lineHints = new Set();
		for (const data of this._decorationsMetadata.values()) {
			if (range2.containsRange(data.item.anchor.range)) {
				lineHints.add(data.item);
			}
		}
		return Array.from(lineHints);
	}
	_installDblClickGesture(updateInlayHints) {
		return this._editor.onMouseUp(async e => {
			if (e.event.detail !== 2) {
				return;
			}
			const part = this._getInlayHintLabelPart(e);
			if (!part) {
				return;
			}
			e.event.preventDefault();
			await part.item.resolve(cancellationToken_none);
			if (isArrayAndHasLength(part.item.hint.textEdits)) {
				const edits = part.item.hint.textEdits.map(edit => EditOperation.replace(Range.lift(edit.range), edit.text));
				this._editor.executeEdits('inlayHint.default', edits);
				updateInlayHints();
			}
		});
	}
	_installContextMenu() {
		return this._editor.onContextMenu(async e => {
			if (!(e.event.target instanceof HTMLElement)) {
				return;
			}
			const part = this._getInlayHintLabelPart(e);
			if (part) {
				await this._instaService.invokeFunction(showGoToContextMenu, this._editor, e.event.target, part);
			}
		});
	}
	_getInlayHintLabelPart(e) {
		if (e.target.type !== 6) {
			return;
		}
		const options2 = e.target.detail.injectedText?.options;
		if (options2 instanceof ModelDecorationInjectedTextOptions && options2?.attachedData instanceof RenderedInlayHintLabelPart) {
			return options2.attachedData;
		}
		return;
	}
	async _invokeCommand(command, item) {
		try {
			await this._commandService.executeCommand(command.id, ...(command.arguments || []));
		} catch (err) {
			this._notificationService.notify({
				severity: Severity.Error,
				source: item.provider.displayName,
				message: err
			});
		}
	}
	_cacheHintsForFastRestore(model) {
		const hints = this._copyInlayHintsWithCurrentAnchor(model);
		this._inlayHintsCache.set(model, hints);
	} // return inlay hints but with an anchor that reflects "updates"
	// that happened after receiving them, e.g adding new lines before a hint
	_copyInlayHintsWithCurrentAnchor(model) {
		const items = new Map();
		for (const [id, obj] of this._decorationsMetadata) {
			if (items.has(obj.item)) {
				continue;
			}
			const range2 = model.getDecorationRange(id);
			if (range2) {
				const anchor = new InlayHintAnchor(range2, obj.item.anchor.direction);
				const copy = obj.item.with({ anchor });
				items.set(obj.item, copy);
			}
		}
		return Array.from(items.values());
	}
	_getHintsRanges() {
		const extra = 30;
		const model = this._editor.getModel();
		const visibleRanges = this._editor.getVisibleRangesPlusViewportAboveBelow();
		const result = [];
		for (const range2 of visibleRanges.sort(Range.compareRangesUsingStarts)) {
			const extendedRange = model.validateRange(
				new Range(range2.startLineNumber - extra, range2.startColumn, range2.endLineNumber + extra, range2.endColumn)
			);
			if (result.length === 0 || !Range.areIntersectingOrTouching(result[result.length - 1], extendedRange)) {
				result.push(extendedRange);
			} else {
				result[result.length - 1] = Range.plusRange(result[result.length - 1], extendedRange);
			}
		}
		return result;
	}
	_updateHintsDecorators(ranges, items) {
		const newDecorationsData = [];
		const addInjectedText = (item, ref, content, cursorStops, attachedData) => {
			const opts = {
				content,
				inlineClassNameAffectsLetterSpacing: true,
				inlineClassName: ref.className,
				cursorStops,
				attachedData
			};
			newDecorationsData.push({
				item,
				classNameRef: ref,
				decoration: {
					range: item.anchor.range,
					options: {
						// className: "rangeHighlight", // DEBUG highlight to see to what range a hint is attached
						description: 'InlayHint',
						showIfCollapsed: item.anchor.range.isEmpty(), // "original" range is empty
						collapseOnReplaceEdit: !item.anchor.range.isEmpty(),
						stickiness: 0,
						[item.anchor.direction]: this._activeRenderMode === 0 ? opts : undefined
					}
				}
			});
		};
		const addInjectedWhitespace = (item, isLast) => {
			const marginRule = this._ruleFactory.createClassNameRef({
				width: `${(fontSize / 3) | 0}px`,
				display: 'inline-block'
			});
			addInjectedText(item, marginRule, '\u200A', isLast ? InjectedTextCursorStops2.Right : InjectedTextCursorStops2.None);
		};
		const { fontSize, fontFamily, padding, isUniform } = this._getLayoutInfo();
		const fontFamilyVar = '--code-editorInlayHintsFontFamily';
		this._editor.getContainerDomNode().style.setProperty(fontFamilyVar, fontFamily);
		let currentLineInfo = { line: 0, totalLen: 0 };
		for (const item of items) {
			if (currentLineInfo.line !== item.anchor.range.startLineNumber) {
				currentLineInfo = {
					line: item.anchor.range.startLineNumber,
					totalLen: 0
				};
			}
			if (currentLineInfo.totalLen > InlayHintsController._MAX_LABEL_LEN) {
				continue;
			}
			if (item.hint.paddingLeft) {
				addInjectedWhitespace(item, false);
			}
			const parts = typeof item.hint.label === 'string' ? [{ label: item.hint.label }] : item.hint.label;
			for (let i = 0; i < parts.length; i++) {
				const part = parts[i];
				const isFirst = i === 0;
				const isLast = i === parts.length - 1;
				const cssProperties = {
					fontSize: `${fontSize}px`,
					fontFamily: `var(${fontFamilyVar}), ${defaultEditorFont_family}`,
					verticalAlign: isUniform ? 'baseline' : 'middle',
					unicodeBidi: 'isolate'
				};
				if (isArrayAndHasLength(item.hint.textEdits)) {
					cssProperties.cursor = 'default';
				}
				this._fillInColors(cssProperties, item.hint);
				if (
					(part.command || part.location) &&
					this._activeInlayHintPart?.part.item === item &&
					this._activeInlayHintPart.part.index === i
				) {
					cssProperties.textDecoration = 'underline';
					if (this._activeInlayHintPart.hasTriggerModifier) {
						cssProperties.color = {
							id: colorId_linkActive_foreground
						};
						cssProperties.cursor = 'pointer';
					}
				}
				if (padding) {
					if (isFirst && isLast) {
						cssProperties.padding = `1px ${Math.max(1, fontSize / 4) | 0}px`;
						cssProperties.borderRadius = `${(fontSize / 4) | 0}px`;
					} else if (isFirst) {
						cssProperties.padding = `1px 0 1px ${Math.max(1, fontSize / 4) | 0}px`;
						cssProperties.borderRadius = `${(fontSize / 4) | 0}px 0 0 ${(fontSize / 4) | 0}px`;
					} else if (isLast) {
						cssProperties.padding = `1px ${Math.max(1, fontSize / 4) | 0}px 1px 0`;
						cssProperties.borderRadius = `0 ${(fontSize / 4) | 0}px ${(fontSize / 4) | 0}px 0`;
					} else {
						cssProperties.padding = `1px 0 1px 0`;
					}
				}
				let textlabel = part.label;
				currentLineInfo.totalLen += textlabel.length;
				let tooLong = false;
				const over = currentLineInfo.totalLen - InlayHintsController._MAX_LABEL_LEN;
				if (over > 0) {
					textlabel = textlabel.slice(0, -over) + '\u2026';
					tooLong = true;
				}
				addInjectedText(
					item,
					this._ruleFactory.createClassNameRef(cssProperties),
					fixSpace(textlabel),
					isLast && !item.hint.paddingRight ? InjectedTextCursorStops2.Right : InjectedTextCursorStops2.None,
					new RenderedInlayHintLabelPart(item, i)
				);
				if (tooLong) {
					break;
				}
			}
			if (item.hint.paddingRight) {
				addInjectedWhitespace(item, true);
			}
			if (newDecorationsData.length > InlayHintsController._MAX_DECORATORS) {
				break;
			}
		}
		const decorationIdsToReplace = [];
		for (const [id, metadata] of this._decorationsMetadata) {
			const range2 = this._editor.getModel()?.getDecorationRange(id);
			if (range2 && ranges.some(r => r.containsRange(range2))) {
				decorationIdsToReplace.push(id);
				metadata.classNameRef.dispose();
				this._decorationsMetadata.delete(id);
			}
		}
		const scrollState = StableEditorScrollState.capture(this._editor);
		this._editor.changeDecorations(accessor => {
			const newDecorationIds = accessor.deltaDecorations(
				decorationIdsToReplace,
				newDecorationsData.map(d => d.decoration)
			);
			for (let i = 0; i < newDecorationIds.length; i++) {
				const data = newDecorationsData[i];
				this._decorationsMetadata.set(newDecorationIds[i], data);
			}
		});
		scrollState.restore(this._editor);
	}
	_fillInColors(props, hint) {
		if (
			2 === hint.kind //Parameter
		) {
			props.backgroundColor = {
				id: colorId_inlayHintParameter_backgroud
			};
			props.color = { id: colorId_inlayHintParameter_foreground };
		} else if (
			1 === hint.kind //Type
		) {
			props.backgroundColor = { id: colorId_inlayHintType_backgroud };
			props.color = { id: colorId_inlayHintType_foreground };
		} else {
			props.backgroundColor = { id: colorId_inlayHint_backgroud };
			props.color = { id: colorId_inlayHint_foreground };
		}
	}
	_getLayoutInfo() {
		const options2 = this._editor.getOption(
			141 // inlayHints
		);
		const padding = options2.padding;
		const editorFontSize = this._editor.getOption(
			52 // fontSize
		);
		const editorFontFamily = this._editor.getOption(
			49 // fontFamily
		);
		let fontSize = options2.fontSize;
		if (!fontSize || fontSize < 5 || fontSize > editorFontSize) {
			fontSize = editorFontSize;
		}
		const fontFamily = options2.fontFamily || editorFontFamily;
		const isUniform = !padding && fontFamily === editorFontFamily && fontSize === editorFontSize;
		return { fontSize, fontFamily, padding, isUniform };
	}
	_removeAllDecorations() {
		this._editor.removeDecorations(Array.from(this._decorationsMetadata.keys()));
		for (const obj of this._decorationsMetadata.values()) {
			obj.classNameRef.dispose();
		}
		this._decorationsMetadata.clear();
	}
}
InlayHintsController.ID = 'editor.contrib.InlayHints';
InlayHintsController._MAX_DECORATORS = 1500;
InlayHintsController._MAX_LABEL_LEN = 43;
__decorate(
	[
		__param(1, ILanguageFeaturesService),
		__param(2, ILanguageFeatureDebounceService),
		__param(3, IInlayHintsCache),
		__param(4, ICommandService),
		__param(5, INotificationService),
		__param(6, IInstantiationService)
	],
	InlayHintsController
);
registerEditorContribution(
	InlayHintsController.ID,
	InlayHintsController,
	1 //AfterFirstRender
);
function fixSpace(str) {
	const noBreakWhitespace2 = '\xA0';
	return str.replace(/[ \t]/g, noBreakWhitespace2);
}
commandsRegistry.registerCommand('_executeInlayHintProvider', async (accessor, uri, range) => {
	if (URI.isUri(uri) && Range.isIRange(range)) {
		const { inlayHintsProvider } = accessor.get(ILanguageFeaturesService);
		const ref = await accessor.get(ITextModelService).createModelReference(uri);
		try {
			const model = await InlayHintsFragments.create(
				inlayHintsProvider,
				ref.object.textEditorModel,
				[Range.lift(range)],
				cancellationToken_none
			);
			const result = model.items.map(e => e.hint);
			setTimeout(model.dispose);
			return result;
		} finally {
			ref.dispose();
		}
	}
});

// node_modules/monaco-editor/esm/vs/editor/contrib/inlayHints/browser/inlayHintsHover.js

class InlayHintsHoverAnchor extends HoverForeignElementAnchor {
	constructor(part, owner, initialMousePosX, initialMousePosY) {
		super(10, owner, part.item.anchor.range, initialMousePosX, initialMousePosY, true);
		this.part = part;
	}
}
class InlayHintsHover extends MarkdownHoverParticipant {
	constructor(
		editor2,
		languageService,
		openerService,
		keybindingService,
		hoverService,
		configurationService,
		_resolverService,
		languageFeaturesService
	) {
		super(editor2, languageService, openerService, configurationService, languageFeaturesService, keybindingService, hoverService);
		this._resolverService = _resolverService;
		this.hoverOrdinal = 6;
	}
	suggestHoverAnchor(mouseEvent) {
		const controller = InlayHintsController.get(this._editor);
		if (!controller) {
			return null;
		}
		if (mouseEvent.target.type !== 6) {
			return null;
		}
		const options2 = mouseEvent.target.detail.injectedText?.options;
		if (!(options2 instanceof ModelDecorationInjectedTextOptions && options2.attachedData instanceof RenderedInlayHintLabelPart)) {
			return null;
		}
		return new InlayHintsHoverAnchor(options2.attachedData, this, mouseEvent.event.posx, mouseEvent.event.posy);
	}
	computeSync() {
		return [];
	}
	computeAsync(anchor, _lineDecorations, token) {
		if (!(anchor instanceof InlayHintsHoverAnchor)) {
			return AsyncIterableObject.EMPTY;
		}
		return new AsyncIterableObject(async executor => {
			const { part } = anchor;
			await part.item.resolve(token);
			if (token.isCancellationRequested) {
				return;
			}
			let itemTooltip;
			if (typeof part.item.hint.tooltip === 'string') {
				itemTooltip = new MarkdownString().appendText(part.item.hint.tooltip);
			} else if (part.item.hint.tooltip) {
				itemTooltip = part.item.hint.tooltip;
			}
			if (itemTooltip) {
				executor.emitOne(new MarkdownHover(this, anchor.range, [itemTooltip], false, 0));
			}
			if (isArrayAndHasLength(part.item.hint.textEdits)) {
				executor.emitOne(
					new MarkdownHover(
						this,
						anchor.range,
						[new MarkdownString().appendText(localize('Double-click to insert'))],
						false,
						10001
					)
				);
			}
			let partTooltip;
			if (typeof part.part.tooltip === 'string') {
				partTooltip = new MarkdownString().appendText(part.part.tooltip);
			} else if (part.part.tooltip) {
				partTooltip = part.part.tooltip;
			}
			if (partTooltip) {
				executor.emitOne(new MarkdownHover(this, anchor.range, [partTooltip], false, 1));
			}
			if (part.part.location || part.part.command) {
				let linkHint;
				const useMetaKey =
					this._editor.getOption(
						78 // multiCursorModifier
					) === 'altKey';
				const kb = useMetaKey
					? isMacintosh
						? localize('cmd + click')
						: localize('ctrl + click')
					: isMacintosh
						? localize('option + click')
						: localize('alt + click');
				if (part.part.location && part.part.command) {
					linkHint = new MarkdownString().appendText(localize(kb));
				} else if (part.part.location) {
					linkHint = new MarkdownString().appendText(localize(kb));
				} else if (part.part.command) {
					linkHint = new MarkdownString(
						`[${localize('Execute Command')}](${asCommandLink(part.part.command)} "${part.part.command.title}") (${kb})`,
						{ isTrusted: true }
					);
				}
				if (linkHint) {
					executor.emitOne(new MarkdownHover(this, anchor.range, [linkHint], false, 1e4));
				}
			}
			const iterable = await this._resolveInlayHintLabelPartHover(part, token);
			for await (const item of iterable) {
				executor.emitOne(item);
			}
		});
	}
	async _resolveInlayHintLabelPartHover(part, token) {
		if (!part.part.location) {
			return AsyncIterableObject.EMPTY;
		}
		const { uri, range: range2 } = part.part.location;
		const ref = await this._resolverService.createModelReference(uri);
		try {
			const model = ref.object.textEditorModel;
			if (!this._languageFeaturesService.hoverProvider.has(model)) {
				return AsyncIterableObject.EMPTY;
			}
			return getHoverProviderResultsAsAsyncIterable(
				this._languageFeaturesService.hoverProvider,
				model,
				new Position(range2.startLineNumber, range2.startColumn),
				token
			)
				.filter(item => !isEmptyMarkdownString(item.hover.contents))
				.map(item => new MarkdownHover(this, part.item.anchor.range, item.hover.contents, false, 2 + item.ordinal));
		} finally {
			ref.dispose();
		}
	}
}
__decorate(
	[
		__param(1, ILanguageService),
		__param(2, IOpenerService),
		__param(3, IKeybindingService),
		__param(4, IHoverService),
		__param(5, IConfigurationService),
		__param(6, ITextModelService),
		__param(7, ILanguageFeaturesService)
	],
	InlayHintsHover
);
hoverParticipantRegistry.register(InlayHintsHover);


// node_modules/monaco-editor/esm/vs/editor/contrib/inlayHints/browser/inlayHints.js

class InlayHintAnchor {
	constructor(range2, direction) {
		this.range = range2;
		this.direction = direction;
	}
}
class InlayHintItem {
	constructor(hint, anchor, provider) {
		this.hint = hint;
		this.anchor = anchor;
		this.provider = provider;
		this._isResolved = false;
	}
	with(delta) {
		const result = new InlayHintItem(this.hint, delta.anchor, this.provider);
		result._isResolved = this._isResolved;
		result._currentResolve = this._currentResolve;
		return result;
	}
	async resolve(token) {
		if (typeof this.provider.resolveInlayHint !== 'function') {
			return;
		}
		if (this._currentResolve) {
			await this._currentResolve;
			if (token.isCancellationRequested) {
				return;
			}
			return this.resolve(token);
		}
		if (!this._isResolved) {
			this._currentResolve = this._doResolve(token).finally(() => (this._currentResolve = undefined));
		}
		await this._currentResolve;
	}
	async _doResolve(token) {
		try {
			const newHint = await Promise.resolve(this.provider.resolveInlayHint(this.hint, token));
			this.hint.tooltip = newHint?.tooltip ?? this.hint.tooltip;
			this.hint.label = newHint?.label ?? this.hint.label;
			this.hint.textEdits = newHint?.textEdits ?? this.hint.textEdits;
			this._isResolved = true;
		} catch (err) {
			onUnexpectedExternalError(err);
			this._isResolved = false;
		}
	}
}
class InlayHintsFragments {
	static async create(registry, model, ranges, token) {
		const data = [];
		const promises = registry
			.ordered(model)
			.reverse()
			.map(provider =>
				ranges.map(async range2 => {
					try {
						const result = await provider.provideInlayHints(model, range2, token);
						if (result?.hints.length || provider.onDidChangeInlayHints) {
							data.push([
								result !== null && result !== undefined ? result : InlayHintsFragments._emptyInlayHintList,
								provider
							]);
						}
					} catch (err) {
						onUnexpectedExternalError(err);
					}
				})
			);
		await Promise.all(promises.flat());
		if (token.isCancellationRequested || model.isDisposed()) {
			throw new CancellationError();
		}
		return new InlayHintsFragments(ranges, data, model);
	}
	constructor(ranges, data, model) {
		this._disposables = new DisposableStore();
		this.ranges = ranges;
		this.provider = new Set();
		const items = [];
		for (const [list, provider] of data) {
			this._disposables.add(list);
			this.provider.add(provider);
			for (const hint of list.hints) {
				const position = model.validatePosition(hint.position);
				let direction = 'before';
				const wordRange = InlayHintsFragments._getRangeAtPosition(model, position);
				let range2;
				if (wordRange.getStartPosition().isBefore(position)) {
					range2 = Range.fromPositions(wordRange.getStartPosition(), position);
					direction = 'after';
				} else {
					range2 = Range.fromPositions(position, wordRange.getEndPosition());
					direction = 'before';
				}
				items.push(new InlayHintItem(hint, new InlayHintAnchor(range2, direction), provider));
			}
		}
		this.items = items.sort((a, b) => Position.compare(a.hint.position, b.hint.position));
	}
	dispose() {
		this._disposables.dispose();
	}
	static _getRangeAtPosition(model, position) {
		const line = position.lineNumber;
		const word = model.getWordAtPosition(position);
		if (word) {
			return new Range(line, word.startColumn, line, word.endColumn);
		}
		model.tokenization.tokenizeIfCheap(line);
		const tokens = model.tokenization.getLineTokens(line);
		const offset = position.column - 1;
		const idx = tokens.findTokenIndexAtOffset(offset);
		let start = tokens.getStartOffset(idx);
		let end = tokens.getEndOffset(idx);
		if (end - start === 1) {
			if (start === offset && idx > 1) {
				start = tokens.getStartOffset(idx - 1);
				end = tokens.getEndOffset(idx - 1);
			} else if (end === offset && idx < tokens.getCount() - 1) {
				start = tokens.getStartOffset(idx + 1);
				end = tokens.getEndOffset(idx + 1);
			}
		}
		return new Range(line, start + 1, line, end + 1);
	}
}
InlayHintsFragments._emptyInlayHintList = freeze({ dispose() {}, hints: [] });
function asCommandLink(command) {
	return URI.from({
		scheme: Schemas.command,
		path: command.id,
		query: command.arguments && encodeURIComponent(JSON.stringify(command.arguments))
	}).toString();
}