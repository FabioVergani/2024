


class EditorZoom {
	constructor() {
		this._zoomLevel = 0;
		this._onDidChangeZoomLevel = new Emitter();
		this.onDidChangeZoomLevel = this._onDidChangeZoomLevel.event;
	}
	getZoomLevel() {
		return this._zoomLevel;
	}
	setZoomLevel(zoomLevel) {
		zoomLevel = Math.min(Math.max(-5, zoomLevel), 20);
		if (this._zoomLevel === zoomLevel) {
			return;
		}
		this._zoomLevel = zoomLevel;
		this._onDidChangeZoomLevel.fire(this._zoomLevel);
	}
}
const editorZoom = new EditorZoom();

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// EditorConfiguration
this._register(editorZoom.onDidChangeZoomLevel(() => this._recomputeOptions()));








//MouseHandler

	_setupMouseWheelZoomListener() {
		const classifier = MouseWheelClassifier.INSTANCE;
		let prevMouseWheelTime = 0;
		let gestureStartZoomLevel = editorZoom.getZoomLevel();
		let gestureHasZoomModifiers = false;
		let gestureAccumulatedDelta = 0;
		const onMouseWheel = browserEvent => {
			this.viewController.emitMouseWheel(browserEvent);
			if (
				!this._context.configuration.options.get(
					76 // mouseWheelZoom
				)
			) {
				return;
			}
			const e = new StandardWheelEvent(browserEvent);
			classifier.acceptStandardWheelEvent(e);
			if (classifier.isPhysicalMouseWheel()) {
				if (hasMouseWheelZoomModifiers(browserEvent)) {
					const zoomLevel = editorZoom.getZoomLevel();
					const delta = e.deltaY > 0 ? 1 : -1;
					editorZoom.setZoomLevel(zoomLevel + delta);
					e.preventDefault();
					e.stopPropagation();
				}
			} else {
				if (Date.now() - prevMouseWheelTime > 50) {
					gestureStartZoomLevel = editorZoom.getZoomLevel();
					gestureHasZoomModifiers = hasMouseWheelZoomModifiers(browserEvent);
					gestureAccumulatedDelta = 0;
				}
				prevMouseWheelTime = Date.now();
				gestureAccumulatedDelta += e.deltaY;
				if (gestureHasZoomModifiers) {
					editorZoom.setZoomLevel(gestureStartZoomLevel + gestureAccumulatedDelta / 5);
					e.preventDefault();
					e.stopPropagation();
				}
			}
		};
		this._register(
			addDisposableListener(this.viewHelper.viewDomNode, EventType.MOUSE_WHEEL, onMouseWheel, {
				capture: true,
				passive: false
			})
		);
		function hasMouseWheelZoomModifiers(browserEvent) {
			return isMacintosh ? (browserEvent.metaKey || browserEvent.ctrlKey) && !browserEvent.shiftKey && !browserEvent.altKey : browserEvent.ctrlKey && !browserEvent.metaKey && !browserEvent.shiftKey && !browserEvent.altKey;
		}
	}

	// const editorZoomLevelMultiplier = 1 + (ignoreEditorZoom ? 0 : editorZoom.getZoomLevel() * 0.1);