/*
		typescript: {
			typescriptVersion: '5.0.2',
			typescriptDefaults,
			javascriptDefaults,
			getTypeScriptWorker: () => getMode_ts().then(e => e.getTypeScriptWorker()),
			getJavaScriptWorker: () => getMode_ts().then(e => e.getJavaScriptWorker()),
			JsxEmit: {
				None: 0,
				Preserve: 1,
				React: 2,
				ReactNative: 3,
				ReactJSX: 4,
				ReactJSXDev: 5,
				0: 'None',
				1: 'Preserve',
				2: 'React',
				3: 'ReactNative',
				4: 'ReactJSX',
				5: 'ReactJSXDev'
			},
			NewLineKind: {
				CarriageReturnLineFeed: 0,
				LineFeed: 1,
				0: 'CarriageReturnLineFeed',
				1: 'LineFeed'
			},
			ScriptTarget: {
				ES3: 0,
				ES5: 1,
				ES2015: 2,
				ES2016: 3,
				ES2017: 4,
				ES2018: 5,
				ES2019: 6,
				ES2020: 7,
				ESNext: 99,
				JSON: 100,
				Latest: 99,
				0: 'ES3',
				1: 'ES5',
				2: 'ES2015',
				3: 'ES2016',
				4: 'ES2017',
				5: 'ES2018',
				6: 'ES2019',
				7: 'ES2020',
				99: 'Latest', // 'ESNext' will be overwritten by 'Latest'
				100: 'JSON'
			},
			ModuleResolutionKind: {
				Classic: 1,
				NodeJs: 2,
				1: 'Classic',
				2: 'NodeJs'
			},
			ModuleKind: {
				None: 0,
				CommonJS: 1,
				AMD: 2,
				UMD: 3,
				System: 4,
				ES2015: 5,
				ESNext: 99,
				0: 'None',
				1: 'CommonJS',
				2: 'AMD',
				3: 'UMD',
				4: 'System',
				5: 'ES2015',
				99: 'ESNext'
			}
		}
*/

const typescriptDefaults = new LanguageServiceDefaults_js(
	{
		allowNonTsExtensions: true,
		target: 99 //Latest
	},
	{
		noSemanticValidation: false,
		noSyntaxValidation: false,
		onlyVisible: false
	},
	{},
	{},
	modeConfigurationJsDefault
);

let typeScriptWorker;
function setupTypeScript(e) {
	typeScriptWorker = setupMode4(e, 'typescript');
}
function getTypeScriptWorker() {
	return new Promise((resolve, reject) => {
		if (!typeScriptWorker) {
			return reject('TypeScript not registered!');
		}
		resolve(typeScriptWorker);
	});
}



// node_modules/monaco-editor/esm/vs/language/typescript/monaco.contribution.js
function getMode_ts() {
	const tsMode_exports = {
		Adapter: AdapterTS,
		CodeActionAdaptor: CodeActionAdaptorTS,
		DefinitionAdapter: DefinitionAdapterTS,
		DiagnosticsAdapter: DiagnosticsAdapterTS,
		DocumentHighlightAdapter: DocumentHighlightAdapterTS,
		FormatAdapter: FormatAdapterTS,
		FormatHelper: FormatHelperTS,
		FormatOnTypeAdapter: FormatOnTypeAdapterTS,
		InlayHintsAdapter: InlayHintsAdapterTS,
		Kind: KindTS,
		LibFiles: LibFilesTS,
		OutlineAdapter: OutlineAdapterTS,
		QuickInfoAdapter: QuickInfoAdapterTS,
		ReferenceAdapter: ReferenceAdapterTS,
		RenameAdapter: RenameAdapterTS,
		SignatureHelpAdapter: SignatureHelpAdapterTS,
		SuggestAdapter: SuggestAdapterTS,
		WorkerManager: WorkerManagerTS,
		flattenDiagnosticMessageText: flattenDiagnosticMessageText,
		getJavaScriptWorker: getJavaScriptWorker,
		getTypeScriptWorker: getTypeScriptWorker,
		setupJavaScript: setupJavaScript,
		setupTypeScript: setupTypeScript
	};
	return Promise.resolve().then(() => tsMode_exports);
}
